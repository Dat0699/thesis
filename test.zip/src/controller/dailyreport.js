const DailyReportCtrl = {};

DailyReportCtrl.exportDailyReport = async function (Req, pipeData) {
	const A = pipeData.A;
	const K = pipeData.K;
	const Excel = K.Excel.Vendor.Excel || {};

	// const workbook = Excel.readFile("./src/resource/test.xlsx");

	// const worksheet = workbook.Sheets["Sheet1"]


	// const data = Excel.utils.sheet_to_json(worksheet)

	

	// return Req.body;


/*
	const dataJson = [{
		"id": "0001",
		"type": "donut",
		"name": "Cake",
		"ppu": 0.55,
		"batter":
				[
					{ "id": "1001", "type": "Regular" },
					{ "id": "1002", "type": "Chocolate" },
				]
		,
		"topping":
				[
					{ "id": "5001", "type": "None" },
					{ "id": "5002", "type": "Glazed" },
				]
	},
	{
		"id": "0002",
		"type": "donut2",
		"name": "Cake2",
		"ppu": 0.1,
		"batters":
				[
					{ "id": "1003", "type": "Regular2" },
					{ "id": "1004", "type": "Chocolate2" },
				]
		,
		"topping":
				[
					{ "id": "5003", "type": "None2" },
					{ "id": "5004", "type": "Glazed2" },
				]
	}]

	const filtered = dataJson.map(obj => {
		const {
			batters,
			topping,
			...rest
		} = obj;
	
		batters.map(c => {
			rest[c['id']] = c.type;
			
		});
	
		return {...rest,
			batters,
			topping,
		};
	});

	const ws = Excel.utils.json_to_sheet(filtered)
	const wb = Excel.utils.book_new();


	Excel.utils.book_append_sheet(wb, ws, "Sheet1")
	Excel.write(wb, { bookType: "xlsx", type: "buffer" });
	Excel.write(wb, { bookType: "xlsx", type: "binary" });
	Excel.writeFile(wb, "./src/resource/arrObject2.xlsx");


	return Req.body;


*/

const data = [{
	Sno: 1,
	Team: 'India',
	Match: 8,
	Win: 7,
	Loss: 0,
	Cancel: 1,
  },
  {
	Sno: 2,
	Team: 'NewZeland',
	Match: 8,
	Win: 6,
	Loss: 1,
	Cancel: 1,
  },
  {
	Sno: '3',
	Team: 'Aus',
	Match: 8,
	Win: 6,
	Loss: 1,
	Cancel: 1,
  },
  {
	Sno: '4',
	Team: 'England',
	Match: 8,
	Win: 5,
	Loss: 2,
	Cancel: 1,
  },
  {
	Sno: '5',
	Team: 'S.Africa',
	Match: 8,
	Win: 4,
	Loss: 3,
	Cancel: 1,
  },
  {
	Sno: '6',
	Team: 'Pak',
	Match: 8,
	Win: 4,
	Loss: 4,
	Cancel: 1,
  }]

  const ws = Excel.utils.json_to_sheet(data)
  for (var i in ws) {


	ws[i].s = {
	  font: {
		name: 'arial',
	  },
	  alignment: {
		vertical: 'center',
		horizontal: 'center',
		wrapText: '1',
	  },
	  border: {
		top: {
			style: 'thin',
			color: 'F8F8FF',
		  },
		right: {
		  style: 'thin',
		  color: 'F8F8FF',
		},
		bottom: {
			style: 'thin',
			color: 'F8F8FF',
		  },
		left: {
		  style: 'thin',
		  color: 'F8F8FF',
		},
		
	  },
	};
}
	const wb = Excel.utils.book_new();
    Excel.utils.book_append_sheet(wb, ws, 'Sheet1');
    Excel.writeFile(wb, './src/resource/style.xlsx');


}


DailyReportCtrl.addData = async function (Req, pipeData) {
	const A = pipeData.A;
	const K = pipeData.K;
	const Excel = K.Excel.Vendor.Excel || {};

	const workbook = Excel.readFile("./src/resource/test.xlsx");
	const worksheet = workbook.Sheets["Sheet1"]

	// const ws = Excel.utils.sheet_add_aoa(worksheet, [
	// 	[11, "ly so ly", 18 ],
	// 	[12, "ly so lee", 25]
	// ], { origin: -1 });

	const ws1 = Excel.utils.sheet_add_json(worksheet, [
		,
		,
		,
		,
		,
		,
		,
		,
		,
		,
		,
		,
		,

		{ id: 12, name: "Soo lee", age: 30 }

	], { headers: ["id", "name", "age"] })
	// const worksheet = Excel.utils.aoa_to_sheet([
	// 	["A1", "B1", "C1"],
	// 	["A2", "B2", "C2"],

	// 	["A3", "B3", "C3"]
	//   ]);			
	// const body = [
	// 	{
	// 		id:"7",
	// 		name:"ly",
	// 		age: "123435345"
	// 	},
	// ]

	// const ws = Excel.utils.json_to_sheet(body)

	let row = [
		{ v: "Courier: 24", t: "s", s: { font: { name: "Courier", sz: 24 } } },
		{ v: "bold & color", t: "s", s: { font: { bold: true, color: { rgb: "#ffffff" } } } },
		{ v: "fill: color", t: "s", s: { fill: { fgColor: { rgb: "E9E9E9" } } } },
		{ v: "line\nbreak", t: "s", s: { alignment: { wrapText: true } } },
	];
	
	
	const ws = Excel.utils.aoa_to_sheet([row]);
	Excel.utils.book_append_sheet(workbook, ws, "Styledemo");
	
	Excel.writeFile(workbook, "./src/resource/xlsx-js-style-demo.xlsx");
	Excel.utils.book_append_sheet(workbook, worksheet)
	Excel.writeFile(workbook, './src/resource/test.xlsx');

	return Req.body;
}


module.exports = DailyReportCtrl;