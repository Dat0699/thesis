const MailReminderCtrl = {};

MailReminderCtrl.config = {
	// second minute hour dayInWeek dayInMonth month year
	// *: means all range (*, */1, /1, 1/* are same)
	// a-b: means from a to b, example 1-3
	// a,b: means list of a and b, example 0-4
	// a-b/c: means looping from a to b and step is c, 1-8/3 -> 1,4,7
	// example * 1-5,10-15/3 * * * * * means 8 1,3,10,13 * * * * *
	
	cronjob: "* */1 * * * * *", // every 10 (by 60/6) minutes this cronjob will be called.
	// shell: "/var/gitgam/cronjob/run-script.sh", // is an example using script for cronjob, if ommited, cronjobStart wll be called.
	// shell: "bash /c/Users/Admin/gitgam/PMS-API-Server/tool/abc.sh"
};


MailReminderCtrl.cronjobStart = async function(Req, pipeData) {
	const A = pipeData.A;
	const K = pipeData.K;

	var now = (new Date()).getTime(); 
	var interval = Math.max(K.CronJob.Interval || 60, 60);

	var startDate = new Date(now - interval*1.5*1000);
	var endDate = new Date(now + interval*1000);

	// console.log('startDate', startDate);
	// console.log('endDate', endDate);

	const modelName = "Main.mailReminder";
	let response = await A.aggregateOne(Req, pipeData, modelName, [
		{ $match: { $expr: { $and: [
			{ $lte: ["$date", endDate] },
			{ $gte: ["$date", startDate] },
			{ $eq:  ["$status", 1] },
		]}}},

		{ $limit: 50 },
		{ $project: {
			title			    : 1,
			content			    : 1,
			listEmails		    : 1,
			date			    : 1,
			status		        : 1,
			refModel	        : 1,
			refNumber	        : 1,
			type				: 1,
			remindBefore		: 1

		}},
		{ $group: {
			_id: null,
			listMails: { $push: "$$ROOT" }
		}},
		{ $addFields: {
			listIds: "$listMails._id"
		}}
	]);

	console.log(`[CronJob] [${startDate.toISOString()} - ${endDate.toISOString()}] process data: `, response);
	if(response?.listIds?.length > 0) {
		Req.config.IgnoreSanitized = true;
		await A.deleteById(Req, pipeData, modelName, {_id: { $in: (response?.listIds || []) }}, true, true);

		var arrs = response?.listMails || [];
		for(let i = 0; i < arrs.length; i++) {
			try {
				let item = arrs[i] || {};
				console.log('item >>>>', item);
				if(item.status == 1) {
					await A.sendMail(Req, pipeData, {
						"to" 		: item.listEmails || [],
						"subject" 	: `[${item.refModel || ""}] have notification`,
						"view" 		: `${(item.refModel || "meeting")}ReminderView`,
						"data" 		: item
					});
				}
			} catch(e) { }
		}
	}
}

module.exports = MailReminderCtrl;