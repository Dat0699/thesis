// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const LabelModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId     : "A.isIdString",

        type          : "A.isEnum(all, task, testcase, risk, issuelog, helpdesk)",
        hasGlobal     : "A.isBoolean < false",

        name          : "A.isString",
		name2         : "A.isString",
		
        descr         : "A.isString",
        descrHTML     : "A.isString",

		color         : "A.isColor",
    },
};

module.exports = LabelModel;
