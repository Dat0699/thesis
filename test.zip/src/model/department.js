const DepartmentModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name				: "A.isString",
		name2				: "A.isString",

		//avt					: "A.isAvatar",
		//avt					: "A.isNumber < 0",
        descr				: "A.isString",
		members				: "A.isArrayIds < []",

		leaderId			: "A.isIdString",
        viceLeaderIds       : "A.isArrayIds",

		canMakeRequest		: "A.isBoolean < true",
		canResolveRequest	: "A.isBoolean < false",
    },
};

DepartmentModel.subKey = {
}

module.exports = DepartmentModel;
