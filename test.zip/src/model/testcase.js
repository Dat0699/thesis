// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const TestCaseModel = {
    priKeys: [
        //{"testCaseId": "text"},
    ],

    allKeys: [],

    validator: {
        number		: "A:autoIncrease(1, testcase, P.project._id)",
		colIndex    : "A.autoIncrease(100, testcase, P.project._id)",

        projectId   : "A.isIdString",
		featureId   	: "A.isIdString",

        title       : "A.isString",
		title2      : "A.isString",
        content     : "A.isString",
        condition	: "A.isString",
        result      : "A.isBoolean < false",

        priority    : "A.isEnum(1, 2, 3, 4, 5) < 2", // 1 -> Low, 2 -> Normal, 3 -> High, 4 -> Urgent, 5 -> Block

        groupId     : "A.isIdEmpty", // Group
        labelIds    : "A.isArrayIds < []",

		featureId		: "A.isIdEmpty",
		sprintId	: "A.isIdEmpty",
    },
};

module.exports = TestCaseModel;
