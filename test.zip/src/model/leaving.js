const LeavingModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		milestoneId		: "A.isIdEmpty",
		sprintId		: "A.isIdEmpty",
		featureId		: "A.isIdEmpty",

		number			: "A.autoIncrease",

        reason      	: "A.isString",
		reason2      	: "A.isString",

		startDate   	: "A.isDate",
        endDate     	: "A.isDate",

        //type        	: "A.isEnum(1, 2, 3, 4, 5, 6)",
		// 1 -> Annual Holiday, 2 -> Compension, 3 -> Payless Holiday, 4 -> Yearly Remaining, 5 -> Policy Holiday, 6 -> Other Holiday

		//type			: "A.isEnum(leaving, yearlyHoliday, rosteredByOT, rosteredByLegal) < leaving",
		//leavingType	: "A.isEnum(leaving, yearly, rostered, legal)",

		type			: "A.isEnum(sick, personal, holiday, legal, bonus) < sick",
		isBonus			: "A.isBoolean < false",
		refId			: "A.isIdString",

		year			: "A.isNumber",
		duration    	: "A.isNumber < 0", // count by day
		estDuration		: "A.isNumber < 0", // use for user input manual
		amount    		: "A.isNumber < 0", // total money

        attachIds   	: "A.isArrayIds < []",
        status	    	: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted
        approverIds		: "A.isArrayIds < []",

		informToIds   	: "A.isArrayIds < []",
		rejectedMessage	: "A.isString",
    },
};


LeavingModel.subKey = {
}

module.exports = LeavingModel;
