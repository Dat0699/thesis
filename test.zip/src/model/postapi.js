const PostAPIModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",
		serverId        : "A.isIdString", // mock server model
		groupId         : "A.isIdEmpty",
		featureId         : "A.isIdEmpty",

		number          : "A.autoIncrease(1, postapi, P.project._id)",
		colIndex        : "A.autoIncrease(100, postapi, P.project._id)",

        name            : "A.isString",
		name2           : "A.isString",

        url             : "A.isString",
        method          : "A.isString < GET",

		reqDoc          : "A.isString",
        reqHeader       : "A.isArray < []",
        reqQuery        : "A.isArray < []",
        reqBody         : "A.isObject < {}",
		reqPreScript    : "A.isObject < {}",

        resHeader       : "A.isObject < {}",
        resBody         : "A.isObject < {}",
		resPostScript   : "A.isObject < {}",

		resStatusText   : "A.isString",
        resStatus       : "A.isNumber",
        resTime         : "A.isNumber",
        resSize         : "A.isNumber",
    },
};

const keyValue = {
    key     : "A.isString",
    value   : "A.isString",
	checked	: "A.isBoolean < false",
	required: "A.isBoolean < false",
}

const body = {
    type    : "A.isEnum(json, xml, formdata, xform, string, text, preview, raw) < formdata",
    value   : "A.isAnyWithSize(2097152)", // 2 * 1024 * 1024
	required: "A.isBoolean < false",
}

const script = {
    type    : "A.isEnum(js, bash) < js",
    value   : "A.isString"
}

const doc = {
    title   : "A.isString",
    content : "A.isString"
}

const postAPIData = {
	//reqDoc      	: {...doc},
    reqHeader   	: [{...keyValue}],
    reqQuery    	: [{...keyValue}],
	reqBody     	: {...body},
	reqPreScript	: {...script},

    resHeader   	: { "*": "A.isString"},
	resBody     	: {...body},
	resPostScript	: {...script},
}

PostAPIModel.subKey = {
	...postAPIData,
}

module.exports = PostAPIModel;
