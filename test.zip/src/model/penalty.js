const PenaltyModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId		: "A.isIdString",
		taskId			: "A.isIdString",

		number			: "A.autoIncrease(1, penalty, P.project._id)",
		members			: "A.isArrayIds",

		point			: "A.isNumber < 5",
		date			: "A.isDate",

		reason			: "A.isString",
		reason2			: "A.isString",

		attachIds		: "A.isArrayIds < []",

		status			: "A.isStatus < 1",
		rejectedMessage	: "A.isString",
    },
};

PenaltyModel.subKey = {
}

module.exports = PenaltyModel;
