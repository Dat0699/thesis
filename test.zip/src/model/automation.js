const AutomationModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId	: "A.isIdString",
		featureId		: "A.isIdString",

		name		: "A.isString",
		name2		: "A.isString",

		script		: "A.isString",
		type		: "A.isEnum(js, bash)",

		status		: "A.isEnum(1, 2, 3, 4)", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted, 6 for completed, 7 for running
    },
};

AutomationModel.subKey = {
}

module.exports = AutomationModel;
