const CommentModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        referenceId     : "A.isIdString",
        comments        : "A.isArray < []",
		['__{{key}}__']	: "A.isIdString",
    },

	template: [
		{ name: "wikicomment",		key: "projectId", keyUserId: "",			keyUserName: ""  },
		{ name: "taskcomment",		key: "projectId", keyUserId: "",			keyUserName: ""  },
		{ name: "riskcomment",		key: "projectId", keyUserId: "",			keyUserName: ""  },
		{ name: "helpdeskcomment",	key: "",		  keyUserId: "",			keyUserName: ""  },
		{ name: "reportbugcomment",	key: "", 		  keyUserId: "publicUserId",keyUserName: ""  },
		{ name: "tutorialcomment",	key: "", 		  keyUserId: "publicUserId",keyUserName: "publicUserName"  }
	]
};

var comment = {
    _id          : "A.autoId",
    creatorId    : "A.isRef(P.user._id)",
    createdAt    : "A.isNow",
    modifiedAt   : "A.isNow",
    descr        : "A.isString",
	descrHTML    : "A.isString",
    isChild      : "A.isBoolean < false",
    parentId     : "A.isIdString",

	// Use for reportbugcomment collect userId for public display
	['__{{keyUserId}}__'] : "A.isRef(P.user.userId)",
	['__{{keyUserName}}__'] : "A.isRef(P.user.name)",
}

CommentModel.subKey = {
    comments: [{...comment}],
}

module.exports = CommentModel;
