const AssetModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        number		: "A:autoIncrease(1, warehouse)",
		shortName	: "A.isShortName",
		type		: "A.isEnum(0, 1, 2, 3, 4) < 1", // 0 for broken product, 1 for warehouse company, 2 for material, 3 product, 4 for store/shop

		code		: "A.isString",
		color		: "A.isString",

        name		: "A.isString",
		name2		: "A.isString",
		descr		: "A.isString",

		importers	: "A.isArray < []",
		exporters	: "A.isArray < []",
		auditors	: "A.isArray < []",
		reporters	: "A.isArray < []",
		admins		: "A.isArray < []",

		status		: "A.isEnum(0, 1, 4, 6) < 1", // 0 for locked, 1 for free and good, 2 for issuing, 3 for broken, 4 for repairing/maintaining
    },
};

AssetModel.subKey = {
}

module.exports = AssetModel;
