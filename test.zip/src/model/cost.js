// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const CostModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		number			: "A:autoIncrease(1, cost, P.project._id)",

        projectId		: "A.isIdString",
        milestoneId     : "A.isIdEmpty",
        sprintId        : "A.isIdEmpty",
        featureId       : "A.isIdEmpty",
		taskId      	: "A.isIdString",

        type        	: "A.isString", // statistic type,
		date			: "A.isDate",

        name	       	: "A.isString",
		name2       	: "A.isString",

        descrHTML   	: "A.isString",

        amount      	: "A.isNumber < 0",
        assignId    	: "A.isIdString",

		labelIds		: "A.isIdString",
		status			: "A.isStatus < 1",

		rejectedMessage	: "A.isString",
    },
};

module.exports = CostModel;
