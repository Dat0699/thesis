const WorkingholidayModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        title : "A.isString",
        type  : "A.isEnum(1, 2)", // 1 -> Holiday, 2 -> Make-up Workday
        date  : "A.isDate"
    },
};

WorkingholidayModel.subKey = {
}

module.exports = WorkingholidayModel;
