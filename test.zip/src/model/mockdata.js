const MockDataModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",
		serverId		: "A.isIdString",

		number          : "A.autoIncrease(1, mockdata, P.project._id)",
		colIndex    	: "A.autoIncrease(100, mockdata, P.project._id)",

        name            : "A.isString",
		name2           : "A.isString",

        content         : "A.isString",
    },
};

module.exports = MockDataModel;
