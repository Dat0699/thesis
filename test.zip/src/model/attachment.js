// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const AttachmentModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId		: "A.isIdString",

        type			: "A.isEnum(1,2,3,4,5,6)", // 1: avatar, 2: attach, 3: public, 4: document, 5: sercurity, 6: private

        name			: "A.isString",
        path			: "A.isString",

        getFileToken	: "A:autoHash(50)", // Used for Get Method of Avatar/Public Image
    },
};

module.exports = AttachmentModel;
