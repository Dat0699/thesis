const HelpDeskModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name			: "A.isString",
		name2			: "A.isString",

		descr			: "A.isString",
		number			: "A.autoIncrease",
		priority		: "A.isEnum(1,2,3,4,5)",

		deptIncharge	: "A.isIdString",
		assignees		: "A.isArrayIds < []",

		startDate		: "A.isDate",
		dueDate			: "A.isDate",

		labels			: "A.isArrayIds < []",

		type			: "A.isIdEmpty",
		subType			: "A.isIdEmpty",

		watchers		: "A.isArrayIds < []",
		status			: "A.isEnum(open, doing, resolved, closed) < open",
		resolvedAt		: "A.isDate",

		isLock			: "A.isBoolean < false"
    },
};

HelpDeskModel.subKey = {
}

module.exports = HelpDeskModel;
