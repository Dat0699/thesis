const CheckinModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		//userId			: "A.isIdString",
		date			: "A.isDate",

		registerIn		: "A.isTime",
		registerOut		: "A.isTime",

		checkin			: "A.isTime",
		checkout		: "A.isTime",

		registerHour	: "A.isNumber",
		checkinHour		: "A.isNumber",

		registerAmount	: "A.isNumber < 0",
		checkinAmount	: "A.isNumber < 0",

		backEarlyHour	: "A.isNumber < 0",
		comeLateHour	: "A.isNumber < 0",

		dayString		: "A.isString(0, 10)",
    },
};

CheckinModel.subKey = {
}

module.exports = CheckinModel;
