const PostServerModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",

		number          : "A.autoIncrease(1, mockserver, P.project._id)",
        name            : "A.isString",
		name2           : "A.isString",

		members			: "A.isArray < []",
    },
};

const member = {
	user	: "A.isIdString",
	role	: {
		//create: "A.isBoolean < true",
		modify: "A.isBoolean < true",
		delete: "A.isBoolean < true",
		action: "A.isBoolean < true",
	}
}

PostServerModel.subKey = {
	members		: [{ ...member }],
}

module.exports = PostServerModel;
