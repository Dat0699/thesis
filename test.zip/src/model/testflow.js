const TestFlowModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		number		: "A.autoIncrease(1, testflow, P.project._id)",
		colIndex    : "A.autoIncrease(100, testflow, P.project._id)",

		projectId   : "A.isIdString",
		featureId   	: "A.isIdString",

        title       : "A.isString",
		title2      : "A.isString",

		testDate	: "A.isDate",

        // tested      : "A.isNumber",
        // passed      : "A.isNumber",
        // testcase    : "A.isNumber",

        status		: "A.isEnum(new, testing, passed, failed) < new",

        testcases	: "A.isArray < []",
    },
};

TestFlowModel.subKey = {
	testcases: [{
		testcase	: "A.isIdString",
		result		: "A.isEnum(new, testing, passed, failed) < new",
		updatedAt	: "A.isDate",
		updatedBy	: "A.isRef(P.user._id)",
	}]
}

module.exports = TestFlowModel;
