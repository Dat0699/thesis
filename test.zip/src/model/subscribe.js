// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const FAQModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		email	: "A.isEmail",
		name	: "A.isUserName",
    },
};

module.exports = FAQModel;
