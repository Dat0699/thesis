// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const GroupModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId	: "A.isIdString",
		parentId	: "A.isIdEmpty",

        // totalItem     : "A.isInteger < 0",
        shortName	: "A.isShortName(32)",

        type		: "A.isEnum(wiki, task, snippet, risk, cost, agile, clog, creq, testcase)", // 1: wiki, 2: test, 3: source, 4: post, 5: task, 6: snippet, 7: risk, 8: cost, 9: agile/scrum board, 10: change log, 11: change request
        hasGlobal	: "A.isBoolean < false",
        colIndex	: "A.autoIncrease(100, group, P.project._id)",

        name		: "A.isString",
		name2		: "A.isString",
		color		: "A.isColor",

		value		: "A.isInteger < 1", // this is Task status value

        //descr     : "A.isString",
        //descrHTML : "A.isString",
    },
};

module.exports = GroupModel;
