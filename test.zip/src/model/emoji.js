const EmojiModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name	 	: "A.isString(1, -1)",
		shortname	: "A.isString",
        icon	    : "A.isString",

        descr 		: "A.isString",
		version		: "A.isString",
		type		: "A.isEnum(iOS, Android, Chrome, Firefox, Safari, Edge, IE, Opera, Other) < Chrome",

		activeAt	: "A.isDate",
		location	: "A.isString",

		lastActiveAt: "A.isDate",
		lastLocation: "A.isString",
    },
};

EmojiModel.subKey = {

}

module.exports = EmojiModel;
