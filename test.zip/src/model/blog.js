const BlogModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        number		: "A.autoIncrease(1, Public.blog)",
		colIndex    : "A.autoIncrease(100, Public.blog)",

		name		: "A.isString",
		name2		: "A.isString",

        content		: "A.isString",
		content2	: "A.isString",
		//date		: "A.isDate",

		language	: "A.isEnum(vn, en) < en",
		userName	: "A.isRef(P.user.name)",
		userRef		: "A.isRef(P.user.userId)",

		isPublic	: "A.isBoolean < true",
    },
};

BlogModel.subKey = {
}

module.exports = BlogModel;
