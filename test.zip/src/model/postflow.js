const PostFlowModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId	: "A.isIdString",
		serverId    : "A.isIdString", // mock server model
		featureId		: "A.isIdString",

		number		: "A.autoIncrease(1, postflow, P.project._id)",
		colIndex    : "A.autoIncrease(100, postflow, P.project._id)",
		
		name		: "A.isString",
		name2		: "A.isString",

		testDate	: "A.isDate",
		testMode	: "A.isEnum(allFlow, stopOnFailed) < stopOnFailed",

		postapis	: "A.isArray < []",
        status		: "A.isEnum(new, testing, passed, failed) < new",
    },
};

PostFlowModel.subKey = {
	postapis: [{
		postapi		: "A.isIdString",
		result		: "A.isEnum(new, testing, passed, failed) < new",
		updatedAt	: "A.isDate",
		updatedBy	: "A.isRef(P.user._id)",
	}]
}

module.exports = PostFlowModel;
