// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const FAQModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		parentId	: "A.isIdEmpty",
		colIndex    : "A.autoIncrease(100, Public.faq)",

		question	: "A.isString",
		question2	: "A.isString",

		answer		: "A.isString",
		answer2		: "A.isString",

		language	: "A.isEnum(vn, en) < en",
    },
};

module.exports = FAQModel;
