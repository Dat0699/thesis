// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const IssueLogModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId     : "A.isIdString",
		milestoneId   : "A.isIdEmpty",
        sprintId      : "A.isIdEmpty",
        featureId     : "A.isIdEmpty",
        taskId        : "A.isIdEmpty",

        labelIds      : "A.isArrayIds < []",
        memberIds     : "A.isArrayIds < []",

        priority      : "A.isEnum(1, 2, 3, 4, 5)", // 1. Low, 2. Normal, 3. High, 4. Urgent, 5. Block

        date		  : "A.isDate",
        number        : "A.autoIncrease(1, issue, P.project._id)",

        name		  : "A.isString",
		name2		  : "A.isString",
        descr		  : "A.isString",
    },
};

module.exports = IssueLogModel;
