// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const UserCompanyModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name             : "A.isString(1,256)",
		name2            : "A.isString(1,256)",
        email            : "A.isEmail",

        // newPassword   : "A.isPassword",
        // verifyToken   : "A.isString",
        password         : "A.isPassword(8, true)",
        // customerCode  : "A.isString",

		//avt      : "A.isAvatar",
		avt				: "A.isNumber < 0",

        companyId        : "A.isIdString",

        // avatarId      : "A.isIdString",
        // shortName     : "A.isString",
        // descr         : "A.isString",
        // descrHTML     : "A.isString",

        phone            : "A.isPhone",
        // fax           : "A.isString",
        address          : "A.isString",
        country          : "A.isCountry",
        countrycode      : "A.isCountryCode",
        has2FA           : "A.isBoolean",
        // feature       : "A.isObject",
        // config        : "A.isObject",
		fingers	   		 : "A.isArray < []", // keep this same as user

        useBio           : "A.isBoolean < false",
        bioToken         : "A.isString",
        bioUpdatedAt     : "A.isDate",

        ssoServices       : "A.isArray < []",

        status           : "A.isNumberEnum(0, 1, 2, 3) < #0", // 0 : not activate, 1: activate, 2: Block, 3: other,
		hasActived		 : "A.isBoolean < false",
    },
};

UserCompanyModel.subKey = {
	fingers : [{
		name		: "A.isString",
		finger		: "A.isString",
		createdAt	: "A.isNow",
		lastActive	: "A.isDate",
	}],

    ssoServices: [{
        name        : "A.isEnum(google, microsoft, apple, github, gitlab, biometric, qr) < []",
        ssoId       : "A.isString",
        status      : "A.isBoolean",
    }],
};

module.exports = UserCompanyModel;
