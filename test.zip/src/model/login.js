// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const LoginModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name          	: "A.isString",
		name2          	: "A.isString",

        email         	: "A.isEmail",
        companyId     	: "A.isIdString",
        newPassword   	: "A.isPassword(8, true)",
        verifyToken   	: "A.isString",
        password      	: "A.A.isPassword(8,true)",
        customerCode	: "A.isString",

        //avt    	: "A.isAvatar",
        shortName     	: "A.isString(32)",
        descr         	: "A.isString",
        descrHTML     	: "A.isString",

        phone         	: "A.isString",
        fax           	: "A.isString",
        address       	: "A.isString",
        country       	: "A.isString",

        feature       	: "A.isObject",
        config        	: "A.isObject",
		fingers			: "A.isArray",

        status          : "A.isEnum(0, 1, 2, 3) < 0", // 0 : not activate, 1: activate, 2: Block, 3: other,
    },
};
LoginModel.subKey = {
}


module.exports = LoginModel;
