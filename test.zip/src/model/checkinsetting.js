const CheckinSettingModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        ip      : "A.isIP",

        mac     : "A.isString",
        gps     : "A.isString",

        descr   : "A.isString",
        type    : "A.isEnum(ip, location, bluetooth)"
    },
};


CheckinSettingModel.subKey = {

}

module.exports = CheckinSettingModel;
