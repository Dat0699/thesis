const AssetTypeModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        number		: "A:autoIncrease(1, warehouseitem, P.warehouse._id)",
		code		: "A.isString",

        name		: "A.isString",
		name2		: "A.isString",
		color		: "A.isString",
    },
};

AssetTypeModel.subKey = {
}

module.exports = AssetTypeModel;
