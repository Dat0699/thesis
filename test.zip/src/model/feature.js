// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const FeatureModel = {
    priKeys: [

    ],

    allKeys: [],

    validator: {
        projectId			: "A.isIdString",
		parentId			: "A.isIdEmpty",

		//taskIds			: "A.isArrayIds < []",
		sprintId			: "A.isIdEmpty",
		milestoneId			: "A.isIdEmpty",

		automationIds		: "A.isArrayIds < []",

		taskIds				: "A.isArrayIds < []",
		bugIds				: "A.isArrayIds < []",
		wikiIds				: "A.isArrayIds < []",
		postapiIds			: "A.isArrayIds < []",
		postflowIds			: "A.isArrayIds < []",
		currentPostFlowId	: "A.isIdString",

		testcaseIds			: "A.isArrayIds < []",
		testflowIds			: "A.isArrayIds < []",
		currentTestFlowId	: "A.isIdString",

		number				: "A.autoIncrease(1, feature, P.project._id)",
		colIndex        	: "A.autoIncrease(100, feature, P.project._id)",

        name        		: `A.isString`,
		name2        		: `A.isString`,
        color       		: "A.isColor",
		icon       			: "A.isString",

		descr        		: `A.isString`,

        startDate   		: "A.isDate",
        dueDate     		: "A.isDate",

		//members			: "A.isArray < []",
		featurePoint		: "A.isObject < {}",
		poking				: "A.isObject < {}",
		earningPoints		: "A.isArray < []",

        status	    		: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted, 6: for Completed
		hasLocked			: "A.isBoolean < false",
    },
};

const earningPoint = {
	user	: "A.isIdString",
	point	: "A.isNumber < 0",
	type	: "A.isEnum(doing, testing, reviewing)",
};

// const testcase = {
// 	testcase	: "A.isIdString",
// 	result		: "A.isEnum(new, testing, passed, failed) < new",
// 	updatedAt	: "A.isDate",
// 	updatedBy	: "A.isRef(P.user._id)",
// };

FeatureModel.subKey = {
	featurePoint: {
		doing		: "A.isNumber < 0",
		testing		: "A.isNumber < 0",
		reviewing	: "A.isNumber < 0",
		total		: "A.isNumber < 0",
	},
	poking			: {
		doing		: [{
			user	: "A.isIdString",
			point	: "A.isNumber < 0"
		}],
		testing		: [{
			user	: "A.isIdString",
			point	: "A.isNumber < 0"
		}],
		reviewing	: [{
			user	: "A.isIdString",
			point	: "A.isNumber < 0"
		}],
	},
	earningPoints	: [{ ...earningPoint }],

	// testcases		: [{ ...testcase }],
	// testflows		: [{
	// 	name		: "A.isString",
	// 	testcases	: [{ ...testcase }],
	// }],
};

module.exports = FeatureModel;
