// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const RiskModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId     : "A.isIdString",
        labelId       : "A.isIdEmpty",

        milestoneId   : "A.isIdEmpty",
        sprintId      : "A.isIdEmpty",
        featureId     : "A.isIdEmpty",
        taskId        : "A.isIdEmpty",
        //assignId      : "A.isIdString",

        priority      : "A.isEnum(1, 2, 3, 4, 5)", // 1. Low, 2. Normal, 3. High, 4. Urgent, 5. Block

        dueDate       : "A.isDate",
        number        : "A.autoIncrease(1, risk, P.project._id)",

        content       : "A.isString",
		content2      : "A.isString",
        mitigate      : "A.isString",

        weight        : "A.isNumber",

        status        : "A.isEnum(1, 2) < 1", // 1. new, 2. resolved
		resolvedAt	  : "A.isDate",
    },
};

module.exports = RiskModel;
