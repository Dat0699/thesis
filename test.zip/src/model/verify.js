const VerifyModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		idType			: "A.isIdString",
		idNumberType	: "A.isIdNumber",
		stringType		: "A.isString",
		numberType		: "A.isNumber",
		emailType		: "A.isEmail",
		nameType		: "A.isUserName",
		phoneType		: "A.isPhone",
		pathType		: "A.isPath",
		fileType		: "A.isFile",
		boolType		: "A.isBoolean",
		regexType		: "A.isRegex",
		objectType		: "A.isObject",
		arrayType		: "A.isArray",
		arrayIdType		: "A.isArrayIds",
		dateType		: "A.isDate",
		dejectType		: "A.isDeject",
		tokenType		: "A.isRegex(/[0-9a-z\\+\\-\\.\\_\\=\\:\\;\\@\\s\\/\\\\]/gmi)",
        testStatusType  : "A.isEnum(new, testing, passed, failed)",
		qrType			: /*"A.isAlphaNumeric",*/ "A.isRegex('/[0-9a-z\\-]{15,64}/gmi')",
    },
};

VerifyModel.subKey = {
}

module.exports = VerifyModel;
