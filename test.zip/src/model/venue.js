const VenueModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		name    : "A.isString",
		name2   : "A.isString",
	    color   : "A.isString"
    },
};

VenueModel.subKey = {
}

module.exports = VenueModel;
