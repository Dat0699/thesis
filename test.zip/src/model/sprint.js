// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const SprintModel = {
    priKeys: [

    ],

    allKeys: [],

    validator: {
        projectId		: "A.isIdString",
		milestoneId		: "A.isIdEmpty",

		number			: "A.autoIncrease(1, sprint, P.project._id)",
		colIndex        : "A.autoIncrease(100, sprint, P.project._id)",

        name        	: `A.isString`,
		name2        	: `A.isString`,
        color       	: "A.isColor",

        startDate   	: "A.isDate",
        dueDate     	: "A.isDate",
        duration     	: "A.isNumber < 0",

		members			: "A.isArray < []",
        status	    	: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted

        approverIds 	: "A.isArrayIds < []",
		rejectedMessage	: "A.isString",
    },
};

SprintModel.subKey = {
};

module.exports = SprintModel;
