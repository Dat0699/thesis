// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const RoleProjectModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {

		hasGlobal	: "A.isBoolean",
		projectId	: "A.isIdString",

        name        : "A.isString",
		name2       : "A.isString",
        descr       : "A.isString",
        //descrHTML   : "A.isString",

        permit      : "A.isObject",
    },
};

// SubKeys implementation
var subPermit = {
	//updateReject	: "A.isBoolean < true",
	//updateClose    	: "A.isBoolean < true",
	//updateFinish	: "A.isBoolean < true",

	view 			: "A.isBoolean < true",
	modify  		: "A.isBoolean < true",
    //create    		: "A.isBoolean < true",
	//update  		: "A.isBoolean < true",
	delete			: "A.isBoolean < true",
	approve			: "A.isBoolean < true",

	//security		: "A.isBoolean < true",
	//share			: "A.isBoolean < true",
	//addPeople		: "A.isBoolean < true"
};

var VCUDA = {
	view 			: "A.isBoolean < true",
	modify  		: "A.isBoolean < true",
    //create    		: "A.isBoolean < true",
	//update  		: "A.isBoolean < true",
	delete			: "A.isBoolean < true",
	approve			: "A.isBoolean < true",
};

var VCUD = {
	view 			: "A.isBoolean < true",
	modify  		: "A.isBoolean < true",
    //create    		: "A.isBoolean < true",
	//update  		: "A.isBoolean < true",
	delete			: "A.isBoolean < true",
};

var CUD = {
	modify  		: "A.isBoolean < true",
    //create    		: "A.isBoolean < true",
	//update  		: "A.isBoolean < true",
	delete			: "A.isBoolean < true",
};

var CUDA = {
	modify  		: "A.isBoolean < true",
    //create    		: "A.isBoolean < true",
	//update  		: "A.isBoolean < true",
	delete			: "A.isBoolean < true",
	approve			: "A.isBoolean < true",
};

var V = {
	view 			: "A.isBoolean < true",
};

RoleProjectModel.subKey = {
    permit: {
		dashboard	: {...VCUD},
		feature		: {...VCUDA},
		sprint		: {...VCUDA},
        planning	: {...V},
	    task        : {...VCUD},
	    wiki        : {...VCUD},
	    gantt       : {...V},
		milestone   : {...VCUDA},
	    document    : {...VCUD},

		automation	: {...VCUD},

	    //team        : {...VCUD},
	    //user        : {...VCUD},

		sourcecode  : {...VCUD},
		cicd		: {...VCUD},
		vmmachine	: {...VCUD},
	    postapi     : {...VCUD},
	    testcase    : {...VCUD},

		performance	: {...VCUDA},
	    changelog   : {...VCUDA},
	    logtime     : {...VCUDA},

	    cost      	: {...VCUDA},
	    risk        : {...VCUD},
		issuelog    : {...VCUD},
		//label		: {...VCUD},
	    setting		: {...VCUD},

	    //snippet     : {...subPermit},
	},
};

module.exports = RoleProjectModel;
