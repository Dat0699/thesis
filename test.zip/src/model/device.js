const DeviceModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		userId		: "A.isIdString",

        name	 	: "A.isString",
		name2	 	: "A.isString",

        descr 		: "A.isString",
		version		: "A.isString",
		type		: "A.isEnum(iOS, iPhone, iPad, Android, Chrome, Firefox, Safari, Edge, IE, Opera, Other)",

		osType		: "A.isString",
		userIP		: "A.isIP",

		token		: "A.isString",
		activeAt	: "A.isDate",
		location	: "A.isString",

		lastActiveAt: "A.isDate",
		lastLocation: "A.isString",
    },
};

DeviceModel.subKey = {
}

module.exports = DeviceModel;
