const MockAPIModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",
		serverId		: "A.isIdString",
		groupId         : "A.isIdString",

		number          : "A.autoIncrease(1, mockapi, P.project._id)",
		colIndex    	: "A.autoIncrease(100, mockapi, P.project._id)",

        name            : "A.isString",
		name2           : "A.isString",

        route           : "A.isString",
        method          : "A.isString < GET",

        resHeaders      : "A.isArray < []",
        resBody         : "A.isObject < {}",
		resScript   	: "A.isObject < {}",

        resCode			: "A.isNumber",
    },
};

const KVObject = {
    key     : "A.isString",
    value   : "A.isString",
	checked	: "A.isBoolean < false",
}

const body = {
    type    : "A.isEnum(json, xml, formdata, xform, string, text, preview, raw) < text",
    value   : "A.isAnyWithSize(2097152) < content" // 2 * 1024 * 1024
}

const script = {
    type    : "A.isEnum(js, bash) < js",
    value   : "A.isString"
}

MockAPIModel.subKey = {
	resHeaders	: [{ ...KVObject }],
	resBody		: { ...body },
	resScript	: { ...script },
}

module.exports = MockAPIModel;
