const MockGroupModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",
		serverId		: "A.isIdString",

		number          : "A.autoIncrease(1, mockgroup, P.project._id)",
		colIndex    	: "A.autoIncrease(100, mockgroup, P.project._id)",

        name            : "A.isString",
		name2           : "A.isString",

		route			: "A.isString",

        resHeaders      : "A.isArray < []",
        resBody         : "A.isObject < {}",
    },
};

const KVObject = {
    key     : "A.isString",
    value   : "A.isString",
	checked	: "A.isBoolean < false",
}

const body = {
    type    : "A.isEnum(json, xml, formdata, xform, string, text, preview, raw) < text",
    value   : "A.isAnyWithSize(2097152) < {{children}}" // 2 * 1024 * 1024
}

MockGroupModel.subKey = {
	resHeaders	: [{ ...KVObject }],
	resBody		: { ...body },
}

module.exports = MockGroupModel;
