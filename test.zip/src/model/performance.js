// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const PerformanceModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId   : "A.isIdString",
        milestoneId	: "A.isIdEmpty",
        sprintId	: "A.isIdEmpty",
		taskId      : "A.isIdString",
		userId      : "A.isIdString",

        name        : "A.isString",
        // descr         : "A.isString",
        // descrHTML     : "A.isString",

        type        : "A.isEnum(1,2) < 2", // 1: penalty, 2: bonus
        point       : "A.isNumber",

		status		: "A.isStatus < 1",
    },
};

module.exports = PerformanceModel;
