// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const TutorialModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		parentId	: "A.isIdEmpty",
		number		: "A.autoIncrease(1, Public.tutorial)",
		colIndex    : "A.autoIncrease(100, Public.tutorial)",

		type		: "A.isEnum(folder, item) < folder",
		name		: "A.isString",
		name2		: "A.isString",
		content		: "A.isString",
		content2	: "A.isString",
		//date		: "A.isDate",

		language	: "A.isEnum(vn, en) < en",
		userName	: "A.isRef(P.user.name)",
		userRef		: "A.isRef(P.user.userId)",

		isPublic	: "A.isBoolean < true",
    },
};

module.exports = TutorialModel;
