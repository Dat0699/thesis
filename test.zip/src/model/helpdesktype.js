const HelpDeskTypeModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		parentId		: "A.isIdString",

        name			: "A.isString",
		name2			: "A.isString",
		number			: "A.autoIncrease",

		deptIncharge	: "A.isIdString",
		persionIncharges: "A.isArrayIds < []",
    },
};

HelpDeskTypeModel.subKey = {
}

module.exports = HelpDeskTypeModel;
