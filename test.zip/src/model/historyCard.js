const HistoryCardModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        status	: "A.isBoolean < true",
        content	: "A.isString",
        amount	: "A.isNumber < 9",
        receipt	: "A.ObjectId"
    },
};

HistoryCardModel.subKey = {
}

module.exports = HistoryCardModel;
