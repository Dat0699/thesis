// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const MentionModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectShortname: "A.isString",
        projectId       : "A.isIdString",
        mentionById     : "A.isIdString",
        mentionToIds    : "A.isIdArray < []",
        readIds         : "A.isIdArray < []",

        feature         : "A.isEnum(task, feature)",
        featureNumber   : "A.isNumber",
        featureName     : "A.isString",
        featureId       : "A.isIdString",
        hasComment      : "A.isBoolean < false",
        commentId       : "A.isIdEmpty",
    },
};

MentionModel.subKey = {
}

module.exports = MentionModel;