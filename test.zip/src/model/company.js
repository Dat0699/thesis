// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const CompanyModel = {
    priKeys: [
        // {"shortName"    : "text"},
        // {"customerCode" : "text"},
    ],

    allKeys: [],

    validator: {
        name			: "A.isString",
		name2			: "A.isString",

        shortName     	: "A.isShortName(32, main.company)",
        descr         	: "A.isString",

		//avt    	: "A.isAvatar",
		avt				: "A.isNumber < 0",

        email         	: "A.isEmail",
        agentId       	: "A.isIdString",

        phone         	: "A.isString",
        fax           	: "A.isString",
        address       	: "A.isString",
        country       	: "A.isString",

        companyCost   	: "A.isObject",
        usageStorage	: "A.isNumber < 0",
		totalStorage	: "A.isNumber < 5", // in GB

        feature       	: `A.isObject`,
        config        	: "A.isObject < {}",

        members       	: "A.isArray < []",

        status        	: "A.isNumberEnum(0, 1) < #0", // 0: not activate, 1: normal
    },
};

// SubKeys implementation
var feature = {
    project                     : "A.isBoolean < true",
    task                        : "A.isBoolean < true",
    dashboard                   : "A.isBoolean < true",
	feature						: "A.isBoolean < true",
	sprint						: "A.isBoolean < true",
    planning					: "A.isBoolean < true",
    milestone                   : "A.isBoolean < true",
    gantt                       : "A.isBoolean < true",
    wiki                        : "A.isBoolean < true",
    activity                    : "A.isBoolean < true",
    document                    : "A.isBoolean < true",
    logtime                     : "A.isBoolean < true",
    changelog                   : "A.isBoolean < true",
    performance                 : "A.isBoolean < true",
    penalty                     : "A.isBoolean < true",

    cost                        : "A.isBoolean < true",
    risk                        : "A.isBoolean < true",
	issuelog                    : "A.isBoolean < true",
    sourcecode                  : "A.isBoolean < true",
    lfsobject                   : "A.isBoolean < true",
    testcase                    : "A.isBoolean < true",
    postapi                     : "A.isBoolean < true",
    cicd                        : "A.isBoolean < true",

    vmmachine					: "A.isBoolean < true",
	automation					: "A.isBoolean < true",

    drive                	    : "A.isBoolean < true",
	helpdesk                	: "A.isBoolean < true",
    casestudy                   : "A.isBoolean < true",
    announcement                : "A.isBoolean < true",
    recruitment                 : "A.isBoolean < true",

	dailyreport                 : "A.isBoolean < true",
    calendar                    : "A.isBoolean < true",
    meeting						: "A.isBoolean < true",
	reminder					: "A.isBoolean < true",
    checkin						: "A.isBoolean < true",
	leaving						: "A.isBoolean < true",
	overtime					: "A.isBoolean < true",
    survey                      : "A.isBoolean < true",
    warehouse					: "A.isBoolean < true",
    campaign                    : "A.isBoolean < true",
    accounting                  : "A.isBoolean < true",
    salary						: "A.isBoolean < true",
    customerservice             : "A.isBoolean < true",
    chat						: "A.isBoolean < true",
	working						: "A.isBoolean < true",
    whitelistipaccess           : "A.isBoolean < true",
    permissionrole              : "A.isBoolean < true",
};

var config = {
    _prefix             		: "A.isString < XP",
    _redis              		: "A.isInteger < 0",
    _dcc                		: "A.isString < DCVNHCM",
    _dbversion          		: "A.isInteger < 1",

    language            		: "A.isString < en",
    timeZone            		: "A.isNumber < 7",
    currency            		: "A.isString < USD",
    currencyDecimal     		: "A.isNumber < 1",

    formatFullDay       		: "A.isString < 'MMM DD YYYY hh:mm'",
    formatShortDay      		: "A.isString <  'MMM DD YYYY'",
    // formatFullHour      		: "A.isString",
    // formatShortHour     		: "A.isString",

    noWorkingDayMonth   		: "A.isNumber < 21",
    yearlyHoliday       		: "A.isNumber < 16",
    noWorkingHourWeek   		: "A.isNumber < 40",

    moringStartTime     		: "A.isNumber < 8",
    moringEndTime       		: "A.isNumber < 12",
    afternoonStartTime  		: "A.isNumber < 13",
    afternoonEndTime   	 		: "A.isNumber < 17",
    nightStartTime      		: "A.isNumber < 0",
    nightEndTime        		: "A.isNumber < 0",

	endtimeSubmitLogtime		: "A.isTime < '20:00'",
	duedateApproveLogtime		: "A.isTime < '21:00'",

	endtimeSubmitDailyReport	: "A.isTime < '20:00'",
	duedateApproveDailyReport	: "A.isTime < '21:00'",

	endtimeSubmitDailyMeeting	: "A.isTime < '20:00'",
	duedateApproveDailyMeeting	: "A.isTime < '21:00'",

    checkinMobile       		: "A.isBoolean < false",

    isWebBrowser        		: "A.isBoolean < false",
    isIOS               		: "A.isBoolean < false",
    isAndroid           		: "A.isBoolean < false",

    listIps             		: "A.isArray < []",
    checkIPMatchedToken 		: "A.isBoolean < false",
	maxDocSize					: "A.isNumber < 320", // 120mb

    ipAccess            		: {
        mode          			: "A.isEnum(all, whitelist, blacklist) < all",
        whiteLists       		: [{
					ip      	: "A.isIP",
					descr   	: "A.isString"
				}],

        blackLists				: [{
					ip      	: "A.isIP",
					descr   	: "A.isString"
				}],
    },

    workingDayWeeks     : {
        sunday      : "A.isBoolean < false",
        monday      : "A.isBoolean < true",
        tuesday     : "A.isBoolean < true",
        wednesday   : "A.isBoolean < true",
        thursday    : "A.isBoolean < true",
        friday      : "A.isBoolean < true",
        saturday    : "A.isBoolean < false",
    },
    //startWeekday        : "A.isEnum(1, 2, 3, 4, 5, 6, 7) < 1", // 1 -> sunday, 2 -> monday, 3 -> tuesday, 4 -> wednesday, 5 -> thursday, 6 -> friday, 7 -> saturday

    enableCheckIps          : "A.isBoolean < true",
    enableCheckLocations    : "A.isBoolean < true",
    enableCheckBluetooths   : "A.isBoolean < true",
};

const companyCost = {
    currentCost : "A.isNumber",
    lastDebt    : "A.isNumber",
    yourBalance : "A.isNumber"
}

CompanyModel.subKey = {
    feature: { ...feature },
	featurePackage: { ...feature },

    config: config,
    companyCost: { ...companyCost },
    members : [{
        userId		: "A.isIdString",
        roleId		: "A.isIdString",
		hasActived	: "A.isBoolean < false",
		hasDeleted	: "A.isBoolean < false",
		hasLocked	: "A.isBoolean < false",
    }]
}

module.exports = CompanyModel;
