const MockServerModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId       : "A.isIdString",

		number          : "A.autoIncrease(1, mockserver, P.project._id)",
        name            : "A.isString",
		name2           : "A.isString",

        host            : "A.isString < 0.0.0.0",
		port			: "A.isString  < 8088",
		route			: "A.isString",

        resHeaders      : "A.isArray < []",
        resBody         : "A.isObject < {}",

		members			: "A.isArray < []",
    },
};

const KVObject = {
    key     : "A.isString",
    value   : "A.isString",
	checked	: "A.isBoolean < false",
}

const body = {
    type    : "A.isEnum(json, xml, formdata, xform, string, text, preview, raw) < text",
    value   : "A.isAnyWithSize(2097152) < {{children}}" // 2 * 1024 * 1024
}

const member = {
	user	: "A.isIdString",
	role	: {
		//create: "A.isBoolean < true",
		modify: "A.isBoolean < true",
		delete: "A.isBoolean < true",
		action: "A.isBoolean < true",
	}
}

MockServerModel.subKey = {
	resHeaders	: [{ ...KVObject }],
	resBody		: { ...body },
	members		: [{ ...member }],
}

module.exports = MockServerModel;
