const MailReminderModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        refCompanyId	    : "A.isIdString",
        refNumber		    : "A.isNumber",

        refModel	        : "A.isEnum(meeting, reminder)",
        refId               : "A.isIdString",
        
        title			    : "A.isString",
        content			    : "A.isString",

        listEmails		    : "A.isArray < []",

        date			    : "A.isDate",
        type                : "A.isEnum(remind, main) < main",
        remindBefore      : "A.isString < ''",
        status		        : "A.isEnum(1, 2) < 1", // 1 for uncomplete , 2 for completed,
        startDate     	    : "A.isDate",
    },
};

MailReminderModel.subKey = {
}

module.exports = MailReminderModel;
