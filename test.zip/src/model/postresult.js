const PostResultModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId		: "A.isIdString",
		serverId    	: "A.isIdString", // mock server model
        postflowId		: "A.isIdString",
		postapiId		: "A.isIdString",

		testDate		: "A.isDate",
        status			: "A.isEnum(new, testing, passed, failed) < new",

		name			: "A.isString",
		name2			: "A.isString",

		url             : "A.isString",
        method          : "A.isString < GET",

		reqHeader       : "A.isArray < []",
		reqQuery		: "A.isArray < []",
        reqBody         : "A.isObject < {}",
		reqPreScript  	: "A.isObject < {}",

		resHeader      	: "A.isArray < []",
        resBody        	: "A.isObject < {}",
		resPostScript  	: "A.isObject < {}",

        resStatus      	: "A.isNumber",
        resTime        	: "A.isNumber",
        resSize        	: "A.isNumber",
    },
};

const keyValue = {
    key     : "isString",
    value   : "isString"
}

const body = {
    type    : "A.isEnum(json, xml, text, image, pdf, raw) < text",
    value   : "A.isAnyWithSize(2097152)" // 2 * 1024 * 1024
}

const script = {
    type    : "A.isEnum(js, bash) < js",
    value   : "A.isString"
}

PostResultModel.subKey = {
	resHeader       : [{ ...keyValue }],
	reqQuery		: [{ ...keyValue }],
	resBody			: { ...body },
	reqPreScript	: { ...script },
	resPostScript	: { ...script },
}

module.exports = PostResultModel;
