// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const TaskModel = {
    priKeys: [
        //{"taskId": "text"},
    ],

    allKeys: [],

    validator: {
        projectId       : "A.isIdString",
		featureId		: "A.isIdEmpty",
		sprintId		: "A.isIdEmpty",
		milestoneId     : "A.isIdEmpty", // Model milestone
		parentId    	: "A.isIdEmpty", // Model Task

        name            : "A.isString",
		name2           : "A.isString",
        descr           : "A.isString",
        descrHTML       : "A.isString",

        type            : "A.isEnum(1,2,3,4,5) < 1", // 1: Task/Issues, 2: Bug, 3: Q&A, 4: Inform, 5: Request
        status          : "A.isEnum(1,2,3,4,5,6) < 1", // 1: Open, 2.Assigned, 3 Doing, 4: Test, 5: Review, 6: Done
        priority        : "A.isEnum(1,2,3,4,5) < 2", // 1: Low, 2: Normal, 3: High, 4: Urgent, 5: Locker

		doneTodo		: "A.isInteger < 0",
		remainTodo		: "A.isInteger < 0",
		totalTodo		: "A.isInteger < 0",

        todos           : "A.isArray < []",
        todo            : "A.isObject",
        reopen          : "A.isInteger < 0",

        weight          : "A.isNumber(1, 10) < 5",

        number          : "A.autoIncrease(1, task, P.project._id)",
        colIndex        : "A.autoIncrease(100, task, P.project._id)",

        groupId         : "A.isIdString", // Model Group
        labelIds        : "A.isArrayIds < []", // Model Label

        //subTaskIds      : "A.isArrayIds < []", // Model Task

        relatedTaskIds  : "A.isArrayIds < []", // Model Task
        attachIds       : "A.isArrayIds < []",

        assigneeIds		: "A.isArrayIds < []", // Model User
        testerIds		: "A.isArrayIds < []", // Model User
		reviewerIds		: "A.isArrayIds < []", // Model User
        watcherIds      : "A.isArrayIds < []", // Model User

        startDate       : "A.isDateEmpty",
        dueDate         : "A.isDateEmpty",

		duration     	: "A.isNumber < 0",
        estHour     	: "A.isNumber",
		minEstHour		: "A.isNumber",
		maxEstHour		: "A.isNumber",

        estCost   		: "A.isNumber",
		logCost			: "A.isNumber",
		minEstCost		: "A.isNumber",
		maxEstCost		: "A.isNumber",

        hasLimited      : "A.isBoolean",
        limitAccessIds  : "A.isArrayIds < []",
        isLock          : "A.isBoolean < false",

        isSubTask       : "A.isBoolean < false",
        taskLogs        : "A.isArray < []",

		budget			: "A.isNumber < 0",
		featurePoint	: "A.isObject",
    },

};

const taskLog = {
    type      : "A.isString",
    userId    : "A.isRef(P.user._id)",
    at        : "A.isNow",
}

const featurePoint = {
	doing		: "A.isNumber < 0",
	testing		: "A.isNumber < 0",
	reviewing	: "A.isNumber < 0",
	total		: "A.isNumber < 0",
};

TaskModel.subKey = {
    todos	 : {
        _id  : "A.autoHash",
        name : "A.isString",
        done : "A.isBoolean"
    },
    todo	 : {
        _id  : "A.autoHash",
        name : "A.isString",
        done : "A.isBoolean"
    },
    taskLogs : [{...taskLog}],
	featurePoint: { ...featurePoint },
};

module.exports = TaskModel;
