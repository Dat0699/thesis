
const TemplateModel = {
    priKeys: [
        //{"taskId": "text"},
    ],

    allKeys: [],

    validator: {
        projectId   : `A.isIdString`,
        
        refId	    : "A.isIdString",
        refModel    : `A.isEnum(task) < task`,

        name        : `A.isString`,
        // type        : `A.isEnum(task) < task`,

        content     : `A.isString`,
    },

};


TemplateModel.subKey = {
};

module.exports = TemplateModel;
