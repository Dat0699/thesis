const ReminderModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId		: "A.isIdString",
		number			: "A.autoIncrease",

		title			: "A.isString",
		title2			: "A.isString",
		descr			: "A.isString",

		userIds			: "A.isArrayIds < []",

		date			: "A.isDate",
		remindBefore	: "A.isNumber < 15",
    },
};

ReminderModel.subKey = {
}

module.exports = ReminderModel;
