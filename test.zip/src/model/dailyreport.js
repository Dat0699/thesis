const DailyreportModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId		: "A.isIdEmpty",
        milestoneId		: "A.isIdEmpty",
		sprintId		: "A.isIdEmpty",
		featureId		: "A.isIdEmpty",
        
		number			: "A.autoIncrease",
		type			: "A.isEnum(daily, weekly, monthly) < dayily",

		content			: "A.isString",
		content2		: "A.isString",

        point			: "A.isInteger(1,10)",

        problem			: "A.isString",
		problem2		: "A.isString",

        hasResolved		: "A.isBoolean < false",

		resolution		: "A.isString",
        reportDate		: "A.isDate",

        reportToIds		: "A.isArrayIds < []", // model user
		status			: "A.isStatus < 1", // 2 for Approved, 3 for Rejected, 4 for Submitted
        approverIds 	: "A.isArrayIds < []",

		rejectedMessage	: "A.isString",
    },
};

DailyreportModel.subKey = {

}

module.exports = DailyreportModel;
