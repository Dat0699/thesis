const QrCodeModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		cookie		: "A.isIdString",
		expired		: "A.isDate",
		qrCode		: "A.isIdString",
    },
};

QrCodeModel.subKey = {
}

module.exports = QrCodeModel;
