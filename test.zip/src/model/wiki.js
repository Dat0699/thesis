// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const WikiModel = {
    priKeys: [
        //{"wikiId": "text"},
    ],

    allKeys: [],

    validator: {
        projectId	: "A.isIdString",
		number		: "A.autoIncrease(1, wiki, P.project._id)",
		colIndex    : "A.autoIncrease(100, wiki, P.project._id)",

        title		: "A.isString",
		title2		: "A.isString",
        descr		: "A.isString",
        // descrHTML	: "A.isString",

		featureId	: "A.isIdEmpty",
        groupId		: "A.isIdEmpty",
		labelIds	: "A.isArrayIds < []",

        message		: "A.isString"
    },
};

module.exports = WikiModel;
