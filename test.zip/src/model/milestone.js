// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const MilestoneModel = {
    priKeys: [

    ],

    allKeys: [],

    validator: {
        projectId		: "A.isIdString",
		number			: "A.autoIncrease(1, milestone, P.project._id)",
		colIndex        : "A.autoIncrease(100, milestone, P.project._id)",

        name        	: `A.isString`,
		name2        	: `A.isString`,
        descr       	: "A.isString",

        attachIds   	: "A.isArrayIds < []",

        releaseNote 	: "A.isString",
		budget			: "A.isNumber < 0",
		//members			: "A.isArray < []",
		//memberSalarys	: "A.isArray < []",

        color       	: "A.isColor < #70CD5F",

        startDate   	: "A.isDate",
        endDate     	: "A.isDate",
        duration     	: "A.isNumber < 0",

		userIds			: "A.isArray < []",

        status	    	: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted
		rejectedMessage	: "A.isString",
    },
};

MilestoneModel.subKey = {
	// members: [{
	// 	user	: "A.isIdString",
	// 	joinAt	: "A.isDate",
	// 	leftAt	: "A.isDate",
	// }],
	// memberSalarys: [{
	// 	user    : "A.isIdString",
    //     joinAt  : "A.isDate",
	// 	leftAt  : "A.isDate",
	// }]
}

module.exports = MilestoneModel;
