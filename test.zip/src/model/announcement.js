const AnnouncementModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		number			: "A.autoIncrease",

        title         	: "A.isString",
		title2         	: "A.isString",

        fromId        	: "A.isIdString", // model department

        content       	: "A.isString",

        attachIds     	: "A.isArrayIds < []", // model fileattach

		sendToAll		: "A.isBoolean < false",
        userIds       	: "A.isArrayIds < []", // model user
        departmentIds	: "A.isArrayIds < []", // model department
        projectIds  	: "A.isArrayIds < []", // model project
        teamIds       	: "A.isArrayIds < []", // model team
        seniorityIds  	: "A.isArrayIds < []", // model seniority

        announcedDate	: "A.isDate",
        status			: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted

		viewerIds		: "A.isArrayIds < []", // User model

		rejectedMessage	: "A.isString",
        approverIds		: "A.isArrayIds < []", // model User
    },
};

AnnouncementModel.subKey = {
}

module.exports = AnnouncementModel;
