// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const SeniorityModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
      title : "A.isString",
	  title2: "A.isString",
      descr : "A.isString"
    },
};

module.exports = SeniorityModel;
