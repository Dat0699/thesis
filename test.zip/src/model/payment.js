const PaymentModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		companyId	: "A.isIdString",

		currentCost	: "A.isNumber < 0",
		lastDebit	: "A.isNumber < 0",
		balance		: "A.isNumber < 0",

		cards		: "A.isArray < []",

		historyLogs	: "A.isArray < []",
		storageLogs	: "A.isArray < []",
		
		status		: "A.isStatus < 1",
    },
};

PaymentModel.subKey = {
	historyLogs: [{
		type	: "A.isEnum(payment, topup, addcard, removecard)",
		date	: "A.isNow",
		descr	: "A.isString",
		amount	: "A.isNumber < 0",
		unit	: "A.isString < USD",
		status	: "A.isBoolean < false"
	}],

	storageLogs: [{
		date			: "A.isNow",
		userId			: "A.isRef(P.user._id)",
		totalStorage	: "A.isNumber < 0",
	}],

	cards: [{
		date	: "A.isNow",
		name	: "A.isString",
		type	: "A.isEnum(visa, master, jcb, amex, paypal, momo, atm, uniopay) < atm",
		data	: "A.isEncrypted",
		status	: "A.isEnum(locked, normal, actived, expired, other) < other"
	}]
}

module.exports = PaymentModel;
