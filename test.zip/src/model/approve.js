const ApproveModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId	: "A.isIdString",
		refId		: "A.isIdString",
		refModel	: "A.isEnum(changelog, logtime, milestone, sprint, penalty, kpi, performance, cost, announcement, dailyreport, overtime, leaving)",
		status		: "A.isEnum(1, 2, 3, 4)", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted,
		message		: "A.isString",
		originData	: "A.isAnyWithSize(2097152)", // 1024 * 1024 * 2 = 2MB.
    },
};

ApproveModel.subKey = {
}

module.exports = ApproveModel;
