const KpiModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		title		: "A.isString",
		title2		: "A.isString",

		fromDate	: "A.isDate",
		toDate		: "A.isDate",

		result		: "A.isBoolean",
		complete	: "A.isNumber < 0",

		enable		: "A.isObject < {}",
		missions	: "A.isArray < []",
		histories	: "A.isArray < []",

		status		: "A.isStatus < 1",
    },
};

const itemKPI = {
	enable		: "A.isBoolean < false",
	value		: "A.isNumber < 0",
	targetValue	: "A.isNumber < 0",
	complete	: "A.isNumber < 0",
	condition	: "A.isEnum(gt, lt, eq)"
};

const mission = {
	_id			: "A.autoHash",
	userId		: "A.isIdString",

	collectedBy	: "A.isRef(P.user._id)",
	collectedAt	: "A.isDate",

	result		: "A.isEnum(passed, failed) < failed",
	complete	: "A.isNumber < 0",

	total		: "A.isNumber < 0",
	rangeIndex	: "A.isIntger < 999999999",

	criteria	: {
		taskRemainCount			: { ...itemKPI },
		taskReopenCount			: { ...itemKPI },
		taskEarlyCount			: { ...itemKPI },
		taskEarlyHour			: { ...itemKPI },
		taskLateCount			: { ...itemKPI },
		taskLateHour			: { ...itemKPI },
		taskAssignCount			: { ...itemKPI },
		taskNewBugCount			: { ...itemKPI },
		taskDoneCount			: { ...itemKPI },

		checkinLateCount		: { ...itemKPI },
		checkinLateHour			: { ...itemKPI },
		checkoutEarlyCount		: { ...itemKPI },
		checkoutEarlyHour		: { ...itemKPI },

		performanceEarningPoint	: { ...itemKPI },
		performancePenaltyCount	: { ...itemKPI },
		performancePenaltyPoint	: { ...itemKPI },
		performancePoint		: { ...itemKPI },

		logTimeHour				: { ...itemKPI },
		logTimeAvg				: { ...itemKPI },
		logTimeLateSubmitCount	: { ...itemKPI },
		logTimeLateApproveCount	: { ...itemKPI },

		dailyReportPoint		: { ...itemKPI },
		dailyReportAvg			: { ...itemKPI },
		dailyReportLateSubmit	: { ...itemKPI },
		dailyReportLateApprove	: { ...itemKPI },

		codeCommitCount			: { ...itemKPI },
		codeCommitAvg			: { ...itemKPI },
		codeCommitAddLine		: { ...itemKPI },
		codeCommitDeleteLine	: { ...itemKPI },
		codeCommitLessInDay		: { ...itemKPI },
	}
};

KpiModel.subKey = {
	enable		: (() => { var obj = {}; Object.keys(mission.criteria).map(k => { obj[k] = "A.isBoolean < true" }) })(),
	missions	: [{ ...mission }],
	cellects	: [{ ...mission }],
}

module.exports = KpiModel;
