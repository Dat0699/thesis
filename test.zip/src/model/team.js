// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const TeamModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name            : "A.isString",
		name2           : "A.isString",
		avt			    : "A.isNumber < 0",

        leaderId        : "A.isIdString",
        viceLeaderIds   : "A.isArrayIds",
        members         : "A.isArrayIds < []",

        projectId	    : "A.isIdString",
    },
};

module.exports = TeamModel;
