const AssetAuditModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		warehouseId	: "A.isIdString",
        number		: "A:autoIncrease(1, warehouseaudit, P.warehouse._id)",

        name		: "A.isString",
		name2		: "A.isString",
		descr		: "A.isString",

		status		: "A.isEnum(0, 1, 4, 6) < 1", // 0 for locked, 1 for free and good, 2 for issuing, 3 for broken, 4 for repairing/maintaining

		quantity	: "A.isNumber < 0",
		lostQty		: "A.isNumber < 0",
		remainQty	: "A.isNumber < 0",

		allItems	: "A.isArray < []",
		auditItems	: "A.isArray < []",
		missedItems	: "A.isArray < []",

		auditedAt	: "A.isIdString",
		auditorId	: "A.isIdString",

		status		: "A.isStatus < 1",
    },
};

AssetAuditModel.subKey = {
}

module.exports = AssetAuditModel;
