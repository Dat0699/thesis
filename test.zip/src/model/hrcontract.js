const HrcontractModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        userId      : "A.isIdString",
		number		: "A.autoIncrease",

        overview    : "A.isObject",
        timelines   : "A.isArray < []",
        missions    : "A.isArray < []",
        careerPath  : "A.isArray < []",
        comments    : "A.isArray < []",
        renews      : "A.isArray < []",

		status		: "A.isStatus < 1",
    },
};

const overview = {
	birthday		: "A.isDate",
    entranceAt      : "A.isDate",
    resignDate      : "A.isDate",
    tempAddress     : "A.isString",
    homeAddress     : "A.isString",
    phoneNumber     : "A.isPhone",
    homeNumber      : "A.isPhone",

    renewAt         : "A.isDate",
    memberType      : "A.isEnum(1, 2, 3)",
    monthlySalary   : "A.isNumber",
    hourlySalary    : "A.isNumber",

    bankAccount     : "A.isString",
    bankName        : "A.isString",
    bankBranch      : "A.isString",

    contractForm    : "A.isEnum(1, 2)",

    attachIds       : "A.isArrayIds < []",

    // "roleId"            : "A.isIdString",
    //departmentId    : "A.isIdString", // saved user at model department
    seniorityId     : "A.isIdString",
    positionId	    : "A.isIdString",
    resignDate	    : "A.isDate",
	staffCode       : "A.isString",

	message  	    : "A.isString", // Used for check only
}

HrcontractModel.subKey = {
    overview    : {... overview},

    timelines    : [{
        "_id"         : "A.autoId",
        "title"       : "A.isString",
        "type"        : "A.isEnum(university, diploma, certificate, company, project, award, archivement, volunteer)",
        "duration"    : "A.isDate",
        "attachIds"   : "A.isArrayIds < []",
        "content"     : "A.isString",
        "creatorId"   : "A.isRef(P.user._id)",
        "createdAt"   : "A.isNow"
    }],

    missions: [{
        "_id"         : "A.autoId",
        "name"        : "A.isString",
        "done"        : "A.isBoolean",
        "type"        : "A.isEnum(1, 2)", // 1 -> careerPath, 2 -> TimelineMission
        "creatorId"   : "A.isRef(P.user._id)",
        "createdAt"   : "A.isNow"
    }],

    comments: [{
        "_id"       : "A.autoId",
        "content"   : "A.isString",
        "creatorId" : "A.isRef(P.user._id)",
        "createdAt" : "A.isNow",
    }],

    renews: [{
        "_id"             : "A.autoId",
        "monthlySalary"   : "A.isNumber",
        "hourlySalary"    : "A.isNumber",
        "attachId"        : "A.isArrayIds < []",
        "content"         : "A.isString",
        "type"            : "A.isEnum(submited, approved) < submited",
        "creatorId"       : "A.isRef(P.user._id)",
        "createdAt"       : "A.isNow"
   }]
}

module.exports = HrcontractModel;
