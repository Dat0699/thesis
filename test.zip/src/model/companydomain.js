const CompanydomainModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name        : "A.isURL",
        status      : "A.isEnum(1, 2)", // 1 -> Nomarl, 2 -> Verified,
        
        mxRecord    : "A.isArray",
        
        dkimRecord  :  "A.isArray",
        spfRecord   : "A.isArray",
        cnameRecord : "A.isArray",
        txtRecord   : "A.isArray"        

    },
};

const mxRecord = {
    record      : "A.isString",
    type        : "A.isString",
    address     : "A.isString",
    priority    : "A.isNumber",
    TTL         : "A.isNumber"
}

const record = {
    name : "A.isString",
    value: "A.isString"
}

CompanydomainModel.subKey = {
    mxRecord    : {...mxRecord},
    dkimRecord  : {...record},
    spfRecord   : {...record},
    cnameRecord : {...record},
    txtRecord   : {...record}   

}

module.exports = CompanydomainModel;