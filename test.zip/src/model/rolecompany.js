const RolecompanyModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name        :  "A.isString",
		name2       :  "A.isString",
        descr       :  "A.isString",
        //descrHTML   :  "A.isString",
        //hasGlobal	:  "A.isBoolean",

        permit      : "A.isObject",
    },
};

var subPermit = {
    view    : "A.isBoolean < true",
	modify  : "A.isBoolean < true",
    //create  : "A.isBoolean < true",
    //update  : "A.isBoolean < true",
	delete	: "A.isBoolean < true",
    approve : "A.isBoolean < true",
};

var VCUDA = {
	view	: "A.isBoolean < true",
	modify  : "A.isBoolean < true",
    //create	: "A.isBoolean < true",
	//update	: "A.isBoolean < true",
	delete	: "A.isBoolean < true",
	approve	: "A.isBoolean < true",
};

var VCUD = {
	view	: "A.isBoolean < true",
	modify  : "A.isBoolean < true",
    //create	: "A.isBoolean < true",
	//update  : "A.isBoolean < true",
	delete	: "A.isBoolean < true",
};

var C = {
	create	: "A.isBoolean < true",
};

var V = {
	view	: "A.isBoolean < true",
};

RolecompanyModel.subKey = {
    permit: {
		//project			: { ...VCUD },
		chat			: { ...VCUD },
		working			: { ...VCUD },
		drive			: { ...VCUD },
		helpdesk		: { ...VCUD },
		warehouse		: { ...VCUDA },

		dailyreport		: { ...VCUDA },
		announcement	: { ...VCUDA },

		calendar		: { ...V },
		leaving			: { ...VCUDA },
		meeting			: { ...VCUD },
		overtime		: { ...VCUDA },
		reminder		: { ...VCUD },

		setting			: { ...VCUD },
	},
}

module.exports = RolecompanyModel;
