// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const RegisterModel = {
    priKeys: [

    ],

    validator: {
        email       : "A.isString",
        password    : "A.isPassword",
        phone       : "A.isPhone",
        name		: "A.isString",
        shortName   : "A.isString",
        ssoService  : "A.isEnumArray(google, github, gitlab, biometric, qr) < []",
    },
};

RegisterModel.subKey = {
}

module.exports = RegisterModel;
