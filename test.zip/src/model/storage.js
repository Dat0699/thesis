const StorageModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        storage : "A.isNumber",
        amount  : "A.isNumber"
    },
};

StorageModel.subKey = {
}

module.exports = StorageModel;