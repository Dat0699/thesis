const ReportlabelModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name    : "A.isString",
		name2   : "A.isString",
        color   : "A.isColor"
    },
};

ReportlabelModel.subKey = {
}

module.exports = ReportlabelModel;
