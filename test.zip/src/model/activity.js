const ActivityModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId	: "A.isIdEmpty",
		milestoneId	: "A.isIdEmpty",
		taskId		: "A.isIdEmpty",
		userId		: "A.isIdString",
		refId		: "A.isIdEmpty",
		refNum		: "A.isNumber",

		type		: "A.isEnum(task, wiki, milestone, document, source, testcase, postapi, cicd, vmmachine, logtime, performance, penalty, changelog, cost, risk, announcement, dailyreport, meeting, leaving, overtime, reminder, checkin)",
		subType		: "A.isEnum(created, updated, deleted, approved, rejected, added, moved, cloned, removed, checked in, checked out)",
		content		: "A.isString",
		oldContent	: "A.isString",

		userIP		: "A.isIP",
    },
};

ActivityModel.subKey = {
}

module.exports = ActivityModel;
