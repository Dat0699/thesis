const MissionModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId	: "A.isIdString",

		number		: "A.autoIncrease(1, mission, P.project._id)",
		content		: "A.isString",
		content2	: "A.isString",
		//startDate	: "A.isDate",
		//endDate		: "A.isDate"

		date		: "A.isDate",
		weekYear	: "A.isString",
    },
};

MissionModel.subKey = {
}

module.exports = MissionModel;
