// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const ChangeLogModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId		: "A.isIdString",
		milestoneId		: "A.isIdEmpty",
        sprintId		: "A.isIdEmpty",
        featureIds		: "A.isIdArray < []",
		number			: "A.autoIncrease(1, changelog, P.project._id)",

        title			: "A.isString",
		title2			: "A.isString",

        content			: "A.isString",
        // descrHTML     : "A.isString",

        changedDate		: "A.isDate",
        attachIds		: "A.isArrayIds",
        message			: "A.isString",

		// note			: "A.isString",
		// noteHTML		: "A.isString",
		// from			: "A.isString",
		// reason		    : "A.isString",
		// reasonHTML	    : "A.isString",


        // hasApproved   : "A.isBoolean",
        // approvedId    : "A.isIdString",
        // approvedDate  : "A.isDate",

		amount	    	: "A.isNumber",
		// minAmount	: "A.isNumber",
		// maxAmount	: "A.isNumber",

		rejectedMessage	: "A.isString",
        status	    	: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted
        // approverIds : "A.isArrayIds < []",

    },
};

module.exports = ChangeLogModel;
