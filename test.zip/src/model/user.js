
const UserModel = {
    priKeys: [
        
    ],

    allKeys: [],

    validator: {
        name            : "A.isString(1, 256)",
		name2           : "A.isString(1, 256)",

        userId   		: "A.isIdString",

        email			: "A.isEmail",
        informEmail     : "A.isEmail",
        // password        : "A.isPassword(8,true)",
        // newpassword     : "A.isPassword(8,true)",

		//avt      : "A.isAvatar",
		avt				: "A.isNumber < 0",

        language        : "A.isString",

        type            : "A.isEnum(1, 2, 3, 4) < #1", // 1: Normal, 2: Part-time, 3: Internship, 4: No login.
        hasAgent        : "A.isBoolean < false",
        hasAdmin        : "A.isBoolean < false",
		hasSupport      : "A.isBoolean < false",

        status          : "A.isEnum(0, 1, 2, 3) < #0", // 0: not activate, 1: Normal, 2: Locked, 3: Muted User
		hasDeleted		: "A.isBoolean < false",
		hasUpdated		: "A.isBoolean < false",
		show2N			: "A.isBoolean < false",

		creatorId		: "A.isIdString"
    },
};


UserModel.subKey = {
	// fingers : [{
	// 	name		: "A.isString",
	// 	finger		: "A.isString",
	// 	createdAt	: "A.isNow",
	// 	lastActive	: "A.isNow",
	// }]
}

module.exports = UserModel;
