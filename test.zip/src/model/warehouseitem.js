const AssetItemModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		warehouseId	: "A.isIdString",
        number		: "A:autoIncrease(1, warehouseitem, P.warehouse._id)",

        name		: "A.isString",
		name2		: "A.isString",

		types		: "A.isArrayIds < []",
		code		: "A.isString",

		descr		: "A.isString",
		note 		: "A.isString",

		imageIds	: "A.isArray < []",

		importBy	: "A.isIdString",
		importAt	: "A.isDate",
		importPrice	: "A.isNumber < 0",

		remainPrice	: "A.isNumber < 0",
		warrantyAt 	: "A.isDate",

		issueTo		: "A.isIdString",
		issueAt		: "A.isDate",
		issueBack	: "A.isDate",

		histories	: "A.isArray < []",

		status		: "A.isEnum(0, 1, 2, 3, 4, 7) < 1", // 0 for locked, 1 for free and good, 2 for issuing, 3 for broken, 4 for repairing/maintaining, 7 for deleted
    },
};

const issue = {
	type	: "A.isEnum(0, 1, 2, 3, 4, 7) < 1",
	at		: "A.isDate",
	to		: "A.isIdString",
	back	: "A.isDate",
};

AssetItemModel.subKey = {
	histories	: [{ ...issue }],
}

module.exports = AssetItemModel;
