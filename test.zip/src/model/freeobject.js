// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const FreeObjectModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		type	: "A.isString",
		key		: "A.isString",
		data	: "A.noneCheck",
    },
};

module.exports = FreeObjectModel;
