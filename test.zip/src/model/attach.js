const AttachModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        refId	: "A.isIdString",

        name	: "A.isString",
        path	: "A.isPath",
        length	: "A.isNumber",
		
		getFileToken	: "A:autoHash(50)", // Used for Get Method of Avatar/Public Image
    },
};

AttachModel.subKey = {
}

module.exports = AttachModel;
