const BoardModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        name          : "A.isString",
		name2         : "A.isString",
		
        projectId     : "A.isIdString",
        groupIds      : `A.isArrayIds < []`,
        shortName     : "A.isShortName(32)",

        hasGlobal     : "A.isBoolean < false",
    },
};

BoardModel.subKey = {
}

module.exports = BoardModel;
