const OvertimeModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		projectId		: "A.isIdEmpty",
		milestoneId		: "A.isIdEmpty",
		sprintId		: "A.isIdEmpty",
		featureId		: "A.isIdEmpty",

		number			: "A.autoIncrease",
        title			: "A.isString",
		title2			: "A.isString",

        startDate       : "A.isDate",
        endDate         : "A.isDate",
		descr		    : "A.isString",

		duration		: "A.isNumber < 0",
		estDuration		: "A.isNumber < 0", // use for user input manual
		mkDuration		: "A.isNumber < 0",

		mkSalaryRatio	: "A.isNumber < 1",

		totalHour       : "A.isNumber < 0", // Not used, will be removed
        effortRatio		: "A.isNumber < 1", // Not used, will be remove
        totalEffortHour	: "A.isNumber < 0", // Not used, will be remove

		memberSalaries	: "A.isArray < []",
        userIds			: "A.isArrayIds < []",
        status	        : "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted

        approverIds     : "A.isArrayIds < []",
		rejectedMessage	: "A.isString",
    },
};

OvertimeModel.subKey = {
	memberSalaries: [{
		user		: "A.isIdString",
		checkin		: "A.isTime",
		checkout	: "A.isTime",
		duration	: "A.isNumber < 0",
		mkDuration	: "A.isNumber < 0",
		amount		: "A.isNumber < 0",
	}]
}

module.exports = OvertimeModel;
