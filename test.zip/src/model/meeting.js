const MeetingModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		number			: "A.autoIncrease",
        title         	: "A.isString",
		title2         	: "A.isString",
        content       	: "A.isString",
        type          	: "A.isEnum(1, 2, 3, 4) < 1", // 1.Daily, 2.Monthly, 3.Weekly, 4. Sudden

        startDate     	: "A.isDate",
        endDate       	: "A.isDate",

		estDuration		: "A.isNumber < 0", // use for user input manual
		duration      	: "A.isNumber < 0",

        remindBefore  	: "A.isNumber < 0",

		venueId        	: "A.isIdString",

		projectIds		: "A.isArrayIds < []",
		teamIds			: "A.isArrayIds < []",
        members       	: "A.isArrayIds < []",

		attends       	: "A.isArrayIds < []",
		disattends    	: "A.isArrayIds < []",

		attachIds   	: "A.isArrayIds < []",
        conclusion    	: "A.isString"
    },
};

MeetingModel.subKey = {
}

module.exports = MeetingModel;
