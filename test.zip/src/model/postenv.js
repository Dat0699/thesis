// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const PostEnvModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId     : "A.isIdString",
		serverId      : "A.isIdString", // mock server model

        name          : "A.isString",
		name2          : "A.isString",

        descr         : "A.isString",
        //descrHTML     : "A.isString",

        variables     : "A.isArray < []", // Save [{Key, Value}]
    },
};

const content = {
    key     : "A.isString",
    value   : "A.isString"
}

PostEnvModel.subKey = {
	variables: [{ ...content }]
}

module.exports = PostEnvModel;
