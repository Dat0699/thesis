const ReportBugModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
		companyId	: "A.isIdString",

        number		: "A.autoIncrease(1, Public.reportbug)",
        priority	: "A.isEnum(1, 2, 3, 4, 5) < 2", // 1. Low, 2. Normal, 3. High, 4. Urgent, 5. Block
        title		: "A.isString",
		title2		: "A.isString",
        content		: "A.isString",
        resolution	: "A.isString",
        labelIds	: "A.isArrayIds",
        attachIds	: "A.isArrayIds",

		status		: "A.isStatus < 1", // 0 for Locked, 1 for Normal, 2 for Approved, 3 for Rejected, 4 for Submitted
		hasGlobal	: "A.isBoolean < false",
		resolvedAt	: "A.isDate",
		listingAt	: "A.isDate",
    },
};

ReportBugModel.subKey = {

}

module.exports = ReportBugModel;
