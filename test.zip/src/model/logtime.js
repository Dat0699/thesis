// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const LogTimeModel = {
    priKeys: [
        //{"logTimeId": "text"},
    ],

    allKeys: [],

    validator: {
        projectId   	: "A.isIdString",
        milestoneId		: "A.isIdEmpty",
        sprintId		: "A.isIdEmpty",
        featureId		: "A.isIdEmpty",
        taskId      	: "A.isIdString",

		number			: "A.autoIncrease(1, logtime, P.project._id)",
        content     	: "A.isString",
		content2     	: "A.isString",

		status			: "A.isStatus < 4", // 2 for Approved, 3 for Rejected, 4 for Submitted
        name        	: "A.isString",
		name2        	: "A.isString",

		type			: `A.isEnum(coding, implementing, testing, correcting, reviewing, optimizing, designing, planning, meeting, training, other, working) < other`,
        hour        	: "A.isNumber(0, 10) < 0",
        fromTime    	: "A.isDate",
        amount      	: "A.isNumber < 0",

        approverIds 	: "A.isArrayIds < []",
		rejectedMessage	: "A.isString",
    },
};

module.exports = LogTimeModel;
