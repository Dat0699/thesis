// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const PostGroupModel = {
    priKeys: [
    ],

    allKeys: [],

    validator: {
        projectId	: "A.isIdString",
		serverId    : "A.isIdString", // Used for Post API
		parentId	: "A.isIdEmpty",

        colIndex	: "A.autoIncrease(100, postgroup, P.project._id)",

		name		: "A.isString",
        name2		: "A.isString",
    },
};

module.exports = PostGroupModel;
