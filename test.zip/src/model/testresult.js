// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const TestResultModel = {
    priKeys: [
        //{"testResultId": "text"},
    ],

    allKeys: [],

    validator: {
        projectId   : "A.isIdString",
        testflowId  : "A.isIdString",
		testcaseId	: "A.isIdString",
        result      : "A.isEnum(new, testing, passed, failed) < new",
		note		: "A.isString",
    },
};

module.exports = TestResultModel;
