// Ref: https://docs.mongodb.com/manual/reference/operator/query/jsonSchema/#jsonschema-extension

const ProjectModel = {
    priKeys: [

    ],

    validator: {
        shortName     : "A.isShortName(32)",
        //avt    : "A.isAvatar",
		avt			  : "A.isNumber < 0",

        name          : "A.isString",
		name2         : "A.isString",

        descr         : "A.isString",
        descrHTML     : "A.isString",

        types         : "A.isStringEnumArray(informatic, sale, marketing, design, concept, consulting, training, production, media, other) < []",
        agentId       : "A.isIdString",
        attachIds     : "A.isArrayIds < []",
        members       : "A.isArray < []", // array of object {user: userId, role: roleprojectID}
		//memberSalarys : "A.isArray < []", // array of object {user: userId, role: roleprojectID}

        budget        : "A.isNumber",
        //riskIds       : "A.isArrayIds < []",

        hasDueDate    : "A.isBoolean",
        startDate     : "A.isDate",
        dueDate       : "A.isDate",

		actLabelIds   : "A.isArrayIds < []",
        actFeatureIds  : "A.isArrayIds < []",
		actSprintIds  : "A.isArrayIds < []",
		actMilestoneIds: "A.isArrayIds < []",

        feature       : `A.isObject`,

		hasCompleted  : "A.isBoolean < false",
        status        : "A.isEnum(0,1,2,6) < 1", // 0: block, 1: normal, 2: archived, 6: complete

		// For cost section
		budget		  : "A.isNumber < 0",
		maxDocSize	  : "A.isNumber < 0",
    },
};

// SubKeys implementation
var feature = {
	dashboard		: "A.isBoolean < true",
	feature			: "A.isBoolean < true",
	sprint			: "A.isBoolean < true",
    planning		: "A.isBoolean < true",
	task		    : "A.isBoolean < true",
	milestone		: "A.isBoolean < true",
	document		: "A.isBoolean < true",
	wiki		    : "A.isBoolean < true",
	gantt	        : "A.isBoolean < true",
	performance	    : "A.isBoolean < true",
	cost		    : "A.isBoolean < true",
	logtime	        : "A.isBoolean < true",
	changelog		: "A.isBoolean < true",
	risk	        : "A.isBoolean < true",
	issuelog	    : "A.isBoolean < true",
	sourcecode		: "A.isBoolean < true",
	cicd		    : "A.isBoolean < true",
	vmmachine		: "A.isBoolean < true",
    postapi		    : "A.isBoolean < true",
    testcase		: "A.isBoolean < true",
	automation		: "A.isBoolean < true",
}

ProjectModel.subKey = {
    feature: { ...feature },
	members: [{
		user    : "A.isIdString",
        role    : "A.isIdString",
        joinAt  : "A.isDate",
		leftAt  : "A.isDate",
	}],
}
module.exports = ProjectModel;
