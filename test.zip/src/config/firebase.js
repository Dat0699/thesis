const Firebase = {
	Enable 			: false,

	CredentialsFile	: "./service-account-file.json",

	UsePushQueue	: true,
	QueueInterval	: 10, // 10 seconds
	QueueFilePath	: "../firebaseFiles",
	QueueReadLimit	: 30, // Queue read limited in 30 items.
	MessageExpired	: 30, // Message expired in 30 seconds.


	// DatabaseURL	: "https://abc.firebase.io/",
	DBName			: "dbfirebase",
	ColName			: "pushqueue",

	Vendor			: "firebase-admin",
}

module.exports = Firebase;
