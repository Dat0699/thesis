const Redis = {
	Enable      		: true,
    ServerURL   		: "@Premium.RedisServer",

	//"redis://redis:123456%3Fz@188.166.211.173:6379/",
    AdminDB     		: "0",
    CommonDB    		: "commondb",
    DBPrefix    		: "DB",

    EnableCache 		: false,

	EnableCount			: true, // if true, every CacheCheck (r+w times), redis check and clear expired data.
    CacheCheck  		: 2000, // count to 2000 iops (read + write) times to check
    CachePerMax 		: 2000, // same as CacheCheck
    CacheExpired		: 86400, // 1 day, (60 secs * 60 mins * 24 hours), unit: second
	ConnectionExpired	: 1800, // 1800 seconds ~ 30 minutes

	CheckInterval   	: 3600, // 1 hour, if EnableCount = false, check expired every "CheckInterval" second.

    PSTypeChat  		: "PSTypeChat",
    PSTypeCache 		: "PSTypeCache",
	PSTypeBList 		: "PSTypeBList",
	PSTimeOut			: 15, // 15 seconds

    SubKeyLength		: 3,
    KeyExpired  		: 15 * 24 * 3600, // Expired in 15 days
    TotalDB     		: 15, // Total Redis database

    Vendor      		: "redis",
}

module.exports = Redis;
