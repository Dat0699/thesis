const Git = {
	Enable 			: false,
	EnableLog		: false,

	EnableLFS		: true,
	EnableLockAPI	: true,

	EnableLOC		: true,

	EnableNFS		: false,
	// Server export : /var/shared	*(rw,sync,no_subtree_check,all_squash,anonuid=999,anongid=999)
	NFSPaths		: [{
		client		: "/gamgit/git-repo",
		server		: "gitgam.com:/var/shared/git-repo",
	}],

	Port			: 222,
	Family			: "any",
	BindIP			: "0.0.0.0",

	MaxTries		: 6,
	MaxSession		: 2000,

	CommandBindIPs	: [], // list IPs
	CommandUser		: "git",
	CommandUserID	: 999,
	CommandHome		: "/gamgit",

	PermitRootLogin	: false,
	AliveInterval	: 120, // 120 second
	UseForceCommand	: true,

	SSHMoreConfig	: ``, // Add mode test Line by line line

	SourceModel		: "source",
	LFSModel		: "lfsmodel",
	LFSTokenTimeOut	: 3600,
	LFSServer		: "http://127.0.0.1:8085",

	LFSMaxFileSize	: 4 * 1024 * 1024 * 1024,
	LFSMaxUploadSize: 4 * 1024 * 1024 * 1024,
	LFSMaxFileCount	: 50,

	FileMaxSize		: 4000000000, // ~ 4GB
	PushSizeMax		: 20000000000, // ~ 20GB
	PushFileMax		: 10000, // 5000 files

	ShellPath		: "/gamsys/git-shell",
	ShellKeyPath	: "/gamsys/git-keys",
	HookPath		: "/gamsys/git-hook",
	DataPath        : "/gamgit/git-data",
	RepoPath        : "/gamgit/git-repo",
	TmpPath			: "/gamgit/git-temp",

	KeyAuthMethod	: "POST",
	KeyAuthURL		: "http://127.0.0.1:8085/git/ssh/auth",

	ForceCmdMethod	: "POST",
	ForceCmdURL		: "http://127.0.0.1:8085/git/ssh/cmd",

	HookURL			: "http://127.0.0.1:8085/hook",

	PreInstallLFS	: "curl -s https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh | sudo bash",
	InstallTool		: "apt-get",
	DebugMode		: false,
}

module.exports = Git;
