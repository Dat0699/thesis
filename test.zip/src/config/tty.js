const TTY = {
	Enable 			: false,

	Port			: 9091,
	ServerIP		: "0.0.0.0",

	MaxTTYSession	: 1,  // 1 session only.
	MaxCMDLength	: 8096,  // 8KB.
	Interval		: 60, // 60 seconds.
	TimeOut			: 30, // Expired in 30 seconds.

	DataPath		: "../ttyData",
	ShellExec		: "/bin/bash",
	WhiteList		: [
		"127.0.0.1",
	],
}

module.exports = TTY;
