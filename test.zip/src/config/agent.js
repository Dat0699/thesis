const Agent = {
	Enable 				: false,
	EnableLog			: false,

	UseCommand			: true, // Get Command from OMS
	CommandPort			: 36289,

	CommandBindIPs		: [], // list IPs
	CommandUser			: "agent",
	PermitRootLogin		: false,
	AliveInterval		: 120, // 120 second
	UseForceCommand		: false,

	SSHMoreConfig		: ``, // Add mode test Line by line line

	KeyAuthMethod		: "GET",
	KeyAuthURL			: "http://127.0.0.1:8080/task/agent-auth",

	ForceCmdMethod		: "GET",
	ForceCmdURL			: "http://127.0.0.1:8085/sshkey/cmd",

	ShellPath			: "/gamagent/agent-shell",

	CheckInterval		: 10, // interval 60 seconds
	ServerURL			: "http://127.0.0.1:8080/oms/server",
	Method				: "POST",

	DiskTestFile		: "/tmp/gamagent/testdisk",
	DiskTestBlockSize	: "8k",
	DiskTestCount		: "4k",

	InstallTool			: "apt-get",

	CollectOS			: true,
	CollectPID			: true,
	CollectPORT			: true,
	CollectLOG			: true,

	CollectCPU			: true,
	CollectRAM			: true,
	CollectDISK			: true,
	CollectNET			: true,
}

module.exports = Agent;
