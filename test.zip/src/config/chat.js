const Chat = {
	Enable				: false,
    ServerPort          : 9000,// + parseInt(Math.random()*100),

	ChatMaxCCU			: 4000, // Limits concurrent Socket
	ChatMaxMsgCCU		: 6000, // Limits concurent Delivery Message

	TimeOut				: 15, // 15 seconds

	ChatUID				: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",

	MaxReqBody			: 10000, // 10 KB
	MaxLiveReqLength	: 10000000, // 10 MB

	MaxResBody			: 10000, // 10 KB
	MaxLiveResLength	: 10000000, // 10 MB

	MaxDuration			: 18000, // 18 seconds
	MaxLiveDuration		: 36000000, // 10 hours

}

module.exports = Chat;
