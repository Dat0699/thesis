const CronJob = {
	Enable 			: true,
	Interval		: 60, // Every 60 Second
}

module.exports = CronJob;
