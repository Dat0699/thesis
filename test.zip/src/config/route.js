const Route = {
	imCompany			: true,
	IgnoreModifiedAt	: true,
	zipThreadHold		: 60*1024, // 10KB must zip
}

module.exports = Route;
