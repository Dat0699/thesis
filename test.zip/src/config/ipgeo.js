const IPGeo = {
	Enable 			: false,

	Port			: 9091,
	ServerIP		: "0.0.0.0",

	Interval		: 60, // 60 seconds.
	TimeOut			: 30, // Expired in 30 seconds.

	PartCount		: 100,

	TimeZoneFile	: "./db/timezone.txt",
	CountryFile		: "./db/country.txt",

	UseTimeZone		: false,
	UseRegionCity	: false,
	UseLocation		: false,
	UseZipCode		: false,

	DBPassword		: "",
	IP4File			: "./db/ipv4.zip",
	IP6File			: "./db/ipv6.zip",

	WhiteList		: [
		"127.0.0.1",
	],
}

module.exports = IPGeo;
