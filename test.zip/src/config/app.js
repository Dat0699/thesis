const App = {
	Enable				: false,
	EnableLog			: false,

	user				: "pms-dev",
	group				: "pms-dev",
	isDevMode			: true,


	EnableValid			: false,
	ValidMode			: "udp", // udp, url, internal (default)
	ValidURL			: "http://127.0.0.1/subrequest",
	ValidExpired		: 600, // 600 seconds ~ 10 minutes.
	ValidExpZero		: 5,
	ValidPathMaxCount	: 20,
	ValidIPMaxCount		: 3000,
	ValidInterval		: 500,

	EnableCSRF			: false,
	CSRFExcepts			: [],

    ServerPort          : 8080,// + parseInt(Math.random()*100),
    MaxBody  	        : 25 * 1024 * 1024, // 25 MB
    Salt                : "ZayEopkQh0",
	SaltKey				: "SUs1dOszQoW02m15sKRDepo",
	SaltPepil			: "GwpOEYµzU1RxbU√4pa3DkXçFr",

    defaultPageLength   : 25,
    defaultPageIndex    : 0,
    maxPageLimit        : 100,
	//pageIndexName		: "pageIndex",
	pageLengthName		: "pageLength",
	pageStartName		: "pageStart",
	dateFromName		: "fromDate",
	dateToName			: "toDate",

    DataPath            : "../data/uploads",
	TimeOut				: 15, // 15 seconds

	//ExConfig			: "http://gcore.gitgam.com/anc.com",

	EnableCORS			: true,
	CORSMethods			: ["GET", "POST", "PUT", "DELETE", "PURGE", "OPTIONS"],
	CORSHeaders			: ["user-token", "content-type", "media-type"],
	CORSOrigins			: "@Premium.CorsOrigin",

	// Override MimeType
	MimeType			: {},
	EnableProfiling		: true,
	ShellCMD			: "/bin/bash",
}

module.exports = App;
