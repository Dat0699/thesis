const Excel = {
	Enable: true,

	Vendor: {
		Excel: "xlsx-js-style"
	}
}

module.exports = Excel;
