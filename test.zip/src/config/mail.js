const Mail = {
	Enable 			: true,

	// Use NodeMailer as Transporter, other use Sendmail to send directly.
	UseTransporter	: true,

	// https://nodemailer.com/about/
	TransportConfig : "@Premium.MailConfig",

	// https://www.npmjs.com/package/sendmail
	SenderConfig	: {
		logger		: {
			debug	: console.log,
			info	: console.info,
			warn	: console.warn,
			error	: console.error
		},
		silent		: false,
		//dkim: { // Auto Config in code, Default: False
		//	privateKey: "", //require("fs").readFileSync("./src/config/mail.dkim", "utf8"),
		//	keySelector: "mydomainkey"
		//},
		//devPort		: 1025, // Default: False
		//devHost		: "localhost", // Default: localhost
		//smtpPort	: 25, // Default: 25
		//smtpHost	: "localhost" // Default: -1 - extra smtp host after resolveMX
	},

	//DKIMFile		: "./src/config/mail.dkim",
	DKIMSelector	: "mydomainkey",

	UseMailQueue	: true,
	QueueInterval	: 15, // 10 seconds
	QueueFilePath	: "../data/mailFiles",
	QueueReadLimit	: 10, // 10 item

	DBName			: "dbmail",
	ColName			: "mailqueue",
	SenderName		: "@Premium.SendByEmail",
	SentTo			: "@Premium.SendByEmail",
	SendTemplate	: "",
	Vendor			: {
		mailTransporter	: "nodemailer",
		mailSender		: "sendmail"
	}
}

module.exports = Mail;
