const SSH = {
	Enable 				: false,
	EnableLog			: false,

	UseCommand			: true, // Get Command from OMS
	CommandPort			: 36289,

	CommandBindIPs		: [], // list IPs
	CommandUser			: "git",
	AliveInterval		: 120, // 120 second
	UseForceCommand		: false,

	KeyAuthMethod		: "GET",
	KeyAuthURL			: "http://127.0.0.1:8080/task/ssh-auth",
	ShellPath			: "../upload/ssh-shell",

	CheckInterval		: 10, // interval 60 seconds
	ServerURL			: "http://127.0.0.1:8080/oms/server",
	Method				: "POST",

	SSHMoreConfig		: ``, // Add mode test Line by line line
	InstallTool			: "apt-get",
}

module.exports = SSH;
