const Mongo = {
	Enable			: true,

    ServerURL       : "@Premium.MongoServer",
	//"mongodb://pms-dev:123456%3Fz@188.166.211.173:27969/?authSource=admin",

    MainDB          : "pms", // black list, red list
    DBPrefix        : "DB",
	DBSuffixKey		: "_id",

    CompanyModel    : "Main.company",
	UserCompanyModel: "Main.usercompany",
	// UserCompanyModel: "Main.usercompany",

    UserModel       : "user",
    ProjectModel    : "project",
    RoleModel       : "role",
	RoleCompanyModel: "rolecompany",
	RoleProjectModel: "roleproject",
    RedListModel	: "redlist",
	BlackListModel  : "blacklist",

    Vendor          : "mongodb",

	Extra			: {
		//Public		: "@Premium.MongoServer",
		Public		: "@Premium.MongoServer",
		Payment		: "@Premium.MongoServer",	
	},
}

module.exports = Mongo;
