const SSO = {
	Enable: true,

	Google: {
		ExchangeTokenURL: "https://oauth2.googleapis.com/token",
		client_id: "1007281245246-tsl09r54ubvr73njt74kn0k3lkl8sur6.apps.googleusercontent.com",
		client_secret: "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",
		grant_type: "authorization_code",
		redirect_uri: "https://dev-pms.gitgam.com/",
		// importName: "google-auth-library",
	},

	Github: {
		ExchangeTokenURL: "https://github.com/login/oauth/access_token",
		GetProfileUrl: "https://api.github.com/user",
		client_id: "1de37992f234039306f3",
		client_secret: "37033a5e91a4ba11ac3a0096043fb206b46a7a6f",
		redirect_uri: "http://localhost:5000/home/login?type=signin",
	},

	Gitlab: {
		ExchangeTokenURL: "https://gitlab.com/oauth/token",
		GetProfileUrl: "https://gitlab.com/oauth/userinfo",
		client_id: "97c791c726b225fbed14cb6fdbcada91d5a0c0455b82c19abf20bdf6ee2ce55a",
		client_secret: "eb4cca7e9e38ad2375ffec9327aa3b421278659da1fa7b83cefa734a3f75c326",
		grant_type: "authorization_code",
		redirect_uri: "http://localhost:5000/home/login?type=signin",
	},

	Vendor: {
		Google: "google-auth-library"
	}
}

module.exports = SSO;
