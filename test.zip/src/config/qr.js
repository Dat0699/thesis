const QR = {
	Enable			: true,
    Vendor          : "qrcode",
}

module.exports = QR;
