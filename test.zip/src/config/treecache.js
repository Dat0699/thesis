const TreeCache = {
	Enable			: false,
	UseDatabase		: true,

	GroupName		: "defTree",
	DBKeyName		: "path",
	NodeValueKey	: "value",

    DataPath		: "../uploads",
	Interval		: 10, // 15 seconds
	Expired			: 5, // 7200 second -> 2 hours
}

module.exports = TreeCache;
