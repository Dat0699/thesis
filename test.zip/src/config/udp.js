const UDP = {
	Enable 				: false, // if Using Pubsub or Cache, it willbe turn automatically to true.

	UDPPort				: 8083,
	ServerIP			: "0.0.0.0",

	UDPMaxCCU			: 500,
	MaxBufferSend		: 65507, // (2^16 = 65535) - 8 - 20 = 65507
	MaxBufferRecv		: 5000000, // Default 786896
	MaxSendUDPSocket	: 1000, // 1000 send socket

	TimeOut				: 2, // Expired in 3 seconds.
	DataPath			: "../udpPath",
	Interval			: 3, // 300 seconds ~ 5 minutes.
	TokenDefExpired		: 10, // 10 second,

	RemoteTypeVersion	: "udp4",
	TopologyType		: "per", // (per, star), per: broadcost all White List. star: send only to Root-star-node server.
	TopologyRole		: "root", // (member, root), member: You are a node in star, root: you are a root-star
	StarIP				: "127.0.0.1",  // Only apply for Star Topology

	// When TopologyType == star, this WhiteList os only StarIP
	ListMembers			: [
		"127.0.0.1",
	],
}

// Tested ~ 1000 CCU for UDP PubSub send-recieve.

/*
	UDP Event for Member:

	// For flow describe and Root
	1. token-issued (Root handle, Member send to Root, Root Save, Root send back to Member saved status).
	2. token-query (Root handle, Member send this token to Root, Root check valid or not, and send back to member stored-value, Member save this stored-value).
	3. token-expired (Root handle, Root and Member auto check local and delete this token).
	4. token-revoked (Root handle, Member send revoke to Root, Root broadcast to all other members).
	5. token-refresh (Root handle, Member sent to Root, Root return back to Member).
	6. chat-connected (Root handle, Member send to Root, Root return back to Member).
	7. chat-disconnected (Root handle, Member send to Root, Root return back to Member).
	8. chat-message (Root handle, Member send to Root, Root check and send to specific client).
	9. chat-refresh (Root handle, Member send to Root to notify the connection still alive to refresh this token).

	When Member recieve event it process event:
	1. token-issued (Member handle, Member invole callback id).
	2. token-query (Member handle, Member save this token return from Root, and invoke callback id).
	3. token-expired (Member handle, Root and Member auto check local and delete this token).
	4. token-revoked (Member handle, Member check all token and delete invoked token).
	5. token-refresh (Member handle, Member invoke callback id).
	6. chat-connected (Member handle, Member invoke callback id).
	7. chat-disconnected (Member handle, Member invoke callback id).
	8. chat-message (Member handle, Member send message to client device/socket id).
	9. chat-refresh (Member handle, Member invoke callback id).
*/

// This Use for Tunneling server to server
module.exports = UDP;
