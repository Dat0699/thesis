const Web = {
	Enable 			: false,
	FilePath		: "./src/web",
	WebPort			: 8089,
	Index			: "client.html",

	UseCache		: true,
	UseZIP			: true,

	CachedTime		: 100, //10 * 84600, = 10 days, now is 100 seconds
	FileNotFound	: "./src/web/error.html",

	BasicAuth		: false,
	BasicExtURL		: "http://localhost:8082/ext/auth",
	BasicExtMethod	: "POST",
	BasicExcepts	: [
		"login",
		"signup",
		"forget",
		"reset",
	],

	// chrome://flags/#allow-insecure-localhost
	//UseSSL			: false,
	//httpVersion		: 1.0,
	//allowHTTP1		: false,
	UseSSL			: false,
	key				: "./cert/localhost-key.pem",
	cert			: "./cert/localhost-cert.pem",
	httpVersion		: 1.1,
	//allowHTTP1		: true,
	UseH2Push		: true,

}

module.exports = Web;
