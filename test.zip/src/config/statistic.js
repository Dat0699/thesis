const Statistic = {
	Enable      	: false,

    Threshold   	: 240,
    ServerURL   	: "http://localhost:5050/user/123",
    Method      	: "GET",

}

module.exports = Statistic;
