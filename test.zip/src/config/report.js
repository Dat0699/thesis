const Report = {
	Enable      : false,

	ServerURL	: "http://localhost:5050/report/123",
	Method		: "GET",

}

module.exports = Report;
