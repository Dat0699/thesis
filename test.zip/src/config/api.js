const API = {
	Enable				: true,
	EnableProfiling		: true,

	UseZip				: true,
	TokenKeyName		: "user-token",

	UserCaches			: true,
	cachedTime			: 500,

	ServerIP			: "@Premium.ServerIP",
    ServerPort          : 12000,// + parseInt(Math.random()*100),
    APIMaxBody  	    : 25 * 1024 * 1024, // 25 MB

    defaultPageLength   : 25,
    defaultPageIndex    : 0,
    maxPageLimit        : 100,

	APIMaxCCU			: 2000, // Limits concurrent API

    DataPath            : "../data/uploads",
	TimeOut				: 15, // 15 seconds

	Enable7Zip			: true,

	//ExConfig			: "http://gcore.gitgam.com/anc.com",

	// Override MimeType
	MimeType			: {},

	imCompany           : true,

	WebURL				: "@Premium.WebServer",

	SvrIntFile			: "@(Premium.FileInternServer + '/internal/__d3lcte^-^Int9rn41__')",
	SvrIntDocument		: "@(Premium.DocInternServer + '/internal/__d3lcte^-^Int9rn41__')",
	SvrIntSource		: "@(Premium.GitInternServer + '/internal/__d3lcte^-^Int9rn41__')",

	FeatureConfig		: {
		//vmmachine		: false,
		accounting		: false,
		//warehouse		: false,
		campaign		: false,
		salary			: false,
		recruitment		: false,
		survey			: false,
		//helpdesk		: false,
		//cicd			: false,
		//chat			: false,
		disableList		: "vmmachine, accounting, campaign, salary, recruitment, survey" // vmmachine, helpdesk, cicd, chat
	}
}

module.exports = API;
