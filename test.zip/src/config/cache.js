const Cache = {
	Enable 				: false,

	CachePort			: 8084,
	ServerIP			: "0.0.0.0",

	CacheMaxCCU			: 500,
	MaxBufferSend		: 65507, // (2^16 = 65535) - 8 - 20 = 65507
	MaxBufferRecv		: 5000000, // Default 786896

	RemoteTypeVersion	: "udp4",
	RemoteHost			: "127.0.0.1",
	RemotePort			: "8084",

	TopologyType		: "per", // (per, star), per: broadcost all White List. star: send only to Root-star-node server.
	StarIP				: "127.0.0.1",
	StarPort			: 9003,

	DataPath			: "../cachePath",
	WhiteLists			: [
		"127.0.0.1",
	],

}

// This Cache used for issues session, token.
module.exports = Cache;
