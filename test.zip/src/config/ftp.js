const FTP = {
	Enable 			: false,
	EnableLog		: false,

	EnableLFS		: true,
	EnableLockAPI	: true,

	EnableLOC		: true,

	EnableNFS		: false,
	// Server export : /var/shared	*(rw,sync,no_subtree_check,all_squash,anonuid=999,anongid=999)
	NFSPaths		: [{
		client		: "/gamftp/ftp-data",
		server		: "gitgam.com:/var/shared/ftp-data",
	}],

	Port			: 33,
	Family			: "any",
	BindIP			: "0.0.0.0",

	MaxTries		: 6,
	MaxSession		: 2000,

	CommandBindIPs	: [], // list IPs
	CommandUser		: "gftp",
	CommandUserID	: 999,
	CommandHome		: "/gamftp",

	PermitRootLogin	: false,
	AliveInterval	: 120, // 120 second
	UseForceCommand	: true,

	SSHMoreConfig	: ``, // Add mode test Line by line line

	FileMaxSize		: 4000000000, // ~ 4GB
	PushSizeMax		: 20000000000, // ~ 20GB
	PushFileMax		: 10000, // 5000 files

	ShellPath		: "/gamsys/ftp-shell",
	ShellKeyPath	: "/gamsys/ftp-keys",
	HookPath		: "/gamsys/ftp-hook",
	DataPath        : "/gamftp/ftp-data",
	//RepoPath        : "/gamftp/ftp-repo",
	TmpPath			: "/gamftp/ftp-temp",

	KeyAuthMethod	: "POST",
	KeyAuthURL		: "http://127.0.0.1:8085/git/ssh/auth",

	ForceCmdMethod	: "POST",
	ForceCmdURL		: "http://127.0.0.1:8085/git/ssh/cmd",

	HookURL			: "http://127.0.0.1:8085/hook",

	PreInstallLFS	: "curl -s https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh | sudo bash",
	InstallTool		: "apt-get",
	DebugMode		: false,
}

module.exports = FTP;
