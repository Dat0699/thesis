const InviteMemberView = {};

// Function render is required function to help GStart request view.
InviteMemberView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h3>You were invited to ${ctx.data.company.name}</h3>
		<p>URL: ${pipeData.K.API.WebURL}/home/login?type=confirmation&company=${ctx.data.company._id}&name=${encodeURIComponent(ctx.data.company.name)}&token=${ctx.data.token}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = InviteMemberView;
