const Milestone = {};


// Function render is required function to help GStart request view.
Milestone.render = (Req, pipeData, ctx, extra) => {
	var url = "";
	var title = `<h4>[Milestone] ${ctx.data?.nameSender} just announce to you in milestone #${ctx?.data?.number} of project ${ctx.data?.project?.name} </h4>`;
	if((Req?.query?.planning+"").trim() == 'true') {
		title = `<h4>[Feature Planning] ${ctx.data?.nameSender} just announce to you in feature planing</h4>`
		url = `<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/feature/planning/?date=allTime&milestones=${ctx?.data?.idItem}">Open for detail</a>`
	} else {
		url = `<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/milestone/${ctx?.data?.number}">Open for detail</a>`
	}


	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		${title}
		${url}
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = Milestone;
