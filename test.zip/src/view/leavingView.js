const LeavingView = {};


// Function render is required function to help GStart request view.
LeavingView.render = (Req, pipeData, ctx, extra) => {
	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>${ctx.data?.name} just ${ctx.data.status} to you for leaving </h4>
		<h4>Type: ${ctx.data?.type} </h4>
		<h4>Start Date: ${ctx.data?.startDate} </h4>
		<h4>End Date: ${ctx.datat?.endDate} </h4>
		<a href="${pipeData.K.API.WebURL}/calendar/leaving/${ctx.data?.number}?mode=detail">Open for detail</a>
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = LeavingView;
