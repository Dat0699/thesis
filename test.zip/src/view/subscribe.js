const Approve = {};

// Function render is required function to help GStart request view.
Approve.render = (Req, pipeData, ctx, extra) => {

	var txt = "";
	if(ctx.data == "subscribe") {
		txt = `<p>Thank you for you ${ctx.data} GitGam!</p>`;

	} else {
		txt = `
			</p>Please press <a href="${pipeData.K.API.WebURL}/home/about?otp=${Req.body.otp}">this link<a> to unsubscribe GitGam!</p>
		`;
	}

	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		${txt}
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`};

module.exports = Approve;
