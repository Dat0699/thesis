const User = {};

User.render = (Req, Body, D) => {`
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		${Req}
		${Body}
		${D}
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}

module.exports = User;
