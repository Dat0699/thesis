const ForgetView = {};

// Function render is required function to help GStart request view.
ForgetView.render = (Req, pipeData, ctx, extra) => {
	var url = `${pipeData.K.API.WebURL}/home/login?type=verification&email=${ctx.data.userdb.email}&code=${ctx.data.code}&enable=true&time=${(new Date()).getTime()}`;

	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h3>Request to change your password</h3>
		<p><a href="${url}">Click here</a> to change your password, or Input OTP code below.</p>
		<p>OTP Code: ${ctx.data.code}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`;}

module.exports = ForgetView;
