const AddUserView = {};

// Function render is required function to help GStart request view.
AddUserView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h3>ACTIVATE USER COMPANY</h3>
		<p>Activated Code: ${ctx.data.token}</p>
		<p>CompanyId: ${ctx.data.companyId}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = AddUserView;
