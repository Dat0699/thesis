const TaskView = {};

// Function render is required function to help GStart request view.
TaskView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
    <p>
      ${Req.user.name} ${ctx.data.type} task:
      <a href="${pipeData.K.API.WebURL}/project/${ctx.data.shortName}/task/${ctx.data.number}">#${ctx.data.number}</a>
      at ${ctx.data.time}
    </p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`
module.exports = TaskView;
