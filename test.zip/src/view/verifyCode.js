const VerifyCodeView = {};

// Function render is required function to help GStart request view.
VerifyCodeView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h3>Activate you account</h3>
		<p>URL: ${pipeData.K.API.WebURL}/home/login?type=verification&sn=${encodeURI(ctx.data.shortName)}&code=${ctx.data.code}&time=${(new Date()).getTime()}</p>
		<p>Activated Code: ${ctx.data.code}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = VerifyCodeView;
