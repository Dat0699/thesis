const WelcomeMemberView = {};

// Function render is required function to help GStart request view.
WelcomeMemberView.render = (Req, pipeData, ctx, extra) => `
            </td>
        </tr>
		<tr>
            <td style="border-top: 1px solid #b8b8b8;background-color: #FbFbFb;">
                <table style="margin: auto; text-align: center; padding: 10px;">
                    <tr style="height: 25px;">
                        <td style="align-items: center;">
                            <a style="text-decoration: none;font-family: Roboto;font-size: 12px;font-style: italic;font-weight: 700;line-height: 14.06px;letter-spacing: 0em;text-align: center;color: #219653;"
                                href="https://gitgam.com">
                                GitGam - IT Project Management
                            </a>
                        </td>
                    </tr>
                    <tr style="height: 25px;">
                        <td>
                            <a style="text-decoration: none;font-family: Roboto;font-size: 14px;font-style: normal;font-weight:
                                400;line-height: 16.41px;letter-spacing: 0em;text-align: center;margin-top: 10px;color: black;"
                                href="mailto:hello@gitgam.com">Contact us via hello@gitgam.com
                            </a>
                            <a style="text-decoration: none;font-family: Roboto;font-size: 14px;font-style: normal;font-weight:
                                400;line-height: 16.41px;letter-spacing: 0em;text-align: center;margin-top: 10px;color: black;"
                                href="https://gitgam.com">or https://www.gitgam.com
                            </a>
                    </tr>
                    <tr>
                        <td
                            style="font-family: Roboto;font-size: 10.5px;font-style: normal;font-weight: 400;line-height: 14px;letter-spacing: 0em;text-align: center;border-top: 1px solid #B9B9B9;max-width: 580px; padding: 8px;">
                            This email is confidential and may be privileged. If you are not the intended recipient, please delete it and notify us immediately. You should not copy or use it for any purpose, nor disclose its contents to any other person. Thank you.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

</body>

</html>
`

module.exports = WelcomeMemberView;
