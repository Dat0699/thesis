const CheckinView = {};

// Function render is required function to help GStart request view.
CheckinView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<p>${Req.user.name} just ${ctx.data.type} at ${('0'+Math.floor(ctx.data.time/3600)).substr(-2)}:${('0'+Math.floor((ctx.data.time%3600)/60)).substr(-2)}.</p>
		<p>${!ctx.data.hour ? "" : `Total hour: ${ctx.data.hour.toFixed(2)}.`}</p>
		<p>${ctx.data.comeLateHour > 0 ? `Come late ${ctx.data.comeLateHour.toFixed(2)} hour.` : ""}</p>
		<p>${ctx.data.backEarlyHour > 0 ? `Back early late ${ctx.data.backEarlyHour.toFixed(2)} hour.` : ""}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = CheckinView;
