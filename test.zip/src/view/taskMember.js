const TaskMemberView = {};

// Function render is required function to help GStart request view.
TaskMemberView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
	<p>
    ${Req.user.name} ${ctx.data.subType} ${ctx.data.member.name} task:
    <a href="${pipeData.K.API.WebURL}/project/${ctx.data.shortName}/task/${ctx.data.number}">#${ctx.data.number}</a>
    at ${ctx.data.time}
    </p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = TaskMemberView;
