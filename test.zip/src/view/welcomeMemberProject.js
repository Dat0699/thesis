const WelcomeMemberProjectView = {};

// Function render is required function to help GStart request view.
WelcomeMemberProjectView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4> You were invited to <h3>${Req.project.name}</h3> </h4>
		<p>User Email: ${Req.userAdd.email}</p>
		<a href="${pipeData.K.API.WebURL}/project/${Req.project.shortName}/dashboard">Open Project</a>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = WelcomeMemberProjectView;
