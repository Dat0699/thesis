const LogtimeView = {};

// Function render is required function to help GStart request view.
LogtimeView.render = (Req, pipeData, ctx, extra) => {
	var hour = ctx?.data?.body?.hour || Req?.popBody?.hour || 0;
	console.log('ctx',ctx);
	console.log('Req',Req?.user);
	var content = `<p>${Req?.user?.name} just ${ctx?.data?.type} a ${(hour-0).toFixed(2)} hours logtime, item #${ctx?.data?.body?.number || ctx?.data?.body?.number}.</p>`
	if(hour == 0) {
		content = `<p>${Req?.user?.name} just ${ctx?.data?.status} your log time task item #${ctx?.data?.body?.number || ctx?.data?.body?.number}.</p>`
	}

return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		${content}
		<p>${ctx?.data?.body?.content || ""}</p>
		<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/task/${ctx?.data?.number}?mode=detail">Open for detail</a>

	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`;}

module.exports = LogtimeView;
