const DailyReportView = {};

// Function render is required function to help GStart request view.
DailyReportView.render = (Req, pipeData, ctx, extra) =>  {
	return `
		${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
			<h4>${ctx?.data.name} just ${ctx?.data?.status} to daily report ${ctx?.data?.number}  </h4>
			<a href="${pipeData.K.API.WebURL}/dailyreport/${ctx?.data?.number}">Open for detail</a>
			
		${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
	`}
module.exports = DailyReportView;
