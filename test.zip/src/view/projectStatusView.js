const ProjectStatusView = {};


// Function render is required function to help GStart request view.
ProjectStatusView.render = (Req, pipeData, ctx, extra) => {
	console.log('ctx', ctx);
	
	var template = ``;

	if(ctx?.data?.typeAction == 'locked') {
		template = `<h4>Please contact admin for more information</h4>`;
	}

	if(ctx?.data?.typeAction == 'unlocked') {
		template = `<a href="${pipeData.K.API.WebURL}/project/${Req?.project?.shortName}/">Go to project</a>`
	}

	if(ctx?.data?.typeAction == 'completed') {
		template = `<h4>Congratulate ! Your project have been completed </h4>`;
	}

	if(ctx?.data?.typeAction == 'reopened') {
		template = `<a href="${pipeData.K.API.WebURL}/project/${Req?.project?.shortName}/">Go to project</a>`
	}


	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>[Project] ${Req?.project?.name} was ${ctx?.data?.typeAction} by  ${Req?.user?.name} </h4>
		${template}
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = ProjectStatusView;
