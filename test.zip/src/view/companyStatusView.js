const CompanyStatusView = {};


// Function render is required function to help GStart request view.
CompanyStatusView.render = (Req, pipeData, ctx, extra) => {
	console.log('ctx', ctx);
	
	var template = ``;

	if(ctx?.data?.typeAction == 'locked') {
		template = `<h4>Please contact admin for more information!</h4>`;
	}

	if(ctx?.data?.typeAction == 'unlocked') {
		template = `<a href="${pipeData.K.API.WebURL}">Go to company</a>`
	}

	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>[Company] ${Req?.company?.name} was ${ctx?.data?.typeAction} by  ${Req?.user?.name} </h4>
		${template}
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = CompanyStatusView;
