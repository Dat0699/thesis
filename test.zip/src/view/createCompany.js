const CreateCompanyView = {};

// Function render is required function to help GStart request view.
CreateCompanyView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h3>ACTIVATE COMPANY</h3>
		<p>URL: ${pipeData.K.API.WebURL}/home/login?type=activate&name=${encodeURIComponent(ctx.data.company.name)}&token=${ctx.data.token}</p>
		<p>Activated Code: ${ctx.data.token}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = CreateCompanyView;
