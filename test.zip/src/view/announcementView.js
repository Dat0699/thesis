const AnnouncementView = {};

// Function render is required function to help GStart request view.
AnnouncementView.render = (Req, pipeData, ctx, extra) =>  {
	return `
		${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
			<h3> You were being on the announcement #${ctx?.data?.number} </h3>
			<a href="${pipeData.K.API.WebURL}/announcement/${ctx?.data?.number}">Open for detail</a>
		${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
	`}
module.exports = AnnouncementView;
