const DeleteTaskView = {};

// Function render is required function to help GStart request view.
DeleteTaskView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
	<p>Task #${ctx.data.number} was deleted by ${Req.user.name} at ${ctx.data.time}</p>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = DeleteTaskView;
