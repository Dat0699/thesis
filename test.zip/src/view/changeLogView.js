const RiskView = {};


// Function render is required function to help GStart request view.
RiskView.render = (Req, pipeData, ctx, extra) => {
	console.log('ctx', ctx);
	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>[ Risk ] ${ctx?.data?.nameSender} just announce to you in risk #${ctx?.data?.number} of project ${ctx?.data?.project?.name} </h4>
		<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/changelog/${ctx.data?.number}?mode=detail">Open for detail</a>
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = RiskView;
