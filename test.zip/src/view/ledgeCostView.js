const LedgeCostView = {};


// Function render is required function to help GStart request view.
LedgeCostView.render = (Req, pipeData, ctx, extra) => {
	console.log('ctx', ctx);
	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>[Ledger Cost] ${ctx.data?.nameSender} just announce you in cost ledger #${ctx.data?.number} of project ${ctx.data?.project?.name} </h4>
		<a href="${pipeData.K.API.WebURL}/project/${ctx.data?.project?.shortName}/cost/ledger/${ctx.data?.number}?mode=detail">Open for detail</a>
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = LedgeCostView;
