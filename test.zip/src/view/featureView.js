const FeatureView = {};

// Function render is required function to help GStart request view.
FeatureView.render = (Req, pipeData, ctx, extra) =>  {
	return `
		${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
			<h3>[Feature] ${ctx?.data?.request?.name} just ${(ctx?.data?.action)?.toLowerCase()} in item #${ctx?.data?.number} in project ${ctx?.data?.project?.name} </h3>
			<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/feature/list/${ctx?.data?.number}">Open for detail</a>
		${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
	`}
module.exports = FeatureView;
