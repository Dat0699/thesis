const SprintView = {};


// Function render is required function to help GStart request view.
SprintView.render = (Req, pipeData, ctx, extra) => {
	console.log('ctx', ctx);
	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4>[ Sprint ] ${ctx.data?.nameSender} just announce to you in sprint #${ctx?.data?.number} of project ${ctx.data?.project?.name} </h4>
		<a href="${pipeData.K.API.WebURL}/project/${ctx?.data?.project?.shortName}/feature/planning/?date=allTime&sprints=${ctx.data?.idItem}&milestones=${ctx.data?.milestoneId}">Open for detail</a>
		
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`}
module.exports = SprintView;
