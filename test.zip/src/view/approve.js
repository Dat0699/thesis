const Approve = {};

// Function render is required function to help GStart request view.
Approve.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
	    <p> #${ctx.data.number || ctx.data.name} đã ${ctx.data.status} at ${ctx.data.date}</p> 
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = Approve;
