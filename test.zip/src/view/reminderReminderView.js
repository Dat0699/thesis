const ReminderReminderView = {};

// Function render is required function to help GStart request view.
ReminderReminderView.render = (Req, pipeData, ctx, extra) =>  {
	let info = ctx?.data;
	var reminder = `<h3> Your ${info?.title} is happening </h3>`;

	if(info?.type == 'remind') {
		reminder = `<h3> Your ${info?.title} will be happening in ${info?.remindBefore} miniute </h3>`;
	}

	return `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
			${reminder}
			<a href="${pipeData.K.API.WebURL}/calendar/board/reminder/${info?.refNumber}">Open for detail!</a>
		${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
	`}
module.exports = ReminderReminderView;
