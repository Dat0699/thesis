const WelcomeMemberView = {};

// Function render is required function to help GStart request view.
WelcomeMemberView.render = (Req, pipeData, ctx, extra) => `
	${pipeData.V.ZHeader.render(Req, pipeData, ctx, extra)}
		<h4> You were invited to <h4>${Req.company.name}</h3> </h4>
		<p>User Email: ${Req.body.email}</p>
		<p>OTP Code: ${Req.code}</p>
		<a href="${pipeData.K.API.WebURL}/home/login?type=verification&email=${Req.body.email}&code=${Req.code}&atx=${Req.token}&time=${(new Date()).getTime()}&extra=welcome">Click Here to update your password and Login!</a>
	${pipeData.V.ZFooter.render(Req, pipeData, ctx, extra)}
`

module.exports = WelcomeMemberView;
