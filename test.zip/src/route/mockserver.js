const MockServerRoute = {
	route	: "/mock/server",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

MockServerRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject:`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var user = Req.user || {};

		if(!body.members || (body.members.length <= 0)) {
			body.members = [{
				user: user._id,
				role: {
					//create: true,
					modify: true,
					delete: true,
					action: true,
				}
			}];
		}

		return Req.UNRESULT;
	}],

	`A.verifyInput:: mockserver: groupId, projectId!, number-, ...`,
	`A.insertOne: mockserver`,

	`A.pipeRoute: mockserver: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockServerRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.findOne: mockserver:`,
	`A.verifyInput:: mockserver: _id-, number-, ...`,

	`A.formatString > name: "{{name}} - cloned"`,
	`A.insertById > P.server: mockserver`,

	`A.cloneById(*) > P.lookUp: mockgroup:: {serverId: "@P.route._id"}: {serverId: "@P.server._id"}: 1000: true: _id-, number-`,
	`A.cloneById(*) > P.newApis: mockapi:: {serverId: "@P.route._id"}: {serverId: "@P.server._id"}: 1000:: _id-, number-, P.lookUp.map.$ => groupId`,

	//`A.printObject(*): P.newApis`,
	//`A.printObject(*): P.lookUp`,

	/*
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;

		var A = pipeData.A;
		var server = await A.insertById(Req, pipeData, "mockserver", body);

		var ngs = [];
		var groups = await A.findMany(Req, pipeData, "mockgroup", {serverId: Req.route._id});
		for (var i = 0; i < groups.length; i++) {
			var group = groups[i] || {};
			group.serverId = server._id;

			ngs[i] = group._id;
			delete group._id;
			delete group.number;
		}

		var ng = {};
		var ngroups = await A.insertMany(Req, pipeData, "mockgroup", groups, 500);
		for (var i = 0; i < ngroups.length; i++) {
			ng[(ngs[i]||"").toString()] = (ngroups[i]||{})._id;
		}

		var apis = await A.findMany(Req, pipeData, "mockapi", {serverId: Req.route._id});
		for (var i = 0; i < apis.length; i++) {
			var api = apis[i];
			if(api) {
				api.serverId = server._id;
				api.groupId = ng[(api.groupId||"").toString()];

				delete api._id;
				delete api.number;
			}
		}

		var napis = await A.insertMany(Req, pipeData, "mockapi", apis, 2000);
		return Req.UNRESULT;
	}],
	*/

	`A.pipeRoute: mockserver: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockServerRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var name = (pipeData.name || pipeData.search) || (pipeData.title || pipeData.text);
		pipeData.name = Req.func.getASCIISearch(name||"", "gmi");
		pipeData.number = (name - 0) || -1;

		pipeData.searchExistFilter = {};
		if(name) {
			// use to filter empty list
			pipeData.searchExistFilter = {anyKey: "__anyValue__"};
		}

		var mockServerIds = (pipeData._id || pipeData.serverId) ||
							(pipeData.servers || pipeData.serverIds) || [];
		if(mockServerIds) {
			if(!Array.isArray(mockServerIds)) {
				mockServerIds = [mockServerIds];
			}
		}
		pipeData.mockServerIds = mockServerIds;

		pipeData.projectId = Req.project._id;
		pipeData.keepItem = !name;

		var user = Req.user;
		pipeData.userId = user._id;
		pipeData.isAdmin = user.hasAdmin || user.hasAgent;

		//console.log(JSON.stringify(pipeData));
        return pipeData;
    }],

    [`A.aggregate: mockserver:`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@projectId"]},
			{ $or: [
				{ $in: ["$_id", "@mockServerIds"]},
				{ $in: ["@mockServerIds", [undefined, null, "", false, [], 0]]},
			]},
		]}}},

		// Check permitted
		{ $addFields: {
			permit: { $cond: [
				{ $eq: ["@isAdmin", true]},
				[{ user: "__anyValue__", role: {
					create: true,
					modify: true,
					delete: true,
					action: true,
				}}],
				{ $filter: {
					input: "$members",
					as: "member",
					cond: { $eq: ["$$member.user", "@userId"] }
				}},
			]}
		}},
		{ $unwind: {
			path: "$permit",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			permit: "$permit.role"
		}},

		// mock Group
		{ $lookup: {
			from: "mockgroup",
			let: { serverId: "$_id" },
			pipeline: [
				{ $match: {
					$expr: {
						$and: [
							{ $eq: ["$serverId", "$$serverId"] },
							//{ $eq: ["$projectId", "@projectId"] },
						]
					}
				}},

				// mock API
				{ $lookup: {
					from: "mockapi",
					let: { groupId : "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ "$eq": [ "$groupId", "$$groupId" ] },
							//{ $eq: ["$projectId", "@projectId"] },
							{ $or: [
								{ $regexMatch: { input: "$name", regex: "@name"} },
								{ $eq: ["$number", "@number"] }
							]}
						]}}},

						{ $sort: {
							colIndex: 1,
						}},

						{ $project: {
							_id: 1,
							name: 1,
							name2: 1,
							number: 1,
							colIndex: 1,

							method: 1,
							route: 1,

					        resHeaders: 1,
					        resBody: 1,
							resCode: 1,
						}}
					],
					as: "apis"
				}},

				{ $sort: {
					colIndex: 1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					route: 1,
					colIndex: 1,
			        resHeaders: 1,
			        resBody: 1,
					apis: 1,
				}},
				{ $match: { $expr: { $or: [
					{ $eq: ["@keepItem", true]},
					{ $gt: [{ $size: "$apis"}, 0]},
				]}}}
			],
			as: "groups"
		}},

		{ $sort: {
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			colIndex: 1,

			host: 1,
			port: 1,
			route: 1,

	        resHeaders: 1,
	        resBody: 1,
			groups: 1,
			permit: 1,
		}},
		{ $match: { $expr: { $or: [
			{ $eq: ["@keepItem", true]},
			{ $gt: [{ $size: "$groups"}, 0]},
		]}}}
	]]
], { useZip: true }]);

MockServerRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = [{
			$eq: ["$projectId", Req.project._id]
		}];

		var name = (pipeData.name || pipeData.search) || (pipeData.title || pipeData.text);

		pipeData.searchExistFilter = {};
		if(name) {
			// use to filter empty list
			var number = (name - 0) || -1;
			name = Req.func.getASCIISearch(name||"", "gmi");

			ops.push({$or: [
				{ $regexMatch: { input : "$name", regex: name }},
				{ $eq: ["$number", number] }
			]});
		}

		var user = Req.user;
		pipeData.userId = user._id;
		pipeData.isAdmin = user.hasAdmin || user.hasAgent;

		pipeData.ops = ops;
		//console.log(JSON.stringify(ops));
        return pipeData;
    }],

    [`A.aggregate: mockserver:`, [
		{ $match: { $expr: { $and: "@ops" }}},

		// Check permitted
		{ $addFields: {
			permit: { $cond: [
				{ $eq: ["@isAdmin", true]},
				[{ user: "__anyValue__", role: {
					//create: true,
					modify: true,
					delete: true,
					action: true,
				}}],
				{ $filter: {
					input: "$members",
					as: "member",
					cond: { $eq: ["$$member.user", "@userId"] }
				}},
			]}
		}},
		{ $unwind: {
			path: "$permit",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			permit: "$permit.role"
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			permit: 1,
		}},
	]]
]]);

MockServerRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var _id = Req.route._id;

		pipeData._id = _id;
		pipeData.number = (_id-0);

		var user = Req.user;
		pipeData.userId = user._id;
		pipeData.isAdmin = user.hasAdmin || user.hasAgent;

		//console.log(JSON.stringify(pipeData));
        return pipeData;
    }],

	//`<F1>A.findOne(P.route): mockserver: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
	[`A.aggregateOne: mockserver:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$_id", "@_id"]},
			{ $eq: ["$number", "@number"]},
		]}}},

		// Check permitted
		{ $addFields: {
			permit: { $cond: [
				{ $eq: ["@isAdmin", true]},
				[{ user: "__anyValue__", role: {
					create: true,
					modify: true,
					delete: true,
					action: true,
				}}],
				{ $filter: {
					input: "$members",
					as: "member",
					cond: { $eq: ["$$member.user", "@userId"] }
				}},
			]}
		}},
		{ $unwind: {
			path: "$permit",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			permit: "$permit.role"
		}},
	]],

	`A.assertKeyExisted:: _id: Invalid request!`,
	`A.responseObject(*): 200: @P.body`
]]);

MockServerRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mockserver: number-, ...`,

	`A.updateById(*): mockserver: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: mockserver: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockServerRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,

	`A.deleteById(*): mockserver: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.deleteById(*): mockgroup: { serverId: "@P.route._id", projectId: "@P.project._id" }: true: true`,
	`A.deleteById(*): mockapi: { serverId: "@P.route._id", projectId: "@P.project._id" }: true: true`,

	`A.pipeRoute: mockserver: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

// ----------- Member update -------------------
MockServerRoute.POST.push([[":_id/member/add"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.verifyInput:: mockserver: members!`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = pipeData.members;
		if(!Array.isArray(data)) {
			data = [data];
		}

		// to make sure data alway correct.
		//console.log("Data: ", data);
		data = data.filter(item => {
			return item.user && item.role;
		});

		Req.body = { members: data };
		return Req.UNRESULT;
	}],

	//`A.printObject`, // Remove than insert
	`A.removeSubItem(*) > dbData: mockserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body.members: user`,
    `A.insertSubItem(*) > dbData: mockserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body.members`,
    `A.responseObject: 200: Add member successfully!`
]]);

MockServerRoute.POST.push([[":_id/member/remove"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.verifyInput:: mockserver: members!`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = pipeData.members;
		if(Array.isArray(data)) {
			data = data[0];
		}

		data = data.user || data;
		Req.body = { members: data };
		return Req.UNRESULT;
	}],

	//`A.printObject`,
    `A.removeSubItem(*) > dbData: mockserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body.members: user`,
    `A.responseObject: 200: Remove member successfully!`
]]);

MockServerRoute.DELETE.push([[":_id/member/remove/:userId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.query.projectId: roleproject: postapi.view, postapi.modify`,

    `A.removeSubItem(*): mockserver: {_id: "@P.route._id", projectId: "@P.project._id"}: members: {user: "@P.route.userId"}`,
    `A.responseObject: 200: Remove member successfully!`
]]);

MockServerRoute.POST.push([[":_id/member/update"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.verifyInput:: mockserver: members!`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = pipeData.members;
		if(Array.isArray(data)) {
			data = data[0];
		}

		Req.body = data;
		return Req.UNRESULT;
	}],

	//`A.printObject`,
    `A.updateSubItem(*) > dbData: mockserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body: user`,
    `A.responseObject: 200: Update member successfully!`
]]);

MockServerRoute.PIPE.push([["checkAccessMockServer"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var user = Req.user || {};
		var userId = user._id.toString();

		var checkRoles = Object.keys(Req.body || {}).role || "";
		checkRoles = checkRoles.split(/[\s\t]{0,}[,:]{1,}[\s\t]{0,}/gmi);

		var passed = false;
		var server = await A.findOne(Req, pipeData, "mockserver", {_id: Req.route._id});
		if(server && server._id) {
			if(!user.hasAdmin && !user.hasAgent) {
				var members = server.members;
				if(member && (members.length > 0)) {
					for (var i = 0; i < members.length; i++) {
						var n = members[i];
						if((m.user||"").toString() == userId) {
							passed = true;

							if(checkKeys.length > 0) {
								passed = false;

								var role = m.role;
								if(role) {
									passed = true;

									for (var i = 0; passed && (i < checkRoles.length); i++) {
										var key = checkRoles[i];
										if(!role[key]) {
											passed = false;
											break;
										}
									}
								}
							}
						}
					}
				}
			}

			if(!passed) {
				return {
					respCode: 500,
					respReturn: true,
					respData: "You were not permitted!",
				};
			}

			//await A.checkExistItem(Req, pipeData, "postserver", {_id: Req.route.serverId, "members.user": user._id}, true, "You were not permitted!");
		}

		return Req.UNRESULT;
	}],
], { name: "checkAccessMockServer" }]);

module.exports = MockServerRoute;
