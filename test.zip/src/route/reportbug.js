const ReportBugRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
	}
};

ReportBugRoute.POST.push([[""], [
	`A.trimObject`,
	`A.verifyInput:: reportbug: title!, content, number-, hasGlobal-, ...`,
	`A.copyKObject(*):: P.company._id, P.body.companyId`,
	`A.insertOne: Public.reportbug`,
]]);

ReportBugRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.pipeRoute: checkFBPermit: {mode: "view"}`,

	[`A.aggregateOne(*): Public.reportbug`, [
		{ $match: { $and: [
			{ $or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]}
		]}},

		{ $match: { $expr: { $or: [
			{ $eq: ["$companyId", "@P.company._id"] },
			{ $eq: ["gitgam", { $toLower: "@P.company.shortName" }] },
			{ $eq: ["$hasGlobal", true] }
		]}}},

		//{ $populate: ["reportlabel", "labelIds", "_id", "labels"] },
		//{ $populate: ["attach", "_id", "refId", "attachs"] },

		{ $project: {
			_id: 1,
			number: 1,
			priority: 1,
			title: 1,
			title2: 1,
			content: 1,
			resolution: 1,
			createdAt: 1,
			creatorId: 1,
			status: 1,

			resolvedAt: 1,
			listingAt: 1,
			hasGlobal: true,
			companyId: 1,

			labelIds: 1,
			//attachs: 1,

			// "labels.name": 1,
			// "labels.name2": 1,
			// "labels.color": 1,

			// "attachs._id": 1,
			// "attachs.name": 1,
			// "attachs.name2": 1,
			// "attachs.path": 1,
			// "attachs.createdAt": 1,
			// "attachs.modifiedAt": 1,
			// "attachs.mimeType": 1,
		}}
	]],

	`A.pipeRoute: updateRole`,

	// `A.verifyKObject(P.route):: _id!: verify.idType`,
	//`<F1>A.findOne(P.route): Public.reportbug: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
], { useZip: true }]);

ReportBugRoute.POST.push([["/s"], [
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user || {};
		var company = Req.company || {};

		var hasGlobal = pipeData.hasGlobal;

		const name = (pipeData.title || pipeData.content) || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		var userIds = pipeData.userIds || pipeData.userId;
		var labels = (pipeData.labels || pipeData.label) || (pipeData.labelIds || pipeData.labelId);

		var hasSupport = pipeData.hasSupport || pipeData.hasSupported;
		if(company.shortName.toLowerCase() === "gitgam") {
			if(hasSupport) {
				if(user.hasAgent || user.hasAdmin || user.hasSupport) {
					hasGlobal = true;
				}
			}

		} else {
			hasSupport = false;
		}

		var type = pipeData.type || pipeData.types || [];
		if(!Array.isArray(type)) {
			type = [type];
		}

		var hasResolved = type.indexOf("resolved") >= 0;
		var hasUnresolved = type.indexOf("unresolved") >= 0;

		var hasListing = type.indexOf("listing") >= 0;
		var hasUnlisting = type.indexOf("unlisting") >= 0;

        var matchOps = [];
		if(hasResolved != hasUnresolved) {
			if(hasResolved) {
				matchOps.push({ status: 2 });
			} else {
				matchOps.push({ status: { $ne: 2 } });
			}
		}

		if(!hasGlobal) {
			// Tab Company Feedback
			matchOps.push({ companyId: Req.company._id });
			if(hasListing != hasUnlisting) {
				if(hasListing) {
					matchOps.push({ hasGlobal: true });
				} else {
					matchOps.push({ hasGlobal: { $ne: true } });
				}
			}

			if(!user.hasAdmin && !user.hasAgent) {
				matchOps.push({ creatorId: user._id });
			}

		} else {
			if(!hasSupport) {
				matchOps.push({ hasGlobal: !!hasGlobal }); // let deafuot value client pass
			}
		}

        if(name) {
            matchOps.push({ $or: [
				{ title: { $regex: Req.func.getASCIISearch(name, "gmi") }},
				{ number: (name-0) || -1 }
			]});
        }

		if(fromDate) {
			matchOps.push({ createdAt: { $gte: new Date(fromDate) }});
        }

		if(toDate) {
			matchOps.push({ createdAt: { $lte: new Date(toDate) }});
        }

		// In company yab, normal user just see what he created
		if(!hasGlobal) {
			if(!user.hasAdmin && !user.hasAgent) {
				userIds = [user._id];
			}
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				matchOps.push({ creatorId: { $in: userIds }});
			}
		}

		if(labels) {
			if(!Array.isArray(labels)) {
				labels = [labels];
			}

			if(labels.length > 0) {
				matchOps.push({ labelIds: { $elemMatch: { $in: labels }} });
			}
		}

		pipeData.matchOps = {};
		if(matchOps.length > 0) {
			pipeData.matchOps = { $and: matchOps };
		}

		//console.log("pipeData: ", matchOps, userIds);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: Public.reportbug`, [
		{ $match: "@matchOps" },
		{ $sort: {
			modifiedAt: -1,
			createdAt: -1,
		}},

		//{ $populate: ["reportlabel", "labelIds", "_id", "labels"]},
		//{ $populate: ["attach", "_id", "refId", "attachs"] },

		{ $getTotalLength: "@page" },

		{ $project: {
			_id: 1,
			number: 1,
			priority: 1,
			title: 1,
			title2: 1,
			content: 1,
			resolution: 1,
			createdAt: 1,
			creatorId: 1,
			status: 1,

			resolvedAt: 1,
			listingAt: 1,
			hasGlobal: true,
			companyId: 1,

			totalLength: 1,

			"labels._id": 1,
			"labels.name": 1,
			"labels.name2": 1,
			"labels.color": 1,

			"attachs._id": 1,
			"attachs.name": 1,
			"attachs.name2": 1,
			"attachs.path": 1,
			"attachs.createdAt": 1,
			"attachs.modifiedAt": 1,
			"attachs.mimeType": 1,
		}},

		{ $group: {
			_id: {
                month: { $month: "$createdAt" },
            },
			date: { $first: "$createdAt" },
			bugs: { $push: "$$ROOT"},
			totalLength : { "$first" : "$totalLength" }
		}},

		{ $sort: {
			date: -1
		}},

		{ $project: {
			"bugs.totalLength": 0,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "bugs"]},
	]],

	`A.pipeRoute: updateRole`,
	//`A.printObject:`,
	//`A.responseObject: 200: {"bugs": "@dbData"}`
], { useZip: true }]);

ReportBugRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

	`A.deleteOne(*): Public.reportbug: {_id: "@P.route._id"}`,
	`A.pipeRoute: deleteReportBug`,
	`A.responseObject: 200: Delete Feedback successfully!`
]]);

ReportBugRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

	`A.verifyInput:: reportbug: number-, companyId-, creatorId-, hasGlobal-, status-, ...`,
	//`A.refactorOutput:: number- , ...`,
	`A.updateOne(*): Public.reportbug: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject(*): 200: @P.body`
]]);

ReportBugRoute.PUT.push([[":_id/status"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		if(body.status == 2) { // Resolved/Approved
			body.resolvedAt = new Date();
		}

		Req.body = { status: body.status, resolvedAt: body.resolvedAt};
		return Req.UNRESULT;
	}],

	//`A.printObject:`,
	`A.verifyInput:: reportbug: status, resolvedAt`,
	//`A.printObject:`,
	`A.updateOne(*): Public.reportbug: {_id: "@P.route._id"}: @P.body`,
]]);

ReportBugRoute.PUT.push([[":_id/listing"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var hasGlobal = body.hasGlobal;

		Req.body = { hasGlobal, listingAt: new Date() };
		return Req.UNRESULT;
	}],

	`A.verifyInput:: reportbug: hasGlobal, listingAt`,
	`A.updateOne(*): Public.reportbug: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject(*): 200: @P.body`
]]);

// ReportBugRoute.POST.push([[":_id/attach"], [
// 	`A.insertSubItem(*) > attachId: Public.reportbug: @P.route._id: attachIds: @P.body.attachId`,
// 	`A.populate: Public.attach, attachId, _id, attach, +, name, name2, mimeType, length `,
//     `A.responseObject: 200: @attach`
// ]]);
//
// ReportBugRoute.PUT.push([[":_id/attach"], [
//     `A.removeSubItem(*): Public.reportbug: @P.route._id: attachIds: @P.body.attachId`,
//     `A.responseObject: 200: Remove attach successfully!`
// ]]);

ReportBugRoute.POST.push([[":_id/label"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

	`A.insertSubItem(*) > attachId: Public.reportbug: {_id: "@P.route._id"}: attachIds: @P.body.labelId`,
	`A.populate: Public.reportlabel, attachId, _id, attach, +, name, name2, mimeType, length `,
    `A.responseObject: 200: @attach`
]]);

ReportBugRoute.PUT.push([[":_id/label"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkFBPermit`,

    `A.removeSubItem(*): Public.reportbug: {_id: "@P.route._id"}: attachIds: @P.body.labelId`,
    `A.responseObject: 200: Remove label successfully!`
]]);

ReportBugRoute.PIPE.push([["updateRole"], [
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = Req.body || {};
		data = data.bugs || data;

		if(data && Object.keys(data).length > 0) {

			var user = Req.user || {};
			var hasAdmin = user.hasAgent || user.hasAdmin;
			var isGitGam = Req.company.shortName.toLowerCase() === "gitgam";

			var canDelete = isGitGam && hasAdmin;
			var canEdit = isGitGam && (hasAdmin || user.hasSupport);

			if(!Array.isArray(data)) {
				data = [{bugs: [data]}];
			}

			var userId = user._id.toString();
			var companyId = Req.company._id.toString();
			var now = new Date();
			data.map(data2 => {
				(data2.bugs||[]).map(bug => {

					if(canDelete) {
						bug.canDelete = true;
					}

					if(canEdit) {
						bug.canEdit = canDelete || (bug.status != 2);
					}

					if(canEdit && canDelete) {
						return;
					}


					var hasCreated = (bug.creatorId.toString() == userId);
					var hasAdminCompany = (hasAdmin || (bug.companyId.toString() == companyId));

					if(hasCreated || hasAdminCompany) {
						if(bug.status != 2) {
							if(now - new Date(bug.createdAt) <= 1800000) {
								bug.canEdit = true;
								bug.canDelete = true;
							}
						}
					}

					delete bug.companyId;
				})
			});
		}

		Req.onResponse(true, Req.body);
	}],
], {name: "updateRole"}]);

ReportBugRoute.PIPE.push([["checkFBPermit"], [
	//`A.findById > P.itemFB: Public.reportbug: _id`,
	//`A.printObject(*): P.route`,
	[`A.aggregateOne(*) > P.itemFB: Public.reportbug`, [
		{ $match: { $and: [
			{ $or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]}
		]}},
	]],

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var user = Req.user || {};
		var company = Req.company || {};

		var data = Req.itemFB;
		var permit = data && data._id;
		if(permit) {
			if(data.hasGlobal || data.hasListing) {
				return Req.UNRESULT;
			}

			if((company.shortName||"").toLowerCase() === "gitgam") {
				if(user.hasAgent || user.hasAdmin || user.hasSupport) {
					return Req.UNRESULT;
				}
			}

			var hasCreated = (data.creatorId.toString() == user._id.toString());

			var hasAdmin = user.hasAgent || user.hasAdmin;
			var hasAdminCompany = (hasAdmin || (data.companyId.toString() == company._id.toString()));

			var viewMode = !(Req.body||{}).mode != "view";
			permit = (hasCreated || hasAdminCompany) && (viewMode || (data.status != 2)); // approved not edit anymore
			if(permit && !viewMode) {
				var nd = new Date(data.createdAt);
				nd = nd - (new Date());
				if(nd > 1800000) {
					permit = false;
				}
			}
		}

		//console.log("AA: ", data);
		return permit ? Req.UNRESULT : {
			respCode: 500,
			respReturn: true,
			respData: "User was not permitted!"
		};
	}],
], {name: "checkFBPermit"}]);

module.exports = ReportBugRoute;
