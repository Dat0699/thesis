const MilestoneRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.milestone",
        checkMIFs		: ["project", "milestone"],
		imProject		: true,
    }
};

MilestoneRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.printObject`,
	`A.fillingDateWorking`,
    `A.verifyInput:: milestone: name!, projectId!, name2, startDate, endDate, color`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;

		body.startDate = new Date(body.startDate || new Date());
		body.endDate = new Date(body.endDate || ((new Date()).getTime() + 86400000));

		// For year maximum
		var y = body.startDate.getFullYear();
		if(body.endDate.getFullYear() - y > 2) {
			body.endDate.setFullYear(y + 1);
		}

		if((body.endDate - body.startDate) / 86400000 > 720) {
			return {
				respData: "Milestone duration should be around 720 days",
				respReturn: true,
				respCode: 500
			};
		}

		return Req.UNRESULT;
	}],

	//`A.printObject:`,
    `A.insertOne: milestone`,

	`A.pipeRoute: milestone: { type: "create" }`,
    `A.refactorOutput:: _id, name, name2, number, color, descr, status, releaseNote, startDate, endDate`
]]);

MilestoneRoute.POST.push([["/s"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: milestone.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyInput > reqBody:: milestone: projectId!`,

    `A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var reqBody = body.reqBody || {};

        var ops = {};
        ops.projectId = Req.project._id;

		var name = reqBody.name || "";
		if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops["$or"] = [
				{ name: nameReg },
				{ name2: nameReg },
				{ number: (name-0) || -1 }
			];
        }

        body.ops = ops;
        return Req.UNRESULT;
    }],

	[`A.aggregate: milestone:`, [
		{ $match: "@ops" },
		{ $limit: 500 },

		//{ $populateFilter: ["user", "creatorId:_id", "creatorId", true, 1, "_id", "name", "email", "userId", "avt"]},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
            number: 1,
			//descr: 1,
			//budget: 1,
			startDate: 1,
			endDate: 1,
		}},

		{ $addFields: {
			color: { $ifNull: ["$color", "#70CD5F"]},
		}},

		{ $sort: {
			colIndex: 1,
			name$: 1
		}}
	]],

    //`A.findMany:milestone: @ops`,
    //`A.populate:user, creatorId, _id, +, email`,
    //`A.refactorOutput::name, name2, color, descr, budget, startDate, endDate, _id`
], { checkMIFs: ["project"], checkKeyFeature: false }]);

MilestoneRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
    [`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		const name = body.name || (body.search || body.text);
		const fromDate = body.fromDate || body.startDate;
		const toDate = body.toDate || body.endDate;
		const projectId = Req.project._id;
		var milestoneIds = (body.milestone || body.milestones) ||
						  (body.milestoneId || body.milestoneIds);

		var numberTask = (body.numberTask || 5) - 0;
		var skipTask = (body.skipTask || 0) - 0;
		var scale = (body.scale || 1.0) - 0;

        var matchOps = {};
		if(projectId) {
        	matchOps.projectId = projectId;
		}

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				matchOps._id = { $in: milestoneIds };
			}
		}

        if(name) {
			var nameReg =  Req.func.getASCIISearch(name, "gmi");
            matchOps["$or"] = [
				{ name: nameReg },
				{ name2: nameReg },
			];
        }

		var milestoneDateOps = [];
        if(fromDate) {
			milestoneDateOps.push({ endDate: { $gte: fromDate} });
        }

		if(toDate) {
			milestoneDateOps.push({ startDate: { $lte: toDate} });
        }

		if(milestoneDateOps.length > 0) {
			matchOps["$and"] = milestoneDateOps;
		}

		body.scale = scale;
		body.paddingWeek = body.scale > 1 ? 14 : 4;

		body.skipTask = skipTask;
		body.numberTask = numberTask;

		body.projectId = projectId;
        body.matchOps = matchOps;
		//console.log("body: ", body);
        return body;
    }],

	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $eq: ["$shortName", "done"] },
						{ $or: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupDone: { $arrayElemAt: [ "$groups", 0 ] },
			// 	 { $filter: {
			// 		 input: "$groups",
			// 		 as: "group",
			// 		 cond: { "$in": ["$$group.shortName", "done"] }
			// 	 }},
			// 	 0
			// ]}
		}},

		{ $lookup: {
			from: "milestone",
			let: {
				groupDoneId: "$groupDone._id"
			},
			pipeline: [
				{ $match: "@matchOps" },

				{ $lookup: {
					from: 'task',
					let: { milestoneId: "$_id" },
					pipeline: [
						{ $match: {
							$expr: {
								$and: [{ $eq: ["$milestoneId", "$$milestoneId"] }]
							}
						}},

						//{ $populate: ["user", "assigneeIds", "_id", "assigneeIds"]},
						//{ $populate: ["user", "testerIds", "_id", "testerIds"]},
						//{ $populate: ["user", "reviewerIds", "_id", "reviewerIds"]},

						{ $addFields: {
							//duration: {$ceil: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000] }},
							//remainingDay: {$ceil: { $divide: [{$subtract: ["$dueDate", "$$NOW"]}, 86400000] }},
							//countTodo: "$totalTodo", //{ $size: "$todos"},
							//countDoneTodo: "$doneTodo",
							// {
							// 	$size: {
							// 		$filter: {
							// 			input: "$todos",
							// 			as: "todos",
							// 			cond: { "$eq": ["$$todos.done", true] }
							// 		}
							// 	}
							// },

							hasTaskDone: { "$cond": [{$eq:["$groupId", "$$groupDoneId"]}, 1, 0] },
						}},

						{ $sort: {
							colIndex: 1,
							createdAt: -1
						}},

						{ $project: {
							// For Task
							_id: 1,
							//number: 1,
							//name: 1,
							//name2: 1,
							//type: 1,
							status: 1,
							//priority: 1,
							duration: 1,
							startDate: 1,
							endDate: 1,
							dueDate: 1,
                            number: 1,
							//remainingDay: 1,

							// "assigneeIds._id" : 1,
							// "assigneeIds.name" : 1,
							// "assigneeIds.avt" : 1,
							// "assigneeIds.userId" : 1,
							//
							// "testerIds._id" : 1,
							// "testerIds.name" : 1,
							// "testerIds.avt" : 1,
							// "testerIds.userId" : 1,
							//
							// "reviewerIds._id" : 1,
							// "reviewerIds.name" : 1,
							// "reviewerIds.avt" : 1,
							// "reviewerIds.userId" : 1,
							//
							// "todos._id": 1,
							// "todos.done": 1,

							//countTodo: 1,
							//countDoneTodo: 1,

							hasTaskDone: 1,
						}}
					],
					as: "tasks"
				}},
				/*
				{ $populateFilter: ["attach", [
					{ $let: { milestoneId: "$_id" }},
					{ $expr: { $and : [
						{ $eq: ["$refModel", "milestone"] },
						{ $eq: ["$refId", "$$milestoneId"] }
					]}}
				], "attachIds",, true, ["_id"] ]},
				*/

				//{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"] },
				{ $addFields: {
					// Workaeound, add 2 second to end Date
					//duration: {$ceil: { $divide: [{$add: [{$subtract: ["$endDateLocal", "$startDateLocal"]}, 2000]}, 86400000] }},

					//remainingDay: {$ceil: { $divide: [{$subtract: ["$endDate", "$$NOW"]}, 86400000] }},
					//passedDay: {$ceil: { $divide: [{$subtract: ["$$NOW", "$endDate"]}, 86400000] }},

					countTask: { $size: "$tasks" },
					countTaskDone : { $sum: "$tasks.hasTaskDone" },

					//countTodo: { $sum: "$tasks.countTodo" },
					//countDoneTodo: { $sum: "$tasks.countDoneTodo" },
					//tasks: { $slice: ["$tasks", "@skipTask", "@numberTask"] },
					//countAttach: { $size: "$attachIds"},
				}},

				{ $sort: {
					colIndex: 1,
					number: -1,
					createdAt: -1,
					startDate: -1,
					createdAt: -1
				}},

				//{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},

				/*
				{ $addFields: {
					testStartDate: {
						year: { $year: "$startDateLocal"},
						month: { $month: "$startDateLocal"},
						day: { $dayOfMonth: "$startDateLocal"},
						hour: { $hour: "$startDateLocal"},
						minute: { $minute: "$startDateLocal"},
						second: { $second: "$startDateLocal"},
					},
					testEndDate: {
						year: { $year: "$endDateLocal"},
						month: { $month: "$endDateLocal"},
						day: { $dayOfMonth: "$endDateLocal"},
						hour: { $hour: "$endDateLocal"},
						minute: { $minute: "$endDateLocal"},
						second: { $second: "$endDateLocal"},
					}
				}},
				*/

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					//descr: 1,

					number: 1,
					colIndex: 1,
					countAttach: 1,

					//budget: 1,
					color: 1,
					milestoneId: 1,

					//assignIds: 1,
					rejectedMessage: 1,
					status: 1,

					startDate: 1,
					//startDateLocal: 1,
					endDate: 1,
					//endDateLocal: 1,
					//duration: 1,
					//remainingDay: 1,
					//passedDay: 1,

					countTask: 1,
					countTaskDone: 1,

					//countTodo: 1,
					//countDoneTodo: 1,

					//tasks: 1

					// Test code
					//testStartDate: 1,
					//testEndDate: 1,
				}}
			],
			as: "milestones",
		}},
		{ $project: {
			milestones: 1
		}},
	]],

	`A.copyKObject:: dbData.milestones, dbData`,

	//`A.printObject: @dbData.startDate`,
	// arrs, weekBoundary=false, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false, keyPaths
	`A.dateMinMax > dbDate : @dbData: true:: true: true: @paddingWeek: startDate, endDate`,
	//`A.printObject:`,

	//`A.convertToLocalTime > minDateLocal: @dbDate.minDate`,
	//`A.printObject: @dbDate: @minDateLocal`,

	// Test code to debug value
	// [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
	// 	var A = pipeData.A;
	//
	// 	var body = Req.body;
	//
	// 	var serverTimeZone = await A.getServerTimeZone(Req, pipeData);
	// 	var companyTimeZone = await A.getCompanyTimeZone(Req, pipeData);
	//
	// 	var delta = (companyTimeZone - serverTimeZone) * 3600000;
	//
	// 	console.log("body.dbDate: ", body.dbDate);
	// 	var d = body.dbDate.minDate;
	//
	// 	console.log("U1: ", d.getHours(), d, d.toString(), d.getTime());
	//
	// 	var i2 = new Date();
	// 	var i = new Date();
	// 	i.setMilliseconds(delta);
	// 	console.log("U2: ", i.getHours(), i, i.toString(), i.getTime(), i2.getTime());
	//
	// 	return Req.UNRESULT;
	// }],

	// arrs, startDate, scale=1.0, adjust=0.0, toLocalTime=false, ...keyPaths
	`A.dateFillDayIndex: @dbData: @dbDate.minDate: @scale:: true: startDate, startIndex, endDate, endIndex`,
	//`A.printObject:`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var DateUtil = pipeData.U.Date;

		var body = Req.body;
		var milestones = body.dbData;
		var date = body.dbDate;

		var scale = body.scale || 1.0;

		var width = body.width || 1024;
		var totalDay = date.totalDay || 0;

		var minDate = date.minDate || new Date();
		var maxDate = date.maxDate || new Date();

		if(!date.minDate) {
			minDate = new Date(minDate.getTime() - minDate.getDay()*86400000);
		}

		var maxWeek = date.maxWeek;
		if(!maxWeek && maxWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, 1, true);
			maxWeek = rw.week || 0;
		}

		var minWeek = date.minWeek;
		if(!minWeek && minWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, true, true);
			minWeek = rw.week || 0;
		}

		var week = Math.ceil(width / (body.itemWidth||336));
		var nWeek = week - (maxWeek - minWeek);
		if (nWeek > 0) {
			nWeek = Math.max(nWeek, 1);
			totalDay += (nWeek * 7);

			maxWeek += (nWeek);
			//minWeek += (-1);

			maxDate = new Date(maxDate.getTime() + (nWeek)*7*86400000);
			//minDate = new Date(minDate.getTime() + (-1)*7*86400000);
		}

		date.maxWeek = maxWeek;
		date.minWeek = minWeek;

		date.maxDate = maxDate;
		date.minDate = minDate;

		//console.log("Max: ", maxDate, maxDate.getDay(), body.dbDate1);
		date.totalDay = Math.ceil(totalDay / scale);
		DateUtil.getUpdateTodayMonthList(Req, pipeData, date, scale);


		var summary = {
			//budget: 0,

			//countTodo: 0,
			//countDoneTodo: 0,

			countTask: 0,
			countTaskDone: 0,

			duration: 0,
			//remainingDay: 0,

			milestoneDone: 0,
			milestoneCount: 0,
		};

		var tz = DateUtil.getCompanyTimeZone(Req);
		var objComponent = DateUtil.companyTimePoint(Req, pipeData);

		// Dont use map, it is async and the result maybe wrong
		for (var i = 0; i < milestones.length; i++) {
			var ms = milestones[i];
		//}
		//await milestones.map(async (ms) => {
			//summary.budget += ms.budget;

			ms.complete = ((ms.countTaskDone||0) / (ms.countTask||1) * 100.0).toFixed(0)-0;

			summary.countTask += (ms.countTask||0);
			summary.countTaskDone += (ms.countTaskDone||0);

			//summary.countTodo += ms.countTodo;
			//summary.countDoneTodo += ms.countDoneTodo;

			var rs = await DateUtil.calendarWorkingDay(Req, ms, ms.startDate, ms.endDate||ms.dueDate, [], true, false, false, false, objComponent, tz) / 8;

			//console.log("rs: ", rs, ms.startDate, ms.endDate, ms.dueDate);
			ms.duration = rs;
			summary.duration += rs;

			//summary.passedDay += ms.passedDay;
			//summary.remainingDay += ms.remainingDay;

			summary.milestoneCount += 1;
			summary.milestoneDone += (([2, 6].indexOf(ms.status) >= 0) ? 1 : 0);

			//console.log("ms.startDateLocal: ", ms.startDateLocal, ms.startDateLocal.toString());
			//console.log("ms.endDateLocal: ", ms.endDateLocal, ms.endDateLocal.toString());

			//console.log("ms.testStartDate: ", ms.testStartDate);
			//console.log("ms.testEndDate: ", ms.testEndDate);

			// remove unused data
			//delete ms.startDateLocal;
			//delete ms.endDateLocal;
		//});
		}

		//var test1 = await A.getServerTimeZone(Req, pipeData);
		//var test2 = await A.getCompanyTimeZone(Req, pipeData);

		//console.log("getServerTimeZone: ", test1);
		//console.log("getCompanyTimeZone: ", test2);

		//console.log("localStart Date: ", localStart, minDate, body.minDateLocal);

		//console.log("minDateLocal: ", body.minDateLocal, body.minDateLocal.toString());

		return { milestones, date, summary };
	}],

	//`A.responseObject: 200: {"milestones": "@dbData", "date": "@dbDate"}`
], { useZip: true }]);


MilestoneRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): milestone`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		// { $lookup: {
		// 	from: "attach",
		// 	localField: "attachIds",
		// 	foreignField: "_id",
		// 	as: "attachs"
		// }},
		// No Need $unwwind for array

		/*
		{ $lookup: {
			from: "task",
			let: { milestoneId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq : ["$milestoneId", "$$milestoneId"] }
				]}}},

				{ $addFields: {
					countTodo: { $size: "$todos"},
					countDoneTodo: {
						$size: {
							$filter: {
								input: "$todos",
								as: "todos",
								cond: { "$eq": ["$$todos.done", true] }
							}
						}
					}
				}}
			],
			as: "tasks"
		}},
		*/

		{ $addFields: {
			//duration: { $ceil: { $divide: [{$subtract: ["$endDate", "$startDate"]}, 86400000] }},

			//remainingDay: { $ceil: { $divide: [{$subtract: ["$endDate", "$$NOW"]}, 86400000] }},
			//passedDay: { $ceil: { $divide: [{$subtract: ["$$NOW", "$startDate"]}, 86400000] }},

			//countTodo: { $sum : "$tasks.countTodo" },
			//countDoneTodo: { $sum : "$tasks.countDoneTodo" },
			members: { $ifNull: ["$members", []]},
		}},

		//{ $populateFilter: ["user", "members$.user:_id", "m2", true, 1, "_id", "name", "avt", "userId"]}, // Same as below
		// { $lookup: {
		// 	from: "__zcounting",
		// 	let: { members : "$members"},
		// 	pipeline: [
		// 		{ $limit: 1 },
		// 		{ $addFields: {
		// 			members: "$$members"
		// 		}},
		// 		{ $project: {
		// 			_id: 0
		// 		}},
		// 		{ $project: {
		// 			members: 1
		// 		}},
		//
		// 		{ $unwind: {
		// 			path: "$members",
		// 			preserveNullAndEmptyArrays: false
		// 		}},
		// 		{ $replaceRoot: {
		// 			newRoot: "$members"
		// 		}},
		//
		// 		{ $populateFilter: ["user", "user:_id", "user", true, 1, "_id", "name", "userId", "avt"] },
		// 	],
		// 	as: "members"
		// }},

		//{ $populateArrayFilter: ["user", "members.user:_id", "members", undefined, 1, "_id", "name", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			descr: 1,
			releaseNote: 1,

			number: 1,
			attachs: 1,
			//countAttach: 1,

			//budget: 1,
			color: 1,
			milestoneId: 1,
			members: 1,

			//assignIds: 1,
			rejectedMessage: 1,
			status: 1,

			startDate: 1,
			endDate: 1,
			//duration: 1,
			//remainingDay: 1,
			//passedDay: 1,

			//countTask: 1,
			//countTodo: 1,
			//countDoneTodo: 1,

			//tasks: 1
		}}
	]],
]]);

// MilestoneRoute.PUT.push([[":_id/next-back"], [
// 	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
// 		var A = pipeData.A;
//
// 		var body = Req.body || {};
// 		var ops = [];
//
// 		var next = body.next;
// 		var back = body.back || body.prev;
//
// 		if(next) {
// 			ops.push(next);
// 		}
//
// 		if(back){
// 			ops.push(back);
// 		}
//
// 		if(!ops || ops.length <= 0) {
// 			return {
// 				respCode: 500,
// 				respData: "Invalid request!",
// 				respReturn: true,
// 			};
// 		}
//
// 		var rs = await A.aggregate(Req, pipeData, "milestone", [
// 			{ $match: {
// 				_id: { $in: ops }
// 			}},
// 			{ $project: {
// 				_id: 1,
// 				colIndex: 1,
// 			}}
// 		]);
//
// 		var obj = {};
// 		(rs||[]).map(ms => {
// 			obj[ms._id.toString()] = ms.colIndex || -1;
// 		});
//
//
//
//
//
// 	}]
// ]]);

MilestoneRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    "A.verifyInput > reqBody:: milestone: number-, name, name2, descr, releaseNote, color, startDate, endDate, members",

    `A.findOne(*) > milestoneDb: milestone: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const milestoneDb = pipeData.milestoneDb;
        //console.log(pipeData);

		//var permit = milestoneDb && (hasAdmin || (milestoneDb.creatorId.equals(user._id) && milestoneDb.status != 2));
        if(!milestoneDb || (!hasAdmin && [2, 4].indexOf(milestoneDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

		var body = (Req.body||{}).reqBody || {};
		if(body.startDate && body.endDate) {
			if((body.endDate - body.startDate) / 86400000 > 720) {
				return {
					respData: "Milestone duration should be around 720 days",
					respReturn: true,
					respCode: 500
				};
			}
		}

        return pipeData;
    }],

    `A.updateById(reqBody): milestone`,

	`A.pipeRoute: milestone: { type: "update" }`,
    `A.responseObject: 200: Update milestone successfully!`
]]);

MilestoneRoute.PUT.push([[":_id/move/position"], [
    `A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: milestone: colIndex, projectId!`,

	`A.updateById(*) > milestoneDb : milestone: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update milestone successfully!`
]]);

MilestoneRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > milestoneDb: milestone: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const milestoneDb = pipeData.milestoneDb;
        //console.log(pipeData);

		//var permit = milestoneDb && (hasAdmin || (milestoneDb.creatorId.equals(user._id) && milestoneDb.status != 2));
        if(!milestoneDb || (!hasAdmin && [4].indexOf(milestoneDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

        return pipeData;
    }],

	`A.deleteById:milestone`,

	`A.pipeRoute: milestone: { type: "delete" }`,
	`A.responseObject: 200: Delete Milestone successfully!`
]]);

/*
MilestoneRoute.POST.push([[":_id/member/join"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
	`A.insertSubItem(*) > member: milestone: @P.route._id: members: @P.body.members`,
	`A.populate: user, member, _id, user, +, _id, name, name2, userId`,
    `A.responseObject: 200: @member`
]]);

MilestoneRoute.POST.push([[":_id/member/left"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
	`A.insertSubItem(*) > member: milestone: @P.route._id: members: @P.body.members`,
	//`A.populate: user, member, _id, user, +, _id, name, name2, userId`,

	`A.dbCall(*): milestone: updateOne: ({
        _id : "@P.project._id",
		"members.user": "@P.body.members[0].user"
	 }): ({
        $set : {
			"members.$.leftAt": "@P.body.members[0].leftAt"
        }
    })`,

    `A.responseObject: 200: @member`
]]);

MilestoneRoute.PUT.push([[":_id/member/remove"], [
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, milestone.modify`,
    `A.removeSubItem(*): milestone: @P.route._id: members: @P.body.members[0]`,
    `A.responseObject: 200: Remove member successfully!`
]]);
*/

// MilestoneRoute.POST.push([[":_id/attach"], [
// 	`A.insertSubItem(*) > attachId: milestone: @P.route._id: attachIds: @P.body.attachIds`,
// 	`A.populate: attach, attachId, _id, attach, +, name, name2, mimeType, length `,
//     `A.responseObject: 200: @attach`
// ]]);
//
// MilestoneRoute.PUT.push([[":_id/attach"], [
//     `A.removeSubItem(*): milestone: @P.route._id: attachIds: @P.body.attachIds[0]`,
//     `A.responseObject: 200: Remove attach successfully!`
// ]]);

module.exports = MilestoneRoute;
