const _isProject = "__{{groupType}}__" == "project";
const _isCompany = ["helpdeskcomment"].indexOf("__{{dbName}}__") >= 0;
const _isUnAuth = ["tutorialcomment"].indexOf("__{{name}}__") >= 0;

const CommentRoute = {
	route	: "__{{name}}__",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		// adjustRoute: {
		// 	type: {
		// 		suffix: "comment",
		// 		as: "modelName"
		// 	}
		// }
		checkKeyFeature	: _isProject ? "project.feature.__{{subType}}__" : false,
		checkMIFs		: _isProject ? ["__{{groupType}}__", "__{{subType}}__"] : false,
		imProject		: _isProject,
	},

	template: [
		{ dbName: "wikicomment", 	name: "wikicomment", 	projectKey: ", projectId", groupType: "project", subType: "wiki" },
		{ dbName: "taskcomment", 	name: "taskcomment", 	projectKey: ", projectId", groupType: "project", subType: "task" },
		{ dbName: "riskcomment", 	name: "riskcomment", 	projectKey: ", projectId", groupType: "project", subType: "risk" },
		{ dbName: "featurecomment",	name: "featurecomment",	projectKey: ", projectId", groupType: "project", subType: "feature" },

		{ dbName: "helpdeskcomment", 		 name: "helpdeskcomment",	projectKey: "", groupType:"", subType:"" },
		{ dbName: "Public.reportbugcomment", name: "reportbugcomment",	projectKey: "", groupType:"", subType:"" },
		{ dbName: "Public.tutorialcomment",	 name: "tutorialcomment",	projectKey: "", groupType:"", subType:"" },
	]
};

CommentRoute.POST.push([[""], [
	//`A.joinString(*) > P.route.modelName:: @P.route.type : comment`,

	//`A.printObject(*): P.body: P.route`,
	`A.verifyInput:: __{{dbName}}__: referenceId!, comments! __{{projectKey}}__`,

	`A.findById > dbData: __{{dbName}}__:
		{ "referenceId": "@referenceId" }:
		{ "referenceId": "@referenceId", "projectId": "@projectId", "comments": []}`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		if(_isUnAuth) {
			return Req.UNRESULT;
		}

		var comments = (Req.body || {}).comments || [];
		comments.map(comment => {
			comment.publicUserName = Req.user.name;
		});

		return Req.UNRESULT;
	}],

	//`A.printObject`,
	`A.insertSubItem > comments: __{{dbName}}__
		: { "referenceId": "@referenceId" }
		: comments
		: @comments`,
	//`A.printObject`,

	`A.populate: user, comments.creatorId, _id, comments.creator, +, _id, name, name2, userId, avt`,
	`A.deleteKObject:: comments.publicUserId, comments.publicUserName`,

	 //`A.printObject`,

	`A.responseObject: 200: {
		comments: {
			"<-": "@((comments||[])[0]||{})",
			replies: []
		}
	}`
]]);

CommentRoute.POST.push([["/s"], [
	//`A.mixObject > dbEmpty::{a: []}`, // cheat
	//`A.responseObject: 200: @dbEmpty.a`, // cheat

	//`A.printObject:`,
	`A.verifyInput > reqBody:: __{{dbName}}__: referenceId!`,
	`A.getPaginate > reqQuery`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		pipeData.childLength = pipeData.childLength || 5;

		if(pipeData.fromLast || pipeData.last) {
			pipeData.childStart = { $subtract : [{ $size: "$replies" }, pipeData.childLength] };

		} else {
			pipeData.childStart = 0;
		}

		var sort = pipeData.sort || 1;
		if((sort+"").toLowerCase() == "asc") {
			sort = 1;
		}
		pipeData.sort = sort;

		pipeData.matchOps = { referenceId: pipeData.reqBody.referenceId };

		if(_isProject || _isCompany || CommentRoute.config.imProject) {
			pipeData.matchOps.projectId = (Req.project||{})._id;
			pipeData.populateUser = { $populate: ["user", "creatorId", "_id", "creator", false] };

		} else {
			pipeData.populateUser = { $addFields: { creatorId: "$publicUserId" } };
		}

		//console.log("Filter Test: ", pipeData.populateUser, "__{{groupType}}__", "ABC");

		return Req.UNRESULT;
	}],

	[`A.aggregate: __{{dbName}}__:`, [
		{ $match: "@matchOps"},
		{ $sort: {
			createdAt: "@sort"
		}},
		{ $set: {
			comment: {
			  $filter: {
				  input: '$comments',
				  as: 'item',
				  cond: { $or: [
					  {$eq: ['$$item.isChild', false]},
					  {$eq: ['$$item.parentId', null]},
					  //{$exists: ['$$item.parentId', false]}
				  ]}},
			 }
		}},
		{ $project: {
			comment: 1
		}},
		{ $unwind: {
			path: "$comment",
			preserveNullAndEmptyArrays: false
		}},
		{ $skip: "@reqQuery.pageStart" },
		{ $limit: "@reqQuery.pageLength" },
		{ $replaceRoot: {
			newRoot: "$comment"
		}},

		"@populateUser", // Remove deleted user

		{ $project: {
			_id: 1,
			createdAt: 1,
			modifiedAt: 1,
			descr: 1,
			descrHTML: 1,
			creatorId: 1,
			"creator._id": 1,
			"creator.name": 1,
			"creator.name2": 1,
			"creator.avt": 1,
			"creator.userId": 1,
			"publicUserName": 1,
		}},

		// Check it has children
		{ $lookup: {
			from: "__{{name}}__",
			let: { parentId: "$_id" },
			pipeline: [
				{ $match: { referenceId: "@reqBody.referenceId" }},
				{ $set: {
					comment: {
					  $filter: {
						  input: '$comments',
						  as: 'item',
						  cond: { $or: [
							  //{$eq: ['$$item.isChild', true]}, // need or not still ok
							  {$eq: ['$$item.parentId', "$$parentId"]},
						  ]}},
					 }
				}},
				{ $project: {
					comment: 1
				}},
				{ $unwind: {
					path: "$comment",
					preserveNullAndEmptyArrays: false
				}},
				// { $skip: "@reqQuery.pageStart" },
				// { $limit: "@reqQuery.pageLength" },
				//{ $limit: 5 },
				{ $replaceRoot: {
					newRoot: "$comment"
				}},
				{ $sort: {
					createdAt: "@sort"
				}},

				"@populateUser", // Remove deleted user

				{ $project: {
					_id: 1,
					createdAt: 1,
				    modifiedAt: 1,
				    descr: 1,
					descrHTML: 1,
					creatorId: 1,
					"creator._id": 1,
					"creator.name": 1,
					"creator.name2": 1,
					"creator.avt": 1,
					"creator.userId": 1,
					"publicUserName": 1,
				}}
			],
			as: "replies",
		}},
		{ $addFields: {
			totalReply: { $size: "$replies" },
			replies: { $slice: ["$replies", "@childStart", "@childLength"] }
		}}
	]],

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		//console.log("Project Type ----------------", "__{{groupType}}__", "XYZ", Req.body.populateUser);
		if(_isProject || _isCompany || CommentRoute.config.imProject) {
			return {
				respCode: 200,
				respData: Req.body || [],
				respReturn: true,
			};
		}

		//console.log("Project Type Next place ----------------", "__{{groupType}}__", "XYZ");
		return Req.UNRESULT;
	}],

	//`A.printObject`,
	`A.populate > P.tmp1: Main.usercompany, creatorId, _id, creator, +, _id, name, name2, userId, avt`,
	`A.populate(replies) > P.tmp2: Main.usercompany, creatorId, _id, creator, +, _id, name, name2, userId, avt`,

	// Get user and name
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var arrs = Req.body || [];
		var userObj = {};

		const fill = (comment) => {
			var uid = ((comment.creator||{})._id||"").toString();
			var u = userObj[uid];
			if(!u) {
				u = {
					...(comment.creator||{}),
				};
				userObj[uid] = u;
			}

			if(!(comment.creator||{}).name) {
				u.name = comment.publicUserName || "Guess User";
			}

			comment.creator = u;
			delete comment.publicUserName;
		}

		arrs.map(comment => {
			if((comment.creator||{}).avt > 0) {
				fill(comment);
			}

			(comment.replies||[]).map(cmt => {
				if((cmt.creator||{}).avt > 0) {
					fill(cmt);
				}
			});
		});

		return Req.UNRESULT;
	}],


	`A.responseObject(*): 200: @P.body`,
], {
	unAuth: _isUnAuth
}]);

CommentRoute.POST.push([["/child"], [
	// `A.mixObject > dbEmpty::{a: []}`, // cheat
	// `A.responseObject: 200: @dbEmpty.a`, // cheat
	`A.verifyInput > reqBody:: __{{dbName}}__: referenceId!, parentId!`,
	`A.verifyKObject:: parentId!: __{{dbName}}__.referenceId`,
	`A.getPaginate > reqQuery`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		pipeData.childLength = pipeData.childLength || 5;

		if(pipeData.fromLast || pipeData.last) {
			pipeData.childStart = { $subtract : [{ $size: "$replies" }, pipeData.childLength] };

		} else {
			pipeData.childStart = 0;
		}

		var sort = pipeData.sort || 1;
		if((sort+"").toLowerCase() == "asc") {
			sort = 1;
		}
		pipeData.sort = sort;

		pipeData.matchOps = { referenceId: pipeData.reqBody.referenceId };

		if(CommentRoute.config.imProject) {
			pipeData.matchOps.projectId = (Req.project||{})._id;
			pipeData.populateUser = { $populate: ["user", "creatorId", "_id", "creator", false] };

		} else {
			pipeData.populateUser = { $addFields: { creatorId: "$publicUserId" } };
		}

		return Req.UNRESULT;
	}],

	[`A.aggregate: __{{dbName}}__:`, [
		{ $match: "@matchOps" },
		{ $set: {
			comment: {
			  $filter: {
				  input: '$comments',
				  as: 'item',
				  cond: { $or: [
					  //{$eq: ['$$item.isChild', true]}, // need or not still ok
					  {$eq: ['$$item.parentId', "@parentId"] },
				  ]}},
			 }
		}},
		{ $project: {
			comment: 1
		}},
		{ $unwind: {
			path: "$comment",
			preserveNullAndEmptyArrays: false
		}},
		{ $sort: {
			"comment.createdAt": "@sort"
		}},
		{ $skip: "@reqQuery.pageStart" },
		{ $limit: "@reqQuery.pageLength" },
		{ $replaceRoot: {
			newRoot: "$comment"
		}},

		"@populateUser", // Remove deleted user

		{ $project: {
			_id: 1,
			createdAt: 1,
			modifiedAt: 1,
			descr: 1,
			descrHTML: 1,
			creatorId: 1,
			"creator._id": 1,
			"creator.name": 1,
			"creator.name2": 1,
			"creator.avt": 1,
			"creator.userId": 1,
		}}
	]],

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		if(CommentRoute.config.imProject) {
			return {
				respCode: 200,
				respData: Req.body,
				respReturn: true,
			};
		}

		return Req.UNRESULT;
	}],

	//`A.printObject`,
	`A.populate > P.tmp1: Main.usercompany, creatorId, _id, creator, +, _id, name, name2, userId, avt`,
	`A.responseObject(*): 200: @P.body`,
]]);

CommentRoute.PUT.push([["/update"], [
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		pipeData.comments = pipeData.comments[0] || (pipeData.comments || {});
		pipeData.comments.modifiedAt = new Date();
		//pipeData.comments.modifierId = Req.user._id;
		return Req.UNRESULT;
	}],
	`A.updateSubItem(*) > comment: __{{dbName}}__
		: { referenceId: "@P.body.referenceId" }
		: comments
		: @P.body.comments
		: _id`,

	`A.assertObject:: and: (
		comment type boolean,
		comment == #true
	): {
		respData: "Update failed!",
		respCode: 500,
		respReturn: true
	}`,

	`A.responseObject: 200: Update successfully!`
]]);

CommentRoute.PUT.push([["/remove"], [
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var comments = pipeData.comments || pipeData.comment;
		if(Array.isArray(comments)) {
			comments = comments[0];
		}

		pipeData.itemData = {
			_id: comments._id,
			//creatorId: Req.user._id
		};

		pipeData.subItemData = {
			parentId: comments._id
		};

		return Req.UNRESULT;
	}],

	// Delete all childs
	`A.removeSubItem > subItemDataRs: __{{dbName}}__: { referenceId: "@referenceId" }: comments: @subItemData`,

	// Delte it self
	`A.removeSubItem > itemDataRs: __{{dbName}}__: { referenceId: "@referenceId" }: comments: @itemData`,
	`A.responseObject: 200: Delete comment and it's sub-items successfully!`
]]);

module.exports = CommentRoute;
