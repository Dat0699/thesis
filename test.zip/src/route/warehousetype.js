const WarehouseTypeRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkMIFs		: ["warehouse"],
		roleUserIdKey	: "userId"
    }
};

WarehouseTypeRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
    `A.verifyInput:: warehousetype: name!, ...`,

    `A.insertOne: warehousetype`,
    `A.refactorOutput:: _id, number, name, name2, color, code`,
]]);

// User for list type picker
WarehouseTypeRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	[`A.aggregate: warehousetype:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			code: 1,
			name: 1,
			name2: 1,
			color: 1,
		}},
	]],
]]);

WarehouseTypeRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: warehousetype: creatorId-, createdAt-, number-, ...`,

    `A.updateById(*): warehousetype: { _id: "@P.route._id" }: @P.body`,
    `A.refactorOutput:: _id, number, name, name2, color, code`,
]]);

WarehouseTypeRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.deleteById(*): warehousetype: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete type successfully!`
]]);

module.exports = WarehouseTypeRoute;
