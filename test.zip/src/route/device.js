const DeviceRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};


// DeviceRoute.POST.push([[""], [
// 	"A.verifyInput:: device: title, descr",
// 	"A.insertOne: device",
// 	`A.refactorOutput:: _id, title, descr`
// ]]);

DeviceRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	[`A.jsScript:`, async (Req, pipeData, ctx) => {
		var body = Req.body;

		var matchOps = {};
		var userId = (body.userId || body.userIds || body.users) ||
					 (body.members || body.memberIds);

		if(userId) {
			if(!Array.isArray(userId)) {
				userId = [userId];
			}

			if(userId.length > 0) {
				matchOps.userId = { $in: userId };
			}
		}

		body.matchOps = matchOps;
		return Req.UNRESULT;
	}],

	[`A.aggregate > respData: device`, [
		{ $match: "@matchOps" },

		{ $project: {
			token: 0
		}},
		{ $sort: {
			lastActiveAt: -1,
			modifiedAt: -1,
			activeAt: -1,
			createdAt: -1
		}},

		{ $group: {
			_id: "$userId",
			devices: { $push: "$$ROOT" }
		}},
		{ $addFields: {
			count: { $size: "$devices" },
		}},

		{ $match: {
			count: { $gt: 0 }
		}},

		{ $populate: ["user", "_id", "_id", "user", true]},
		{ $project : {
			"devices._id": 1,
			"devices.name": 1,
			"devices.name2": 1,
			"devices.descr": 1,
			"devices.type": 1,
			"devices.version": 1,
			"devices.lastActiveAt": 1,
			"devices.activeAt": 1,
			"devices.location": 1,
			"devices.lastLocation": 1,

			"user._id": 1,
			"user.name": 1,
			"user.name2": 1,
			"user.email": 1,
			"user.userId": 1,
			"user.avt": 1,
		}},
	]]
], { useZip: true }]);

DeviceRoute.POST.push([["/mydevice"], [
	[`A.aggregate(*) > respData: device`, [
		{ $match: {
			userId: "@P.user._id"
		}},
		{ $sort: {
			lastActiveAt: -1,
			modifiedAt: -1,
			activeAt: -1,
			createdAt: -1
		}},

		{ $project : {
			_id: 1,
			name: 1,
			name2: 1,
			descr: 1,
			type: 1,
			version: 1,
			location: 1,
			lastLocation: 1,
			lastActiveAt: 1,
			activeAt: 1,
			createdAt: 1,
		}}
	]]
], { useZip: true }]);

// DeviceRoute.GET.push([["/:_id"], [
// 	"A.findOne: device",
// 	`A.refactorOutput:: _id, title, descr`
// ]]);

// DeviceRoute.PUT.push([["/:_id"], [
// 	"A.verifyInput:: device: title, descr",
// 	"A.updateOne: device",
//     `A.responseObject: 200: Update successfully!`
// ]]);

DeviceRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	`A.findById > device: device`,
	//`A.deleteOne: device: {userId: "@P.user._id", token: "@(P.header['user-token'])"}`,
	`A.decodeToken > token: @device.token: @device.userId`,
	//`A.printObject`,
	`A.setKValue: @token: @device.userId: 0`,
	//`A.printObject`,
	`A.removeDeviceLogin: @device.token: @device.userId: #false`,

    `A.responseObject: 200: Delete successfully!`
]]);

module.exports = DeviceRoute;
