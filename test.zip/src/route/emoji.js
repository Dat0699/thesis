const EmojiRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
        imProfiling     : true,
        unAuth          : true
	}
};


EmojiRoute.POST.push([["create"],[
    // `A.printObject`,
    `A.verifyInput:: emoji: name!, icon!, shortname!, ...`,
    // `A.printObject`,

    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		const A = pipeData.A;
		const {name} = Req.body;
        if (name)
        // const userDb = body.userDb;

        // if(userDb && userDb._id) {
		// 	// In case an user being exist and not company attached as Agent owner, permit to create new company
		// 	//var rs = await A.findById(Req, pipeData, "Main.company", {agentId: userDb._id});
		// 	//if(rs) {
		//  		return {
		// 			respData: "User has existed!",
		// 			respReturn: true,
		// 			respCode : 500
		// 		};
		// 	//}
        // }

		// pipeData.D.IgnoreSanitized = true;
		// var companyDb = await A.findOne(Req, pipeData, "Main.company", {
		// 	shortName: { $regex : new RegExp(`^${body.shortName}$`, "i") }
		// });

        // if(companyDb) {
		// 	return {
		// 		respData: "Company has existed!",
		// 		respReturn: true,
		// 		respCode : 500
		// 	};
        // }

		// body.code = A.hashOTP(Req, pipeData);
		// body.otp = `otp_^_${body.shortName}_^_${body.code}`;

		// var data = {
		// 	name		: body.name,
		// 	name2		: body.name2,
		// 	email   	: body.email,
	    // 	password	: body.password,
		// 	shortName	: body.shortName,
	    // };

		// body.data = data;

		// delete body.userDb;
        // delete body.companyDb;

		return {A, body}
	}],
    // `A.insertOne: emoji`
]])

module.exports = EmojiRoute;
