const FAQRoute = {
    route	: true,
    ctrl	: false,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        //checkMIFs	: ["project"],
		imCompany: true,
    }
};

FAQRoute.POST.push([[""], [
	`A.pipeRoute: isGitGamWebSite`,

    `A.verifyInput:: Public.faq: parentId, question, answer, language`,
    `A.insertOne: Public.faq`,
]]);

FAQRoute.POST.push([["/s"], [
	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var search = (body.search || body.text) || (body.question || "");

		Req.body.search = Req.func.getASCIISearch(search, "gmi");
		return Req.UNRESULT;
	}],

    [`A.aggregate: Public.faq`, [
		{ $match: {
			parentId: { $in: [undefined, null, ""]}
		}},

		// Get Level 2
		{ $lookup: {
			from: "faq",
			let: {parentId1: "$_id"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$parentId", "$$parentId1"]},
				]}}},

				// Get Level 3
				{ $lookup: {
					from: "faq",
					let: {parentId2: "$_id"},
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$parentId", "$$parentId2"]},
						]}}},
						{ $match: { $or: [
							{ question: "@search" },
							{ answer: "@search" }
						]}},
						{ $sort: {
							colIndex: 1,
						}},
						{ $project: {
							_id: 1,
							parentId: 1,
							question: 1,
							answer: 1,
							colIndex: 1,
						}}
					],
					as: "listItem"
				}},

				// Filter empty ----------------
				{ $addFields: {
					totalItem: { $size: "$listItem" }
				}},
				{ $match: { $or: [
					{ totalItem: { $gt: 0 } },
					{ question: "@search" },
					{ answer: "@search" }
				]}},

				{ $sort: {
					colIndex: 1,
				}},

				{ $project: {
					_id: 1,
					parentId: 1,
					question: 1,
					answer: 1,
					colIndex: 1,
					listItem: 1,
				}}
			],
			as: "listItem"
		}},

		// Filter empty ----------------
		{ $addFields: {
			totalItem: { $size: "$listItem" }
		}},
		{ $match: { $or: [
			{ totalItem: { $gt: 0 } },
			{ question: "@search" },
			{ answer: "@search" }
		]}},

		{ $sort: {
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			parentId: 1,
			question: 1,
			answer: 1,
			colIndex: 1,
			listItem: 1,
		}}
	]],
], {
	useZip: true,
	imCompany: false,
	unAuth: true,
}]);

FAQRoute.PUT.push([[":_id/move/position"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: Public.blog: colIndex, parentId!`,

	`A.updateById(*) > faqDb : Public.faq: { _id: "@P.route._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update faq successfully!`
]]);

FAQRoute.PUT.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: faq: ...`,
	`A.updateById(*): Public.faq: {_id: "@P.route._id"}: @P.body`,
    `A.refactorOutput`
]]);

FAQRoute.DELETE.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `<F1>A.deleteById(*): Public.faq: {$or: [{_id: "@P.route._id"}, {parentId: "@P.route._id"}]}`,
], {F1: {IgnoreSanitized: true}}]);

module.exports = FAQRoute;
