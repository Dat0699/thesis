const TeamRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
        checkMIFs	: ["project"],
		imProject	: true,
    }
};

TeamRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: team: name!, projectId!, ...`,
    `A.insertOne: team`,

	`A.pipeRoute: team: { type: "create" }`,
	`A.populate: user, members, _id, members, +, name, name2, userId, avt`,
    //`A.populate: user, viceLeaderIds, _id, viceLeaders, +, name, name2, userId, avt`,
    //`A.populate: user, leaderId, _id, leader, +, name, name2, userId, avt`,
]]);

TeamRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqBody:: team: projectId!`,
	[`A.aggregate: team`, [
		{ $match: {
			projectId: "@reqBody.projectId",
		}},
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1
		}}
	]],
]]);

TeamRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqBody:: team: projectId!`,
    //"A.findMany: team: @reqBody",
    //`A.populate: user, members, _id ,members, +, name, name2, userId, avt`,
	[`A.aggregate: team`, [
		{ $match: {
			projectId: "@reqBody.projectId",
		}},
		{ $populateFilter: ["user", [
			{ $let: { members: "$members"}},
			{ $expr: { $and: [
				{ $in: ["$_id", "$$members"] }
			]}},
			{ $match: {
				hasDeleted: { $nin: [true] }
			}}
		], "members", undefined, 1, "_id", "name", "name2", "userId", "avt"]},

        { $addFields: {
            viceLeaderIds: { $ifNull: ["$viceLeaderIds", []] },
        }},

        { $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
        { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			members: 1,

            leader: 1,
            viceLeaders: 1,
		}}
	]],
    //`A.refactorOutput:: _id, name, name2, avt, members`
]]);

// Used for list team to pick
TeamRoute.POST.push([["/pick"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
    `A.verifyInput > reqBody:: team: projectId`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var search = body.search || body.text || body.name;
		var projectId = body.projectId || body.project;

		var filter = {};
		if(projectId) {
			filter.projectId = projectId;
		}

		if(search) {
			filter.name = Req.func.getASCIISearch(search, "gmi");
		}

		Req.filter = filter;
		return Req.UNRESULT;
	}],

	[`A.aggregate(*): team`, [
		{ $match: "@P.filter" },
		{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "avt"] },
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			project: 1,
		}}
	]],

], { imProject: false } ]);

TeamRoute.POST.push([["/:_id/add"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: team: members!, projectId!`,

    `A.findOne(*) > dbBody: team: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.modifyObject::
        dbBody.members = */reqBody.members`,

    `A.updateById(*): team: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.dbBody`,

    `A.populate: user, members, _id, members, +, name, name2, userId, avt`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        return [pipeData.members[pipeData.members.length - 1]];
    }],
]]);

TeamRoute.POST.push([["/:_id/remove"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.verifyInput > reqBody:: team: members!, projectId!",

    `A.findById(*) > dbBody: team: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    `A.modifyObject::
        dbBody.members = //reqBody.members`,

    `A.updateById(*) > tmpBody: team: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.dbBody`,

    `A.responseObject: 200: Remove Member successfully!`
]]);

//     `A.removeSubItem(*): testcase: @P.route._id: labelIds: @P.body.labelIds[0]`,

TeamRoute.PUT.push([["/:_id/remove/:userId"], [
	`A.checkRole(*): project: @P.query.projectId: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.query.projectId`,

	`A.verifyKObject(P.route)::	 _id!: verify.idType:
								userId!: verify.idType `,

    // `A.findById(*) > dbBody: team: { _id: "@P.route._id", projectId: "@P.query.projectId" }`,
    // `A.printObject`,
    `A.removeSubItem(*): team: @P.route._id: members : @P.route.userId`,
    // `A.printObject`,
    `A.responseObject: 200: Remove Member successfully!` 
]]);



TeamRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    //"A.findById: team",
    //"A.populate: user, members, _id, members, +, _id, name, name2, userId, avt",
    //`A.refactorOutput:: projectId-, createdAt-, modifiedAt-, creatorId-, modifierId-, ...`
	[`A.aggregate(*): team`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populate: ["user", "members", "_id", "members"]},
        { $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
        { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
            leader: 1,
            viceLeaders: 1,
			"members._id": 1,
			"members.name": 1,
			"members.name2": 1,
			"members.avt": 1,
			"members.userId": 1,
		}}
	]],
]]);

TeamRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: team: name!, projectId!, ...`,

    //`A.printObject`,
    `A.updateById(*): team: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.reqBody`,
	`A.populate: user, members, _id, members, +, name, name2, userId, avt`,

	`A.pipeRoute: team: { type: "update" }`,
    `A.refactorOutput`,
]]);

TeamRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.deleteById(*): team: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: deleteTeam`,
	`A.pipeRoute: team: { type: "delete" }`,
	`A.responseObject: 200: Delete Team successfully!`
]]);

module.exports = TeamRoute;
