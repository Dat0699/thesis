const CheckinSettingRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar", "checkin"],
		roleUserIdKey	: "userId"
	}
};

CheckinSettingRoute.POST.push([["/s"], [
	`A.findMany: checkinsetting::type`,
]]);

CheckinSettingRoute.POST.push([[""], [
	`A.verifyInput:: checkinsetting: ...`,
	`A.insertOne: checkinsetting`
]]);

CheckinSettingRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.verifyInput:: checkinsetting: ...`,
	`A.findOne: checkinsetting`
]]);

CheckinSettingRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput > reqBody:: checkinsetting: ...`,
	`A.updateOne(reqBody): checkinsetting`
]]);

CheckinSettingRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: checkinsetting`
]]);

module.exports = CheckinSettingRoute;
