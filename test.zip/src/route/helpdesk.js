const HelpDeskRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        checkMIFs		: ["helpdesk"],
    }
};

HelpDeskRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
    `A.verifyInput:: helpdesk: name!, number-, ...`,

    `A.insertOne: helpdesk`,
    //`A.populate: label, labels, _id, label, +, name, name2, color
    //           : user, creatorId, _id, creator, +, _id, name, name2, avt, userId`,

	`A.pipeRoute: helpdesk: { type: "create" }`,
    `A.refactorOutput:: modifiedAt-, modifierId-, ...`
	//`A.responseObject: 200, Create successfully!`
]]);

HelpDeskRoute.PIPE.push([["prepareFilter"], [
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;

		//name, name2, date, type/subType, assignees, members, status
		var ops = [{ $ne: ["$number", "__anyValue__" ] }];

        var name = (body.name || body.content) || (body.search || body.text) || "";
		if(name) {
			name = Req.func.getASCIISearch(name, "gmi");
			ops.push({ $or: [
				{ $regexMatch: { input:"$name", regex: name} },
				{ $regexMatch: { input:"$descr", regex: name} },
			]});
		}

		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

		var memberIds = (body.member || body.members) || (body.memberId || body.memberIds);
		var assignees = (body.assignee || body.assignees) || (body.assigneeId || body.assigneeIds);
		if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds];
			}
		}
		if(assignees) {
			if(!Array.isArray(assignees)) {
				assignees = [assignees];
			}
		}

		memberIds = [ ...(memberIds||[]), ...(assignees||[]) ];

		let status = (body.status || body.statuses) || (body.statusId || body.statusIds);
		if(status != undefined) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.push({ $in: ["$status", status] });
			}
		}

		// if(memberIds) {
		// 	if(!Array.isArray(memberIds)) {
		// 		memberIds = [memberIds];
		// 	}
		// 	if(memberIds.length > 0) {
		// 		ops.push({ $in: ["$creatorId", memberIds] });
		// 	}
		// }

		if(fromDate && toDate) {
			ops.push({ $gte: ["$createdAt", new Date(fromDate)] });
			ops.push({ $lte: ["$createdAt", new Date(toDate)] });
		}

		let types = body.type || body.types;
		if(types != undefined) {
			if(!Array.isArray(types)) {
				types = [types];
			}
			if(types.length > 0) {
				ops.push({ $or: [
					{ $in: ["$type", types] },
					{ $in: ["$subType", types] }
				]});
			}
		}

		var depts = (body.department || body.departments) || (body.dept || body.depts);
		if(depts) {
			if(!Array.isArray(depts)) {
				depts = [depts];
			}
			if(depts.length > 0) {
				ops.push({ $in: ["$deptIncharge", depts] });
			}
		}

		var ops2 = { number: { $ne: "__anyValue__" } };
		//var assignees = (body.assignee || body.assignees) || (body.assigneeId || body.assigneeIds);
		if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds];
			}
			if(memberIds.length > 0) {
				ops2["$or"] = [
					{ assignees: { $elemMatch: { $in: memberIds } }},
					{ creatorId: { $in: memberIds }},
				];
			}
		}

		var labelIds = (body.label || body.labelId) || (body.labels || body.labelIds);
		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				ops2.labels = { $elemMatch: { $in: labelIds } };
			}
		}

		body.ops2 = ops2;
        body.ops1 = { $expr: { $and: ops }};

		//console.log("Ops: ", JSON.stringify(ops2), ops);
        return Req.UNRESULT;
    }],
], { name: "prepareFilter" }]);

HelpDeskRoute.POST.push([["/:type:(/^(next|prev)$/gmi)/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

    `A.pipeRoute: prepareFilter`,
	//`A.printObject: ops1: ops2`,

	[`A.aggregateOne(*): helpdesk`, [
		{ $match: "@P.body.ops1"},
		{ $match: "@P.body.ops2"},

		{ $convertDate: ["dueDate -> dueDateLocal"]},
		{ $sort: {
			//status: 1,
			dueDate: -1,
			priority: -1,
			startDate: -1,
			dueDate: -1,
			modifiedAt: -1
		}},

		{ $group: {
			_id: null,
			allItems: { $push: "$$ROOT" },
		}},

		{ $addFields: {
			idx: { $indexOfArray: ["$allItems._id", "@P.route._id"] },
			step: { $cond: [{$eq: ["@P.route.type", "next"]}, 1, -1] }
		}},

		{ $addFields: {
			// If idx >= 0 => idx+steop else sizeLengtg+20
			idx: { $cond: [
				{ $or: [
					{ $lt: ["$idx", 0] },
					{ $lt: [{ $add: ["$idx", "$step"] }, 0] }
				]},
				{ $add: [{$size: "$allItems"}, 20] },
				{ $add: ["$idx", "$step"] }
			]}
		}},

		{ $addFields: {
			item: { $arrayElemAt: ["$allItems", "$idx"] },
			length: {$size: "$allItems"}
		}},

		{ $project: {
			"item._id": 1,
			"item.number": 1,
			idx: 1,
			step: 1,
			length: 1,
		}},
		{ $project: {
			_id: 0
		}},
	]],

	//`A.printObject`,
	`A.responseObject: 200: @item`,
]]);

HelpDeskRoute.POST.push([["/full/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,

    `A.pipeRoute: prepareFilter`,

	`A.getPaginate > page`,
	[`A.aggregateOne: helpdesk`, [
		{ $match: "@ops1"},
		{ $match: "@ops2"},

		{ $sort: {
			//status: 1,
			dueDate: -1,
			priority: -1,
			startDate: -1,
			dueDate: -1,
			modifiedAt: -1
		}},

		{ $addFields: {
			hasResolved: { $cond: [{$eq: ["$status", 2]}, 1, 0]},
			isResolver: { $in: ["@P.user._id", "$assignees"]},
			isRequester: { $eq: ["@P.user._id", "$creatorId"]},
		}},

		{ $getTotalLength: "@page" },
		// { $getTotalLength: ["@page", "totalLength", {
		// 	totalResolved: { $sum: "$hasResolved" }
		// }]},

		{ $populateFilter: ["label", "labels$:_id", "labels", undefined, 1, "_id", "name", "name2", "color"] },
		{ $populateFilter: ["user", "creatorId:_id", "creator", true, 1, "_id", "name", "avt", "userId"] },
		{ $populateFilter: ["user", "assignees$:_id", "assigneeIds", undefined, 1, "_id", "name", "avt", "userId"] },

		{ $populateFilter: ["helpdesktype", "type:_id", "type", true, 1, "_id", "name", "number", "persionIncharges", "deptIncharge"] },
		{ $populateFilter: ["helpdesktype", "subType:_id", "subType", true, 1, "_id", "name", "number", "persionIncharges", "deptIncharge"] },

		{ $project: {
			_id: 1,
			priority: 1,

			number: 1,
			name: 1,
			name2: 1,
			descr: 1,

			deptIncharge: 1,
			//assignees: 1,

			startDate: 1,
			dueDate: 1,

			type: 1,
			subType: 1,

			status: 1,

			resolvedAt: 1,

			totalLength: 1,
			hasResolved: 1,
			//totalResolved: 1,

			isLock: 1,
			isResolver: 1,
			isRequester: 1,

			"labels._id": 1,
			"labels.name": 1,
			"labels.name2": 1,
			"labels.color": 1,

			"creator._id": 1,
			"creator.name": 1,
			"creator.name2": 1,
			"creator.userId": 1,
			"creator.avt": 1,

			"assigneeIds._id": 1,
			"assigneeIds.name": 1,
			"assigneeIds.name2": 1,
			"assigneeIds.userId": 1,
			"assigneeIds.avt": 1,
		}},

		{ $convertDate: ["dueDate -> dueDateLocal"]},
		{ $addFields: {
			$dateString: ["$dueDateLocal -> $dayString"],
		}},

		{ $group: {
			_id: "$dayString",
			helpdesks: { $push: "$$ROOT" },
			totalResolved: { $sum: "$hasResolved" },
			//totalResolved: { $first: "$totalResolved" },
			totalLength: { $first: "$totalLength" },
			dayString: { $first: "$dayString" },
		}},
		{ $sort: {
			dayString: -1,
		}},

		{ $project: {
			_id: 0,
			"helpdesks.totalLength": 0,
			"helpdesks.dueDateLocal": 0,
			"helpdesks.dayString": 0,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "days", "", { totalResolved: {$sum: "$totalResolved"} }]},
	]]
], { useZip: true }]);

HelpDeskRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): helpdesk`, [
		{ $match: {
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populateFilter: ["label", "labels$:_id", "labels", undefined, 1, "_id", "name", "name2", "name2", "color"] },
		{ $populateFilter: ["user", "creatorId:_id", "creator", true, 1, "_id", "name", "name2", "avt", "userId"] },
		{ $populateFilter: ["user", "assignees$:_id", "assigneeIds", undefined, 1, "_id", "name", "name2", "avt", "userId"] },
		{ $populateFilter: ["user", "watchers$:_id", "watcherIds", undefined, 1, "_id", "name", "name2", "avt", "userId"] },

		{ $populateFilter: ["helpdesktype", "type:_id", "type", true, 1, "_id", "name", "name2", "number", "persionIncharges", "deptIncharge"] },
		{ $populateFilter: ["helpdesktype", "subType:_id", "subType", true, 1, "_id", "name", "name2", "number", "persionIncharges", "deptIncharge"] },

		{ $addFields: {
			isResolver: { $in: ["@P.user._id", "$assignees"]},
			isRequester: { $eq: ["@P.user._id", "$creatorId"]},
		}},
		{ $project: {
			modifierId: 0,
			creatorId: 0,
		}}
	]],
]]);

HelpDeskRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.verifyInput:: helpdesk:name, name2, status-, number-, creatorId-, isLock-, ...`,

    `A.findOne(*) > helpdeskDb: helpdesk: { _id: "@P.route._id" }`,

    // [`A.jsScript`, (Req, pipeData, ctx) => {
	// 	var user = Req.user;
	// 	var hasAdmin = user.hasAgent || user.hasAdmin;
	//
	// 	var risk = Req.body.riskDb || {};
	// 	var permit = risk._id && (hasAdmin || risk.creatorId.equals(user._id));
	// 	if (!permit) {
	// 		return {
	// 			respData: "E-02",
	// 			respReturn: true,
	// 			respCode : 500
	// 		};
	// 	}
	// 	return pipeData;
    // }],

    `A.updateById(*): helpdesk: { _id: "@P.route._id" }: @P.body`,
    `A.populate: label, labelId, _id, label, +, name, name2, color
                : milestone, milestoneId, _id, milestone, +, name`,

	`A.pipeRoute: helpdesk: { type: "update" }`,
    `A.responseObject: 200: Update successfully!`,
]]);

HelpDeskRoute.PUT.push([[":_id/resolve"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.verifyInput:: helpdesk: status!`,
    `A.updateById(*): helpdesk: { _id: "@P.route._id" }: { status: "@P.body.status", resolvedAt: "@(new Date())" }`,

	`A.pipeRoute: helpdesk: { type: "@status" }`,
    `A.responseObject: 200: Update successfully!`
]]);

HelpDeskRoute.PUT.push([[":_id/:type:(/^(lock|unlock)$/)"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    //`A.verifyInput:: helpdesk: status!`,
    `A.updateById(*): helpdesk: { _id: "@P.route._id" }: { isLock: "@(P.route.type=='unlock'?false:true)" }`,

	`A.pipeRoute(*): helpdesk: { type: "@P.route.type" }`,
    `A.responseObject: 200: Update successfully!`
]]);

HelpDeskRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.findOne(*) > helpdeskDb: helpdesk: { _id: "@P.route._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var helpdesk = Req.body.helpdeskDb;

        if(!helpdesk || (helpdesk.status == 2)) {
			var user = Req.user || {};

			if(!user.hasAdmin && !user.hasAgent) {
	            return {
					respData: "E-02",
					respReturn: true,
					respCode: 500
				};
			}
        }
        return Req.UNRESULT;
    }],

    `A.deleteById: helpdesk`,

	`A.pipeRoute: helpdesk: { type: "delete" }`,
    `A.responseObject: 200: Delete successfully!`
]]);

module.exports = HelpDeskRoute;
