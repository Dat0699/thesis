const ChangeRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.changelog",
		checkMIFs		: ["project", "changelog"],
		imProject		: true,
    }
};

ChangeRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: changelog.view, changelog.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: changelog: title!, projectId!, number-, ...`,
    `A.insertOne: changelog`,

	`A.pipeRoute(*): changelog: { type: "create" }`,
    `A.refactorOutput:: _id, title, changedDate, number`
]]);

ChangeRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: changelog.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
    [`A.jsScript`,(Req, pipeData, ctx) => {
		const title = (pipeData.title || pipeData.content) ||
					  (pipeData.text || pipeData.search);

		let projectIds = Req.project._id;
		 				// || Req.query.projectId || Req.header.projectId);// ||
						//  (pipeData.projectId || pipeData.projectIds) ||
						//  (pipeData.project || pipeData.projects);

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		var milestoneIds = pipeData.milestoneId || pipeData.milestoneIds;
		var sprintIds = pipeData.sprintId || pipeData.sprintIds;
		var featureIds = pipeData.featureId || pipeData.featureIds;
		
		const status = pipeData.status || pipeData.statuses;

        var ops = [];
		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds }});
			}
		}

        if(title) {
			var nameReg = Req.func.getASCIISearch(title, "gmi");
            ops.push({ $or: [
				{ title: nameReg },
				{ title2: nameReg },
				{ number: (title-0) || -1 }
			]});
        }

        if(fromDate) {
			ops.push({changedDate: {"$gte" : new Date(fromDate)}});
		}

		if(toDate) {
			ops.push({changedDate: {"$lte" : new Date(toDate)}});
		}

		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				ops.push({ status: { $in: status } });
			}
		}

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
			if(milestoneIds.length > 0) {
				ops.milestoneId = { $in: milestoneIds };
			}
		}

		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}
			if(sprintIds.length > 0) {
				ops.sprintId = { $in: sprintIds };
			}
		}

		if(featureIds) {
			if(!Array.isArray(featureIds)) {
				featureIds = [featureIds];
			}
			if(featureIds.length > 0) {
				ops.featureId = { $in: featureIds };
			}
		}

		if(ops && ops.length > 0) {
        	pipeData.ops = { $and: ops };

		} else {
			pipeData.ops = { };
		}
		//console.log("Ops: ", ops);
        return Req.UNRESULT;
    }],

    `A.uniquizedObject`,

	`A.getPaginate > page`,

	[`A.aggregateOne: changelog:`, [
		{ $match: "@ops" },
		{ $sort: {
			changedDate: -1,
			modifiedAt: -1,
			createdAt: -1,
		}},

		{ $getTotalLength: ["@page", "totalLength"]},

		// model, condition, saveAs, keepEmpty, filterType, keys
		// { $populateFilter: ["attach", [
		// 	{ $let: { changelogId: "$_id" }},
		// 	{ $expr: { $and : [
		// 		{ $eq: ["$refModel", "changelog"] },
		// 		{ $eq: ["$refId", "$$changelogId"] }
		// 	]}}
		// ], "attach", undefined, true, ["_id", "name", "mimeType", "length"] ]},

		/*
		{ $lookup: {
			from: "attach",
			let: { changelogId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and : [
					{ $eq: ["$refModel", "changelog"] },
					{ $eq: ["$refId", "$$changelogId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					mimeType: 1,
					length: 1
				}}
			],
			as: "attach"
		}},
		*/

		{ $populate: ["user", "approverId", "_id", "approvedBy", true] },
		{ $populateFilter: ["milestone", "milestoneId:_id", "milestone", true, 1, "_id", "number", "name", "name2", "color"]},
		// { $populate: ["user", "approverIds", "_id", "approvers"] },

		{ $groupTotalLength: ["@page", "totalLength", "changelogs"]},
	]],

    //`A.findMany: changelog: @ops`,
    //`A.populate: attach, attachIds, _id, attach, +, name, name2, mimeType, length `,

], { useZip: true }]);

ChangeRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: changelog.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): changelog`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		{ $populate: ["milestone", "milestoneId", "_id", "milestone", true]},
		{ $project: {
			_id: 1,
			title: 1,
			title2: 1,
			content: 1,
			attach: 1,
			changedDate: 1,
			status: 1,
			number: 1,
			modifiedAt: 1,
			rejectedMessage: 1,
			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			amount: 1,
			
			milestoneId: 1,
			sprintId: 1,
			featureId: 1,
			taskId: 1,

			"milestone._id": 1,
			"milestone.number": 1,
			"milestone.name": 1,
			"milestone.name2": 1,
			"milestone.color": 1,
		}}
	]],

    //`<F1>A.findOne(P.route): changelog: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
	//`A.populate: user, approverId, _id, approvedBy, +, name, name2, userId, avt`,
	//		//    : user, approverIds, _id, approvers, +, name, name2, userId, avt, `,
    //`A.refactorOutput:: _id, title, content, attach, changedDate, status, number, rejectedMessage`
]]);

ChangeRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: changelog.view, changelog.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: changelog: title, content, status, changedDate, message, number-, ...`,

    `A.findOne(*) > changelogDb: changelog: {
		projectId: "@P.project._id",
		_id: "@P.route._id"
	}`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        if(!pipeData.changelogDb || (pipeData.changelogDb.status == 2)) {
            return {
				respData: "E-02",
				respReturn: true,
				respCode : 500
			};
        }
        return pipeData;
    }],

    `A.updateById(*): changelog: {_id: "@P.route._id"}: @P.body`,
	`A.pipeRoute(*): changelog: { type: "update" }`,
    `A.responseObject: 200: Update ChangeLog successfully!`
]]);

ChangeRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: changelog.view, changelog.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.deleteById(*): changelog: {
		_id: "@P.route._id",
		projectId: "@P.project._id"
	}`,

	`A.pipeRoute(*): changelog: { type: "delete" }`,
    `A.responseObject: 200: Delete ChangeLog successfully!`
]]);

// ChangeRoute.POST.push([[":_id/attach"], [
//     `A.insertSubItem(*) > attachId: changelog: @P.route._id: attachIds: @P.body.attachIds`,
//     `A.populate: attach, attachId, _id, attach, +, name, name2, mimeType, length `,
//     `A.responseObject: 200: @attach`
// ]]);
//
// ChangeRoute.PUT.push([[":_id/attach"], [
//     `A.removeSubItem(*): changelog: @P.route._id: attachIds: @P.body.attachIds[0]`,
//     `A.responseObject: 200: Remove attach successfully!`
//
// ]]);

module.exports = ChangeRoute;
