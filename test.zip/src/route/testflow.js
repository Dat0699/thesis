const TestFlowRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.testcase",
		checkMIFs		: ["project", "testcase"],
		imProject		: true,
	}
};

TestFlowRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: testflow: projectId!, title!, status-, testcases, number-, ...`,
	`A.insertOne: testflow`,

	`A.pipeRoute: testflow: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

TestFlowRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: testflow: colIndex, projectId!`,

	`A.updateById(*) > testflowDb : testflow: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update test flow successfully!`
]]);

TestFlowRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: testflow: projectId!, title, testDate, status, mode, testcases`,
	`A.updateOne(*): testflow: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: testflow: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

TestFlowRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.deleteOne(*): testflow: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	// colName, idKey, hardDelete=true, deleteMany=false`
	`A.deleteMany(*) > tmp: testresult: {"testflowId": "@P.route._id"}: true: true`,

	`A.pipeRoute: testflow: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

TestFlowRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];

        var projectIds = pipeData.projectId || pipeData.projectIds;
		var startDate = pipeData.fromDate || pipeData.startDate;
		var endDate = pipeData.toDate || pipeData.endDate;
		var userIds = pipeData.userId || pipeData.userIds;
		var title = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds } });
			}
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.push({
					status: { $in: status }
				});
			}
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.push({ creatorId: { $in: userIds } });
			}
		}

		if(startDate && endDate) {
			ops.push({ $or: [
				{ testDate: { $in: [undefined, null, 0, -1, [], ''] }},
				{ $and: [
					{ testDate: { $gte: new Date(startDate) } },
					{ testDate: { $lte: new Date(endDate) } },
				]}
			]});
			// ops.push({ testDate: { $gte: new Date(startDate) } });
			// ops.push({ testDate: { $lte: new Date(endDate) } });
		}

        if(title) {
            ops.push({ $or: [
				{ title : Req.func.getASCIISearch(title, "gmi") },
				{ number: (title-0) || -1 }
			]});
        }

		if(!ops || (ops.length <= 0)) {
			pipeData.ops = {};

		} else {
        	pipeData.ops = { $and: ops };
		}

        //console.log(ops);
        return pipeData;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: testflow:`, [
		{ $match: "@ops" },
		{ $sort: {
			//nunber: 1,
			//testDate: 1,
			createdAt: 1
		}},

		{ $getTotalLength: ["@page", "totalLength"] },
		{ $populate: ["user", "creatorId", "_id", "creatorId", true]},
		{ $populate: ["testresult", "_id", "testflowId", "testresult", undefined]},

		{ $addFields: {
			testedCount: { $size: {
				$filter: {
					input: "$testresult",
					as: "tr",
					cond: { "$in": ["$$tr.result", [/*"testing",*/ "passed", "failed"]] }
				}
			}},
			passedCount: { $size: {
				$filter: {
					input: "$testresult",
					as: "tr",
					cond: { "$in": ["$$tr.result", ["passed"]] }
				}
			}},
			// failedCount: { $size: {
			// 	$filter: {
			// 		input: "$testresult",
			// 		as: "tr",
			// 		cond: { "$in": ["$$tr.result", ["failed"]] }
			// 	}
			// }},
			//testcaseCount: { $size: "$testresult" }
			testcaseCount: { $size: "$testcases" }
		}},

		{ $addFields: {
			failedCount: { $subtract: ["$testedCount", "$passedCount"] }
		}},

		{ $project: {
			title: 1,
			testDate: { $ifNull: ["$testDate", "$createdAt"]},

			number: 1,
			mode: 1,
	        status: 1,

			testcaseCount: 1,
			testedCount: 1,
			passedCount: 1,
			failedCount: 1,

			totalLength: 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,

			//"envId._id": 1,
			//"envId.name": 1,
			//"envId.name2": 1,
		}},

		{ $group: {
			_id: {
				day: { $dayOfMonth: "$testDate" },
                month: { $month: "$testDate" },
                year: { $year: "$testDate" }
            },
			date: { $first: "$testDate" },
			testflows: { $push: "$$ROOT"},

			testcaseCount: { $sum: "$testcaseCount" },
			testedCount: { $sum: "$testedCount" },
			passedCount: { $sum: "$passedCount" },
			failedCount: { $sum: "$failedCount" },

			totalLength : { "$first": "$totalLength" }
		}},

		{ $project: {
			"testflows.totalLength": 0,
		}},

		{ $sort: {
			date: 1,
		}},

		{ $groupTotalLength: ["@page", false, "testflows", false, {
			testcaseCount: { $sum: "$testcaseCount" },
			testedCount: { $sum: "$testedCount" },
			passedCount: { $sum: "$passedCount" },
			failedCount: { $sum: "$failedCount" },
		}]},
	]],
], { useZip: true }]);

TestFlowRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): testflow:`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		// CreatorId
		{ $populate: ["user", "creatorId", "_id", "creatorId", true]},

		// Post Case
		{ $populate: ["testresult", "_id", "testflowId", "testresult"]},

		// Environment Id
		//{ $populate: ["postenv", "envId", "_id", "envId", true]},

		{ $addFields: {
			testedCount: { $size: {
				$filter: {
					input: "$testresult",
					as: "testresult",
					cond: { "$in": ["$$testresult.status", [/*"testing",*/ "passed", "failed"]] }
				}
			}},
			passedCount: { $size: {
				$filter: {
					input: "$testresult",
					as: "testresult",
					cond: { "$in": ["$$testresult.status", ["passed"]] }
				}
			}},
			//testcaseCount: { $size: "$testresult" }
			testcaseCount: { $size: "$testcases" }
		}},

		{ $addFields: {
			failedCount: { $subtract: ["$testedCount", "$passedCount"] }
		}},

		{ $project: {
			title: 1,
			testDate: 1,

			number: 1,
			mode: 1,
	        status: 1,

			testcaseCount: 1,
			testedCount: 1,
			passedCount: 1,
			failedCount: 1,

			testcases: 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,
		}}
	]],
]]);

/*
// Old code, we are using sprint, and flow content list of test case and it result
TestFlowRoute.POST.push([[":_id/testresult/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	//`A.printObject`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var testResultOps = {};
		var testcaseOps = [{ $in: ["$_id", "$$testcases"] }];

		var title = (pipeData.title || pipeData.name) || pipeData.search;
		if(title) {
			testcaseOps.push({ $regexMatch: { input : "$title", regex: Req.func.getASCIISearch(title, "gmi") } });
		}

		var status = (pipeData.status || pipeData.statuses) || (pipeData.result || pipeData.results);
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				testResultOps["testresult.result"] = { $in: status };
			}
		}

		var labelOps = {};
		var labelIds = pipeData.labelIds || pipeData.labelId;
		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				labelOps.labelIds = { $elemMatch: { $in: labelIds } };
			}
		}

		var body = Req.body || {};
		body.testcaseOps = testcaseOps;
		body.testResultOps = testResultOps;
		body.labelOps = labelOps;

		body.testflowId = Req.route._id;

		return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

	[`A.aggregateOne(*): testflow:`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.body.testflowId" },
				{ number: "@P.body.testflowId" }
			]
		}},

		{ $limit : 1 },
		{ $project: {
			_id: 1,
			testcases: 1
		}},

		{ $lookup: {
			from: "testcase",
			let: { testcases: "$testcases", testflowId: "$_id"},
			pipeline: [
				{ $match: { $expr: { $and: "@P.body.testcaseOps"}}},
				{ $match: "@P.body.labelOps" },

				{ $lookup: {
					from: "testresult",
					let: { testcaseId: "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$testcaseId", "$$testcaseId"] },
							{ $eq: ["$testflowId", "$$testflowId"] },
						]}}},
						{ $project: {
							_id: 1,
							note: 1,
							result: 1
						}}
					],
					as: "testresult"
				}},
				{ $unwind: {
					path: "$testresult",
					preserveNullAndEmptyArrays: true
				}},
				{ $addFields: {
					testresult: { $ifNull: ["$testresult", {result: "new"} ]}
				}},

				{ $match: "@P.body.testResultOps" },

				{ $sort: {
					number: 1,
					// "testresult.result": 1,
					// priority: -1
				}},

				{ $getTotalLength: "@P.body.page" },

				{ $populate: ["label", "labelIds", "_id", "label"]},

				{ $project: {
					_id: 1,
					number: 1,
					title: 1,
			        content: 1,
			        condition: 1,
			        result: 1,
			        priority: 1,

					totalLength: 1,

					testresult: 1,
			        groupId: 1,

			        "label._id": 1,
					"label.name": 1,
					"label.name2": 1,
					"label.color": 1
				}},

				// page, keyTotalName, keyGroupName, keyGroupBy, groupObj
				{ $groupTotalLength: ["@P.body.page", "totalLength", "testcases", "$groupId"]},
				// { $group: {
				// 	_id: "$groupId",
				// 	testcases: {
				// 		$push: "$$ROOT"
				// 	}
				// }},

				{ $populate: ["group", "_id", "_id", "group", true]},

				{ $project: {
					_id: 1,
					name: "$group.name",
					testcases: 1,
					page: 1,
				}},
				{ $project: {
					"testcases.groupId": 0
				}}
			],
			as: "testcases"
		}},

		{ $addFields: {
			page: { $first: "$testcases.page" }
		}},

		{ $project: {
			_id: 0,
			"testcases.page": 0,
		}}
	]],
], { useZip: true }]);
*/

TestFlowRoute.POST.push([[":_id/testresult/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	//`A.printObject`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {

		const body = Req.body || {};

		var projectId = body.projectId;
		var startDate = body.fromDate || body.startDate;
		var endDate = body.toDate || body.endDate;
		var userIds = body.userId || body.userIds;
		var labelIds = (body.label || body.labels) || (body.labelId || body.labelIds);
		var groupIds = (body.group || body.groups) || (body.groupId || body.groupIds);
		var title = (body.title || body.name) || (body.search || body.text);

		var opsFlow = [];
		var opsTestcase = [{ projectId: {$eq: projectId} }];

		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				opsTestcase.push({ labelIds: { $elemMatch: { $in: labelIds }}});
			}
		}

		if(groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}
			if(groupIds.length > 0) {
				opsTestcase.push({ groupId: { $in: groupIds }});
			}
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				opsFlow.push({
					//result: { $in: status }
					$in: ["$result", status]
				});
			}
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				opsFlow.push({
					//updatedBy: { $in: userIds }
					$in: ["$updatedBy", userIds]
				});
			}
		}

		if(startDate) {
			opsFlow.push({ updatedAt: { $gte: new Date(startDate) } });
		}

		if(endDate) {
			opsFlow.push({ updatedAt: { $lte: new Date(endDate) } });
		}

        if(title) {
			var titleReg = Req.func.getASCIISearch(title, "gmi");
            opsTestcase.push({ $or: [
				// { $regexMatch: { input: "$title", regex: titleReg }},
				// { $regexMatch: { input: "$title2", regex: titleReg }},
				// { $regexMatch: { input: "$content", regex: titleReg }},
				// { $regexMatch: { input: "$condition", regex: titleReg }},
				// { $eq: ["$number", (title-0) || -1] },
				{ title: titleReg },
				{ title2: titleReg },
				{ content: titleReg },
				{ condition: titleReg },
				{ number: (title-0) || -1 },
			]});
        }


		if(opsFlow && opsFlow.length > 0) {
			body.opsFlow = { $expr: { $and: opsFlow }};
		} else {
			body.opsFlow = {};
		}

		if(opsTestcase && opsTestcase.length > 0) {
			// body.opsTestcase = { $expr: { $and: opsTestcase }};
			body.opsTestcase = { $and: opsTestcase };
		} else {
			body.opsTestcase = {};
		}

		//console.log("opsFlow: ", opsTestcase);
		body.testflowId = Req.route._id;
		return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

	[`A.aggregateOne: testflow:`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@projectId"] },
			{ $or: [
				{ $eq: ["$_id", "@testflowId"]},
				{ $eq: ["$number", "@(testflowId-0)"]},
			]}
		]}}},
		{ $addFields: {
			"testcases.testflowId": "$_id"
		}},
		{ $project: {
			testcases: 1
		}},
		{ $unwind: {
			path: "$testcases"
		}},

		{ $replaceRoot: {
			newRoot: "$testcases"
		}},

		// Filter Result type, in testcaose field of TestFlow model
		{ $match: "@opsFlow" },

		{ $populateFilter: ["testcase", "testcase:_id", "testcase", true, 1, "_id", "title", 'title2', "priority", "content", "condition", "labelIds", "projectId" ]},
		{ $addFields: {
			"testcase.result": "$result",
			"testcase.testedBy": "$updatedBy",
			"testcase.testedAt": "$updatedAt",
			"testcase.testflowId": "$testflowId",
		}},

		{ $replaceRoot: {
			newRoot: "$testcase"
		}},

		{ $addFields: {
			"labelIds": { $ifNull: ["$labelIds", []]},
			"groupId": { $ifNull: ["$groupId", []]}
		}},

		{ $match: "@opsTestcase" },
		// Sort

		{ $sort: {
			"folder.name": 1,
			"folder.name$": 1,
		}},

		{ $getTotalLength: "@page" },

		// Puppulate
		{ $populate: ["group", "groupId", "_id", "group", true] },
		{ $populateFilter: ["label", "labelIds$:_id", "labels", undefined, 1, "_id", "name", "name2", "color"]},

		// Group by Groupd Id
		{ $group: {
			_id: "$group._id",
			group: { $first: "$group" },
			testcases: { $push: "$$ROOT" },
			totalLength: { $first: "$totalLength" },
		}},

		// { $addFields: {
		// 	page: {
		// 		totalLength: "$totalLength",
		// 		pageIndex: "@page.pageIndex",
		// 		pageStart: "@page.pageStart",
		// 		pageLength: "@page.pageLength",
		// 	},
		// 	testcases: { $ifNull: ["$testcases", []] }
		// }},
		//
		// { $project: {
		// 	_id: 0,
		// 	totalLength: 0,
		// 	"testcases.totalLength": 0,
		// }}

		{ $groupTotalLength: ["@page", "totalLength", "testcases"]},

		{ $project: {
			"testcases._id": 0,
			"testcases.totalLength": 0,
		}},
	]]
], { useZip: true }]);

// /testflow${testflowId}/testcase/${testcaseId}/status/${status.toLowerCase()}
TestFlowRoute.PUT.push([[":_id/testresult/update/status"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route._id, P.body.testflowId`,

	`A.verifyKObject:: testflowId!: verify.idType:
					   testcaseId!: verify.idType:
					   status!: verify.testStatusType`,

	// `A.printObject:`,
	`A.updateSubItem > tmp: testflow:
		{_id: "@testflowId", projectId: "@projectId"}:
		testcases:
		{testcase: "@testcaseId", result: "@status"}: testcase`,

	`A.responseObject: 200: Update test case successfully!`,
]]);

TestFlowRoute.POST.push([[":_id/clone"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > dbData: testflow: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.keepKObject(dbData):: projectId, title, mode, testDate, testcases`,

	`A.verifyInput(dbData) > cloneData:: testflow: projectId!, ...`,

	`A.insertOne: testflow: @cloneData`,
	`A.populate: user, creatorId, _id, creatorId, +, _id, name, name2, userId, avt`,

	`A.pipeRoute: testflow: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

TestFlowRoute.POST.push([[":_id/testresult/add"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findOne(*) > dbData: testflow: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.modifyObject::
        dbData.testcases = */testcases,
        respCode = 200`,

	`A.updateOne(*): testflow: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.dbData`,

	`A.pipeRoute: testresult: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`,
]]);

TestFlowRoute.POST.push([[":_id/testresult/remove"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > dbData: testflow: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`<F1>A.deleteOne(*) > tmp: testresult: {
		testflowId: "@P.route._id",
		testcaseId: { "$in": "@P.body.testcases" },
		projectId: "@P.project._id"
	}`,

	`A.modifyObject::
        dbData.testcases = //testcases,
        respCode = 200`,

	`A.updateOne(*): testflow: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.dbData`,

	`A.pipeRoute: testresult: { type: "delete" }`,
	`A.responseObject(*): 200: @P.body`,
], { F1: { IgnoreSanitized: true } }]);

// TestFlowRoute.POST.push([[""], [
// 	`A.verifyInput:: testflow: ...`,
// 	`A.insertOne: testflow`
// ]]);
//
// TestFlowRoute.GET.push([["/:_id"], [
// 	`A.findOne: testflow`
// ]]);
//
// TestFlowRoute.POST.push([["/s"], [
// 	`A.findMany: testflow`
// ]]);
//
// TestFlowRoute.PUT.push([["/:_id"], [
// 	`A.verifyInput:: testflow: ...`,
// 	`A.updateOne: testflow`
// ]]);
//
// TestFlowRoute.DELETE.push([["/:_id"], [
// 	`A.deleteOne: testflow`
// ]]);
//
// TestFlowRoute.POST.push([["/:_id/testcase"], [
// 	`A.insertSubItem(*) > testcaseId: testflow: @P.route._id: testcaseIds: @P.body.testcaseIds`,
// ]]);
//
// TestFlowRoute.PUT.push([["/:_id/testcase"], [
//     `A.removeSubItem(*): testflow: @P.route._id: testcaseIds: @P.body.testcaseIds[0]`,
// ]]);

module.exports = TestFlowRoute;
