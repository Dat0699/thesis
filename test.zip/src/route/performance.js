const PerformanceRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.performance",
        checkMIFs		: ["project", "performance"],
		imProject		: true,
    }
};

PerformanceRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,


    `A.verifyInput:: performance: name, name2, taskId!, projectId!, ...`,
    `A.insertOne: performance`,

	`A.pipeRoute: performance: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PerformanceRoute.POST.push([["/task/:taskId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var results = [];
		var arrs = body.listUsers || [];
		var projectId = Req.project._id;
		var taskId = Req.route.taskId;

		var keys = ["projectId", "taskId", "userId", "point"];

		for (var i = 0; i < arrs.length; i++) {
			var obj = arrs[i];
			obj.projectId = projectId;
			obj.taskId = taskId;

			// removedKeys, requiredKeys, keepKeys,
			var rs = await A.verifyInput(Req, pipeData, obj, "performance", [], keys, keys);
			if(rs) {
				results.push(rs);
			}
		}

		if(!results || results.length <= 0) {
			return Req.onResponse(false, "Create performance failed!");
		}

		Req.body = results;
		return Req.UNRESULT;
	}],

    //`A.verifyInput(listUsers):: performance: name, name2, taskId!, projectId!, ...`,
	//`A.printObject:`,

    `A.insertMany(*) > xyz: performance: @P.body`,

	//`A.pipeRoute: performance: { type: "create" }`,
	`A.responseObject(*): 200: Create performance successfully!`
]]);

PerformanceRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ..`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {
			point: {
				$gt: 0
			}
		};

		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		// Point must be greater than 0
		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
        return Req.UNRESULT;
	}],

    [`A.aggregate > respData: performance:`, [
		{ $match: "@ops" },
		{ $populate: ["user", "creatorId", "_id", "creator", false]},

		{ $group : {
            _id			: "$userId",
            userId		: { $first : "$userId" },
            avgPoint	: { $avg: "$point" },
            list		: { $push : "$$ROOT" }
        }},

		{ $match: { avgPoint: { $gt: 0 } }},

		{ $populate: ["user", "_id", "_id", "user", false]}, // Remove deleted user

		{ $project: {
            _id : 0,

            "avgPoint"		: 1,
            "user.name"		: 1,
			"user.name2"	: 1,
            "user._id"		: 1,
            "user.avt"		: 1,
			"user.userId"	: 1,
        }}
	]],
]]);


// ------------------------------ By List to Approve ---------------------
PerformanceRoute.POST.push([["/by/list"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ...`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.userId = { $in: userIds };
			}
		}

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

    [`A.aggregateOne: performance:`, [
		{ $match: "@ops" },
		{ $sort: {
			modifiedAt: -1,
			createdAt: -1,
		}},
		{ $populateFilter: ["user", "creatorId:_id", "creator", false, 1, "_id", "name", "userId", "avt"]},

		{ $group: {
			_id: {
				userId: "$userId",
				taskId: "$taskId",
			},
			performances: { $push: {
				_id: "$_id",
				point: "$point",
				createdAt: "$createdAt",
				status: "$status",
				creator: "$creator"
			}},
			point: { $sum: "$point" },
			avgPoint: { $avg: "$point" },
		}},
		{ $match: { avgPoint: { $gt: 0 } }},

		{ $populateFilter: ["task", "_id.taskId:_id", "task", false, 1, "_id", "name", "name2", "type", "priority", "number", "status"]},

		{ $group: {
			_id: "$_id.userId",
			tasks: { $push: "$$ROOT" },
			point: { $sum: "$point" },
			avgPoint: { $avg: "$point" },
		}},

		{ $populateFilter: ["user", "_id:_id", "user", false, 1, "_id", "name", "userId", "avt"]}, // Remove delete user
		{ $project: {
			_id: 0,
			"tasks._id": 0,
		}},
		{ $sort: {
			point: -1,
			avgPoint: -1,
			"user.name": 1,
		}},

		{ $getTotalLength: "@page" },
		{ $groupTotalLength: ["@page", "totalLength", "users"]},
	]],
], { useZip: true }]);


// --------------------- by Task -------------------------------
PerformanceRoute.POST.push([["/by/task"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ...`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};
		var taskNameOps = {};

		var name = pipeData.name || (pipeData.search || pipeData.text);
		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(name) {
			var reg = Req.func.getASCIISearch(name, "gmi");
			taskNameOps["$or"] = [
				{ "name": { $regex: reg }},
				{ "name2": { $regex: reg }},
				{ "number": (name-0) || -1 },
			];
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.userId = { $in: userIds };
			}
		}

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
		pipeData.taskNameOps = taskNameOps;

		//console.log(":: ", taskNameOps["$or"]);

        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

    [`A.aggregateOne: performance:`, [
		{ $match: "@ops" },

		// Group by task+user
		{ $group: {
			_id: {
				user: "$userId",
				task: "$taskId"
			},
            earningPoint: { $avg: "$point" },
		}},
		{ $match: { earningPoint: {$gt: 0} }},

		{ $addFields: {
			user: "$_id.user",
			task: "$_id.task",
		}},

		// { $lookup: {
		// 	from: "penalty",
		// 	let: {userId: "$user", taskId: "$taskId"},
		// 	pipeline: [
		// 		{ $match: { $expr: { $and: [
		// 			{ $eq: ["$taskId", "$$taskId"] },
		// 			{ $in: ["$$userId", "$members"] },
		// 		]}}},
		// 		// Penalty for all case of performance.
		// 	],
		// 	as: "penalty"
		// }},
		{ $addFields: {
			//penaltyPoint: { $sum: "$penalty.point"},
			//totalPoint: { $subtract: ["$earningPoint", {$sum: "$penalty.point"}]}, // get onlu earning point
			totalPoint: "$earningPoint"
		}},

		{ $populate: ["user", "user", "_id", "user", false]}, // Remove deleted user

		{ $project: {
			_id: 0
		}},
		{ $project: {
			"user._id": 1,
			"user.name": 1,
			"user.name2": 1,
			"user.avt": 1,
			"user.userId": 1,

			task: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,
		}},
		{ $sort: {
			totalPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1
		}},

		// Group by Task
		{ $group: {
			_id: "$task",
			users: { $push: "$$ROOT" },

			earningPoint: { $sum: "$earningPoint"},
			//penaltyPoint: { $sum: "$penaltyPoint"},
			totalPoint: { $sum: "$totalPoint"},

			avgEarningPoint : { $avg: "$earningPoint" },
			//avgPenaltyPoint : { $avg: "$penaltyPoint" },
			avgPoint : { $avg: "$totalPoint" },
		}},

		{ $project: {
			"users.task": 0
		}},

		{ $sort: {
			totalPoint: -1,
			earningPoint: -1,
			avgPoint: -1,
			penaltyPoint: 1
		}},

		// Get task information
		{ $lookup: {
			from: "task",
			//localField: "task",
			//foreignField: "_id",
			let: { taskId: "$_id"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$taskId"]}
				]}}},
				{ $match: "@taskNameOps" },
				/*
				{ $addFields: {
					totalTodo: { $size: "$todos"},
					doneTodo: {
						$size: {
							$filter: {
								input: "$todos",
								as: "todos",
								cond: { "$eq": ["$$todos.done", true] }
							}
						}
					}
				}},
				*/
				{ $addFields: {
					percentComplete: { $cond: [
						{ $eq: ["$status", 6] },
						100,
						{ $multiply: [
							{ "$cond": [{$gt:["$totalTodo", 0]}, { $divide: ["$doneTodo", {$max: ["$totalTodo", 1]}]}, 0] },
							100
						]}
					]}
				}},
			],
			as: "task"
		}},
		{ $unwind: {
			path: "$task",
			preserveNullAndEmptyArrays: false
		}},

		//{ $match: "@taskNameOps" },
		{ $getTotalLength: "@page" },

		// { $addFields: {
		// 	"totalTodo": { $size: "$task.todos"},
		// 	"doneTodo": {
		// 		$size: {
		// 			$filter: {
		// 				input: "$task.todos",
		// 				as: "todos",
		// 				cond: { "$eq": ["$$todos.done", true] }
		// 			}
		// 		}
		// 	}
		// }},

		// { $addFields: {
		// 	"percentComplete": { $multiply: [
		// 		{ "$cond": [{$gt:["$task.totalTodo", 0]}, { $divide: ["$task.doneTodo", "$task.totalTodo"]}, 0] },
		// 		100
		// 	]}
		// }},

		{ $project: {
			"task._id": 1,
			"task.type": 1,
			"task.name": 1,
			"task.name2": 1,
			"task.number": 1,
			"task.priority": 1,
			"task.descr": 1,
			"task.status": 1,

			"task.totalTodo": 1,
			"task.doneTodo": 1,
			"task.percentComplete": 1,

			users: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			avgEarningPoint: 1,
			//avgPenaltyPoint: 1,
			avgPoint: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "performances"]},
	]],
], {useZip: true}]);


// --------------------- by User -------------------------------
PerformanceRoute.POST.push([["/by/user"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ...`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.userId = { $in: userIds };
			}
		}

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

    [`A.aggregateOne: performance:`, [
		{ $match: "@ops" },

		// Group by task+user
		{ $group: {
			_id: {
				user: "$userId",
				task: "$taskId"
			},
            earningPoint: { $avg: "$point" },
		}},
		{ $match: { earningPoint: {$gt: 0} }},

		{ $addFields: {
			user: "$_id.user",
			task: "$_id.task",
		}},

		// { $lookup: {
		// 	from: "penalty",
		// 	let: {userId: "$user", taskId: "$taskId"},
		// 	pipeline: [
		// 		{ $match: { $expr: { $and: [
		// 			{ $eq: ["$taskId", "$$taskId"] },
		// 			{ $in: ["$$userId", "$members"] },
		// 		]}}},
		// 		// Penalty for all case of performance.
		// 	],
		// 	as: "penalty"
		// }},
		{ $addFields: {
			//penaltyPoint: { $sum: "$penalty "},
			//totalPoint: { $subtract: ["$earningPoint", {$sum: "$penalty"}]}, // Not count penalty, it only earningPoint
			totalPoint: "$earningPoint"
		}},

		{ $populate: ["task", "_id.task", "_id", "task", false]},
		{ $addFields: {
			countTodo: "$task.totalTodo", //{ $size: "$task.todos" },
			countDoneTodo: "$task.doneTodo",
			// {
			// 	$size: {
			// 		$filter: {
			// 			input: "$task.todos",
			// 			as: "todos",
			// 			cond: { "$eq": ["$$todos.done", true] }
			// 		}
			// 	}
			// },
			hasTaskDone: { "$cond": [{$eq:["$status", 6]}, 1, 0] },
		}},
		{ $addFields: {
			complete: { $multiply: [{$divide: ["$countDoneTodo", {$max: ["$countTodo", 1]}]}, 100]},
		}},

		{ $project: {
			_id: 0
		}},
		{ $project: {
			"task._id": 1,
			"task.type": 1,
			"task.name": 1,
			"task.name2": 1,
			"task.number": 1,
			"task.priority": 1,
			"task.descr": 1,
			"task.status": 1,

			user: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			countTodo: 1,
			countDoneTodo: 1,
			hasTaskDone: 1,

			complete: 1,
			completeTodo: "$complete",
		}},

		{ $sort: {
			totalPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1,
		}},

		// Group by User
		{ $group: {
			_id: "$user",
			tasks: { $push: "$$ROOT" },

			earningPoint: { $sum: "$earningPoint"},
			//penaltyPoint: { $sum: "$penaltyPoint"},
			totalPoint: { $sum: "$totalPoint"},

			avgEarningPoint : { $avg: "$earningPoint" },
			//avgPenaltyPoint : { $avg: "$penaltyPoint" },
			avgPoint : { $avg: "$totalPoint" },

			countTodo: { $sum: "$countTodo" },
			countDoneTodo: { $sum: "$countDoneTodo" },

			taskDone: { $sum: "$hasTaskDone" },
		}},
		{ $addFields: {
			complete: { $multiply: [{$divide: ["$taskDone", {$max: [{$size: "$tasks"}, 1]} ]}, 100]},
			completeTodo: { $multiply: [{$divide: ["$countDoneTodo", {$max: ["$countTodo", 1]}]}, 100]}
		}},

		{ $project: {
			"tasks.user": 0
		}},

		{ $sort: {
			totalPoint: -1,
			avgPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1,
		}},

		// Get user information
		{ $populate: ["user", "_id", "_id", "user", false]},

		{ $project: {
			"user._id": 1,
			"user.name": 1,
			"user.name2": 1,
			"user.avt": 1,
			"user.userId": 1,

			tasks: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			avgEarningPoint: 1,
			//avgPenaltyPoint: 1,
			avgPoint: 1,

			complete: 1,
			completeTodo: 1,

			//totalLength: 1,
		}},

		{ $getTotalLength: "@page" },
		{ $groupTotalLength: ["@page", "totalLength", "performances"]},
	]],
], {useZip: true}]);


// --------------------- by Team -------------------------------
PerformanceRoute.POST.push([["/by/team"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ...`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.userId = { $in: userIds };
			}
		}

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

    [`A.aggregateOne: performance:`, [
		{ $match: "@ops" },

		{ $populate: ["task", "taskId", "_id", "task", false]},
		{ $addFields: {
			countTodo: "$task.totalTodo", //{ $size: "$task.todos" },
			countDoneTodo: "$task.doneTodo",
			// {
			// 	$size: {
			// 		$filter: {
			// 			input: "$task.todos",
			// 			as: "todos",
			// 			cond: { "$eq": ["$$todos.done", true] }
			// 		}
			// 	}
			// },
			hasTaskDone: { "$cond": [{$eq:["$status", 6]}, 1, 0] },
		}},
		{ $addFields: {
			complete: { $multiply: [{$divide: ["$countDoneTodo", {$max: ["$countTodo", 1]}]}, 100]},
		}},

		// Group by task+user
		{ $group: {
			_id: "$userId",
            earningPoint: { $avg: "$point" },
			//totalPoint: { $sum: "$point" },

			countTodo: { $sum: "$countTodo" },
			countDoneTodo: { $sum: "$countDoneTodo" },

			taskDone: { $sum: "$hasTaskDone" },
			countTask: { $sum: 1},
			projectId: { $first: "$projectId" }
		}},
		{ $match: {earningPoint: {$gt: 0} }},

		{ $addFields: {
			complete: { $multiply: [{$divide: ["$taskDone", {$max: ["$countTask", 1]} ]}, 100]},
			completeTodo: { $multiply: [{$divide: ["$countDoneTodo", {$max: ["$countTodo", 1]}]}, 100]}
		}},

		{ $addFields: {
			user: "$_id"
		}},

		// { $lookup: {
		// 	from: "penalty",
		// 	let: { userId: "$user" },
		// 	pipeline: [
		// 		{ $match: { $expr: { $and: [
		// 			//{ $eq: ["$taskId", "$$taskId"] },
		// 			{ $in: ["$$userId", "$members"] },
		// 		]}}},
		// 		// Penalty for all case of performance.
		// 		// Filter by date also??????
		// 	],
		// 	as: "penalty"
		// }},
		{ $addFields: {
			//penaltyPoint: { $sum: "$penalty "},
			//totalPoint: { $subtract: ["$earningPoint", {$sum: "$penalty"}]}, // only earning point, not penalty
			totalPoint: "$earningPoint"
		}},

		{ $populate: ["user", "user", "_id", "user", false]}, // Remove deleted user

		/*
		{ $lookup: {
			from: "task",
			localField: "_id.task",
			foreignField: "_id",
			as: "task",
		}},
		{ $unwind: {
			path: "$task",
			preserveNullAndEmptyArrays: false
		}},
		*/

		{ $project: {
			_id: 0
		}},
		{ $project: {
			"user._id": 1,
			"user.name": 1,
			"user.name2": 1,
			"user.avt": 1,
			"user.userId": 1,

			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			countTodo: 1,
			countDoneTodo: 1,

			countTask: 1,
			taskDone: 1,

			complete: 1,
			completeTodo: 1,
			projectId: 1,
		}},

		{ $sort: {
			totalPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1,
		}},

		// Add Team and group member into team,
		//{ $populate: ["team", "user._id", "members", "team", false]},

		{ $populateFilter: ["team", [
			{ $let: { userId: "$user._id", projectId: "$projectId" }},
			{ $expr: { $and : [
				{ $in: ["$$userId", "$members"] },
				{ $eq: ["$$projectId", "$projectId"] },
			]}}
		], "team", false, 1, "_id", "name", "avt"]},


		// Group by Team
		{ $group: {
			_id: "$team._id",
			team: { $first: "$team" },
			users: { $push: "$$ROOT" },

			earningPoint: { $sum: "$earningPoint"},
			//penaltyPoint: { $sum: "$penaltyPoint"},
			totalPoint: { $sum: "$totalPoint"},

			avgEarningPoint : { $avg: "$earningPoint" },
			//avgPenaltyPoint : { $avg: "$penaltyPoint" },
			avgPoint : { $avg: "$totalPoint" },

			countTodo: { $sum: "$countTodo"},
			countDoneTodo: { $sum: "$countDoneTodo"},

			countTask: { $sum: "$countTask"},
			taskDone: { $sum: "$taskDone"},
		}},

		{ $addFields: {
			complete: { $multiply: [{$divide: ["$taskDone", {$max: ["$countTask", 1]} ]}, 100]},
			completeTodo: { $multiply: [{$divide: ["$countDoneTodo", {$max: ["$countTodo", 1]}]}, 100]}
		}},

		{ $sort: {
			totalPoint: -1,
			avgPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1,
		}},

		{ $project: {
			"users.team": 0,
			"users.projectId": 0,
		}},

		{ $project: {
			"team._id": 1,
			"team.name": 1,
			"team.name2": 1,
			"team.avt": 1,

			users: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			avgEarningPoint: 1,
			//avgPenaltyPoint: 1,
			avgPoint: 1,

			countTodo: 1,
			countDoneTodo: 1,
			countTask: 1,
			taskDone: 1,
			complete: 1,
			completeTodo: 1,

			//totalLength: 1,
		}},

		{ $getTotalLength: "@page" },
		{ $groupTotalLength: ["@page", "totalLength", "performances"]},
	]],
], {useZip: true}]);


// --------------------- by Date -------------------------------
PerformanceRoute.POST.push([["/by/date"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.verifyInput:: performance: projectId!, taskId, ...`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;
		//console.log(taskIds);

		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				ops.userId = { $in: userIds };
			}
		}

		if(fromDate && toDate) {
            ops["$and"] = [
				{ createdAt: { $gte : new Date(fromDate) }},
				{ createdAt: { $lte : new Date(toDate) }}
			];
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			if(taskIds.length > 0) {
				ops.taskId = { $in: taskIds }
			}
		}

		ops.point = { $gt: 0 };

		//console.log(ops);
		pipeData.ops = ops;
        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

    [`A.aggregateOne: performance:`, [
		{ $match: "@ops" },

		// Group by user+day
		{ $group: {
			_id: {
				user: "$userId",
                day: { $dayOfMonth: "$createdAt" },
				month: { $month: "$createdAt" },
                year: { $year: "$createdAt" }
			},
			earningPoint: { $sum: "$point" },
            avgPoint: { $avg: "$point" },
			date: { $first: "$createdAt" }
		}},
		{ $match: { avgPoint: { $gt: 0 } }},

		{ $addFields: {
			user: "$_id.user",
			day: "$_id.day",
			month: "$_id.month",
			year: "$_id.year"
		}},
		// { $lookup: {
		// 	from: "penalty",
		// 	let: {userId: "$user", day: "$day", month: "$month", year:"$year"},
		// 	pipeline: [
		// 		{ $match: { $expr: { $and: [
		// 			{ $in: ["$$userId", "$members"] },
		// 			{ $eq: ["$$day", { $dayOfMonth: "$date"}] },
		// 			{ $eq: ["$$month", { $month: "$date"}] },
		// 			{ $eq: ["$$year", { $year: "$date"}] },
		// 		]}}},
		// 		// Penalty for all case of performance.
		// 	],
		// 	as: "penalty"
		// }},
		{ $addFields: {
			//penaltyPoint: { $sum: "$penalty "},
			//totalPoint: { $subtract: ["$earningPoint", { $sum: "$penalty" }]}, // Gte only earning point
			totalPoint: "$earningPoint",
			dayString: { $concat: [
				{ $toString: "$year" }, "-",
				{ $toString: "$month" }, "-",
				{ $toString: "$day" }
			]},
		}},

		{ $project: {
			_id: 0,
		}},
		{ $project: {
			user: 1,
			date: 1,
			dayString: 1,
			avgPoint: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,
		}},

		{ $sort: {
			date: -1,
			avgPoint: -1,
			totalPoint: -1,
			earningPoint: -1,
			//penaltyPoint: 1,
		}},

		// Group by User
		{ $group: {
			_id: "$user",
			days: { $push: "$$ROOT" },

			earningPoint: { $sum: "$earningPoint"},
			//penaltyPoint: { $sum: "$penaltyPoint"},
			totalPoint: { $sum: "$totalPoint"},

			avgEarningPoint : { $avg: "$earningPoint" },
			//avgPenaltyPoint : { $avg: "$penaltyPoint" },
			avgPoint : { $avg: "$avgPoint" },
		}},

		{ $project: {
			"days.user": 0,
		}},

		{ $sort: {
			totalPoint: -1,
			earningPoint: -1,
			avgPoint: -1,
			//penaltyPoint: 1,
		}},

		// Get task information
		{ $populate: ["user", "_id", "_id", "user", false]}, // Remove deleted user

		{ $project: {
			"user._id": 1,
			"user.name": 1,
			"user.name2": 1,
			"user.avt": 1,
			"user.userId": 1,

			days: 1,
			earningPoint: 1,
			//penaltyPoint: 1,
			totalPoint: 1,

			avgEarningPoint: 1,
			//avgPenaltyPoint: 1,
			avgPoint: 1,

			//totalLength: 1,
		}},

		{ $getTotalLength: "@page" },
		{ $groupTotalLength: ["@page", "totalLength", "performances"]},
	]],
], {useZip: true}]);


PerformanceRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    `A.findOne(*): performance: { _id: "@P.route._id", projectId: "@P.project._id" }`,
]]);

PerformanceRoute.PUT.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: performance: creatorId-, modifiedAt-, ...`,
    `A.findOne > dbBody: task: { _id: "@taskId", projectId: "@projectId" }`,
    `A.pipeRoute: Checktask`,

    `A.uniquizedObject`,
    [`A.jsScript::`,
        (Req, pipeData, ctx) => {
            if (pipeData.userId.toString() == Req.user._id.toString()) {
                return undefined;
            }

            pipeData.modifiedAt = new Date();
            return Req.UNRESULT;
        }
    ],

    `A.dbRaw(*): performance: updateOne: {
        $and : [
            { taskId    : "@P.body.taskId" },
            { projectId : "@P.body.projectId" },
            { userId    : "@P.body.userId" },
            { creatorId : "@P.user._id" }
        ]
    }:
    {
        $set : {
            taskId    : "@P.body.taskId",
            projectId : "@P.body.projectId",
            creatorId : "@P.user._id",
            userId    : "@P.body.userId",
            point     : "@P.body.point",
            type      : "@P.body.type",
            modifiedAt: "@P.body.modifiedAt",
            createdAt : "@P.body.modifiedAt",

        }
    }:
    {
        upsert : true
    }`,

	`A.pipeRoute: performance: { type: "update" }`,
    `A.responseObject: 200: Update performance successfully!`
]]);

PerformanceRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.deleteById(*): performance: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: performance: { type: "delete" }`,
	`A.responseObject: 200: Delete performance successfully!`
]]);

PerformanceRoute.POST.push([["assessor"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: performance: taskId!, projectId!`,
    `A.findOne > dbBody: task: { _id: "@taskId", projectId: "@projectId" }`,
    `A.pipeRoute: Checktask`,

    `A.findMany(*): performance: {
                projectId : "@P.body.projectId",
                taskId : "@P.body.taskId",
                creatorId : "@P.user._id"
            }`,

    `A.populate: user, userId, _id, user, +, name, name2, userId, avt`,
    `A.refactorOutput:: _id, point, user, ...`
]]);

/*
PerformanceRoute.POST.push([["/bytask/full"], [
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = {};

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		const projectIds = pipeData.projectId || pipeData.projectIds;
		var taskIds = pipeData.taskId || pipeData.taskIds;

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
        	ops.projectId = { $in: projectIds };
		}

		if(taskIds) {
			if(!Array.isArray(taskIds)) {
				taskIds = [taskIds];
			}
			ops.taskId = { $in: taskIds };
		}

        if(fromDate) {
            ops.createdAt =  {
                "$gte" : new Date(fromDate)
            }
        }

		if(toDate) {
            ops.createdAt =  {
                "$lte" : new Date(toDate)
            }
        }

        pipeData.ops = ops;
		//console.log("pipeData: ", pipeData);

        return pipeData;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: task`, [
		{ $match: "@ops" },
		{ $sort: {
			colIndex: 1,
			createdAt: -1
		}},
		{ $getTotalLength: "@page" },

		{ $addFields: {
			totalTodo: { $size: "$todos"},
			doneTodo: {
				$size: {
					$filter: {
						input: "$todos",
						as: "todos",
						cond: { "$eq": ["$$todos.done", true] }
					}
				}
			}
		}},

		// for TaskId
		{ $lookup: {
			from: "performance",
			let: { taskId: "$_id" },
			pipeline: [
				{ $match: {
					$expr: {
						$and: [
							{ $eq: ["$taskId", "$$taskId"] }
						]
					}
				}},

				// group by user
				{ $group: {
					_id: "$userId",
					earningPoint: { $avg: "$point" },
					userId: { $first: "$userId" },
					taskId: { $first: "$taskId" },
					performances: {
						$push : {
							point: "$point",
							creatorId: "$creatorId"
						}
					}
				}},

				// for userId
				{ $lookup: {
					from: "user",
					localField: "userId",
					foreignField: "_id",
					as: "userId"
				}},
				{ $unwind: {
					path: "$userId",
					preserveNullAndEmptyArrays: true
				}},

				// Get Penalty
				{ $lookup: {
					from: "penalty",
					let: { taskId: "$taskId", userId: "$userId" }, // Model performance -> taskId, userId
					pipeline: [
						{ $match: {
							$expr: {
								$and: [
									{ $in: ["$$userId", "$members"] },
									{ $eq: ["$taskId", "$$taskId"] },
								]
							}
						}}
					],
					as: "penalties"
				}},

				{ $addFields: {
					_id: "$user._id",
					name: "$user.name",
					avt: "$user.avt",
					userId: "$user.userId",
					penaltyPoint: { $sum: "penalties.point" },
					totalPoint: { $subtract: ["$earningPoint", { $sum: "penalties.point" }] }
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					userId: 1,

					totalPoint: 1,
					earningPoint: 1,
					penaltyPoint: 1,
				}}

			],
			as: "performances"
		}},

		{ $addFields: {
			percentComplete: { $multiply: [
				{ "$cond": [{$gt:["$totalTodo", 0]}, { $divide: ["$doneTodo", "$totalTodo"]}, 0] },
				100
			]}
		}},

		// Filter data, keep valuable keys
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			type: 1,
			status: 1,
			priority: 1,
			complete: 1,

			totalTodo: 1,
			doneTodo: 1,
			percentComplete: 1,

			performances: 1,
			totalLength: 1,

			earningPoint: 1,
			totalPoint: 1,
			penaltyPoint: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "performances"]}
	]],

	//`A.printObject:`,
	//`A.responseObject: 200: {"performances": "@dbData"}`
]]);
*/

module.exports = PerformanceRoute;
