const VenueRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar", "meeting"],
		roleUserIdKey	: "userId"
	}
};

VenueRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.modify`,
	`A.verifyInput:: venue: name!, color!`,
	`A.insertOne: venue`,
]]);

VenueRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.modify`,
	`A.verifyInput:: venue: ...`,
	`A.updateOne: venue`,
]]);

VenueRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.delete`,
	`A.deleteOne: venue`,
]]);

VenueRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];

		var name = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);

        if(name) {
            ops.push({ $or: [
				{ name : Req.func.getASCIISearch(name, "gmi") },
				{ number: (name-0) || -1 }
			]});
        }

		if(!ops || ops.length <= 0) {
			pipeData.ops = {};

		} else {
        	pipeData.ops = { $and: ops };
		}

        //console.log(ops);
        return Req.UNRESULT;
    }],

	//`A.findMany: venue::::: name`,
	[`A.aggregate: venue`, [
		{ $match: "@ops" },
		{ $sort: {
			name$: 1
		}},
		{ $project: {
			_id: 1,
			color: 1,
			name: 1,
			name2: 1,
			//modifiedAt: 1,
		}}
	]]
]]);

module.exports = VenueRoute;
