const StorageRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		unAuth: true,
		roleUserIdKey	: "userId"
	}
};

StorageRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	"A.findMany: main.storage"
]]);

module.exports = StorageRoute;
