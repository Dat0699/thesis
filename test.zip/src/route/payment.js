const PaymentRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

PaymentRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findOne(*) > dbData: Payment.payment : {"companyId": "@P.company._id"}`,
	`A.assertObject:::(
		dbData != undefined,
		dbData._id != null,
		dbData.companyId != null
	):{
		respData: "Not existed company!",
		respReturn: true,
		respCode: 503
	}`,
	//`A.printObject: dbData`,

	`A.populate(dbData): user, storageLogs.userId, _id, +, _id, name, name2, userId, avt`,
	`A.responseObject(*): 200 :({
		"<-": "@P.body",
		usageStorage: "@P.company.currentStorage",
		totalStorage: "@P.company.totalStorage"
	})`,
]]);

PaymentRoute.POST.push([["/add/card"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.insertSubItem(*): Payment.payment: {"companyId": "@P.company._id"}: cards: @P.body`,
	//`A.findOne(*): Payment.payment : {"companyId": "@P.company._id"}`,
]]);

PaymentRoute.POST.push([["/remove/card"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.removeSubItem(*): Payment.payment: {"companyId": "@P.company._id"}: cards: @P.body`,
	//`A.findOne(*): Payment.payment : {"companyId": "@P.company._id"}`,
]]);

PaymentRoute.POST.push([["/update/storage"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	//`A.printObject`,
	`A.verifyKObject:: totalStorage!: company.totalStorage`,

	`A.insertSubItem(*) > tmp1: Payment.payment: { "companyId": "@P.company._id" }: storageLogs:
		{totalStorage: "@P.body.totalStorage", userId: "", date: ""}
	`,
	`A.updateSubItem(*) > tmp2: Main.company: {"_id": "@P.company._id"}: totalStorage: @P.body.totalStorage`,
	//`A.printObject`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,
	`A.responseObject: 200: Update storage successfully!`

	//`A.findOne(*): Payment.payment : {"companyId": "@P.company._id"}`,
]]);

PaymentRoute.POST.push([["/forcast"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.responseObject: 200: Forcast successfully!`
]]);

PaymentRoute.POST.push([["/payment"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.responseObject: 200: Payment successfully!`
]]);

PaymentRoute.POST.push([["/topup"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.responseObject: 200: Topup successfully!`
]]);

module.exports = PaymentRoute;
