const BoardRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],

	config	: {
		imProject	: true,
	}
};

BoardRoute.POST.push([[""], [
	"A.verifyInput > reqBody:: board: projectId!, ...",
	`A.findOne > xyz: board: @reqBody`,
    `A.jsScript::(
        if (pipeData.xyz) {
            return {"respData": "Board has existed", "respReturn": true , "respCode" : 400};
        }
	 	return pipeData;
	)`,
    "A.insertOne: board: @reqBody",
]]);

BoardRoute.POST.push([["/s"], [
	"A.verifyInput > reqBody:: board: ...",
	"A.findMany: board: @reqBody",
	`A.refactorOutput:: _id, name, name2, shortName`
]]);

BoardRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.aggregate(*): board: {
        match : {
            "_id" : "@P.route._id"
        }
	}: {
		unwind : {
			"path" : "$groupIds"
		}
	} : {
		lookup : {
			"from" : "task",
            "localField" : "groupIds",
            "foreignField" : "groupId",
            "as" : "tasks"
		}
	}`,
	`A.refactorOutput:: groupIds ,tasks, tasks.groupId-, tasks.subTaskIds-, tasks.relatedTaskIds-, tasks.attachIds-, tasks.todos-, tasks.createdAt-, tasks.modifiedAt-, tasks.modifierId-, tasks.projectId-`,
	`A.populate :group, groupIds, _id, group,+, name, name2, type, shortName, color,
				:label, tasks.labelIds, _id, tasks.labels,+, name, name2, type, descr, color
				:milestone, tasks.milestoneId, _id, tasks.milestone,
				:user, tasks.assigneeIds, _id, tasks.assignee,  +, name, name2,
				:user, tasks.testerIds, _id, tasks.tester,  +, name, name2,
				:user, tasks.reviewerIds, _id, tasks.reviewer,  +, name, name2,
				:user, tasks.watcherIds, _id, tasks.watchers,  +, name`,
	`A.moveKObject(*):: P.body.group._id, P.body._id
				: P.body.group.shortName, P.body.shortName,
				: P.body.group.name, P.body.name,
				: P.body.group.color, P.body.color,
				: P.body.group.type, P.body.type`,
	`A.deleteKObject:: group`,
	`A.refactorOutput`
]]);

BoardRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.verifyObject > reqBody:: board: projectId-, shortName-, creatorId-, createdAt-,...",
	"A.updateById: board",
	`A.responseObject: 200: Update successfully!`
]]);

BoardRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.deleteById: board",
]]);

BoardRoute.POST.push([["/:_id/groups"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: board: groupIds`,
    "A.findById > dbBody: board",
    `A.modifyObject::
        dbBody.groupIds = */reqBody.groupIds`,
    "A.updateById(dbBody): board",

]]);

BoardRoute.DELETE.push([["/:_id/groups"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    "A.verifyInput:: board: groupIds!",
    "A.findById > dbBody: board",
    `A.modifyObject::
    dbBody.groupIds = //groupIds`,
    "A.updateById(dbBody): board",

]]);

module.exports = BoardRoute;
