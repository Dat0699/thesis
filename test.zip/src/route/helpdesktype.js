const HelpDeskTypeRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
        checkMIFs	: ["helpdesk"],
    }
};

HelpDeskTypeRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,

    `A.verifyInput:: helpdesktype: name!, number-, ...`,
	//`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"], type: "@type"}`,

    `A.insertOne: helpdesktype`,
    `A.refactorOutput:: _id, name, name2, type, parentId, persionIncharges, deptIncharge`
]]);

HelpDeskTypeRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,
    //`A.verifyInput > reqBody:: label: projectId!, type, hasGlobal, ...`,

	//`A.pipeRoute: checkLabelGroup: {permit: "view", type: "@type"}`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var name = (body.name || body.search) || (body.text || "");
        body.name = Req.func.getASCIISearch(name, "gmi");

        return Req.UNRESULT;
    }],

	[`A.aggregate: helpdesktype:`, [
		{ $match: { $expr: { $and: [
			{ $not: [{$in: ["$parentId", [null, undefined, "", 0, []]] }] },
			{ $regexMatch: { input: "$name", regex: "@name"} }
		]}}},
		{ $limit: 200 },
		{ $sort: {
			name$: 1,
		}},

		{ $lookup: {
			from: "helpdesktype",
			let: { parentId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$parentId", "$$parentId"] },
					{ $regexMatch: { input: "$name", regex: "@name"} }
				]}}},
				{ $limit: 200 },

				{ $sort: {
					name$: 1,
				}},

				{ $populateFilter: ["user", "persionIncharges:_id", "persionIncharges", true, 1, "_id", "name", "userId", "avt"]},
				{ $populateFilter: ["department", "deptIncharge:_id", "deptIncharge", true, 1, "_id", "name", "avt"]},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					deptIncharge: 1,
					persionIncharges: 1,
				}},

			],
			as: "subTypes",
		}},

		{ $populateFilter: ["user", "persionIncharges:_id", "persionIncharges", true, 1, "_id", "name", "userId", "avt"]},
		{ $populateFilter: ["department", "deptIncharge:_id", "deptIncharge", true, 1, "_id", "name", "avt"]},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			subTypes: 1,
			deptIncharge: 1,
			persionIncharges: 1,
		}},
	]],
], {useZip: true}]);

// User for Setting function
HelpDeskTypeRoute.POST.push([["/full/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,
    //`A.verifyInput > reqBody:: label: projectId!, type, hasGlobal, ...`,

	//`A.pipeRoute: checkLabelGroup: {permit: "view", type: "@type"}`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var name = (body.name || body.search) || (body.text || "");
        body.name = Req.func.getASCIISearch(name, "gmi");

        return Req.UNRESULT;
    }],

	[`A.aggregateOne::`, [
		{ $lookup: {
			from: "helpdesktype",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $not: [{$in: ["$parentId", [null, undefined, "", 0, []]] }]},
					{ $regexMatch: { input: "$name", regex: "@name"} }
				]}}},
				{ $limit: 200 },
				{ $sort: {
					name$: 1,
				}},

				{ $lookup: {
					from: "helpdesktype",
					let: { parentId: "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$parentId", "$$parentId"] },
							{ $regexMatch: { input: "$name", regex: "@name"} }
						]}}},
						{ $limit: 200 },

						{ $sort: {
							name$: 1,
						}},

						{ $addFields: {
							persionIncharges: { $ifNull: ["$persionIncharges", []]}
						}},

						{ $populateFilter: ["user", "persionIncharges$:_id", "persionIncharges", undefined, 1, "_id", "name", "userId", "avt"]},
						{ $populateFilter: ["department", "deptIncharge:_id", "deptIncharge", true, 1, "_id", "name", "avt"]},

						{ $project: {
							_id: 1,
							name: 1,
							name2: 1,
							deptIncharge: 1,
							persionIncharges: 1,
						}},

					],
					as: "subTypes",
				}},

				{ $addFields: {
					persionIncharges: { $ifNull: ["$persionIncharges", []]}
				}},
				{ $populateFilter: ["user", "persionIncharges$:_id", "persionIncharges", undefined, 1, "_id", "name", "userId", "avt"]},
				{ $populateFilter: ["department", "deptIncharge:_id", "deptIncharge", true, 1, "_id", "name", "avt"]},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					subTypes: 1,
					deptIncharge: 1,
					persionIncharges: 1,
				}},
			],
			as: "types"
		}},

		{ $lookup: {
			from: "department",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $regexMatch: { input: "$name", regex: "@name"} }
				]}}},
				{ $sort: {
					name$: 1,
				}},
				{ $populateFilter: ["user", [
					{ $let: { members: "$members"}},
					{ $expr: { $and: [
						{ $in: ["$_id", "$$members"] },
						{ $not: [{$in: ["$hasActived", [false]] }]},
						{ $not: [{$in: ["$hasDeleted", [true]] }]},
						{ $not: [{$in: ["$hasLocked", [true]] }]},
					]}},
				], "members", undefined, 1, "_id", "name", "userId", "avt"]},

				{ $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
                { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,

                    members: 1,
					leader: 1,
                    viceLeaders: 1,

					canResolveRequest: 1,
					canMakeRequest: 1,
				}}
			],
			as: "departments"
		}}

	]],
], {useZip: true}]);

HelpDeskTypeRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.verifyInput:: helpdesktype: number-, ...`,
	//`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"]}`,

    `A.updateById(*): helpdesktype: { _id: "@P.route._id" }: @P.body`,
    `A.responseObject: 200, Update successfully!`,
]]);

HelpDeskTypeRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	//`A.pipeRoute: checkLabelGroup: {permit: ["view", "delete"]}`,

    `A.deleteById(*): helpdesktype: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete successfully!`
]]);

// For department update
/*
HelpDeskTypeRoute.POST.push([["/department/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var name = (body.name || body.search) || (body.text || "");
        body.name = Req.func.getASCIISearch(name, "gmi");

        return Req.UNRESULT;
    }],

	[`A.aggregate: department:`, [
		{ $match: { $expr: { $and: [
			{ $regexMatch: { input: "$name", regex: "@name"} }
		]}}},
		{ $sort: {
			name$: 1,
		}},

		{ $populateFilter: ["user", [
			{ $let: { members: "$members"}},
			{ $expr: { $and: [
				{ $in: ["$_id", "$$members"] },
				{ $not: [{$in: ["$hasActived", [false]] }]},
				{ $not: [{$in: ["$hasDeleted", [true]] }]},
				{ $not: [{$in: ["$hasLocked", [true]] }]},
			]}},
		], "members", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
        { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			members: 1,
			caption: 1,
			canResolveRequest: 1,
			canMakeRequest: 1,
		}}
	]],
], {useZip: true}]);
*/

HelpDeskTypeRoute.PUT.push([["department/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: helpdesk.view, helpdesk.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.verifyInput:: department: canResolveRequest, canMakeRequest`,
	//`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"]}`,

    `A.updateById(*): department: { _id: "@P.route._id" }: @P.body`,
    `A.responseObject: 200, Update successfully!`,
]]);

module.exports = HelpDeskTypeRoute;
