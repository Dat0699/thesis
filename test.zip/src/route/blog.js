const BlogRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
	}
};

BlogRoute.POST.push([[""], [
	`A.pipeRoute: isGitGamWebSite`,
	`A.verifyInput:: Public.blog: name!, content, ...`,
	`A.insertOne: Public.blog`,
]]);


BlogRoute.POST.push([["/s"], [
	`A.pipeRoute: blogList`,
	`A.responseObject(*): 200: @P.body`,
], {
	useZip: true,
	imCompany: false,
	unAuth: true,
}]);

BlogRoute.POST.push([["/edit/s"], [
	`A.pipeRoute: blogList`,
	`A.responseObject(*): 200: @P.body`,
], {
	useZip: true,
}]);

BlogRoute.PIPE.push([["blogList"], [
	`A.verifyInput:: Public.blog: language`,
	//`A.findMany: Public.blog`,

	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var user = Req.user || {};

		var search = (body.search || body.text) || (body.name || "");

		body.search = Req.func.getASCIISearch(search, "gmi");
		body.isGitGam = ((Req.company||{}).shortName||"").toLowerCase() == "gitgam";
		body.hasAdmin = user.hasAdmin || user.hasAgent;
		body.hasGitGamAdmin = body.isGitGam && body.hasAdmin;

		return Req.UNRESULT;
	}],

	[`A.aggregate: Public.blog `, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$isPublic", true] },
			{ $eq: ["@hasGitGamAdmin", true]},
			//{ language: "@language" },
		]}}},
		{ $addFields: {
			creator: {
				_id: "$creatorId",
				userId: "$userRef",
				name: "$userName",
				avt: 100,
			}
		}},
		{ $sort: {
			colIndex: 1,
			createdAt: -1,
			number: -1
		}},
		{ project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			colIndex: 1,
			content: 1,
			userName: 1,
			language: 1,
			createdAt: 1,
			creator: 1,
			isPublic: 1
		}}
	]]
], { name: "blogList" }]);


BlogRoute.GET.push([["/:_id"], [
	`A.pipeRoute: blogDetail`,
	`A.responseObject(*): 200: @P.body`,
], {
	imCompany: false,
	unAuth: true,
}]);

BlogRoute.GET.push([["/edit/:_id"], [
	`A.pipeRoute: blogDetail`,
	`A.responseObject(*): 200: @P.body`,
]]);

BlogRoute.PIPE.push([["blogDetail"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	//`A.findOne: Public.blog`,

	[`A.aggregateOne: Public.blog`, [
		{ $match: { $expr: { $or: "@ops" }}},
		{ $addFields: {
			creator: {
				_id: "$creatorId",
				userId: "$userRef",
				name: "$userName",
			}
		}},
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			content: 1,
			userName: 1,
			createdAt: 1,
			creator: 1,
			isPublic: 1,
		}}
	]]

], { name: "blogDetail" }]);


BlogRoute.DELETE.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: Public.blog`,
]]);

BlogRoute.PUT.push([[":_id/move/position"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: Public.blog: colIndex, parentId!`,

	`A.updateById(*) > blogDb : Public.blog: { _id: "@P.route._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update blog successfully!`
]]);

BlogRoute.PUT.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: Public.blog: number-, ...`,
	`A.updateById(*): Public.blog: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject: 200: Update successfully!`,
]]);


// Check for permission
BlogRoute.PIPE.push([["isGitGamWebSite"], [
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var company = Req.company || {};
		if((company.shortName||"").toLowerCase() == "gitgam") {

			var user = Req.user || {};
			var hasAdmin = user.hasAdmin || user.hasAgent || user.hasSupport;
			if(hasAdmin) {
				return Req.UNRESULT;
			}
		}

		return {
			respCode: 500,
			respReturn: true,
			respData: "Invalid request!"
		};
	}]
], { name: "isGitGamWebSite" }]);

module.exports = BlogRoute;
