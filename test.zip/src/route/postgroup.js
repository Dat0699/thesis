const PostGroupRoute = {
    route	: "post/:serverId/group",
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        checkMIFs	: ["project"],
		imProject	: true,
    }
};

PostGroupRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

    `A.verifyInput:: postgroup: name!, projectId!, serverId!, ...`,
    `A.insertOne: postgroup`,

	`A.pipeRoute: postgroup { type: "create" }`,
	`A.refactorOutput:: _id, name, name2, descr, colIndex`,
]]);

PostGroupRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    `A.findOne(*): postgroup: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,
    `A.refactorOutput:: _id, name, name2, descr, colIndex`,
]]);

PostGroupRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.findOne(P.route): postgroup: {_id: "@_id", serverId: "@serverId"}`,
	`A.verifyInput:: postgroup: _id-, number-, ...`,

	`A.insertById > P.postgroup: postgroup`,
	`A.cloneById(*) > P.lookUp: postapi:: {groupId: "@P.route._id"}: {groupId: "@P.postgroup._id"}: 500:: _id-, number-`,

	// Need checking sub folder

	/*
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;

		var A = pipeData.A;
		var group = await A.insertOne(Req, pipeData, "postgroup", body);

		//console.log("Group: ", group, Req.route._id);
		var apis = await A.findMany(Req, pipeData, "postapi", {serverId: group.serverId, groupId: Req.route._id});
		for (var i = 0; i < apis.length; i++) {
			var api = apis[i];
			api.groupId = group._id;

			delete api._id;
			delete api.number;
		}

		//console.log("Insert: ", apis);
		var napis = await A.insertMany(Req, pipeData, "postapi", apis, 200);
		return Req.UNRESULT;
	}],
	*/

	`A.pipeRoute: postgroup: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostGroupRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: postgroup: colIndex, parentId, projectId!`,

	`A.updateById(*) > postgroupDb : postgroup: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update postgroup successfully!`
]]);

PostGroupRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyInput:: postgroup: projectId-, serverId-, creatorId-, createdAt-, modifierId-, modifiedAt-, ...`,

	`A.updateById(*): postgroup: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: @P.body`,

	`A.pipeRoute: postgroup { type: "update" }`,
    `A.refactorOutput:: _id, name, name2, descr, colIndex`,
]]);

PostGroupRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessPostServer: {role: "delete"}`,

	`A.deleteById(*): postgroup: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,

	`A.pipeRoute: postgroup { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = PostGroupRoute;
