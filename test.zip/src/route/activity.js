const ActivityRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.dashboard",
		checkMIFs 		: ["project", "dashboard"],
		imProject 		: true,
		keepRole		: true,
	}
};

ActivityRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject`,
	//`A.printObject:`,
    [`A.jsScript`, async (Req, body, ctx) => {
		var body = Req.body;

		var matchOps = {};
		//var milestoneOps = {};
		//var milestoneOps2 = { $nin: [true] };

		var startDate = body.fromDate || body.startDate;
		var endDate = body.toDate || body.endDate;
		var userIds = (body.userId || body.userIds);// || Req.user._id;

		var milestoneIds = (body.milestone || body.milestones) || (body.milestoneId || body.milestoneIds);
		var projectIds = (Req.project._id || Req.query.projectId || Req.header.projectId); // ||
		 				 //(body.projectId || body.projectIds);

		var modelTask = "__anyModelName__";
		var types = (body.type || body.types) || [];// || Req.user._id;
 		if(types) {
 			if(!Array.isArray(types)) {
 				types = [types];
 			}

			// Remove type was not enable or permit
			for (var i = 0; i < types.length; i++) {
				// ["task","milestone","wiki","document","sourcecode","testcase","postapi","logtime","performance","penalty","changeLog","cost","risk"]
				var type = types[i];
				type = {
					penalty: "performance",
					changeLog: "changelog",
				}[type] || type;

				types[i] = type;
				if(types.indexOf(type, i+1) > 0) {
					types.splice(i--, 1);
				}
			}
 		}

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAdmin;
		if(!hasAdmin && (types && (types.length > 0))) {

			var pfeature = (Req.project||{}).feature || {};
			var cfeature = (Req.company||{}).feature || {};
			var prole = (Req.roleproject||{}).permit || {};

			// Remove type was not enable or permit
			for (var i = 0; i < types.length; i++) {
				// ["task","milestone","wiki","document","sourcecode","testcase","postapi","logtime","performance","penalty","changeLog","cost","risk"]
				var type = types[i];
				type = {
					penalty: "performance",
					changeLog: "changelog",
				}[type] || type;

				if(type) {
					var enable = (cfeature[type] && pfeature[type]) && (prole[type]||{}).view;
					if(!enable) {
						types.splice(i--, 1);
					}
				}
			}
		}

		if(types && (types.length > 0)) {
			matchOps.type = { $in: types };
		}

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
			// if(milestoneIds.length > 0) {
			// 	milestoneOps["$and"] = [
			// 		{ $or: [
			// 			{ milestoneId: { $in: milestoneIds }},
			// 			{ milestoneId: { $in: [undefined, null, ""] }}
			// 		]},
			// 		{ type: { $in: ["task"] }}
			// 	];
			// 	//milestoneOps2 = { $gt: 0 };
			// }
		}

		// Milestine in: task, risk, logtime->task, milestone->_id, (costledger -> task, issues log, changelog, )
		if((!types) || (types.length <= 0) || types.join(",").match(/(task|logtime|cost)/gmi)) {
			if(milestoneIds && (milestoneIds.length > 0)) {
				// Get list task for milestone Filter
				modelTask = "task";
			}
		}

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				matchOps.projectId = { $in: projectIds };
			}
		}

		if(!startDate) {
			var date = new Date();
			startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
		} else {
			startDate = new Date(startDate);
		}

		if(!endDate) {
			var date = new Date();
			endDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59);
		} else {
			endDate = new Date(endDate);
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				matchOps.userId = { $in: userIds };
			}
		}

		if(startDate && endDate) {
			matchOps["$and"] = [
				{ createdAt: { $gte: startDate }},
				{ createdAt: { $lte: endDate }},
			];
		}

		body.matchOps = matchOps;
		//body.milestoneOps = milestoneOps;

		body.milestoneIds = milestoneIds || [];
		body.modelTask = modelTask;
		body.types = types;

		//console.log("body: ", body, types, matchOps);
        return Req.UNRESULT;
    }],

	`A.getPaginate > dbQuery`,
	//`A.printObject`,

	[`A.aggregateOne > dbData::`, [
		// Get list filter
		{ $lookup: {
			from: "@modelTask",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$milestoneId", "@milestoneIds"] },
				]}}},
				{ $project: {
					_id: 1
				}},
			],
			as: "taskIds"
		}},

		{ $addFields: {
			taskIds: { $ifNull: ["$taskIds._id", [] ]},
		}},
		{ $addFields: {
			hasEmptyFilter: { $cond: [
				{ $and: [
					{ $in: ["$taskIds", [[], undefined, null, "", false]] },
					{ $in: ["@milestoneIds", [[], undefined, null, "", false]] },
				]},
				true,
				false,
			]},

			hasEmptyMilestone: { $cond: [
				{ $in: ["@milestoneIds", [[], undefined, null, "", false]] },
				true,
				false
			]},
		}},

		// Get list activities
		{ $lookup: {
			from: "activity",
			let: {
				taskIds: "$taskIds",
				hasEmptyFilter: "$hasEmptyFilter",
				hasEmptyMilestone: "$hasEmptyMilestone"
			},
			pipeline: [
				{ $match: "@matchOps" },
				{ $addFields: {
					taskId: { $ifNull: ["$taskId", null]},
					refId: { $ifNull: ["$taskId", null]},
				}},
				{ $match: { $expr: { $or: [
					{ $not: [{$in: ["$type", ["task", "milestone", "risk", "logtime", "cost"]]} ]},

					// Task
					{ $and: [
						{ $in: ["$type", ["task"]] },
						{ $or: [
							//{ $in: ["$refId", "$$taskIds"] },
							{ $in: ["$refId", "$$taskIds"] },
							{ $eq: ["$refId", null] },
							{ $eq: ["$$hasEmptyFilter", true] },
						]}
					]},

					// Milestone
					{ $and: [
						{ $in: ["$type", ["milestone"]] },
						{ $or: [
							{ $eq: ["$$hasEmptyMilestone", true] },
							{ $in: ["$refId", "@milestoneIds"] },
							{ $eq: ["$refId", null] },
						]}
					]},

					// Risk
					{ $and: [
						{ $in: ["$type", ["risk"]] },
						{ $or: [
							{ $eq: ["$$hasEmptyMilestone", true] },
							{ $in: ["$milestoneId", "@milestoneIds"] },
							{ $eq: ["$milestoneId", null] },
						]}
					]},

					// Logtime, Cost
					{ $and: [
						{ $in: ["$type", ["logtime", "cost"]] },
						{ $or: [
							//{ $in: ["$refId", "$$taskIds"] },
							{ $in: ["$taskId", "$$taskIds"] },
							{ $eq: ["$taskId", null] },
							{ $eq: ["$$hasEmptyFilter", true] },
						]}
					]},
				]}}},



					//
					// { $in: ["$milestoneId", "@milestoneIds"] },
					// { $in: ["$taskId", "$$taskIds"] },
				//}}},

				// // { $lookup: {
				// // 	from: "task",
				// // 	let: { taskNumber: "$number", projectId: "$projectId", typeItem: "$type" },
				// // 	pipeline: [
				// // 		{ $match: { $expr: { $and: [
				// // 			{ $in: ["$$typeItem", ["task"]] },
				// // 			{ $eq: ["$number", "$$taskNumber"] },
				// // 			{ $eq: ["$project", "$$projectId"] },
				// // 		]}}},
				// // 		{ $match: "@milestoneOps" }
				// // 	],
				// // 	as: "taskDetail"
				// // }},
				// //
				// // { $addFields: {
				// // 	taskDetail: { $ifNull: ["$taskDetail", -1] }
				// // }},
				// //
				// // { $match: { $or: [
				// // 	{ type: { $nin: ["task"] }},
				// // 	{ taskDetail: "@milestoneOps2"}
				// // ]}},
				//
				// { $project: {
				// 	taskDetail: 0
				// }},

				{ $sort: {
					createdAt: -1
				}},

				{ $skip: "@dbQuery.pageStart" },
				{ $limit: "@dbQuery.pageLength" },

				// Register
				// model, localField, foreignField, saveAs, keepEmpty (true, false, undefined)
				//{ $populate: ["user", "userId", "_id", "userId", false] }, // Remove deteled suer

				{ $addFields: {
					userId: { $ifNull: ["$userId", "$creatorId"]}
				}},

				{ $project: {
					_id: 1,
					type: 1,
					subType: 1,
					content: 1,
					oldContent: 1,
					refId: 1,
					refNum: 1,
					createdAt: 1,
					userId: 1,
					// "userId._id": 1,
					// "userId.name": 1,
					// "userId.name2": 1,
					// "userId.avt": 1,
					// "userId.userId": 1,
				}},

				{ $convertDate: ["createdAt -> createdAtLocal"]},
				{ $group: {
					_id: {
						year: { $year: "$createdAtLocal" },
						month: { $month: "$createdAtLocal" },
						day: { $dayOfMonth: "$createdAtLocal" },
					},
					date: { $first: "$createdAt" },
					listDays: {
						$push: "$$ROOT"
					},
					//userIds: { $push: "$userId" }
				}},
				{ $sort: {
					date: -1
				}},
			],
			as: "activities"
		}},

		{ $flatArray: {
			userIds: "$activities.listDays.userId"
		}},

		{ $addFields: {
			userIds: { $setUnion: "$userIds" },
		}},

		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "_id", "name", "avt", "userId"] },

		{ $project: {
			users: 1,
			activities: 1,
			//userIds: 1,
			//taskIds: 1,
			//taskIds2: 1,
			//userIds2: 1
		}}
	]],

	//`A.printObject:`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var dbData = body.dbData || {};

		var userObj = {};
		var users = dbData.users || [];
		users.map(u => {
			userObj[u._id.toString()] = u;
		});

		var activities = dbData.activities || [];
		activities.map(act => {
			(act.listDays||[]).map(a => {
				if(a.userId) {
					a.userId = userObj[a.userId.toString()];
				}
			});
		});

		//console.log("body: ", body);
		return activities;
	}],

	//`A.printObject:`,
	//`A.responseObject: 200: @activities`,

], { useZip: true }]);

module.exports = ActivityRoute;
