
const ProjectRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
    PIPE     : [],

    config	: {
		checkMIFs		: ["project"],
		imProject		: true,
		projectIdName	: "_id",

        //EnableProfiling	: true,
		//imProjectRole	: true,
    }
}


ProjectRoute.POST.push([[":type:(/(s|postapi)/)"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.view",
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		var name = pipeData.name || (pipeData.search || pipeData.title);
		if(name) {
			ops.name = Req.func.getASCIISearch(name, "gmi");
		}

		var user = Req.user || {};
		if(!user.hasAdmin && !user.hasAgent) {
			ops.members = { $elemMatch: {
				user: { $in: [user._id] }
			}};
			ops.status = { $in: [1] };
		}

		var query = Req.query || {};
		var postApi = (Req.route||{}).type;
		if((postApi == "postapi") || (query && query.feature)) {
			var features = postApi || (query.feature || query.features || "");
			features = features.replace(/[\s\t]/gmi, "").split(",");
			features.map(f => {
				ops[`feature.${f.trim()}`] = true;
			});
		}

		//console.log("Ops: ", ops);
		pipeData.ops = ops;
		return Req.UNRESULT;
    }],

	[`A.aggregate: project:`, [
		{ $match: "@ops" },
		{ $addFields: {
			countMember: { $size: "$members" }
		}},
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			status: 1,
			hasCompleted: 1,
			//types: 1,
			//descr: 1,
			//descrHTML: 1,
			//countMember: 1,
			//startDate: 1,
			//dueDate: 1,
		}}
	]]
], {imProject: false}]);

ProjectRoute.POST.push([["full/s"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

	//`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`, // no check
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.view",
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var projectOps = {};

		var name = pipeData.name || (pipeData.search || pipeData.title);
		var startDate = pipeData.startDate || pipeData.fromDate;
		var endDate = pipeData.dueDate || (pipeData.endDate || pipeData.toDate);

		var status = pipeData.status || pipeData.statuses;

		if(startDate) {
			projectOps.startDate = { $lte: new Date (endDate) };
		}
		if(endDate) {
			projectOps.dueDate = { $gte: new Date (startDate) };
		}

		if(name) {
			projectOps.name = Req.func.getASCIISearch(name, "gmi");
		}

		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				projectOps.status = { $in: status };
			}
		}

		var user = Req.user || {};
		if(!user.hasAdmin && !user.hasAgent) {
			projectOps.members = { $elemMatch: {
				user: { $in: [user._id] }
			}}
			projectOps.status = { $in: [1] };
		}

		pipeData.projectOps = projectOps;
		return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: project:`, [
		{ $match: "@projectOps" },
		{ $getTotalLength: "@page" },

		{ $addFields: {
			countMember: { $size: "$members" }
		}},

		// Add task
		// { $populate: ["task", "_id", "projectId", "tasks"]},
		{ $lookup: {
			from: "task",
			let: { projectId : "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "$$projectId"] },
				]}}},
				{ $addFields: {
					//countTodo: "$totalTodo", //{ $size: "$todos" },
					//countDoneTodo: "$doneTodo",

					// {
					// 	$size: {
					// 		$filter: {
					// 			input: "$todos",
					// 			as: "todos",
					// 			cond: { "$eq": ["$$todos.done", true] }
					// 		}
					// 	}
					// },
					hasTaskDone: { "$cond": [{ $eq:["$status", 6] }, 1, 0] },
				}},
			],
			as: "tasks"
		}},

		/*
		// Add Logtime
		//{ $populate: ["logtime", "_id", "projectId", "logtimes"]},
		{ $lookup: {
			from: "logtime",
			let: { projectId : "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "$$projectId"] },
				]}}},
				{ $addFields: {
					approvedHour: { $cond: [{$eq: ["$status", 2]}, "$hour", 0]},
				}},
			],
			as: "logtimes"
		}},
		*/

		{ $addFields: {
			now: "$$NOW"
		}},

		{ $convertDate: ["dueDate -> dueDateLocal", "startDate -> startDateLocal", "now -> nowLocal"]},

		{ $addFields: {
			//countTodo: { $sum: "$tasks.countTodo"},
			//countDoneTodo: { $sum: "$tasks.countDoneTodo"},

			taskCount: { $size: "$tasks" },
			taskDone: { $sum: "$tasks.hasTaskDone" },

			//logtimeCount: { $size: "$logtimes" },
			//logtimeHour: { $sum: "$logtimes.hour" },
			//logtimeApprovedHour: { $sum: "$logtimes.approvedHour" },

			//dueDate: { $ifNull: ["$dueDate", "$$nowLocal"]},
			duration: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000]},
			dayRemaining: { $divide: [{$subtract: ["$dueDateLocal", "$nowLocal"]}, 86400000]},
			dayComplete: { $divide: [{$subtract: ["$nowLocal", "$startDateLocal"]}, 86400000]},
		}},

		{ $addFields: {
			//dayRemaining: { $cond: [{$lt: ["$dayRemaining", 0]}, {$sum: ["$dayRemaining", -1]}, "$dayRemaining"]},
			//dayComplete: { $cond: [{$lt: ["$dayComplete", 0]}, {$sum: ["$dayComplete", -1]}, "$dayComplete"]},
			//dayComplete: { $add: ["$dayComplete", -1]},

			taskRemaining: { $subtract: ["$taskCount", "$taskDone"]},
			complete: { $multiply: [{$divide: ["$taskDone", {$cond:[{$lte: ["$taskCount", 1]}, 1, "$taskCount"]}]}, 100]},
			completeDay: { $multiply: [{$divide: ["$dayComplete", {$cond:[{$lte: ["$duration", 1]}, 1, "$duration"]}]}, 100]},
		}},

		{ $addFields: {
			dayComplete: { $floor: "$dayComplete" },
			dayRemaining: { $floor: "$dayRemaining" },
			delta: { $subtract: ["$completeDay", "$complete"]},
		}},

		{ $addFields: {
			completeDay: { $ceil: "$completeDay" },

			statusColor: {$cond: [
				{ $or: [{ $lte: ["$dayComplete", 0]}, {$lte: ["$completeDay", 0]} ]},
				"#0e69de",
				{ $cond: [
					{ $or: [{ $eq: ["$hasCompleted", true] }, { $gte: ["$complete", 97.5] }] },
					"#01ac58",

					{ $cond: [
						{$gte: ["$delta", 35]},
						"#495b7c",
						{ $cond: [
							{$gte: ["$delta", 20]},
							"#db4b36",
							{ $cond: [
								{$gte: ["$delta", 10]},
								"#e25d18",
								{ $cond: [
									{$gte: ["$delta", 5]},
									"#0e69de",
									{ $cond: [
										{$gte: ["$delta", 2]},
										"#01ac58",
										"#27ae66",
									]}
								]}
							]}
						]}
					]}
				]}
			]},

			statusMode: {$cond: [
				{ $or: [{ $lte: ["$dayComplete", 0]}, {$lte: ["$completeDay", 0]} ]},
				"",

				{ $cond: [
					{ $or: [{ $eq: ["$hasCompleted", true] }, { $gte: ["$complete", 97.5] }] },
					"blue",
					{ $cond: [
						{$gte: ["$delta", 35]},
						"black",
						{ $cond: [
							{$gte: ["$delta", 20]},
							"red",
							{ $cond: [
								{$gte: ["$delta", 10]},
								"orange",
								{ $cond: [
									{$gte: ["$delta", 5]},
									"blue",
									{ $cond: [
										{$gte: ["$delta", 2]},
										"blue",
										"green",
									]}
								]}
							]}
						]}
					]}
				]}
			]},

			statusMessage: {$cond: [
				{ $or: [{ $lte: ["$dayComplete", 0]}, {$lte: ["$completeDay", 0]} ]},
				"Will start soon!",

				{ $cond: [
					{ $or: [{ $eq: ["$hasCompleted", true] }, { $gte: ["$complete", 97.5] }] },
					"Yes, Trying to Target!",
					{ $cond: [
						{$gte: ["$delta", 35]},
						"Uhm, Fastest ASAP!",
						{ $cond: [
							{$gte: ["$delta", 20]},
							"Oh, Keep Faster!",
							{ $cond: [
								{$gte: ["$delta", 10]},
								"Yah, Let's Trying More!",
								{ $cond: [
									{$gte: ["$delta", 5]},
									"On Progress!",
									{ $cond: [
										{$gte: ["$delta", 2]},
										"On Good!",
										"So Excellent!",
									]}
								]}
							]}
						]}
					]}
				]}
			]}
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			types: 1,
			descr: 1,
			descrHTML: 1,
			countMember: 1,
			startDate: 1,
			dueDate: 1,
			status: 1,
			hasCompleted: 1,
			totalLength: 1,

			//countTodo: 1,
			//countDoneTodo: 1,
			taskCount: 1,
			taskDone: 1,
			taskRemaining: 1,

			//logtimeHour: 1,
			//logtimeCount: 1,
			//logtimeApprovedHour: 1,

			dayRemaining: 1,
			dayComplete: 1,

			taskRemaining: 1,
			taskComplete: 1,

			delta: 1,
			complete: 1,
			completeDay: 1,

			duration: 1,
			statusColor: 1,
			statusMode: 1,
			statusMessage: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "projects"]}
	]]

], { imProject: false, useZip: true } ]);

ProjectRoute.POST.push([["/detail"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

	[`A.aggregateOne(*) > dbData::`, [
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: {
					$or: [
						{ shortName: "@P.body.shortName" },
						{ _id: "@P.body.shortName" }
					],
					//{ status: 1 }
				}},
				{ $match: { $expr: { $or: [
					{ $in: ["@P.user._id", "$members.user"] },
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]}}},

				{ $addFields: {
					actMilestoneIds: { $ifNull: ["$actMilestoneIds", []]},
					actSprintIds: { $ifNull: ["$actSprintIds", []]},
					actFeatureIds: { $ifNull: ["$actFeatureIds", []]},
                    actLabelIds: { $ifNull: ["$actLabelIds", []]},
				}},

				{ $populateFilter: ["milestone", "actMilestoneIds$:_id", "actMilestones", undefined, 1, "_id", "name", "name2", "color", "number", "status"]},
				{ $populateFilter: ["sprint", "actSprintIds$:_id", "actSprints", undefined, 1, "_id", "name", "name2", "color", "number", "status"]},
				{ $populateFilter: ["feature", "actFeatureIds$:_id", "actFeatures", undefined, 1, "_id", "name", "name2", "color", "number", "status"]},
                { $populateFilter: ["label", "actLabelIds$:_id", "actLabels", undefined, 1, "_id", "name", "name2", "color", "number", "type"]},
				//{ $populate: ["milestone", "actMilestoneIds", "_id", "actMilestones", undefined]},
				//{ $populate: ["sprint", "actSprintIds", "_id", "actSprints", undefined]},
				//{ $populate: ["feature", "actFeatureIds", "_id", "actSprints", undefined]},
			],
			as: "project",
		}},
		{ $unwind: {
			path: "$project",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			projectId: "$project._id",
		}},

		// Get Groups List ============================
		{ $lookup: {
			from: "group",
			let: { projectId: "$projectId" },
			pipeline: [
				{ $match: {
					$and: [
			            { type : "task" },
			            { $or: [
			                { hasGlobal: true },
			                { projectId : "$$projectId" }
			            ]}
			        ]
				}},
				{ $sort: {
					value: 1,
					name$: 1,
					colIndex: 1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
					type: 1,
					value: 1
				}}
			],
			as: "listTaskGroups"
		}},

		// Get Milestones List ============================
		{ $lookup: {
			from: "milestone",
			let: { projectId: "$projectId" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "$$projectId"] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
                    number: 1,
					//descr: 1,
					//budget: 1,
					startDate: 1,
					endDate: 1,
				}},

				{ $addFields: {
					color: { $ifNull: ["$color", "#70CD5F"]},
				}},

				{ $sort: {
					colIndex: 1,
					name$: 1
				}}
			],
			as: "listMilestones"
		}},

		// Get Sprints List ============================
		{ $lookup: {
			from: "sprint",
			let: { projectId: "$projectId" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "$$projectId"] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
                    number: 1,
					//descr: 1,
					//budget: 1,
					startDate: 1,
					dueDate: 1,
					milestoneId: 1,
				}},

				{ $addFields: {
					color: { $ifNull: ["$color", "#70CD5F"]},
				}},

				{ $sort: {
					colIndex: 1,
					name$: 1
				}}
			],
			as: "listSprints"
		}},

		// Get Labels List ============================
		{ $lookup: {
			from: "label",
			let: { projectId: "$projectId" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$hasGlobal", true]},
						{ $eq: ["$projectId", "$$projectId"]},
					]},
					{ $in: ["$type", ["all", "task"]]},
				]}}},
				{ $sort: {
					name$: 1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
					type: 1,
					hasGlobal: 1,
				}},
			],
			as: "listLabels",
		}},

		// Get Users List ============================
		{ $addFields: {
			projectMembers: { $ifNull: ["$project.members.user", []]},
		}},
		{ $lookup: {
			from: "user",
			let: { members: "$projectMembers" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$_id", "$$members"] },
					{ $not: [{$in: ["$hasActived", [false]] }]},
					{ $not: [{$in: ["$hasDeleted", [true]] }]},
					{ $not: [{$in: ["$hasLocked", [true]] }]},
					{ $eq: ["$status", 1] },
				]}}},
				{ $sort: {
					name$: 1
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					userId: 1,
				}}
			],
            as: "listMembers"
        }},
		{ $project: {
			projectId: 0,
			projectMembers: 0,
		}},
	]],

	//`A.printObject:`,
	//`A.findById: project: {$or:[ {shortName: "@shortName"}, {_id: "@shortName"} ]}`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var UtilFn = pipeData.U.Func;
		var company = Req.company;

		var cf = UtilFn.featureConfig({
			...(company.feature||{}),
			...(company.featurePackage||{}),
			...(pipeData.K.API.FeatureConfig||{})
		});

		var dbData = (Req.body||{}).dbData || {};
		var project = dbData.project || {};
		var pf = project.feature;

		var user = Req.user;
		var userId = user._id.toString();

		var hasAdmin = user.hasAgent || user.hasAdmin;
		if(!pf || !cf || !cf.project || (!hasAdmin && JSON.stringify(project.members||[]).indexOf(userId) < 0)) {
			return {
				respCode: 500,
				respData: "User was not permitted!",
				respReturn: true,
			};
		}

		var projectRole = {};
		if(!hasAdmin) {
			var A = pipeData.A;
			var roleModel = pipeData.K.Mongo.RoleProjectModel || "roleproject";
			projectRole = A.getRoleId(Req, pipeData, project, user._id);
			if(!projectRole) {
				return {
					respCode: 500,
					respData: "User was not permitted!",
					respReturn: true,
				};
			}

			projectRole = await A.getDBCachedObject(Req, pipeData, roleModel, projectRole);
			projectRole = (projectRole||{}).permit;
			delete company.members;

			if(!projectRole) {
				return {
					respCode: 500,
					respData: "You were not recognized on this project!",
					respReturn: true,
				};
			}
		}

		// Delete project role
		// delete (projectRole.label||{}).view;
		// delete (projectRole.milestone||{}).view;

		// Lock information when project disable
		var projectFeature = {};
		if((project.status != 1) || project.hasCompleted) {
			projectRole = { setting: (projectRole||{}).setting };

		} else {
			projectFeature = {
				dashboard		: cf.dashboard && pf.dashboard,
				feature			: cf.feature && pf.feature,
				sprint			: cf.sprint && pf.sprint,
                planning		: cf.planning && pf.planning,
				task		    : cf.task && pf.task,
				milestone		: cf.milestone && pf.milestone,
				document		: cf.document && pf.document,
				wiki		    : cf.wiki && pf.wiki,
				gantt	        : cf.gantt && pf.gantt,
				performance	    : cf.performance && pf.performance,
				cost		    : cf.cost && pf.cost,
				logtime	        : cf.logtime && pf.logtime,
				changelog		: cf.changelog && pf.changelog,
				risk	        : cf.risk && pf.risk,
				sourcecode		: cf.sourcecode && pf.sourcecode,
				cicd		    : cf.cicd && pf.cicd,
				vmmachine		: cf.vmmachine && pf.vmmachine,
				automation		: cf.automation && pf.automation,
			    postapi		    : cf.postapi && pf.postapi,
			    testcase		: cf.testcase && pf.testcase,
				issuelog		: !!(cf.issuelog && pf.issuelog),
			}
		}

		//console.log("Project Role: ", projectRole);
		var rs = {
			_id			: project._id,
			name		: project.name,
			shortName	: project.shortName,
			avt			: project.avt,
			types		: project.types,
			descr		: project.descr,
			startDate	: project.startDate,
			dueDate		: project.dueDate,
			createdAt	: project.createdAt,
			status		: project.status,
			feature		: projectFeature,
			maxDocSize	: project.maxDocSize,

			listMembers		: dbData.listMembers || [],
			listLabels		: dbData.listLabels || [],
			listSprints		: dbData.listSprints || [],
			listMilestones	: dbData.listMilestones || [],
			listTaskGroups	: dbData.listTaskGroups || [],

			actLabels		: project.actLabels,
            actSprints		: project.actSprints,
			actMilestones	: project.actMilestones,

            actLabelIds     : project.actLabelIds,
			actFeatureIds	: project.actFeatureIds,
			actSprintIds	: project.actSprintIds,
			actMilestoneIds	: project.actMilestoneIds,

			projectRole,
		}

		//console.log("RS: ", rs, project, dbData);
		Req.respCode = 200;
		return rs;
	}]
], { imProject: false, useZip: true }]);

ProjectRoute.GET.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.view",

	[`A.aggregateOne(*) > dbData: project`, [
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: {
					$or: [
						{ shortName: "@P.body.shortName" },
						{ _id: "@P.body.shortName" }
					],
				}},
				{ $match: { $expr: { $or: [
					{ $and: [
						{ $in: ["$members.user", ["@P.user._id"]] },
						{ $in: ["$status", [1]] },
					]},
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]}}},
			],
			as: "project"
		}},

		{ $lookup: {
			from: "team",
			pipeline: [
				{ $match: {
					projectId: "@P.route._id"
				}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					members: 1,
				}}
			],
			as: "teams"
		}}
	]],

	// `<F1>A.findOne(*) > projectDb: project: { $or: [
	// 	{ _id: "@P.route._id" },
	// 	{ shortName: "@P.route._id" }
	// ]}`,

    // `A.findOne(*) > userDb: user: {_id: "@P.user._id"}`,
    // `A.findMany(*) > teamDb: team: {
    //     projectId : "@P.route._id"
    // }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var dbData = pipeData.dbData;
		var projectDb = dbData.project || {};
		var userDb = Req.user || {};
		var teams = dbData.teams || [];

        projectDb.hasAdmin = false;

        if (userDb.hasAgent || userDb.hasAdmin ||
			((projectDb.agentId||"").toString() == (userDb._id||"_").toString()) ) {
            projectDb.hasAdmin = true;
        }

		var members = projectDb.members || [];
		projectDb.members = members;

        for(let i = 0; i < members.length; i++) {
            for (let j = 0; j < teams.length; j++) {
                let index = (teams[j].members||[]).findIndex((item) => {
                    return item.toString() == members[i].user.toString();
                })

                if(index >= 0) {
                    members[i].teamName = teams[j].name;
					members[i].teamName2 = teams[j].name2;
                }
            }
        }

        return projectDb;
    }],

    `A.populate: user, members.user, _id, members.user, +, name, name2, userId, avt
               : roleproject, members.role, _id, members.role, +, name`,
    `A.refactorOutput:: _id, avt, name, name2, shortName, types, dueDate, startDate, descr, hasAdmin, feature, members, hasCompleted, actLabelIds, actFeatureIds, actSprintIds, actMilestoneIds, maxDocSize`
], {imProject: false}]);

ProjectRoute.POST.push([[""], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view, project.modify`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.modify",
	`A.fillingDateWorking:: startDate: dueDate: 720`, // 720h => 30 days
    `A.verifyInput > project:: project: name!, shortName!, hasCompleted-, members!, ...`,
    `A.findOne > projectdb: project: ({"shortName": "@project.shortName"})`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        if(pipeData.projectdb) {
            return {
				respData: "ShortName was existed!",
				respReturn: true ,
				respCode: 400
			};
		}

		var body = Req.body;
		if(!body || !body.project) {
			return {
				respData: "Invalid request!",
				respReturn: true ,
				respCode: 400
			};
		}

		var user = Req.user || {};
		if(user.hasAgent || user.hasAdmin) {
			body.project.agentId = user._id;
			//console.log("Project: ", body);
			return Req.UNRESULT;
        }

		return {
			respData: "User was not permitted!",
			respReturn: true ,
			respCode: 400
		};
    }],

    //`A.modifyObject(*):: P.body.project.agentId = P.user._id`,
    `A.insertOne > P.project: project: @project`,
	`A.findById > P.firstGroup: group: { hasGlobal: true, type: "task", shortName: "backlog" }`,
	`A.insertOne(*) > newTask: task: ({
		projectId: "@P.project._id",
		name: "Welcome to project First Task!",
		groupId: "@P.firstGroup._id",
		assigneeIds: ["@P.user._id"]
    })`,

    //`A.pipeRoute: role`,
    `A.refactorOutput(P.project):: attachIds-, members-, riskIds-, creatorId-, modifierId-, ...`,
], {imProject: false}]);

ProjectRoute.PUT.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
    `A.verifyInput > reqData:: project: shortName-, budget-, projectId!, avt, name, name2, dueDate, startDate, types, descr, actLabelIds, actFeatureIds, actSprintIds, actMilestoneIds`,

    `A.updateById(*) > xyz: project: { _id: "@P.project._id" }: @P.body.reqData`,
    `A.responseObject: 200: Update successfully!`
]]);

ProjectRoute.PUT.push([[":_id/shortName"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
    //"A.verifyInput > projectBody:: project: shortName!",

	`A.verifyKObject:: shortName!: project.shortName`,

	[`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		//pipeData.D.IgnoreSanitized = true;
		var company = await pipeData.A.aggregateOne(Req, pipeData, "project", [
			{ $match: {
				shortName: { $regex : new RegExp(`^${body.shortName}$`, "i") }
			}},
			{ $project: {
				_id: 1,
				status: 1,
			}}
		]);

		if(company && company._id) {
			return {
				respData: "ShortName was existed!",
				respReturn: true,
				respCode: 503
			};
		}

        return Req.UNRESULT;
    }],

	// `A.findOne(*) > dbData: project: {shortName: "@P.body.shortName"}`,
	//
	// `A.assertObject:: or: (
	// 	dbData not-type object,
	// 	dbData type empty,
	// 	dbData type undefined,
	// 	dbData type null
	// ) : {
	// 	respData: "ShortName was existed!",
	// 	respCode: 503,
	// 	respReturn: true
	// }`,

    `A.updateById(*) > xyz: project: {_id: "@P.route._id"}: {shortName: "@P.body.shortName"}`,
	`A.notifyClearCached(*): project: @P.route._id`,

    `A.responseObject: 200: Update successfully!`
]]);


ProjectRoute.DELETE.push([[":_id"], [
	`A.verifyAdmin:: User was not permitted!`,
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view, project.delete`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",

    `A.deleteOne(*) > xyz: project: { _id: "@P.project._id" }`,

	`A.pipeRoute: deleteProjectResource`,
	`A.pipeRoute: deleteProject`,
    `A.responseObject: 200: Delete Project successfully!`
]]);

ProjectRoute.GET.push([[":_id/lock"], [
	`A.verifyAdmin:: User was not permitted!`,
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view, project.modify`,

	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.copyKObject(*):: P.project.members.user, P.body.users`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $and: [
			{ $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],

    `A.updateById(*) > temp: project: { _id: "@P.route._id" }: {status: 0}`,
	
	//`A.copyKObject:: users.emails, P.body.userEmails`,
	//`A.printObject: userEmails`,

	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Project] Project {{P.project.shortName}} was locked",
		"view" 		: "projectStatusView",
		"data" 		: {
			"typeAction": "locked",
		}
	}`,

	`A.responseObject: 200: Block project successfully!`,

]]);

ProjectRoute.GET.push([[":_id/unlock"], [
	`A.verifyAdmin:: User was not permitted!`,
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findById(*) > P.project: project: {_id: "@P.route._id"}`,
	
	`A.verifyKObject(P.project):: _id!: verify.idType`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.copyKObject(*):: P.project.members.user, P.body.users`,

    `A.updateById(*) > temp: project: { _id: "@P.route._id" }: { status: 1 }`,

	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $and: [
			{ $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],
	
	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Project] Project {{P.project.shortName}} was unlocked",
		"view" 		: "projectStatusView",
		"data" 		: {
			"typeAction": "unlocked",
		}
	}`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.responseObject: 200: Unblock project successfully!`
], {imProject: false}]);

ProjectRoute.POST.push([[":_id/complete"], [
	`A.verifyAdmin:: User was not permitted!`,
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.copyKObject(*):: P.project.members.user, P.body.users`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.updateById(*) > temp: project: { _id: "@P.project._id" }: { hasCompleted: true, status: 6}`,

	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $and: [
			{ $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],
	
	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Project] Project {{P.project.shortName}} was completed",
		"view" 		: "projectStatusView",
		"data" 		: {
			"typeAction": "completed",
		}
	}`,
    `A.responseObject: 200: Complete project successfully!`
]]);

ProjectRoute.POST.push([[":_id/uncomplete"], [
	`A.verifyAdmin:: User was not permitted!`,
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findById(*) > P.project: project: {_id: "@P.route._id"}`,
	`A.verifyKObject(P.project):: _id!: verify.idType`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.copyKObject(*):: P.project.members.user, P.body.users`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.updateById(*) > temp: project: { _id: "@P.project._id" }: { hasCompleted: false, status: 1 }`,

	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $and: [
			{ $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],
	
	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Project] Project {{P.project.shortName}} was reopened",
		"view" 		: "projectStatusView",
		"data" 		: {
			"typeAction": "reopened",
		}
	}`,

    `A.responseObject: 200: Project was reopened successfully!`
], {imProject: false}]);

// ProjectRoute.POST.push([["/:_id/add/attach"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
//     "A.verifyInput > reqBody:: project: attachIds!",
//     "A.findById > dbBody: project",
//     `A.modifyObject::
//         dbBody.attachIds = */reqBody.attachIds,
//         respData = 200`,

// 	`A.mixObject(dbBody) > upBody:: ({
// 		"modifiedAt" : "@modifiedAt",
// 		"attachIds"  : "@attachIds"
// 	})`,

//     "A.updateById(upBody) : project",
// ]]);

// ProjectRoute.POST.push([["/:_id/remove/attach"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
// 	"A.verifyInput > reqBody:: project: attachIds!",
//     "A.findById > dbBody: project",
//     `A.modifyObject:: dbBody.attachIds = //reqBody.attachIds`,
//     "A.updateById(dbBody) > tmpBody: project",
//     "A.populate(dbBody) > tmpBody: user, creatorId, _id, +, email, hasAdmin, userCode",
//     "A.refactorOutput(tmpBody) > respData:: creatorId.hasAdmin-",
// ]]);

// ProjectRoute.POST.push([["/:_id/add/risk"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
//     "A.verifyInput > reqBody:: project: riskIds!",
//     "A.findById > dbBody: project",
//     `A.modifyObject::
//         dbBody.riskIds = */reqBody.riskIds,
//         respData = 200`,
//
// 	`A.mixObject(dbBody) > upBody:: ({
// 		"modifiedAt" : "@modifiedAt",
// 		"riskIds"  : "@riskIds"
// 	})`,
//
//     "A.updateById(upBody) : project",
// ]]);
//
// ProjectRoute.POST.push([["/:_id/remove/risk"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
// 	"A.verifyInput > reqBody:: project: riskIds!",
//     "A.findById > dbBody: project",
//     `A.modifyObject:: dbBody.riskIds = //reqBody.riskIds`,
//     "A.updateById(dbBody) > tmpBody: project",
//     "A.populate(dbBody) > tmpBody: user, creatorId, _id, +, email, hasAdmin, userCode",
//     "A.refactorOutput(tmpBody) > respData:: creatorId.hasAdmin-",
// ]]);

ProjectRoute.POST.push([["/label/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	[`A.jsScript:`, async (Req, pipeData, ctx) => {
		var nameOps = { $and: [{ $or: [
			{ projectId: Req.project._id },
			{ hasGlobal: true }
		]}]};

		var body = Req.body;
		var name = body.name || body.search || body.text;

		if(name) {
			name = Req.func.getASCIISearch(name, "gmi");
			nameOps["$and"].push({"$or": [ { name }, { descr: name }, { color: name } ] });
		}

		body.nameOps = nameOps;
		return Req.UNRESULT;
	}],

	[`A.aggregate: label:`, [
		{ $match: "@nameOps" },

		{ $populate: ["project", "projectId", "_id", "projectId", true] },

		{ $sort: {
			"projectId.name$": 1,
			name$: 1,
		}},

		{ $project: {
			name: 1,
			name2: 1,
	        descr: 1,
	        descrHTML: 1,

	        type: 1,
			color: 1,
	        hasGlobal: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.shortName": 1
		}},
	]],
], { projectIdName: "projectId", useZip: true }]);

ProjectRoute.POST.push([["/:_id/member/add"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
    `A.verifyInput > reqBody:: project: members!, projectId!`,
    `A.findById(*) > dbBody: project: { _id: "@P.project._id" }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        const {dbBody, reqBody} = pipeData;

		var dbArrs = dbBody.members;
		if(!Array.isArray(dbArrs)) {
			dbArrs = [dbArrs];
		}

		var arrs = reqBody.members || reqBody;
		if(!Array.isArray(arrs)) {
			arrs = [arrs];
		}

		var foundObj = false;
		for(var i=0; i<arrs.length; i++) {
			var reqObj = arrs[i] || {};
			reqObj.joinAt = new Date();
			arrs[i] = reqObj;

			var reqUserId = reqObj.user;

			for(var j=0; j<dbArrs.length; j++) {
				var obj = dbArrs[j] || {};

				var dbUserId = obj.user;
				if(reqUserId.toString() == dbUserId.toString()) {
					foundObj = reqObj;
					break;
				}
			}

			if(foundObj) break;
		}

        if (foundObj) {
            return {
				respData: "User exists",
				respReturn: true,
				respCode: 500,
			};
        }

        pipeData.reqBody = { members: arrs };
        return pipeData;
    }],

    `A.modifyObject::
        dbBody.members = */reqBody.members,
		dbBody.members = ?unify`, // *#
    `A.uniquizedObject`,

    `A.updateById(*) > xyz: project: { _id: "@P.project._id" }: @P.body.dbBody`,
    `A.populate: user, reqBody.members.user, _id, +, name, name2, userId, avt, hasAgent, hasAdmin
               : roleproject, reqBody.members.role, _id, +, name`,
	
	`A.findOne(*) > P.userAdd: user: { _id: "@P.body.members[0].user" }`,

	`A.sendMail(*) > tmpMail: {
		"to" 		: ["@P.userAdd.email","@P.userAdd.email"],
		"subject" 	: "You were invited to {{P.project.name}}.",
		"view" 		: "welcomeMemberProject",
		"data" 		: "@P.body"
	}`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        return pipeData.reqBody.members;
    }],
]]);

ProjectRoute.POST.push([["/:_id/member/remove"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.verifyInput:: project: members!, projectId!`,

	`A.deleteKObject:: members.joinAt`,

	//`A.printObject`,

    `A.dbCall(*) > tmp1: project: updateOne: ({ _id: "@P.project._id" }): ({
        $pull: {
			members: {user: "@P.body.members[0].user"}
        }
     })`,

	 //`A.printObject(*): @P.body.members[0].user`,

	 // Remove member out of team
	 // colName, idKey, keyPath, itemValue, itemPath, removeMany=false
	 `A.removeSubItem(*) > tmp2: team: { projectId: "@P.project._id" }: members: @P.body.members[0].user:: true`,
	 // `A.dbCall(*) > tmp2: team: updateOne: ({ _id: "@P.project._id" }): ({
     //     $pull: {
 		// 	members: "@P.body.members[0]"
     //     }
     //  })`,

	  // Remove this member out of all source code respository
	  `A.sendData(*) > tmp3: PURGE: @(K.API.SvrIntSource + '/r3p0/mewb3r'):
  		{ refId: "@P.route._id", userId: "@P.body.members[0].user", refModel: "rcesou" }:
  		{ "user-token": "@(P.header['user-token'])" }`,

	`A.responseObject: 200: Remove member successfully!`
]]);


ProjectRoute.POST.push([["/:_id/member/update"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.verifyInput:: project: members!, projectId!`,
	`A.deleteKObject:: members.joinAt`,
	//`A.printObject`,

    `A.dbCall(*): project: updateOne: ({
        _id : "@P.project._id",
		"members.user": "@P.body.members[0].user"
	 }): ({
        $set : {
			"members.$.role": "@P.body.members[0].role"
        }
    })`,
	`A.responseObject: 200: Update member successfully!`
]]);

ProjectRoute.POST.push([["/:_id/member/left"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.delete",
    `A.verifyInput:: project: members!, projectId!`,
	`A.deleteKObject:: members.joinAt, members.role`,
	//`A.printObject`,

    `A.dbCall(*): project: updateOne: ({
        _id : "@P.project._id",
		"members.user": "@P.body.members[0].user"
	 }): ({
        $set : {
			"members.$.leftAt": "@P.body.members[0].leftAt",
        }
    })`,
	`A.responseObject: 200: Update member successfully!`
]]);

// ProjectRoute.POST.push([["/:_id/member/s"], [
//     `A.findOne: project`,
//     `A.populate: user, members.user, _id, members.user,+, name, name2, userId, shortName, avt
//                 :roleproject, members.role, _id, members.role, +, name`,
//     `A.refactorOutput:: members`
// ]]);

ProjectRoute.POST.push([["/:_id/member/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var name = body.name || body.search || "";
		Req.body.name = Req.func.getASCIISearch(name, "gmi");

        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne(*)::`, [
		{ $lookup: {
			from: "project",
			//let: {},
			pipeline: [
				{ $match: {
					$expr: {
						$and:[
							{ $eq: ["$_id", "@P.route._id"] },
							{ $or: [
								{ $eq: ["@P.user.hasAdmin", true] },
								{ $eq: ["@P.user.hasAgent", true] },
								{ $in: ["@P.user._id", "$members.user"] },
							]},
							{ $eq: ["$status", 1] }
						]
					}
				}},

				{ $project: {
					members: 1
				}},

				{ $unwind: {
					path: "$members",
					preserveNullAndEmptyArrays: true
				}},

				{ $addFields: {
					user: "$members.user",
					role: "$members.role",
					joinAt: "$members.joinAt",
					leftAt: "$members.leftAt"
				}},

				{ $populate: ["user", "user", "_id", "user", true]},
				{ $match: { // Remove all user lock, delete, not active
					hasLocked: { $nin: [true] },
					hasActived: { $nin: [false] },
					hasDeleted: { $nin: [true] },
				}},
				{ $match: {
					$or: [
						{ "user.name": "@P.body.name" },
						{ "user.email": "@P.body.name" },
					],
					//"user.hasDeleted": { $nin: [true] },
					//"user.hasActived": { $nin: [false] },
					//"user.status": 1
				}},

				{ $sort: {
					"user.name$": 1,
				}},

				{ $getTotalLength: ["@P.body.page", "totalLength"]},
				{ $populate: ["roleproject", "role", "_id", "role", true]},

				{ $project: {
					_id: 0
				}},

				{ $addFields: {
					"user.hasAdmin": {$cond: [{$eq: ["$user.hasAgent", true]}, true, "$user.hasAdmin"]},
				}},

				{ $project: {
					joinAt: 1,
					leftAt: 1,

					"user._id": 1,
					"user.name": 1,
					"user.name2": 1,
					"user.avt": 1,
					"user.userId": 1,
					"user.hasAgent": 1,
					"user.hasAdmin": 1,

					"role._id": 1,
					"role.name": 1,
					"role.name2": 1,

					totalLength: 1,
				}},

				{ $groupTotalLength: ["@P.body.page", "totalLength", "users"]}
			],
			as: "user"
		}},

		{ $unwind: {
			path: "$user",
			preserveNullAndEmptyArrays: true,
		}},

		{ $lookup: {
			from: "roleproject",
			//let: {},
			pipeline: [
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
				}}
			],
			as: "roles"
		}},
		{ $addFields: {
			users: "$user.users",
			page: { $ifNull: ["$user.page", "@P.body.page"] }
		}},
		{ $project: {
			_id: 0,
		}},

		{ $project: {
			roles: 1,
			users: 1,
			page: 1,
		}}
	]],
], {imProject: true}]);

ProjectRoute.POST.push([["/:_id/member/search"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view`, // all

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = { $and: [
			{ hasDeleted: { $nin: [true] }},
		]};

		var name = pipeData.name || pipeData.search || pipeData.text;
        if(name) {
			name = Req.func.getASCIISearch(name, "gmi");
            ops.$and.push({ $or: [
				{ name: name },
				{ email: name }
			]});
        }

		Req.ops = ops;
        return Req.UNRESULT;
    }],

    [`A.aggregateOne(*)::`, [
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match : { $expr: { $and: [
					{ $eq: ["$_id", "@P.route._id"] },
					{ $or: [
						{ $eq: ["@P.user.hasAdmin", true] },
						{ $eq: ["@P.user.hasAgent", true] },
						{ $in: ["@P.user._id", "$members.user"] },
					]},
					{ $not: [{$in: ["$hasActived", [false]] }]},
					{ $not: [{$in: ["$hasDeleted", [true]] }]},
					{ $not: [{$in: ["$hasLocked", [true]] }]},
					{ $eq: ["$status", 1] }
				]}}},

				// Should using JS script to remove user who left company
				// { $addFields: {
				// 	// Filter left member
				// 	members: { $filter: {
				// 		input: "$members",
				// 		as: "member",
				// 		cond: { $or: [
				// 			{ $in: ["$$member.leftAt", [undefined, null, "", 0]] },
				// 			//{ $exists: ["$$member.leftAt", false] },
				// 		]}
				// 	}}
				// }},
				{ $project: {
					_id: 1,
					members: 1
				}}
			],
			as: "project",
		}},
		{ $unwind: {
			path: "$project",
			preserveNullAndEmptyArrays: false
		}},

		{ $lookup: {
			from: "user",
            //localField: "members.user",
            //foreignField: "_id",
			let: { members: "$project.members.user" },
			pipeline: [
				{ $match: "@P.ops"},
				{ $match: { $expr: { $and: [
					{ $in: ["$_id", "$$members"] },
					{ $not: [{$in: ["$hasActived", [false]] }]},
					{ $not: [{$in: ["$hasDeleted", [true]] }]},
					{ $not: [{$in: ["$hasLocked", [true]] }]},
					{ $eq: ["$status", 1] },
				]}}},
				{ $sort: {
					name$: 1
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					userId: 1,
				}}
			],
            as: "members"
        }},

		// { $project: {
		// 	members: {
		// 		$filter: { input: "$members", as: "item", cond: { $and: [
		// 			{ $regexMatch: {input : "$$item.name", regex: "@P.body.name"}},
		// 			{ $or: [
		// 				{ $eq: ["$hasDeleted", false] },
		// 				{ $eq: ["$hasDeleted", undefined] },
		// 				{ $eq: ["$hasDeleted", null] },
		// 				{ $nin: ["$hasDeleted", [true]] }
		// 			]}
		// 		]}},
        //     }
        // }},
		//
		// { $project: {
		// 	members: {
		// 		_id: 1,
		// 		name: 1,
		//		name2: 1,
		// 		avt: 1
		// 		userId: 1
		// 	}
		// }}
	]],

    // `A.populate: user, projectDb.members.user, _id, membersDb, +, name, name2, userId, avt`,
    // `A.trimObject`,
    // `A.refactorOutput:: membersDb, name, name2, taskId`,
    // [`A.jsScript`,  (Req, pipeData, ctx) => {
    //     if (!pipeData.membersDb) {
	// 		return {
	// 			respCode: 200,
	// 			respData: [],
	// 			respReturn: true,
	// 		}
	// 	};

    //     if (!pipeData.name) {
    //         pipeData.name = "";
    //     }

	// 	var members = [];
    //     pipeData.membersDb.filter((member) => {
    //         if((member.name || "").toLowerCase().indexOf((pipeData.name || "").toLowerCase()) > -1)
    //             members.push(member);
    //         }
	// 	);

    //     pipeData.members = members;
    //     return pipeData;
    // }],
    // `A.moveKObject(*):: P.body.members, P.body`,
    //`A.refactorOutput(members)`,

	`A.responseObject: 200: @members`,

], {imProject: true}]);

ProjectRoute.POST.push([["/:_id/role/search"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.findMany(*) > roleDb: roleproject: {projectId: "@P.projectId._id"}`,

    `A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
        if (!pipeData.roleDb) return;
        if (!pipeData.name) {
            pipeData.name = "";
        }
        var roles = [];
        var pipe = pipeData.taskDb;
        pipeData.roleDb.filter((member) => {
            if((member.name).toLowerCase().indexOf((pipeData.name).toLowerCase()) > -1)
                roles.push(member);
            })
        pipeData.roles = roles;
        return pipeData;
    }],

    `A.moveKObject(*):: P.body.roles, P.body`,
    `A.refactorOutput:: _id, name`,
]]);

ProjectRoute.POST.push([["/:_id/feature"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: project.view`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

    // `A.checkPermission(*): rolecompany: @P.user.roleId: project.edit`,
	`A.assertObject:: and: (
		feature type object,
		feature not-type empty
	): {
		respReturn: true,
		respCode: 503,
		respData: "You must send feature data!"
	}`,

	`A.allKeyObject(*) > P.allKeys: @P.body`,
	`A.verifyInput > P.reqData:: project: feature`,
	//`A.printObject(*): P.body: P.reqData: P.allKeys`,

	//`A.printObject(*): P.body: P.reqData`,
	`A.keepKObject(*): @P.reqData.feature: @P.allKeys`,
	//`A.printObject(*): P.reqData: P.body`,

	`A.copyObject(P) > P.featureData: @reqData.feature: @allKeys`,

	//`A.printObject(P): featureData: body.feature: allKeys`,
	`A.trimObject(*): @P.featureData`,

	//`A.printObject(P): featureData`,
	`A.assertObject(P):: and: (
		featureData type object,
		featureDate not-type empty
	): {
		respReturn: true,
		respCode: 503,
		respData: "You must send corrected data!"
	}`,

	`A.updateSubItem(*): project: { _id: "@P.project._id" }: feature: @P.featureData:: false`,

	`A.findOne(*) > P.dbData: project: {_id: "@P.project._id"}`,
	`A.notifyClearCached(*): project: @P.route._id, @P.dbData.shortName`,
	`A.notifyClearToken: project: @P.route._id, @P.dbData.shortName`,

	`A.refactorOutput(P.dbData):: feature `
]]);

ProjectRoute.GET.push([[":_id/group/task"], [
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	//`A.pipeRoute: checkLabelGroup: {permit: "view", type: "@type"}`,

	//`A.checkRole(*): project: @P.project._id: roleproject: @(P.body.type + ".view")`,
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,

	[`A.aggregate(*): group`, [
		{ $match: {
			$and: [
	            { type : "task" },
	            { $or: [
	                { hasGlobal: true },
	                { projectId : "@P.project._id" }
	            ]}
	        ]
		}},
		//{ $populateFilter: ["user", "creatorId:_id", "creatorId", true, 1, "_id", "email", "name", "userId", "avt" ]},
		{ $sort: {
			value: 1,
			name$: 1,
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			type: 1,
			value: 1
		}}
	]],
]]);

ProjectRoute.POST.push([[":_id/check/:userId"], [
	// Check user in project or not
	// `A.printObject:`,
	`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
	// `A.printObject:`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								userId!: verify.idType `,
	// `A.printObject:`,

	[`A.aggregateOne(*)::`, [
		{ $lookup: {
			from: "source",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
					{ $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					shortName: 1,
				}}
			],
			as: "sources"
		}},
		{ $lookup: {
			from: "team",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members"] },
					{ $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
				}}
			],
			as: "teams"
		}},

		{ $lookup: {
			from: "postserver",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
					{ $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					number: 1,
					name2: 1,
				}}
			],
			as: "postServers"
		}},

		{ $lookup: {
			from: "mockserver",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", {$ifNull : ["$members.user", []]} ]},
					{ $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					number: 1,
					name2: 1,
				}}
			],
			as: "mockServers"
		}},

	]],
]]);

ProjectRoute.PIPE.push([["/checkInProject"], [
	// Check user in project or not
	[`A.aggregate(*) > P.project:`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$_id", "@P.route._id"] },
			{ $or: [
				{ $eq: ["@P.user.hasAdmin", true] },
				{ $eq: ["@P.user.hasAgent", true] },
				{ $in: ["@P.user._id", "$members.user"] },
			]},
			{ status: 1 }
		]}}}
	]],
	`A.verifyKObject(project):: _id!: verify.idType`,
], {name: "checkInProject"}]);


module.exports = ProjectRoute;
