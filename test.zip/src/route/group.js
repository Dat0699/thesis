const GroupRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        checkMIFs	: ["project"],
		imProject	: true,
    }
};

GroupRoute.POST.push([[""], [
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view, label.modify`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyInput:: group: name!, type!, projectId!, ...`,

	`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"], type: "@type"}`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
        const {shortName} = pipeData;
        if(shortName) {
            return pipeData;
        }

        let value;
        switch (shortName) {
            case 'backlog':
                value = 1;
                break;
            case 'assigned':
                value = 2;
                break;
            case 'indoing':
                value = 3;
                break;

            case 'intesting':
                value = 4;
                break;
            case 'inreviewing':
                value = 5;
                break;
            case 'done':
                value = 6;
                break;
            default:
                break;
        }

        pipeData.value = value;
        return pipeData;
    }],

    `A.insertOne(*): group: @P.body`,
    `A.refactorOutput:: _id, color, hasGlobal, shortName, type, name, name2, number`
]]);

GroupRoute.POST.push([["/s"], [
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyInput:: group: type!, projectId!`,

	`A.pipeRoute: checkLabelGroup: {permit: "view", type: "@type"}`,

	//`A.checkRole(*): project: @P.project._id: roleproject: @(P.body.type + ".view")`,
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,

	[`A.aggregate(*): group`, [
		{ $match: {
			$and: [
	            { type : "@P.body.type" },
	            { $or: [
	                { hasGlobal: true },
	                { projectId : "@P.project._id" }
	            ]}
	        ]
		}},
		//{ $populateFilter: ["user", "creatorId:_id", "creatorId", true, 1, "_id", "email", "name", "userId", "avt" ]},
		{ $sort: {
			name$: 1,
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			type: 1,
			value: 1
		}}
	]],
]]);

// GroupRoute.GET.push([[":_id"], [
// 	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,
// 	`A.copyKObject(*):: P.project._id, P.body.projectId`,
//
// 	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
//     `A.findOne(*): group: { _id: "@P.route._id", projectId: "@P.project._id" }`,
//     `A.refactorOutput`
// ]]);

GroupRoute.PUT.push([[":_id/:type:(/(wiki|postapi|testcase)$/)"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute(*): checkLabelGroup: {permit: ["view", "modify"], type: "@P.route.type"}`,

    `A.verifyInput:: group: name, name2, color, type`,
    `A.updateById(*): group: {_id: "@P.route._id", projectId: "@P.project._id", hasGlobal: false}: @P.body`,
    `A.refactorOutput`
]]);

GroupRoute.PUT.push([[":_id/:type:(/(wiki|postapi|testcase)$/)/move/position"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute(*): checkLabelGroup: {permit: ["view", "modify"], type: "@P.route.type"}`,

    `A.verifyInput:: group: name, name2, color, type`,
    `A.updateById(*): group: {_id: "@P.route._id", projectId: "@P.project._id", hasGlobal: false}: @P.body`,
    `A.responseObject: 200: Update group successfully!`
]]);

// GroupRoute.DELETE.push([[":_id"], [
// 	`A.checkRole(*): project: @P.project._id: roleproject: label.view, label.delete`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
//     `A.deleteById(*): group: {_id: "@P.route._id", projectId: "@P.project._id"}`,
// 	`A.responseObject: 200: Delete group successfully!`
// ]]);

GroupRoute.DELETE.push([[":_id/:type:(/(wiki|postapi|testcase)$/)"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute(*): checkLabelGroup: {permit: ["view", "delete"], type: "@P.route.type"}`,
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view, label.delete`,
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.delete`,

    `A.findMany(*) > groupDb: @P.route.type: {
        groupId : "@P.route._id",
        type: "@P.route.type",
		projectId: "@P.project._id",
		hasGlobal: false
    }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        if(pipeData.groupDb && pipeData.groupDb.length > 0) {
            return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }
        return pipeData;
    }],

    `A.deleteById(*): group: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.responseObject: 200: Delete group successfully!`
]]);

// GroupRoute.PUT.push([[":_id/:type:(/(wiki|postapi)$/)"], [
// 	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,
//
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.pipeRoute(*): checkLabelGroup: {permit: ["view", "modify"], type: "@P.route.type"}`,
//
//     "A.verifyInput:: group: name",
//     //`A.printObject`,
//     `A.updateById(*): group:
//     	({ _id: "@P.route._id", type: "@P.route.type", projectId: "@P.project._id" }):
//     	({ name : "@P.body.name" })`,
//     `A.responseObject: 200: Update group successfully!`
// ]]);

GroupRoute.PIPE.push([["checkLabelGroup"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var project = Req.project || {};
		var body = Req.body || {};

		var model = "project";
		var idValue = project._id;
		var roleModel = "roleproject";

		var rs = true;
		var type = body.type;
		if(!type || (type == "all") || (type == "type")) {
			type = "setting";

		} else if(type == "helpdesk") {
			rs = A.checkKeyFeature(Req, false, `company.feature.${type}`);
			model = "Main.company";
			roleModel = "rolecompany";

		} else {
			rs = A.checkKeyFeature(Req, false, `project.feature.${type}`);
		}

		if(rs) {
			var permit = body.permit || ["view"];
			if(!Array.isArray(permit)) {
				permit = [permit];
			}

			permit = permit.map(p => `${type}.${p}`);
			rs = await A.checkRole(Req, pipeData, model, idValue, roleModel, permit);
		}

		if(!rs) {
			return {
				respData: "User was not permitted!",
				respCode: 500,
				respReturn: true
			};
		}

		return Req.UNRESULT;
	}],
], {name: "checkLabelGroup"}]);

// GroupRoute.POST.push([["wiki/s"], [
//     "A.verifyInput:: group: projectId!",
//     `A.findMany: group: ({
//         type : "wiki" ,
//         projectId : "@projectId"
// })`,
//     `A.sortObject:: colIndex`,
//     "A.refactorOutput:: _id, name"
// ]]);

module.exports = GroupRoute;
