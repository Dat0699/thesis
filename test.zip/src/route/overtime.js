const OvertimeRoute = {
	route 	: true,
	ctrl 	: true,
	model 	: true,

	POST	: [],
	GET 	: [],
	PUT		: [],
	DELETE 	: [],
	PIPE 	: [],

	config: {
		checkMIFs		: ["calendar", "overtime"],
		roleUserIdKey	: "userId"
	}
};

// API /s và API /:_id gần như tương đồng nhau chỉ khác filter thôi,
OvertimeRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view`,
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		const name = body.name || (body.search || body.text) || "";
		const fromDate = body.fromDate || body.startDate;
		const toDate = body.toDate || body.endDate;

		var status = body.status || body.statuses;
		var userIds = (body.memberIds || body.memberId) ||
					  (body.userIds || body.userId);

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAdmin;

		var rolecompany = (Req.rolecompany||{}).permit;
		if(!hasAdmin && (!rolecompany || !rolecompany.overtime.approve)) {
			userIds = [user._id];
		}

        var matchOps = [];

        if(name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            matchOps.push({ $or: [
				{ title: { $regex: nameReg }},
				{ title2: { $regex: nameReg }},
				{ number: (name-0) || -1 }
			]});
        }

		if(fromDate) {
			matchOps.push({ startDate : { $gte: fromDate}});
		}

		if(toDate) {
			matchOps.push({ startDate : { $lte: toDate}});
		}

        if(userIds) {
			if(!Array.isArray(userIds)){
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				matchOps.push({ $or: [
					{ userIds: { $elemMatch: { $in: userIds }}},
					//{ "members.user": { $in: userIds }},
					{ creatorId: { $in: userIds }}
				]});
			}
		}

		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status && status.length > 0) {
				matchOps.push({ status: {$in: status} });
			}
		}

		body.matchOps = {};
		if(matchOps.length > 0) {
			body.matchOps = { $and: matchOps };
		}

		//console.log("body: ", JSON.stringify(matchOps));
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne(*): overtime`, [
		{ $match: "@P.body.matchOps" },

		{ $match: { $expr: { $or: [
			//{ $in: ["@P.user._id", "$members.user"] },
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },

			{ $and: [
				{ $in: ["@P.user._id", { $ifNull: ["$userIds", []] } ] },
				{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},

			{ $and: [
				{ $eq: ["@P.rolecompany.permit.overtime.approve", true] },
				{ $in: ["@P.user._id", { $ifNull: ["$approverIds", [] ]} ]},
				{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},
		]}}},

		{ $getTotalLength: "@P.body.page" },

		{ $populate: ["user", "creatorId", "_id", "creatorId", true]},
		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		// { $populate: ["user", "approverIds", "_id", "approvers"]},
		{ $populate: ["project", "projectId", "_id", "projectId", true]},

		{ $addFields: {
			userIds: {$ifNull: ["$userIds", []]},
		}},

		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "_id", "name", "name2", "avt", "userId"]},

		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $addFields: {
			countUser: { $size: "$userIds" },
			//countUser: { $size: "$members" },
			//totalHour: { $divide : [{ $subtract: ["$endDate", "$startDate"]}, 3600000]},
		}},

		/*
		// This block calculated by update function at the time it created or update, so calculate amount not need anymore
		{ $lookup: {
			from: "user",
			let: {
				//userIds: "$userIds",
				userIds: "$members.user",
				duration: "$totalHour",
				effortRatio: "$effortRatio",
			},
			pipeline: [
				{ $match: {
					$expr: {
						$and:[{
							$in: ["$_id", "$$userIds"]
						}]
					}
				}},

				{ $populate: ["hrcontract", "_id", "userId", "hrcontract", true]},

				{ $addFields: {
					hourlySalary: "$hrcontract.overview.hourlySalary",
					monthlySalary: "$hrcontract.overview.monthlySalary",
					duration: "$$duration",
					effortRatio: "$$effortRatio",
				}},

				{ $addFields: {
					amount: { $multiply: ["$hourlySalary", "$duration", "$effortRatio"] }
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					userId: 1,
					avt: 1,
					hourlySalary: 1,
					monthlySalary: 1,
					duration: 1,
					amount: 1
				}}
			],
			as: "members"
		}},

		{ $addFields: {
			amount: { $sum: "$members.amount" }
		}},

		*/

		{ $project: {
			_id: 1,
			title: 1,
			title2: 1,
			startDate: 1,
			endDate: 1,
			//totalHour: 1,
			descr: 1,
			rejectedMessage: 1,
			status: 1,
			number: 1,

			//effortRatio: 1,
			//totalEffortHour: 1,
			modifiedAt: 1,

			countUser: 1,
			//totalHour: 1,
			//totalSalaryHour: 1,
			//amount: 1,
			duration: 1,

			//userIds: 1,
			totalLength: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.shortName": 1,
			"projectId.avt": 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,

			approverIds: 1,
			// "approvers._id": 1,
			// "approvers.name": 1,
			// "approvers.name2": 1,
			// "approvers.avt": 1,
			// "approvers.userId": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			//userIds: 1,
			"users._id": 1,
			"users.name": 1,
			"users.name2": 1,
			"users.avt": 1,
			"users.userId": 1,
		}},

		{ $group: {
			_id: {
                month: { $month: "$startDate" },
                //day: { $dayOfMonth: "$startDate" },
                year: { $year: "$startDate" }
            },
			date: { $first: "$startDate" },
			//amount: { $sum: "$amount" },
			//totalEffortHour: { $sum: "$totalEffortHour" },
			duration: { $sum: "$duration" },
			overtimes: { $push: "$$ROOT"},
			totalLength : { "$first" : "$totalLength" }
		}},
		{ $sort: {
			date: -1,
		}},

		{ $project: {
			"overtimes.totalLength": 0,
		}},

		{ $groupTotalLength: ["@P.body.page", "totalLength", "overtimes"]},
	]],

	//`A.printObject:`,
	//`A.responseObject: 200: @dbData`
]]);

OvertimeRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	[`A.aggregateOne(*): overtime`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				//{ $in: ["@P.user._id", "$members.user"] },
				{ $eq: ["@P.user._id", "$creatorId"] },
				{ $eq: ["@P.user.hasAgent", true] },
				{ $eq: ["@P.user.hasAdmin", true] },

				{ $and: [
					{ $in: ["@P.user._id", { $ifNull: ["$userIds", []] } ] },
					{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
				]},

				{ $and: [
					{ $eq: ["@P.rolecompany.permit.overtime.approve", true] },
					{ $in: ["@P.user._id", { $ifNull: ["$approverIds", [] ]} ]},
					{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
				]},
			]},
		]}}},

		{ $populate: ["user", "creatorId", "_id", "creatorId", true]},
		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		// { $populate: ["user", "approverIds", "_id", "approvers"]},
		{ $populate: ["project", "projectId", "_id", "projectId", true]},

		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $addFields: {
			countUser: { $size: "$userIds" },
			//countUser: { $size: "$members" },
			//totalHour: "$duration", //{ $divide : [{ $subtract: ["$endDate", "$startDate"]}, 3600000]},
		}},

		/*
		// This block was no need to calculated
		{ $lookup: {
			from: "user",
			let: {
				userIds: "$userIds",
				//userIds: "$members.user",
				duration: "$duration",
				effortRatio: "$effortRatio",
			},
			pipeline: [
				{ $match: {
					$expr: {
						$and:[{
							$in: ["$_id", "$$userIds"]
						}]
					}
				}},

				{ $populate: ["hrcontract", "_id", "userId", "hrcontract", true]},

				{ $addFields: {
					hourlySalary: "$hrcontract.overview.hourlySalary",
					monthlySalary: "$hrcontract.overview.monthlySalary",
					duration: "$$duration",
					effortRatio: "$$effortRatio",
				}},

				{ $addFields: {
					amount: { $multiply: ["$hourlySalary", "$duration", "$effortRatio"] }
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					userId: 1,
					avt: 1,
					hourlySalary: 1,
					monthlySalary: 1,
					duration: 1,
					amount: 1
				}}
			],
			as: "userIds"
		}},

		{ $addFields: {
			amount: { $sum: "$userIds.amount" }
		}},
		*/

		{ $project: {
			_id: 1,
			title: 1,
			title2: 1,
			descr: 1,
			number: 1,
			duration: 1,
			startDate: 1,
			endDate: 1,
			//totalHour: 1,
			rejectedMessage: 1,
			status: 1,

			//effortRatio: 1,
			totalEffortHour: 1,
			modifiedAt: 1,

			mkDuration: 1,
			estDuration: 1,
			mkSalaryRatio: 1,

			countUser: 1,
			//totalHour: 1,
			totalSalaryHour: 1,
			amount: 1,

			// projectId: 1,
			milestoneId: 1,
			sprintId: 1,
			featureId: 1,

			userIds: 1,
			approverIds: 1,
			//members: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.shortName": 1,
			"projectId.avt": 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			// "approvers._id": 1,
			// "approvers.name": 1,
			// "approvers.name2": 1,
			// "approvers.avt": 1,
			// "approvers.userId": 1,
		}},
	]],
]]);

OvertimeRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view, overtime.modify`,
	`A.trimObject`,
	//`A.verifyInput:: overtime: title!, title2, startDate!, endDate!, descr!, effortRatio!, userIds!, projectId`,

	`A.fillingDateWorking`,
	`A.verifyInput:: overtime: title!, title2, number-, memberSalaries-, ...`,

	`U.Date.calculateOvertimeDuration`,
	//`A.pipeRoute: calculateOvertimeAmount`,

	`A.insertOne: overtime`
]]);

OvertimeRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view, overtime.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.verifyInput:: overtime: startDate!, endDate!, effortRatio, projectId, memberSalaries-, number-, status-, approverId-, creatorId-, createdAt-, modifierId-, modifiedAt-, _id-, ...`,

	//`A.findOne > overtimeOld: overtime`,
	[`A.aggregateOne(*) > overtimeDb: overtime`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.overtime.modify", true] },
				]}
			]},
		]}}},
	]],
	
	`A.verifyKObject(overtimeDb):: _id!: verify.idType`,

	`U.Date.calculateOvertimeDuration`,
	//`A.pipeRoute: calculateOvertimeAmount`,
	//`A.printObject`,

	//`A.updateById: overtime`
	`A.updateById(*): overtime: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject: 200: Update successfully!`,
]]);

// OvertimeRoute.PUT.push([[":_id/status"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view, overtime.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput > overtimeNew:: overtime: status!`,
// 	`A.updateById: overtime`
// ]]);

// OvertimeRoute.PUT.push([[":_id/approved"], [
// 	`A.updateById(*): overtime: { _id: "@P.route._id"}: {status: 2, approverId : "@P.user._id"}`
// ]]);

OvertimeRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: overtime.view, overtime.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	//`A.findOne > overtimeOld: overtime`,
	[`A.aggregateOne(*) > overtimeDb: overtime`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.overtime.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(overtimeDb):: _id!: verify.idType`,

	// Delete all Bonus Leaving matched with this Overtime
	`A.deleteMany(*) > tmp: leaving: {type: "bonus", refId: "@P.route._id"}: true: true`,

	`A.deleteOne: overtime`,
	`A.pipeRoute: deleteOvertime`,
	`A.responseObject: 200: Delete Overtime successfully!`
]]);


// -------------- Pipe calculate Overtime Amount -------------------
OvertimeRoute.PIPE.push([["calculateOvertimeAmount"], [

	`A.getKObject(*) > P.allUserIds: @P.body: members.user`,
	`A.flatObject(*) > P.allUserIds: @P.allUserIds`,

	[`A.aggregate(*) > P.hrcontracts: hrcontract`, [
		{ $match: { $expr: { $and: [
			{ $in: ["$userId", "@P.allUserIds"]}
		]}}},
		{ $addFields: {
			hourlySalary: "$overview.hourlySalary",
			monthlySalary: "$overview.monthlySalary"
		}},
		{ $project: {
			userId: 1,
			hourlySalary: 1,
			monthlySalary: 1
		}}
	]],

	// transArrayToObject = function(Param, pipeData, arrs, key, hasOverride=true)
	`A.transArrayToObject(*) > P.hrcontract: @P.hrcontracts: userId: true`,
	[`A.jsScript(*`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var salary = Req.hrcontract || {};
		var members = body.members;

		for (var i = 0; i < members.length; i++) {
			var member = members[i];
			member.amount = (member.duration||0) * ((salary[member.user]||{}).hourlySalary || 0);
		}

		return Req.UNRESULT;
	}]
], { name: "calculateOvertimeAmount" }]);

module.exports = OvertimeRoute;
