const ReminderRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar", "reminder"],
		roleUserIdKey	: "userId"
	}
};

ReminderRoute.POST.push([["s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: reminder.view`,
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {

		const name = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		var userIds = pipeData.userId || pipeData.userIds;

		var matchOps = {};

        if(name) {
            matchOps.title = Req.func.getASCIISearch(name, "gmi");
        }

        if(fromDate) {
			var and = matchOps["$and"] || []
			matchOps["$and"] = and;
            and.push({
                "$gte" : new Date(fromDate)
            });
        }

		if(toDate) {
			var and = matchOps["$and"] || []
			matchOps["$and"] = and;
            and.push({
                "$lte" : new Date(toDate)
            });
        }

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			matchOps.userId = {
				"$in": userIds
			}
		}

        pipeData.matchOps = matchOps;

		//console.log("pipeData: ", pipeData);
        return pipeData;
    }],

	[`A.aggregate > dbData: reminder`, [
		{ $match: "@matchOps" },

		{ $populate: ["project", "projectId", "_id", "projectId", true]},
		{ $populate: ["user", "userIds", "_id", "userIds"]},

		{ $project: {
			_id: 1,
			title: 1,
			descr: 1,
			date: 1,
			remindBefore: 1,
			number: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.avt": 1,

			"userIds._id": 1,
			"userIds.name": 1,
			"userIds.name2": 1,
			"userIds.avt": 1,
			"userIds.userId": 1,
		}}
	]],

	//`A.printObject:`,
	`A.responseObject: 200: {"reminders": "@dbData"}`
]]);

ReminderRoute.POST.push([[""], [
`A.checkRole(*): Main.company: @P.company._id: rolecompany: reminder.view, reminder.modify`,
	`A.verifyInput:: reminder: title!, userIds!, date!, remindBefore!, decsr`,

	`A.insertOne: reminder`,
	[`A.aggregateOne(*) > reminderDb: reminder`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.body._id"] },
				//{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				{ $eq: ["@P.user.hasAgent", true] },
				{ $eq: ["@P.user.hasAdmin", true] },
				{ $eq: ["@P.user._id", "$creatorId"] },
			]},
		]}}},
		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "email"] },
		{ $addFields: {
			userEmails: "$users.email"
		}}
	]],
	`A.printObject`,
	`A.pipeRoute: addReminderReminder`,
]]);

ReminderRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: reminder.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): reminder`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.reminder.view", true] },
				]}
			]},
		]}}},
		{ $populate: ["user", "userIds", "_id", "users"]}
	]],
	//`A.verifyKObject:: _id!: verify.idType`,
]]);

ReminderRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: reminder.view, reminder.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: reminder: number-, ...`,

	[`A.aggregateOne(*) > reminderDb: reminder`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				//{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.reminder.modify", true] },
				]}
			]},
		]}}},

		// Populate new user Ids
		{ $addFields: {
			newUserIds: { $ifNull: ["@P.body.userIds", "$userIds"] }
		}},

		{ $populateFilter: ["user", "newUserIds$:_id", "users", undefined, 1, "email"] },
		{ $addFields: {
			userEmails: "$users.email"
		}}
	]],

	`A.verifyKObject(reminderDb):: _id!: verify.idType`,

	`A.updateOne > respData: reminder`,
	`A.pipeRoute: addReminderReminder`,

]]);

ReminderRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: reminder.view, reminder.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	[`A.aggregateOne(*) > reminderDb: reminder`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				//{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.reminder.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(reminderDb):: _id!: verify.idType`,

	`A.deleteOne(*): reminder: {"_id": "@P.route._id"}: true`,
	`A.pipeRoute: addReminderReminder`,
	`A.responseObject: 200: Delete successfully!`,
]]);

module.exports = ReminderRoute;
