const CalendarRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar"],
		roleUserIdKey	: "userId"
	}
};

CalendarRoute.POST.push([["/full"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,

	//`A.printObject`,
	`A.verifyKObject::  date: verify.dateType:
						startDate: verify.dateType:
						fromDate: verify.dateType`,
	`A.trimObject`,
	//`A.monthRangeFromDate > dbDate: @(date||startDate||fromDate): true: true: true`,
	//`A.weekRangeFromDate > weekRange: @(date||startDate||fromDate): true`,
	//`A.printObject`,
    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};

		// Param, pipeData, date, fillFitCalendar=false, sunDayIsFirstDay=true, toLocalTime=false
		body.dbDate = await A.monthRangeFromDate(Req, pipeData, body.date||body.startDate||body.fromDate, true, true, true);
		//console.log("dbDate", body.date, body.dbDate);

		var dbDate = body.dbDate || (body || {});

		var fromDate =  (dbDate.minDate || (dbDate.startDate || dbDate.fromDate)) ||
						(body.fromDate || body.startDate);
		var toDate = (dbDate.maxDate || (dbDate.endDate || dbDate.toDate)) ||
					 (body.toDate || body.endDate);

		var projectIds = body.projectId || body.projectIds;
		var userIds = (body.userId || body.userIds) ||
		 			  (body.memberId || body.memberIds) ||
					  (body.member || Req.user._id);

		// Only admin agent can view other calendar
		var user = Req.user || {};
		if(!user.hasAgent && !user.hasAdmin) {
			userIds = [user._id];
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			body.userIds = userIds;
			body.userId = userIds[0];
		}

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			body.reqProjectIds = projectIds;
		}

		fromDate = new Date(fromDate); ////new Date(new Date(fromDate).getTime() - 86400000);
		toDate = new Date(new Date(toDate).getTime() + 86400000);

		body.startDate = fromDate;
		body.endDate = toDate;


		//body.startDateNumber = fromDate.getMonth() * 100 + fromDate.getDate();
		//body.endDateNumber = toDate.getMonth() * 100 + toDate.getDate();
		body.startDateLocal = await A.convertToLocalTime(Req, pipeData, fromDate);
		body.endDateLocal = await A.convertToLocalTime(Req, pipeData, toDate);

        body.matchOps = { $expr: {
			$and: [
				{ $in: ["$userId", userIds]},
				{ $gte: ["$endDate", fromDate]},
				{ $lte: ["$endDate", toDate]}
			]
		}};

		body.matchUserOps = {
			userIds: { $elemMatch: { $in: userIds }}
		};

		body.matchDateOps = { $expr: {
			$and: [
				{ $gte: ["$endDate", fromDate]},
				{ $lte: ["$endDate", toDate]}
			]
		}};

		//console.log("body: ", body);
        return Req.UNRESULT;
    }],

	/*
		// register,
		// check in/out

		overtime
		meeting
		leaving
		birthday

		task start/end
		milestone start/end

		risk dueDate
		penalty
		announcement

		- survey
		- interview
		- salary payslip
		- campaign start/end
		reminder for team


		#### holiday
		calendar holiday
		company holiday
		makeup work day (làm bù)
		rosteredDayOff / compensate day (nghỉ bù).
	*/
	//`A.printObject`,

	[`A.aggregate > dbObject::`, [

		//{ departmentIds: { $elemMatch: { $in: "@departmentIds" }}},
		//{ teamIds: { $elemMatch: { $in: "@teamIds" }}},
		//{ seniorityIds: { $elemMatch: { $in: "@seniorityIds" }}},

		// Get all project that user is being in.
		{ $lookup: {
			from: "project",
			//let: {},
			pipeline: [
				{ $match: {
					"members.user": { $in: "@userIds" }
				}},
				{ $replaceRoot: {
					newRoot: { _id: "$_id" }
				}}
			],
			as: "projectIds"
		}},

		// Get group done item
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $eq: ["$shortName", "done"] },
						{ $or: [
							//{ $eq: ["$projectId", "@projectId"] }, // Global so no project here!
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupDone: { $arrayElemAt: [ "$groups", 0 ] },
			// 	 { $filter: {
			// 		 input: "$groups",
			// 		 as: "group",
			// 		 cond: { "$in": ["$$group.shortName", "done"] }
			// 	 }},
			// 	 0
			// ]}
		}},

		// Team
		{ $lookup: {
			from: "team",
			//let: {},
			pipeline: [
				{ $match: {
					"members": { $elemMatch: { $in: "@userIds" }}
				}},
				{ $replaceRoot: {
					newRoot: { _id: "$_id" }
				}}
			],
			as: "teamIds"
		}},

		// Lookup Department
		{ $lookup: {
			from: "department",
			//let: {},
			pipeline: [
				{ $match: {
					"members": { $elemMatch: { $in: "@userIds" }}
				}},
				{ $replaceRoot: {
					newRoot: { _id: "$_id" }
				}}
			],
			as: "department"
		}},

		// Seniority
		{ $lookup: {
			from: "hrcontract",
			//let: {},
			pipeline: [
				{ $match: {
					"userId": { $in: "@userIds" }
				}},

				{ $populate: ["department", "overview.departmentId", "_id", "departmentId", undefined] },
				{ $populate: ["seniority", "overview.seniorityId", "_id", "seniorityId", undefined] },

				{ $replaceRoot: {
					newRoot: {
						seniorityId: "$seniorityId",
					}
				}}
			],
			as: "hrcontract"
		}},
	]],

	//`A.printObject`,
	`A.getKObject > projectDBIds:: dbObject.projectIds._id`,
	`A.getKObject > teamIds:: dbObject.teamIds._id`,
	`A.getKObject > departmentIds:: dbObject.department._id`,
	`A.getKObject > seniorityIds:: dbObject.hrcontract.seniorityId._id`,
	//`A.printObject:`,

	`U.Date.companyTimePoint > cpnTP`,
	// `A.printObject: cpnTP`,

	[`A.jsScript(*):`, (Req, pipeData, ctx) => {
		var user = Req.user;

		var body = Req.body || {};
		body.projectIds = (body.projectIds || body.projectDBIds) || [];
		body.teamIds = body.teamIds || [];
		body.userIds = body.userIds || [];

		body.seniorityIds = body.seniorityIds || [];
		body.departmentIds = body.departmentIds || [];

		// Multiple project
		body.groupDoneId = ((body.dbObject||{}).groupDone||{})._id;
		//console.log("groupDoneId: ", body.groupDoneId, body.dbObject);

		var birthdayMonth = body.startDateLocal.getUTCMonth() + 1;
		var birthdayStartYear = body.startDateLocal.getUTCFullYear();
		var birthdayEndYear = body.endDateLocal.getUTCFullYear();

		var startMorning = ((body.cpnTP||{}).ms||8) * 60;
		var endAfternoon = ((body.cpnTP||{}).ae||17) * 60;

		var ops = [];
		var unionCalendar = [];
		var config = body.config || {};

		var isAdmin = user.hasAgent || user.hasAdmin;

		//console.log("body:", body, config);

 		// --------------------- Array of Filter Calendar Item ------------------------------
		// Register
		if(config.register) {
			unionCalendar.push("$register");
			ops.push({ $lookup: {
				from: "checkin",
				let: { userId: "$_id" },
				pipeline: [
					{ $match: { $and: [
						// Just show start date checking on calendar
						{ creatorId: { "$in": body.userIds }},
						{ registerIn: { "$gt": -1 }},
						{ date: { "$gte": body.startDate }},
						{ date: { "$lte": body.endDate }},
					]}},

					{ $convertDate: ["date -> dateLocal"]},
					{ $addFields: {
						type: "register",
						//startTime: "$registerIn",
						//endTime: "$registerOut",
						startTime: { $divide: ["$registerIn", 60] }, // Minutes
						endTime: { $divide: ["$registerOut", 60] }, // Minutes
						//duration: "$checkinHour",
						$dateString: ["$dateLocal -> $dayString"],

						// dayString: { $concat: [
						// 	{$toString: {$year: "$dateLocal"}}, "-",
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]},
						canDelete: { $and: [
							{ $or: [
								{ $eq: [user._id, "$creatorId"]},
								{ $eq: [isAdmin, true]},
							]},
							{ $or: [
								{ $eq: [isAdmin, true]},
								{ $lte: [{ $ifNull: ["$checkin", -1]}, 0]},
							]}
						]}
					}},

					{ $project: {
						_id: 1,
						type: 1,
						startTime: 1,
						endTime: 1,
						date: 1,
						duration: 1,
						dayString: 1,
						canDelete: 1,
						checkin: 1
					}}
				],
				as: "register"
			}});
		}

		// Checkin
		if(config.checkin) {
			unionCalendar.push("$checkin");
			ops.push({ $lookup: {
				from: "checkin",
				//let: { userId: body.userId },
				pipeline: [
					{ $match: { "$and": [
						// Just show start date checkin on calendar
						{ creatorId: { "$in": body.userIds }},
						{ checkin: { "$gt": -1 }},
						{ date: { "$gte": body.startDate }},
						{ date: { "$lte": body.endDate }},
					]}},

					{ $convertDate: ["date -> dateLocal"]},
					{ $addFields: {
						type: "checkin",
						//startTime: "$checkin",
						//endTime: "$checkout",
						startTime: { $divide: ["$checkin", 60] }, // Minutes
						endTime: { $divide: ["$checkout", 60] }, // Minutes
						duration: "$checkinHour",
						$dateString: ["$dateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dateLocal"}}, "-",
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]}
					}},
					{ $project: {
						_id: 1,
						type: 1,
						startTime: 1,
						endTime: 1,
						date: 1,
						duration: 1,
						dayString: 1,
					}}
				],
				as: "checkin"
			}});
		}

		// for Overtime
		if(config.overtime) {
			unionCalendar.push("$overtime");
			ops.push({ $lookup: {
				from: "overtime",
				pipeline: [
					{ $match: { "$and": [
						// Just show start date overtime on calendar
						//{ startDate: { "$gte": body.startDate }},
						//{ startDate: { "$lte": body.endDate }},
						{ startDate: { "$lte": body.endDate }},
						{ endDate: { "$gte": body.startDate }},
						{ userIds: { $elemMatch: { $in: body.userIds }}},
						// { $or: [
						// 	// Can not get correct this case
						// 	//{ userIds: { $elemMatch: { $in: body.userIds }}},
						// 	//{ "members.user": { $in: body.userIds } }, // Can breakdown like this
						// ]}
					]}},

					{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},
					{ $addFields: {
						endRange: { $ceil: { $divide: [{ $subtract: [{$add: ["$endDateLocal", 1000]}, "$startDateLocal"] }, 86400000]}},
					}},
					{ $addFields: {
						startRange: { $range: [ 0, "$endRange", 1 ]},
					}},
					{ $addFields: {
						startRange: { $slice: ["$startRange", 84]},
						endRange: { $subtract: ["$endRange", 1]},
					}},
					{ $unwind: {
						path: "$startRange",
						includeArrayIndex: "idx",
						preserveNullAndEmptyArrays: true,
					}},
					{ $addFields: {
						startDateLocal: { $add: [
							"$startDateLocal", {$multiply: ["$startRange", 86400000]}
						]},
						startDate: { $add: [
							"$startDate", {$multiply: ["$startRange", 86400000]}
						]},
					}},

					// Filter out of range
					{ $match: { $expr: { $and: [
						{ $gte: ["$startDate", body.startDate ]},
						{ $lte: ["$startDate", body.endDate ]},
					]}}},

					{ $addFields: {
						type: "overtime",
						date: "$startDate",
						startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						endTime: { $sum: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
						duration: "$totalHour",
						$dateString: ["$startDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$startDateLocal"}}, "-",
						// 	{$toString: {$month: "$startDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
						// ]}
					}},
					{ $addFields: {
						startTime: { $cond: [
							{ $gt: ["$idx", 0] },
							startMorning, //480, // 8:00AM
							"$startTime",
						]},
						endTime: { $cond: [
							{ $lt: ["$idx", "$endRange"] },
							endAfternoon, //1020, // 17:00PM
							"$endTime",
						]},
					}},

					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						endTime: 1,
						duration: 1,
						dayString: 1,
						date: 1,
						number: 1,
					}}
				],
				as: "overtime",
			}});
		}

		// for Meeting
		if(config.meeting) {
			unionCalendar.push("$meeting");
			ops.push({ $lookup: {
				from: "meeting",
				pipeline: [
					{ $match: { "$and": [
						// Just show start date meeting on calendar
						//{ startDate: { "$gte": body.startDate }},
						//{ startDate: { "$lte": body.endDate }},
						{ startDate: { "$lte": body.endDate }},
						{ endDate: { "$gte": body.startDate }},
						{ members: { $elemMatch: { $in: body.userIds }} }
					]}},

					{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},
					{ $addFields: {
						endRange: { $ceil: { $divide: [{ $subtract: [{$add: ["$endDateLocal", 1000]}, "$startDateLocal"] }, 86400000]}},
					}},
					{ $addFields: {
						startRange: { $range: [ 0, "$endRange", 1 ]},
					}},
					{ $addFields: {
						startRange: { $slice: ["$startRange", 84]},
						endRange: { $subtract: ["$endRange", 1]},
					}},
					{ $unwind: {
						path: "$startRange",
						includeArrayIndex: "idx",
						preserveNullAndEmptyArrays: true,
					}},
					{ $addFields: {
						startDateLocal: { $add: [
							"$startDateLocal", {$multiply: ["$startRange", 86400000]}
						]},
						startDate: { $add: [
							"$startDate", {$multiply: ["$startRange", 86400000]}
						]},
					}},
					// Filter out of range
					{ $match: { $expr: { $and: [
						{ $gte: ["$startDate", body.startDate ]},
						{ $lte: ["$startDate", body.endDate ]},
					]}}},

					{ $addFields: {
						type: "meeting",
						date: "$startDate",
						startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						endTime: { $sum: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
						$dateString: ["$startDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$startDateLocal"}}, "-",
						// 	{$toString: {$month: "$startDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
						// ]}
					}},
					{ $addFields: {
						startTime: { $cond: [
							{ $gt: ["$idx", 0] },
							startMorning, //480, // 8:00AM
							"$startTime",
						]},
						endTime: { $cond: [
							{ $lt: ["$idx", "$endRange"] },
							endAfternoon, //1020, // 17:00PM
							"$endTime",
						]},
					}},

					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						endTime: 1,
						duration: 1,
						dayString: 1,
						date: 1,
						number: 1,
					}}
				],
				as: "meeting",
			}});
		}

		// for Leaving
		if(config.leaving) {
			unionCalendar.push("$leaving");
			ops.push({ $lookup: {
				from: "leaving",
				pipeline: [
					{ $match: { "$and": [
						// Just show start date leaving on calendar
						//{ startDate: { "$gte": body.startDate }},
						//{ startDate: { "$lte": body.endDate }},
						{ startDate: { "$lte": body.endDate }},
						{ endDate: { "$gte": body.startDate }},
						{ creatorId: { "$in": body.userIds }}
					]}},

					{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},
					{ $addFields: {
						endRange: { $ceil: { $divide: [{ $subtract: [{$add: ["$endDateLocal", 1000]}, "$startDateLocal"] }, 86400000]}}
					}},
					{ $addFields: {
						startRange: { $range: [ 0, "$endRange", 1 ]},
					}},
					{ $addFields: {
						startRange: { $slice: ["$startRange", 84]},
						endRange: { $subtract: ["$endRange", 1]},
					}},
					{ $unwind: {
						path: "$startRange",
						includeArrayIndex: "idx",
						preserveNullAndEmptyArrays: true,
					}},
					{ $addFields: {
						startDateLocal: { $add: [
							"$startDateLocal", {$multiply: ["$startRange", 86400000]}
						]},
						startDate: { $add: [
							"$startDate", {$multiply: ["$startRange", 86400000]}
						]},
					}},

					// Filter out of range
					{ $match: { $expr: { $and: [
						{ $gte: ["$startDate", body.startDate ]},
						{ $lte: ["$startDate", body.endDate ]},
					]}}},

					{ $addFields: {
						type: "leaving",
						date: "$startDate",
						title: "$reason",
						startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						endTime: { $sum: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
						$dateString: ["$startDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$startDateLocal"}}, "-",
						// 	{$toString: {$month: "$startDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
						// ]}
					}},
					{ $addFields: {
						startTime: { $cond: [
							{ $gt: ["$idx", 0] },
							startMorning, //480, // 8:00AM
							"$startTime",
						]},
						endTime: { $cond: [
							{ $lt: ["$idx", "$endRange"] },
							endAfternoon, //1020, // 17:00PM
							"$endTime",
						]},
					}},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						endTime: 1,
						duration: 1,
						dayString: 1,
						date: 1,
						number: 1,
					}}
				],
				as: "leaving"
			}});
		}

		// for Birthday
		if(config.birthday) {
			unionCalendar.push("$birthday");
			ops.push({ $lookup: {
				from: "hrcontract",
				pipeline: [
					{ $convertDate: ["overview.birthday -> dateLocal"]},
					{ $addFields: {
						birthday: "$overview.birthday",
						month: { $month: "$dateLocal" },
						day: { $dayOfMonth: "$dateLocal" },
					}},
					{ $addFields: {
						dateTestStart: { $dateFromParts: {
							year: birthdayStartYear,
							month: "$month",
							day: "$day",
						}},
					}},

					{ $addFields: {
						yearPicked: { $cond: [
							{ $and: [
								{ $gte: ["$dateTestStart", body.startDate ]},
								{ $lte: ["$dateTestStart", body.endDate ]},
							]},
							birthdayStartYear,
							birthdayEndYear
						]}
					}},

					{ $addFields: {
						date: { $dateFromParts: {
							year: "$yearPicked",
							month: "$month",
							day: "$day",
						}},
					}},

					{ $match: { $and: [
						{ date: { "$gte": body.startDate }},
						{ date: { "$lte": body.endDate }},
					]}},

					{ $populate: ["user", "userId", "_id", "user", false]},

					{ $addFields: {
						_id: "$user._id",
						type: "birthday",
						title: "$user.name",
						avt: "$user.avt",
						userId: "$user.userId",

						dayString: { $concat: [
							{ $toString: "$yearPicked" },
							{ $cond: [{$lte: [{$month: "$dateLocal"}, 9]}, "-0", "-"] },
							{ $toString: {$month: "$dateLocal"}},
							{ $cond: [{$lte: [{$dayOfMonth: "$dateLocal"}, 9]}, "-0", "-"] },
							{ $toString: {$dayOfMonth: "$dateLocal"}}
						]},
						// dayString: { $concat: [
						// 	//{$toString: {$year: "$overview.birthday"}}, "-",
						// 	{$toString: "$yearPicked"}, "-", // abc exception
						// 	//{$toString: {$year: "$dateLocal"}}, "-", // accept for view
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]}
					}},
					{ $project: {
						_id: 1,
						title: 1,
						avt: 1,
						userId: 1,
						type: 1,
						//startTime: 1,
						//endTime: 1,
						//duration: 1,
						dayString: 1,
						date: 1,
						birthday: 1,
					}}
				],
				as: "birthday"
			}});
		}

		// for Risk
		if(config.risk) {
			unionCalendar.push("$risk");
			ops.push({ $lookup: {
				from: "risk",
				pipeline: [
					{ $match: { "$and": [
						{ status: { $ne: 2 }}, // Resolved will not be showed anymore.
						{ projectId: { "$in": body.projectIds }},
						{ dueDate: { "$gte": body.startDate }},
						{ dueDate: { "$lte": body.endDate }},
					]}},

					{ $convertDate: ["dueDate -> dueDateLocal"]},
					{ $addFields: {
						type: "risk",
						title: "$content",
						date: "$dueDate",
						endTime: { $sum: [{$multiply: [{$hour: "$dueDateLocal"}, 60]}, {$minute: "$dueDateLocal"}] },
						$dateString: ["$dueDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dueDateLocal"}}, "-",
						// 	{$toString: {$month: "$dueDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dueDateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						//startTime: 1,
						endTime: 1,
						//duration: 1,
						dayString: 1,
						date: 1,
						number: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "risk"
			}});
		}

		// for Penalty
		if(config.penalty) {
			unionCalendar.push("$penalty");
			ops.push({ $lookup: {
				from: "penalty",
				pipeline: [
					{ $match: { "$and": [
						{ members: { "$elemMatch": { "$in": body.userIds }}},
						{ date: { "$gte": body.startDate }},
						{ date: { "$lte": body.endDate }},
					]}},

					{ $convertDate: ["date -> dateLocal"]},
					{ $addFields: {
						type: "penalty",
						//date: "$date",
						title: "$reason",
						startTime: { $sum: [{$multiply: [{$hour: "$dateLocal"}, 60]}, {$minute: "$dateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$endDate"}, 60]}, {$minute: "$endDate"}] },

						$dateString: ["$dateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dateLocal"}}, "-",
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						//endTime: 1,
						//duration: 1,
						dayString: 1,
						date: 1,
						number: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "penalty"
			}});
		}

		// for Announcement
		if(config.announcement) {
			unionCalendar.push("$announcement");
			ops.push({ $lookup: {
				from: "announcement",
				pipeline: [
					{ $match: { "$and": [
						{ announcedDate: { "$gte": body.startDate } },
						{ announcedDate: { "$lte": body.endDate } },
						{ $or: [
							{ sendToAll: true },
							{ userIds: { $elemMatch: { $in: body.userIds }}},
							{ projectIds: { $elemMatch: { $in: body.projectIds }} },
							{ departmentIds: { $elemMatch: { $in: body.departmentIds }}},
							{ teamIds: { $elemMatch: { $in: body.teamIds }}},
							{ seniorityIds: { $elemMatch: { $in: body.seniorityIds }}},
						]}
					]}},

					{ $convertDate: ["announcedDate -> announcedDateLocal"]},
					{ $addFields: {
						type: "announcement",
						date: "$announcedDate",
						startTime: { $sum: [{$multiply: [{$hour: "$announcedDateLocal"}, 60]}, {$minute: "$announcedDateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$endDate"}, 60]}, {$minute: "$endDate"}] },
						$dateString: ["$announcedDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$announcedDateLocal"}}, "-",
						// 	{$toString: {$month: "$announcedDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$announcedDateLocal"}}
						// ]}
					}},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						dayString: 1,
						date: 1,
						number: 1,
					}}
				],
				as: "announcement"
			}});
		}

		// for Reminder
		if(config.reminder) {
			unionCalendar.push("$reminder");
			ops.push({ $lookup: {
				from: "reminder",
				pipeline: [
					{ $match: { "$and": [
						{ userIds: { $elemMatch: { $in: body.userIds }}},
						{ date: { "$gte": body.startDate } },
						{ date: { "$lte": body.endDate } },
					]}},

					{ $convertDate: ["date -> dateLocal"]},
					{ $addFields: {
						type: "reminder",
						startTime: { $sum: [{$multiply: [{$hour: "$dateLocal"}, 60]}, {$minute: "$dateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$endDate"}, 60]}, {$minute: "$endDate"}] },
						$dateString: ["$dateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dateLocal"}}, "-",
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]},
						canDelete: { $cond: [
							{ $and: [
								{ $or: [
									{ $eq: [user._id, "$creatorId"]},
									{ $eq: [isAdmin, true]},
								]},
							]}, true, false,
						]}
					}},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						dayString: 1,
						date: 1,
						number: 1,
						canDelete: 1,
					}}
				],
				as: "reminder"
			}});
		}

		// for Working holiday
		if(config.workingholiday) {
			unionCalendar.push("$workingholiday");
			ops.push({ $lookup: {
				from: "workingholiday",
				pipeline: [
					{ $match: { "$and": [
						{ date: { "$gte": body.startDate } },
						{ date: { "$lte": body.endDate } },
					]}},

					{ $convertDate: ["date -> dateLocal"]},
					{ $addFields: {
						type: "workingholiday",
						startTime: { $sum: [{$multiply: [{$hour: "$dateLocal"}, 60]}, {$minute: "$dateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$dateLocal"}, 60]}, {$minute: "$dateLocal"}] },
						$dateString: ["$dateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dateLocal"}}, "-",
						// 	{$toString: {$month: "$dateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dateLocal"}}
						// ]}
					}},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						//endTime: 1,
						dayString: 1,
						date: 1,
					}}
				],
				as: "workingholiday"
			}});
		}

		// for Milestone Start
		if(config.milestoneStart) {
			unionCalendar.push("$milestoneStart");
			ops.push({ $lookup: {
				from: "milestone",
				pipeline: [
					{ $match: { "$and": [
						{ status: { $ne: 2 }}, // approved will not show any more
						// Just show start date milestone on calendar
						{ startDate: { "$gte": body.startDate }},
						{ startDate: { "$lte": body.endDate }},
						{ projectId: { "$in": body.projectIds }},
					]}},
					{ $convertDate: ["startDate -> startDateLocal"]},
					{ $addFields: {
						type: "milestoneStart",
						date: "$startDate",
						startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						$dateString: ["$startDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$startDateLocal"}}, "-",
						// 	{$toString: {$month: "$startDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						startTime: 1,
						//endTime: 1,
						dayString: 1,
						date: 1,
						number: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "milestoneStart"
			}});
		}

		// for Milestone End
		if(config.milestoneEnd) {
			unionCalendar.push("$milestoneEnd");
			ops.push({ $lookup: {
				from: "milestone",
				pipeline: [
					{ $match: { "$and": [
						{ status: { $ne: 2 }}, // approved will not show any more
						// Just show start date milestone on calendar
						{ endDate: { "$gte": body.startDate }},
						{ endDate: { "$lte": body.endDate }},
						{ projectId: { "$in": body.projectIds }}
					]}},

					{ $convertDate: ["endDate -> endDateLocal"]},
					{ $addFields: {
						type: "milestoneEnd",
						date: "$endDate",
						//startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						endTime: { $sum: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
						$dateString: ["$endDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$endDateLocal"}}, "-",
						// 	{$toString: {$month: "$endDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$endDateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						type: 1,
						//startTime: 1,
						endTime: 1,
						dayString: 1,
						date: 1,
						number: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "milestoneEnd"
			}});
		}

		// for Task Start
		if(config.taskStart) {
			unionCalendar.push("$taskStart");
			ops.push({ $lookup: {
				from: "task",
				pipeline: [
					{ $match: { "$and": [
						{ $and: [
							{ groupId: { $ne: body.groupDoneId }},
							{ status: { $ne: 6 }},
						]},
						{ startDate: { "$gte": body.startDate }},
						{ startDate: { "$lte": body.endDate }},
						{ projectId: { "$in": body.projectIds }},
						{ "$or": [
							{ assigneeIds: { $elemMatch: { $in: body.userIds }}},
							{ testerIds: { $elemMatch: { $in: body.userIds }}},
							{ reviewerIds: { $elemMatch: { $in: body.userIds }}},
						]},
					]}},

					{ $convertDate: ["startDate -> startDateLocal"]},
					{ $addFields: {
						taskType: "$type",
						type: "taskStart",
						date: "$startDate",
						title: "$name",
						startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						//endTime: { $sum: [{$multiply: [{$hour: "$dueDateLocal"}, 60]}, {$minute: "$dueDateLocal"}] },
						$dateString: ["$startDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$startDateLocal"}}, "-",
						// 	{$toString: {$month: "$startDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						taskType: 1,
						type: 1,
						number: 1,
						priority: 1,
						startTime: 1,
						//endTime: 1,
						duration: 1,
						dayString: 1,
						date: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "taskStart"
			}});
		}

		// for Task End
		if(config.taskEnd) {
			unionCalendar.push("$taskEnd");
			ops.push({ $lookup: {
				from: "task",
				pipeline: [
					{ $match: { "$and": [
						{ $and: [
							{ groupId: { $ne: body.groupDoneId }},
							{ status: { $ne: 6 }},
						]},
						{ dueDate: { "$gte": body.startDate }},
						{ dueDate: { "$lte": body.endDate }},
						{ projectId: { "$in": body.projectIds }},
						{ "$or": [
							{ assigneeIds: { $elemMatch: { $in: body.userIds }}},
							{ testerIds: { $elemMatch: { $in: body.userIds }}},
							{ reviewerIds: { $elemMatch: { $in: body.userIds }}},
						]},
					]}},

					{ $convertDate: ["dueDate -> dueDateLocal"]},
					{ $addFields: {
						taskType: "$type",
						type: "taskEnd",
						date: "$dueDate",
						title: "$name",
						//startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
						endTime: { $sum: [{$multiply: [{$hour: "$dueDateLocal"}, 60]}, {$minute: "$dueDateLocal"}] },
						$dateString: ["$dueDateLocal -> $dayString"],
						// dayString: { $concat: [
						// 	{$toString: {$year: "$dueDateLocal"}}, "-",
						// 	{$toString: {$month: "$dueDateLocal"}}, "-",
						// 	{$toString: {$dayOfMonth: "$dueDateLocal"}}
						// ]}
					}},

					{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "shortName"]},
					{ $project: {
						_id: 1,
						title: 1,
						taskType: 1,
						type: 1,
						number: 1,
						priority: 1,
						//startTime: 1,
						endTime: 1,
						duration: 1,
						dayString: 1,
						date: 1,
						shortName: "$project.shortName",
					}}
				],
				as: "taskEnd"
			}})
		}

		//console.log("Config: ", config);
		// if(!ops || (ops.length <= 0)) {
		// 	return {
		// 		respData: "Request invalid!",
		// 		respCode: 500,
		// 		respReturn: true
		// 	}
		// }

		//console.log("OPS:", ops.length, JSON.stringify(ops[12]));
		//ops = [ops[0], ops[1], ops[2], ops[3], ops[4], ops[5], ops[6], ops[7], ops[8], ops[9], ops[10], ops[11], ops[13]];
		ops.push(
			// Join all tem into one array
			{ $addFields: {
				calendar: {
					//$setUnion: unionCalendar
					$concatArrays: unionCalendar
					//["$register", "$checkin", "$overtime", "$meeting", "$leaving", "$birthday", "$risk", "$penalty", "$announcement", "$reminder", "$workingholiday", "$milestoneStart", "$milestoneEnd", "$taskStart", "$taskEnd"]
				}
			}},

			{ $project: {
				calendar: 1,
			}},
			{ $unwind: "$calendar" },
			{ $replaceRoot: {
				newRoot: "$calendar"
			}},

			{ $sort: {
				date: 1,
				dayString: 1
			}},

			{ $group: {
				_id: "$dayString",
				date: {$max: "$date"},
				dayString: {$first: "$dayString"},
				lists: {
					$push: "$$ROOT"
				}
			}},
			{ $sort: {
				date: 1,
				_id: 1
			}},
			{ $project: {
				dayString: 0,
				"lists.date": 0,
				"lists.dayString": 0,
			}},
			//{ $convertDate: ["date -> dateLocal"]},
			{ $addFields: {
				dateRaw: "$date",
			}},
			{ $addFields: {
				date: "$dayString",
			}},
		);

		body.opsArrs = ops;
		body.unionCalendar = unionCalendar;
		return Req.UNRESULT;
	}],
	//`A.printObject: @opsArrs`,

	`A.aggregate > dbData:: @opsArrs`,

	//`A.printObject:`,

	// arrs, weekBoundary=false, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false, keyPaths
	//`A.dateMinMax(dbData.tasks) > dbDate1:: false:: true: true: 0: startDate, endDate`,
	//`A.dateMinMax(dbData.tasks.subTasks) > dbDate2:: false:: true: true: 0: startDate, endDate`,
	//`A.dateMinMax(*) > dbDate: ["@P.body.dbDate1", "@P.body.dbDate2", "@P.body"]: true:: true: true: 0: minDate, maxDate, startDate, endDate`,

	//`A.dateMinMax(*) > dbDate: ["@P.body"]: true:: true: true: 0: fromDate, toDate`,
	//`A.printObject`,

	`A.dateFillDayIndex: @dbData: @startDate::: true: dateRaw, index`,
	//`A.dateFillDayIndex: @dbPresences: @dbDate.minDate: 1:: true: date, index`,
	//`A.printObject

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var dbData = body.dbData;

		var totalOTHour = 0;
		var totalRegisterHour = 0;
		var totalWorkingHour = 0;

		dbData.map(item => {
			delete item.dateLocal;
			delete item.dateRaw;

			item.lists.map(i => {
				var type = i.type;
				if(type == "overtime") {
					totalOTHour += (item.duration || 0);

				} else if(type == "register") {
					totalRegisterHour += (item.duration || 0);

				} else if(type == "checkin") {
					totalWorkingHour += (item.duration || 0);
				}
			});
		});

		body.totalOTHour = totalOTHour;
		body.totalRegisterHour = totalRegisterHour;
		body.totalWorkingHour = totalWorkingHour;
		body.percent = Math.floor(((totalWorkingHour||0) / (totalRegisterHour||1)) * 100);

		return Req.UNRESULT;
	}],

	`A.responseObject: 200: {
		"calendar": "@dbData",
		"totalOTHour": "@totalOTHour",
		"totalRegisterHour": "@totalRegisterHour",
		"totalWorkingHour": "@totalWorkingHour",
		"percent": "@percent",
		"date": {
			minDate: "@startDate",
			maxDate: "@endDate",
			inRange: "@dbDate.inRange",
			numberDay: "@dbDate.numberDay"
		}
	}`,
], { useZip: true }]);


CalendarRoute.POST.push([["/presence"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,

	`A.trimObject`,

	`U.Date.companyTimePoint > cpnTP`,
    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};

		//const name = body.name || (body.search || body.text);
		var startDate = body.fromDate || body.startDate;
		var endDate = body.toDate || body.endDate;
		var userIds = (body.member || body.members) ||
					  (body.memberId || body.memberIds) ||
					  (body.userId || body.userIds);// || Req.user._id;

        // if(name) {
        //     matchOps.title = Req.func.getASCIISearch(name, "gmi");
		//     matchOps.title = Req.func.getASCIISearch(name, "gmi");
        // }

		if(!startDate) {
			startDate = new Date();
			var idx = startDate.getDay();
			startDate = new Date(startDate.getTime() - idx*86400000);

		} else {
			startDate = new Date(startDate);
			// startDate.setHours(0);
			// startDate.setMinutes(0);
			// startDate.setSeconds(0);
		}

		if(!endDate) {
			endDate = new Date(startDate.getTime() + 7*86400000 - 1000);

		} else {
			endDate = new Date(endDate);
		}
		
		body.startDateLocal = await A.convertToLocalTime(Req, pipeData, startDate);

		var userOps = {
			hasDeleted: { $nin: [true] },
			status: 1,
		};

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				userOps._id = { $in: userIds };
			}

		} else {
			userIds = [];
		}

		body.userOps = userOps;
        body.userIds = userIds;
		body.startDate = startDate;
		body.endDate = endDate;

		body.startMorning = ((body.cpnTP||{}).ms||8) * 60;
		body.endAfternoon = ((body.cpnTP||{}).ae||17) * 60;

		body.getAll = ["1", "true", "yes"].indexOf(body.getAll+"") >= 0;

		//console.log("body: ", body);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne > dbData: user`, [
		{ $match: "@userOps" },
		{ $sort: {
			name$: 1,
		}},

		{ $getTotalLength: ["@page", "totalLength"]},

		// Register
		{ $lookup: {
			from: "checkin",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$creatorId", "$$userId" ]},
					{ $gt: ["$registerIn", 0 ]},
					{ $gte: ["$date", "@startDate" ]},
					{ $lte: ["$date", "@endDate" ]}
				]}}},
				{ $convertDate: ["date -> dateLocal"]},
				{ $addFields: {
					sort: 1,
					type: "register",
					startTime: { $divide: ["$registerIn", 60] }, // Minutes
					endTime: { $divide: ["$registerOut", 60] }, // Minutes
					duration: "$registerHour",
					$dateString: ["$dateLocal -> $dayString"],
					// dayString: { $concat: [
					// 	{$toString: {$year: "$dateLocal"}}, "-",
					// 	{$toString: {$month: "$dateLocal"}}, "-",
					// 	{$toString: {$dayOfMonth: "$dateLocal"}}
					// ]}
				}},

				{ $project: {
					_id: 1,
					sort: 1,
					startTime: 1,
					endTime: 1,
					status: 1,
					date: 1,
					dayString: 1,
					duration: 1,
					type: 1,
				}}
			],
			as: "register"
		}},

		// Check In
		{ $lookup: {
			from: "checkin",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					// Just show start date checkin on calendar
					{ $eq: ["$creatorId", "$$userId" ]},
					{ $gt: ["$checkin", 0 ]},
					{ $gte: ["$date", "@startDate" ]},
					{ $lte: ["$date", "@endDate" ]},
				]}}},

				{ $convertDate: ["date -> dateLocal"]},
				{ $addFields: {
					sort: 2,
					type: "checkin",
					//startTime: "$checkin",
					//endTime: "$checkout",
					startTime: { $divide: ["$checkin", 60] }, // Minutes
					endTime: { $divide: ["$checkout", 60] }, // Minutes
					duration: "$checkinHour",
					$dateString: ["$dateLocal -> $dayString"],
					// dayString: { $concat: [
					// 	{$toString: {$year: "$dateLocal"}}, "-",
					// 	{$toString: {$month: "$dateLocal"}}, "-",
					// 	{$toString: {$dayOfMonth: "$dateLocal"}}
					// ]}
				}},
				{ $project: {
					_id: 1,
					sort: 1,
					type: 1,
					startTime: 1,
					endTime: 1,
					date: 1,
					duration: 1,
					dayString: 1,
				}}
			],
			as: "checkin"
		}},

		// Overtime
		{ $lookup: {
			from: "overtime",
			let: { userId: "$_id" },
			pipeline: [
				{ $addFields: {
					memberIds: { $ifNull: ["$userIds", []]},
	                //memberIds: { $ifNull: ["$members.user", []]},
	            }},
				{ $match: { $expr: { $and: [
					// Can not make correctly for this case
					//{ $in: [ "$$userId", "$userIds" ]},
					{ $in: [ "$$userId", "$memberIds" ]}, // old is $userIds
					//{ $in: [ "$userCheckId", "$memberIds" ]},
					//{ $gte: ["$startDate", "@startDate" ]},
					//{ $lte: ["$startDate", "@endDate" ]},
					{ $lte: ["$startDate", "@endDate" ]},
					{ $gte: ["$endDate", "@startDate" ]}
				]}}},

				{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},
				{ $addFields: {
					endRange: { $ceil: { $divide: [{ $subtract: [{$add: ["$endDateLocal", 1000]}, "$startDateLocal"] }, 86400000]}},
				}},
				{ $addFields: {
					startRange: { $range: [ 0, "$endRange", 1 ]},
				}},
				{ $addFields: {
					startRange: { $slice: ["$startRange", 7]},
					endRange: { $subtract: ["$endRange", 1]},
				}},
				{ $unwind: {
					path: "$startRange",
					includeArrayIndex: "idx",
					preserveNullAndEmptyArrays: true,
				}},
				{ $addFields: {
					startDateLocal: { $add: [
						"$startDateLocal", {$multiply: ["$startRange", 86400000]}
					]},
					startDate: { $add: [
						"$startDate", {$multiply: ["$startRange", 86400000]}
					]},
				}},

				// Filter out of range
				{ $match: { $expr: { $and: [
					{ $gte: ["$startDate", "@startDate" ]},
					{ $lte: ["$startDate", "@endDate" ]},
				]}}},

				{ $addFields: {
					sort: 4,
					type: "overtime",
					date: "$startDate",
					startTime: { $add: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
					endTime: { $add: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
					$dateString: ["$startDateLocal -> $dayString"],
					// dayString: { $concat: [
					// 	{$toString: {$year: "$startDateLocal"}}, "-",
					// 	{$toString: {$month: "$startDateLocal"}}, "-",
					// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
					// ]},
				}},
				{ $addFields: {
					startTime: { $cond: [
						{ $gt: ["$idx", 0] },
						"@startMorning", //480, // 8:00AM
						"$startTime",
					]},
					endTime: { $cond: [
						{ $lt: ["$idx", "$endRange"] },
						"@endAfternoon",//1020, // 17:00PM
						"$endTime",
					]},
				}},

				{ $project: {
					_id: 1,
					sort: 1,
					title: 1,
					type: 1,
					startTime: 1,
					endTime: 1,
					duration: 1,
					dayString: 1,
					date: 1,
					number: 1,
				}}
			],
			as: "overtime"
		}},

		{ $lookup: {
			from: "leaving",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					// Just show start date leaving on calendar
					//{ $gte: ["$startDate", "@startDate" ]},
					//{ $lte: ["$startDate", "@endDate" ]},
					{ $lte: ["$startDate", "@endDate" ]},
					{ $gte: ["$endDate", "@startDate" ]},
					{ $eq: ["$creatorId", "$$userId" ]},
				]}}},

				{ $convertDate: ["startDate -> startDateLocal", "endDate -> endDateLocal"]},
				{ $addFields: {
					endRange: { $ceil: { $divide: [{ $subtract: [{$add: ["$endDateLocal", 1000]}, "$startDateLocal"] }, 86400000]}},
				}},
				{ $addFields: {
					sort: 1,
					startRange: { $range: [ 0, "$endRange", 1 ]},
				}},
				{ $addFields: {
					startRange: { $slice: ["$startRange", 14]},
					endRange: { $subtract: ["$endRange", 1]},
				}},
				{ $unwind: {
					path: "$startRange",
					includeArrayIndex: "idx",
					preserveNullAndEmptyArrays: true,
				}},
				{ $addFields: {
					startDateLocal: { $add: [
						"$startDateLocal", {$multiply: ["$startRange", 86400000]}
					]},
					startDate: { $add: [
						"$startDate", {$multiply: ["$startRange", 86400000]}
					]},
				}},

				// Filter out of range
				{ $match: { $expr: { $and: [
					{ $gte: ["$startDate", "@startDate" ]},
					{ $lte: ["$startDate", "@endDate" ]},
				]}}},

				{ $addFields: {
					sort: 3,
					type: "leaving",
					date: "$startDate",
					title: "$reason",
					startTime: { $sum: [{$multiply: [{$hour: "$startDateLocal"}, 60]}, {$minute: "$startDateLocal"}] },
					endTime: { $sum: [{$multiply: [{$hour: "$endDateLocal"}, 60]}, {$minute: "$endDateLocal"}] },
					$dateString: ["$startDateLocal -> $dayString"],
					// dayString: { $concat: [
					// 	{$toString: {$year: "$startDateLocal"}}, "-",
					// 	{$toString: {$month: "$startDateLocal"}}, "-",
					// 	{$toString: {$dayOfMonth: "$startDateLocal"}}
					// ]},
				}},
				{ $addFields: {
					startTime: { $cond: [
						{ $gt: ["$idx", 0] },
						"@startMorning", //480, // 8:00AM
						"$startTime",
					]},
					endTime: { $cond: [
						{ $lt: ["$idx", "$endRange"] },
						"@endAfternoon", //1020, // 17:00PM
						"$endTime",
					]},
				}},

				{ $project: {
					_id: 1,
					sort: 1,
					title: 1,
					type: 1,
					startTime: 1,
					endTime: 1,
					duration: 1,
					dayString: 1,
					date: 1,
					number: 1,
					startRange: 1,
				}},
			],
			as: "leaving"
		}},

		{ $addFields: {
			lists: {
				$setUnion: ["$register", "$checkin", "$leaving", "$overtime"]
			}
		}},

		{ $lookup: {
			from: "__zcounting",
			let: { lists: "$lists" },
			pipeline: [
				{ $limit: 1 },
				{ $project: { _id: 1 }},
				{ $project: { _id: 0 }},
				{ $addFields: {
					lists: "$$lists",
				}},
				{ $unwind: "$lists" },
				{ $sort: {
					sort: 1,
					type: 1
				}},

				{ $group: {
					_id: "$lists.dayString",

					//date: { $first: "$lists.date" },
					dayString: { $first: "$lists.dayString" },
					lists: { $push: "$$ROOT" }
				}},

				{ $replaceRoot: { newRoot: {
					_id: "$_id",
					//date: "$date",
					date: "$dayString",
					//dayString: "$dayString",
					listItems: "$lists.lists"
				}}},

				{ $project: {
					_id: 1,
					date: 1,
					//dayString: 1,
					"listItems._id": 1,
					"listItems.type": 1,
					"listItems.number": 1,
					"listItems.status": 1,
					"listItems.startTime": 1,
					"listItems.endTime": 1,
					"listItems.duration": 1,

					//"listItems.memberIds": 1,
					//"listItems.startIndex": 1,
					//"listItems.endIndex": 1,
					//"listItems.startRange": 1,
				}},
				{ $sort: {
					date: 1,
				}}
			],
			as: "listDays"
		}},

		// Filter all Item has Data days
		{ $match: { $expr: { $or: [
			{ $eq: ["@getAll", true]},
			{ $gt: [{$size: {$ifNull: ["$listDays", []]}}, 0]},
		]}}},

		{ $project: {
			_id: 1,
			type: 1,
			name: 1,
			name2: 1,
			avt: 1,
			userId: 1,

			//checkin: 1,
			//overtime: 1,
			listDays: 1,
			//presences: 1,
			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "presences"]},
	]],

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var dbData = body.dbData || {};
		var presences = dbData.presences;

		if(!presences) {
			body.dbData = { presences: [], page: body.page };
		}

		return Req.UNRESULT;
	}],

	//`A.printObject`,
	`A.getKObject(dbData.presences) > dbPresences:: listDays`,
	`A.trimObject(dbPresences) > dbPresences`,
	`A.flatObject(dbPresences) > dbPresences:: 2`,
	//`A.printObject:`,

	// Update in cafe client not send Date data
	// `A.modifyObject:: (
	// 	startDate = (startDate || new Date())
	// )`,

	//`A.printObject`,
	// arrs, weekBoundary=false, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false, keyPaths
	
	// `A.dateMinMax > dbDate:: true:: true: true: 0: startDate, endDate, dbPresences.date`,
	`A.formObject > dbDate:: {
		minDate: "@startDate",
		maxDate: "@endDate",
	}`,
	//`A.printObject`,

	// arrs, startDate, scale=1.0, adjust=0.0, toLocalTime=false, ...keyPaths
	`A.dateFillDayIndex: @dbPresences: @dbDate.minDate: 1:: true: date, index`,
	//`A.printObject:`,

	`A.responseObject: 200: {"date": "@dbDate", "presences": "@dbData.presences", "page": "@dbData.page"}`
], { useZip: true }]);


CalendarRoute.POST.push([["/statistic"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,

	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		//const name = body.name || (body.search || body.text);
		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;
		var userIds = (body.member || body.members) ||
					  (body.memberId || body.memberIds) ||
					  (body.userId || body.userIds);

		var matchDateOps = {};
		var matchDateOpsSE = {};
        var matchUserOps = { hasDeleted: {$nin: [true]}, status: 1};

        if(fromDate && toDate) {
			fromDate = new Date(fromDate);
			toDate = new Date(toDate);

			matchDateOps["$and"] = [
				{ date: {"$gte" : fromDate} },
				{ date: {"$lte" : toDate} },
			];

			// Only count foe start Date
			matchDateOpsSE["$and"] = [
				{ startDate: {"$gte" : fromDate} },
				{ startDate: {"$lte" : toDate} },
			];
        }

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				matchUserOps._id = {
					"$in": userIds
				}
			}
		}

        body.matchUserOps = matchUserOps;
		body.matchDateOps = matchDateOps;
		body.matchDateOpsSE = matchDateOpsSE;

		body.startDate = new Date(fromDate);
		body.endDate = new Date(toDate);

		//console.log("body: ", body);
        return Req.UNRESULT;
    }],
	//`A.printObject`,

	`U.Date.companyTimePoint > cpnTP`,
	`U.Date.calendarWorkingDay > calendarWorkingDay`,

	`A.getPaginate > page`,
	[`A.aggregateOne > dbData: user`, [
		{ $match: "@matchUserOps" },
		{ $sort: {
			name$: 1,
		}},

		{ $getTotalLength: ["@page", "totalLength"] },

		// for Checkin
		{ $lookup: {
			from: "checkin",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$creatorId", "$$userId"] }
				]}}},
				{ $match: "@matchDateOps" },
				// { $addFields: {
				// 	comeLateHour: { "$cond": [
				// 				{ $in:["$type", [1]] },
				// 				{ "$subtract": ["$checkin", startMorning] }, // morning start
				// 				{ "$subtract": ["$checkin", "$registerIn"] }
				// 			  ]},
				// 	backEarlyHour: { "$cond": [
				// 				{ $in:["$type", [1]] },
				// 				{ "$subtract": [endAfternoon, "$checkout"] }, // afternoon end
				// 				{ "$subtract": ["$registerOut", "$checkout"] }
				// 			  ]},
				// }},
				{ $addFields: {
					// user type = 1 => normal user
					comeLate: { "$cond": [{$lt:["$comeLateHour", 0]}, 0, "$comeLateHour"] },
					backEarly: { "$cond": [{$lt:["$backEarlyHour", 0]}, 0, "$backEarlyHour"] },
				}},
				// { $addFields: {
				// 	// user type = 1 => normal user
				// 	comeLateHour: { "$cond": [{$gt:["$comeLateHour", 0]}, "$comeLateHour", 0] },
				// 	backEarlyHour: { "$cond": [{$gt:["$backEarlyHour", 0]}, "$backEarlyHour", 0] }
				// }}
			],
			as: "checkin"
		}},

		{ $lookup: {
			from: "overtime",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$$userId", { $ifNull: ["$userIds", []] } ] },
					//{ $in: ["$$userId", "$members.user"] }, // old is $userIds
					{ $eq: ["$status", 2] }
				]}}},
				{ $match: "@matchDateOpsSE" }
			],
			as: "overtime"
		}},

		{ $lookup: {
			from: "leaving",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$$userId", "$creatorId"] }, // userIds -> not esxist
					{ $eq: ["$status", 2] }
				]}}},
				{ $match: "@matchDateOpsSE" }
			],
			as: "leaving"
		}},

		{ $addFields: {
			overtimeCount: { "$size": "$overtime" },
			overtimeDay: { "$divide": [{ "$sum": "$overtime.totalHour" }, 8] }, // check it multiply with effortRatio or not?

			leavingCount: { "$size": "$leaving" },
			leavingDay: { "$divide": [{ "$sum": "$leaving.duration" }, 8] }, //{ "$sum": "$leaving.duration" }, // count by day

			comeLateCount: { "$sum": "$checkin.comeLate" },
			comeLateHour: { "$sum": "$checkin.comeLateHour" },

			backEarlyCount: { "$sum": "$checkin.backEarly" },
			backEarlyHour: { "$sum": "$checkin.backEarlyHour" },

			workingCount: { "$size": "$checkin" },
			//workingHour: { "$sum": "$checkin.checkinHour" },
			workingDay: { "$divide": [{ "$sum": "$checkin.checkinHour" }, 8]},

			// for normal user, type == 1.
			scheduleDay: { "$cond": [{$in:["$type", [1]]}, "@calendarWorkingDay", {"$size": "$checkin"}] },
		}},

		{ $project: {
			_id: 1,
			type: 1,
			name: 1,
			name2: 1,
			avt: 1,
			userId: 1,

			// Data
			overtimeCount: 1,
			overtimeHour: 1,
			overtimeDay: 1,

			leavingCount: 1,
			leavingDay: 1,

			comeLateCount: 1,
			comeLateHour: 1,

			backEarlyCount: 1,
			backEarlyHour: 1,

			workingCount: 1,
			//workingHour: 1,
			workingDay: 1,

			scheduleDay: 1,
			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "statistics"] }
	]],

	`A.responseObject: 200: {"statistics": "@dbData.statistics", "page": "@dbData.page" }`,
	//`A.responseObject: 200: {"statistics": "@dbData"}`
], { useZip: true }]);


module.exports = CalendarRoute;
