const RolecompanyRoute = {
	route	: "role-company",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

RolecompanyRoute.POST.push([["s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findMany: rolecompany`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-, permit-`
]]);

RolecompanyRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.findOne: rolecompany`,
	`U.Func.unifyRoleCompany(*): @P.body.permit`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RolecompanyRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyInput:: rolecompany: name!, ...`,
    `A.insertOne: rolecompany`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RolecompanyRoute.POST.push([["clone/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	//`A.verifyInput:: roleproject: name!, ...`,

	`A.findById: rolecompany`,
    `A.refactorOutput:: _id-, number-, createdAt-, modifiedAt-, creatorId-, modifierId-`,

	`A.formatString > name: "{{name}} - copied"`,
	`A.insertById: rolecompany`,
	`A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`,
]]);

RolecompanyRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput > reqData:: rolecompany: projectId-, ...`,
	`A.findOne > dbData: rolecompany`,

    // < merge defined, but + is free merge.
	`A.modifyObject::
		dbData = <+reqData,
		respData = dbData
    `,

	//`A.printObject: @respData: @dbData`,
    `A.updateById(dbData) > resData: rolecompany`,
    `A.refactorOutput(respData):: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RolecompanyRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.deleteById: rolecompany`,
]]);

module.exports = RolecompanyRoute;
