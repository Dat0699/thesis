const WikiRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
    PATCH   : [],

    config	: {
		checkKeyFeature	: "project.feature.wiki",
        checkMIFs		: ["project", "wiki"],

		imProject		: true,
		groupPath		: "project",
		featurePath		: "wiki",
    }
};

// POST: /wiki
WikiRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view, wiki.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: wiki: title!, projectId!, descr!, number-, ...`,
    `A.insertOne(*): wiki: @P.body`,
    `A.insertOne > wikicommentdb: wikicomment: { projectId: "@projectId", wikiId: "@_id" }`,

    `A.populate: user, modifierId, _id, modifier, +, name, name2, userId, avt`,
    `A.refactorOutput:: _id, number, title, descr, groupId, message, modifiedAt, modifier`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;

        body.history =  {
            historyId : new Date().getTime(),
            title : body.title,
			title2 : body.title2,
            descr : body.descr,
            message : body.message || body.title,
            modifier: Req.user._id,
            modifiedAt: body.modifiedAt || new Date(),
        };

        return Req.UNRESULT;
    }],

    `A.formatString > filePath: "{{_id}}.gwiki"`,
    `A.jsonAppendFile: @filePath: @history`,

	`A.pipeRoute: wiki: { type: "create" }`,
	`A.pipeRoute: featureUpdateRelatedItem`,

    `A.refactorOutput:: history-, filePath-, ...`
]]);

WikiRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqBody:: wiki: groupId, projectId, featureId`,

	[`A.aggregate(*): wiki`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@P.project._id"] },
			// { $or: [
			// 	{ $in: ["$featureId", ['', undefined, null, 0, [], false]] },
			// 	{ $not: [{ $in: ["$featureId", ["@P.body.reqBody.featureId"]] }] },
			// ]}
		]}}},
		{ $project: {
			_id: 1,
			number: 1,
			title: 1,
			title2: 1,
		}}
	]],

	// `A.findMany: wiki: @reqBody`,
	// `A.refactorOutput:: _id, number, title, title2`,
]]);

WikiRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	[`A.aggregateOne(*): wiki`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		// model, condition, saveAs, keepEmpty, filterType, keys
		{ $populateFilter: ["user", "modifierId:_id", "modifier", true, 1, "_id", "name", "userId", "avt"]},
		//{ $populateFilter: ["label", "labelIds$:_id", "labelIds", undefined, 1, "_id", "name", "name2", "color"]},
		{ $projectKeep: [
			"_id", "number", "title", "descr",
			"groupId", "labelIds", "message",
			"modifiedAt", "modifier"
		]}
	]],
], { useZip: true }]);

WikiRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view, wiki.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: wiki: colIndex, groupId, projectId!`,

	`A.updateById(*) > wikiDb : wiki: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update wiki successfully!`
]]);

WikiRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view, wiki.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: wiki: title, descr, message, groupId, labelIds, projectId!, featureId`,

    `A.updateById(*) > wikiDb : wiki: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		if(!body || !body.wikiDb || !body.wikiDb._id) {
			return {
				respCode: 500,
				respData: "Item was not found!",
				respReturn: true,
			};
		}

		var wiki = body.wikiDb;
        var history =  {
            historyId : new Date().getTime(),
            title : body.title,
			title2 : body.title2,
            descr : body.descr,
            message : body.message || body.title,
            modifier: Req.user._id,
            modifiedAt: wiki.modifiedAt || new Date(),
        };

        body.history = history;
        //console.log(history);

        return Req.UNRESULT;
    }],

    `A.formatString(P.route) > filePath: "{{_id}}.gwiki"`,
	//`A.printObject:`,
    `A.jsonAppendFile: @filePath: @history`,

	`A.pipeRoute: wiki: { type: "update" }`,
    `A.responseObject: 200: Update wiki successfully!`
]]);

WikiRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view, wiki.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.deleteById(*): wiki: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    `A.refactorOutput::creatorId.hasAdmin-, modifierId-, creatorId-, modifiedAt-, createdAt-`,
    `A.formatString(P.route) > P.route.filePath: "{{_id}}.gwiki"`,

	`A.deleteFile(P.route): @filePath:: true: Item`,
	// fromPath, excepts, recursive=true, type="File/Folder"

	`A.pipeRoute: wiki: { type: "delete" }`,
    `A.responseObject: 200: Delete wiki successfully!`,
]]);

WikiRoute.POST.push([["/group/full/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var projectId = Req.project._id;

		var wikiListEmpty = {};
		var wikiMatchOps = [
			{ $eq: ["$projectId", projectId] }
		];
		// [
		// 	{ $eq: ["$groupId", "$$groupId"] }
		// ];

		var wikiLabelMatchOps = {};
		var labelIds = pipeData.labelId || pipeData.labelIds;
		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}

			wikiLabelMatchOps = { labelIds: { $elemMatch: { $in: labelIds }}};
		}

		var title = pipeData.title || pipeData.text;
        if (title) {
            wikiMatchOps.push({ $or: [
				{ $regexMatch: { input : "$title", regex: Req.func.getASCIISearch(title, "gmi") }},
				{ $eq: ["$number", (title-0) || -1] }
			]});

			wikiListEmpty = {
	   			 $and: [
					 { numberWiki: { $gt: 0 } },
	   				 { wikis: { $ne: [] } },
	   				 { wikis: { $exists: true } }
	   			 ]
	   		 };
        }

		pipeData.hasTrim = !!title;
		pipeData.projectId = projectId;
		pipeData.wikiLabelMatchOps = wikiLabelMatchOps;
		pipeData.wikiListEmpty = wikiListEmpty;
        pipeData.wikiMatchOps = {
			$expr: {
				$and: wikiMatchOps
			},
			...wikiLabelMatchOps
		}

		//console.log(JSON.stringify(pipeData));
        return pipeData;
    }],

    // [`A.aggregate > respData: group:`, [
	// 	{ $match: {
	// 		type: "wiki",
	// 		projectId: "@projectId",
	// 	}},
	// 	{ $sort: {
	// 		colIndex: 1,
	// 		name$: 1,
	// 		createdAt: -1
	// 	}},
	//
	// 	{ $lookup: {
	// 		 from: "wiki",
	// 		 let: { groupId : "$_id" },
	// 		 pipeline: [
	// 			{ $match: "@wikiMatchOps" },
	// 			{ $sort: {
	// 				colIndex: 1,
	// 				title: 1,
	// 				createdAt: -1
	// 			}},
	//
	// 			//{ $populate: ["label", "labelIds", "_id", "labelIds"] },
	// 			{ $addFields: {
	// 				type: 'wiki'
	// 			}},
 	// 			{ $project: {
 	// 				_id: 1,
 	// 				title: 1,
	// 				title2: 1,
	// 				number: 1,
	// 				modifiedAt: 1,
	// 				type: 1,
	// 				colIndex: 1,
	//
	// 				"labelIds._id": 1,
	// 				"labelIds.name": 1,
	// 				"labelIds.name2": 1,
	// 				"labelIds.color": 1,
 	// 			} },
	// 		 ],
	// 		 as: "wikis"
	// 	 }},
	// 	 { $project: {
	// 		 _id: 1,
	// 		 name: 1,
	// 		 name2: 1,
	// 		 type: "folder",
	// 		 colIndex: 1,
	//
	// 		 "wikis._id": 1,
	// 		 "wikis.title": 1,
	// 		 "wikis.title2": 1,
	// 		 "wikis.number": 1,
	// 		 "wikis.type": 1,
	// 		 "wikis.colIndex": 1,
	// 		 //"wikis.labelIds": 1,
	// 	 }},
	// 	 { $addFields: {
	// 		 numberWiki: { "$size": "$wikis" }
	// 	 }},
	// 	 { $match: "@wikiListEmpty" }
	//  ]]

	[`A.aggregateOne > data::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$type", "wiki"] },
					{ $eq: ["$projectId", "@projectId"] },
				]}}},
				{ $sort: {
					colIndex: 1,
					name$: 1,
					name2$: 1,
				}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					type: "folder",
					colIndex: 1,
					groupId: "$parentId",
				}}
			],
			as: "groups",
		}},

		{ $lookup: {
			from: "wiki",
			pipeline: [
				{ $match: "@wikiMatchOps" },
				{ $sort: {
					colIndex: 1,
					name$: 1,
					name2$: 1,
				}},
				{ $project: {
					_id: 1,
					title: 1,
					title2: 1,
					number: 1,
					groupId: 1,
					type: "wiki",
					colIndex: 1,
					modifiedAt: 1,
				}}
			],
			as: "wikis"
		}},
		{ $addFields: {
			lists: { $concatArrays: [{$ifNull: ["$groups", []]}, {$ifNull: ["$wikis", []]}]}
		}},
		{ $project: {
			lists: 1,
		}}
	]],
	// lists, parentKey, groupKey, sortKey, searchKeys, searchValue
	`A.parentGroupObject > data: @data.lists: groupId: wikis: colIndex`,
	// enable, arrs, childrenKey, condKey, condValue
	`A.trimObjectDeeply: @hasTrim: @data: wikis: type: folder`,

], { useZip: true }]);

WikiRoute.POST.push([["/group/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var name = (body.name || body.title) || (body.search || body.text) || "";

		body.name = Req.func.getASCIISearch(name, "gmi");
        return pipeData;
    }],

    [`A.aggregate > respData: group:`, [
		{ $match: {
			type: "wiki",
			projectId: "@projectId",
			name: "@name",
		}},
		{ $sort: {
			colIndex: 1,
			name$: 1,
			createdAt: -1
		}},
		 { $project: {
			 _id: 1,
			 name: 1,
			 name2: 1,
			 number: 1,
		 }},
	 ]],
]]);

WikiRoute.GET.push([[":_id/history"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.formatString(P.route) > P.route.filePath: "{{_id}}.gwiki"`,
    `A.jsonFromFile(P.route): @filePath`,
    `A.populate: user, modifier, _id, +, name, name2, userId, avt`,
	`A.sortObject:: modifiedAt: false`,
    `A.refactorOutput:: descr-, title-, ...`
]]);

WikiRoute.GET.push([[":_id/history/:historyId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: wiki.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType:
								historyId: verify.idNumberType`,

    `A.formatString(P.route) > P.route.filePath: "{{_id}}.gwiki"`,
    `A.jsonFromFile(P.route): @filePath`,

    `A.findFirstObject(*) > P.resData: @P.body: historyId: @P.route.historyId`,
	[`A.jsScript(*):`, (Req, pipeData, ctx) => {
		Req.resData.isFirstItem = Req.body.indexOf(Req.route.historyId) == 0;
		return Req.UNRESULT;
	}],
    `A.populate(P.resData): user, modifier, _id, +, name, name2, userId, avt`,
]]);

module.exports = WikiRoute;
