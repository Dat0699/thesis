const CheckinRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		imDB			: true,
		checkMIFs		: ["calendar", "checkin"],
		roleUserIdKey	: "userId"
	}
};

CheckinRoute.POST.push([["/register"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,
	`A.verifyInput > P.reqData:: checkin: date, registerIn, registerOut`,
	//`A.printObject(P.reqData):`,

	`A.dateFillYMDValue(*): @P.reqData:: date, dayString`,
	//`A.printObject(*): @P.reqData`,

	//`A.setKObject(*): @P.reqData: creatorId: @P.user._id`,
	//`A.printObject(*): @P.reqData`,

	`U.Date.calculateRegisterDuration`,
	`A.findById(*) > P.hrcontract: hrcontract: {userId: "@P.user._id"}`,

	//`A.printObject:`,
	//`A.updateMany(P): checkin: @reqData: dayString, creatorId: 10: true`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var salary = (Req.hrcontract||{}).overview || {};
		var hourlySalary = salary.hourlySalary || 0;

		var creatorId = Req.user._id;
		var arrs = Req.reqData;
		for (var i = 0; i < arrs.length; i++) {
			var r = arrs[i];

			dayString = r.dayString;
			if(!dayString) {
				var d = new Date(r.date || (r.registerIn || r.registerOut));

				var tz = A.getCompanyTimeZone(Req) * 3600000;
				d.setUTCMilliseconds(tz);
				dayString = `${d.getUTCFullYear()}${("0"+(d.getUTCMonth()+1)).substr(-2)}${("0"+d.getUTCDate()).substr(-2)}`;
			}

			r.registerAmount = r.registerHour * hourlySalary;
			var rs = await A.updateById(Req, pipeData, "checkin", {dayString, creatorId}, r, true);
			arrs[i] = rs;
		}

		return arrs;
	}],

	//`A.pipeRoute: registerworking: {action: "register"}`,

	`A.refactorOutput:: dayString-, creatorId-, createdAt-, modifierId-, modifiedAt-`
	//`A.responseObject: 200: Checkin successfully!`
]]);

CheckinRoute.DELETE.push([["/register/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	[`A.aggregateOne(*) > ck: checkin:`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$_id", "@P.route._id" ]},
		]}}},
		{ $addFields: {
			hasValid: { $cond: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true]},
					{ $eq: ["@P.user.hasAdmin", true]},
					{ $lt: ["$checkin", 0]},
					{ $in: ["$checkin", [null, undefined, ""]]}
				]},
				true,
				false
			]}
		}}
	]],

	`A.assertKeyExisted(*): @P.body.ck: hasValid: Can not delete checked-in register!`,

	`A.deleteById(*): checkin: {creatorId: "@P.user._id", _id: "@P.route._id"}`,
	`A.responseObject: 200: Delete register successfully!`
]]);

CheckinRoute.POST.push([["/checkin"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,
	// [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
	// 	var A = pipeData.A;
	//
	// 	var date = await A.convertToLocalTime(Req, pipeData, new Date());
	//
	// 	var body = Req.body || {};
	// 	body.reqData = {
	// 		creatorId: Req.user._id,
	// 		checkin: date,
	// 		date: date
	// 	}
	//
	// 	Req.body = body;
	// 	return Req.UNRESULT;
	// }],

	`A.mixObject(*) > reqData:: {
		checkin: "@(new Date())",
		date: "@(new Date())",
	}`,
	//`A.printObject`,

	`A.verifyInput(reqData) > reqData:: checkin: checkin, date`,
	//`A.printObject:`,

	`A.convertToLocalTime > date: @reqData.date`, // dateFillYMDValue include convert
	//`A.printObject:`,

	// arrs, toLocalTime=false, joinerLeter="-", ...keyPaths
	`A.dateFillYMDValue: @reqData: false:: date, dayString`,
	//`A.printObject`,

	//`A.printObject:`,
	`A.updateById(*) > dbData: checkin: {"dayString": "@P.body.reqData.dayString", "creatorId": "@P.user._id"}: @P.body.reqData: true`,

	`U.Date.calculateCheckinDuration(dbData)`,

	// Update Duration
	`A.updateById(*): checkin: {"dayString": "@P.body.reqData.dayString", "creatorId": "@P.user._id"}: {
		comeLateHour: "@P.body.dbData.comeLateHour",
	}`,

	`A.pipeRoute: checkin: {
		action: "checked in",
		time: "@checkin",
		comeLateHour: "@comeLateHour",
	}`,
	`A.responseObject: 200: Checkin successfully!`
]]);

CheckinRoute.POST.push([["/checkout"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,
	// [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
	// 	var A = pipeData.A;
	//
	// 	var date = await A.convertToLocalTime(Req, pipeData, new Date());
	//
	// 	var body = Req.body || {};
	// 	body.reqData = {
	// 		userId: Req.user._id,
	// 		checkout: date,
	// 		date: date
	// 	}
	//
	// 	Req.body = body;
	// 	return Req.UNRESULT;
	// }],

	`A.mixObject(*) > reqData:: {
		checkout: "@(new Date())",
		date: "@(new Date())",
	}`,
	//`A.printObject`,

	`A.verifyInput > reqData: @reqData: checkin: checkout, date`,
	//`A.printObject`,

	`A.convertToLocalTime > date: @reqData.date`,

	`A.dateFillYMDValue: @reqData: false:: date, dayString`,
	//`A.printObject`,

	`A.updateById(*) > dbData: checkin: {"dayString": "@P.body.reqData.dayString", "creatorId": "@P.user._id"}: @P.body.reqData: true`,
	//`A.printObject`,

	`U.Date.calculateCheckinDuration(dbData)`,
	`A.findById(*) > P.hrcontract: hrcontract: {userId: "@P.user._id"}`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var reqData = Req.body.reqData;
		var dbData = Req.body.dbData;

		var salary = (Req.hrcontract||{}).overview || {};
		var hourlySalary = salary.hourlySalary || 0;

		reqData.userId = Req.user._id;
		reqData.checkinHour = dbData.checkinHour;
		reqData.comeLateHour = dbData.comeLateHour;
		reqData.backEarlyHour = dbData.backEarlyHour;

		reqData.checkinAmount = reqData.checkinHour * hourlySalary;

		return Req.UNRESULT;
	}],

	//`A.updateById: checkin: {"dayString": "@dayString", "userId": "@userId"}`,
	//`A.printObject`,

	// Update Duration
	`A.updateById(reqData): checkin: {"dayString": "@dayString", "creatorId": "@userId"}: {
		checkinHour: "@checkinHour",
		comeLateHour: "@comeLateHour",
		backEarlyHour: "@backEarlyHour",
		checkinAmount: "@checkinAmount"
	}`,

	//`A.printObject`,
	`A.pipeRoute: checkin: {
		action: "checked out",
		time: "@checkout",
		hour: "@checkinHour",
		comeLateHour: "@comeLateHour",
		backEarlyHour: "@backEarlyHour",
	}`,

	`A.responseObject: 200: Checkout successfully!`
]]);

CheckinRoute.POST.push([["/verify"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: calendar.view`,
	[`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var d = await A.convertToLocalTime(Req, pipeData, new Date());
		var dayString = `${d.getFullYear()}${("0"+(d.getMonth()+1)).substr(-2)}${("0"+d.getDate()).substr(-2)}`;
		var hourString = `${d.getHours()}${("0"+(d.getMinutes()+1)).substr(-2)}${("0"+d.getSeconds()).substr(-2)}`;

		var user = Req.user || {};
		var rs = await Req.func.dbCall("checkin", "findOne", {
			creatorId: user._id,
			dayString: dayString,
		});

		rs = rs || {};

		var hasRegisterCheckin = (rs.registerHour > 0) || ((rs.registerIn > 0) || (rs.registerOut > 0));
		var hasRegister = (user.type == 1); // official staff

		var hasCheckIn = (rs.checkinHour > 0) || (rs.checkin > 0);
		var hasCheckOut = (rs.checkinHour > 0) || (rs.checkout > 0);

		if(!hasCheckIn) {
			hasCheckOut = true; // disable checkout button
		}

		if(!hasRegister && !hasRegisterCheckin) {
			// user not register (not normal user) will be lock checkin checkout
			hasCheckIn = true;
			hasCheckOut = true;
			rs.checkin = 0;
			rs.checkout = 0;
		}

		return {
			hasRegister, hasCheckIn, hasCheckOut,
			date: rs.date,
			checkin: (rs.checkin||0) / 60,
			checkout: (rs.checkout||0) / 60,
			registerIn: rs.registerIn,
			registerOut: rs.registerOut,
			dayString: dayString,
			hourString: hourString,
		};
	}]
]]);

module.exports = CheckinRoute;
