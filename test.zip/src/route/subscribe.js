const SubscribeRoute = {
    route	: true,
    ctrl	: false,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        //checkMIFs	: ["project"],
		imCompany: false,
    }
};

// Subscribe new user
SubscribeRoute.POST.push([["new"], [
	`A.verifyKObject:: email!: verify.emailType:
					   name!: verify.nameType`,

	`A.checkLimitItem: Public.subscribe: {email: "@email"}: 0: true: You are being subscribed!`,
    `A.findById(*): Public.subscribe: {email: "@P.body.email"}: @P.body`,

	`A.sendMail(*) > tmpMail: {
        "to" 		: ["@P.body.email"],
		"subject" 	: "[GitGam] Subscribe to GitGam!",
		"view" 		: "subscribe",
        "data" 		: "subscribe"
    }`,

	//`A.printObject`,
	`A.responseObject: 200: Subscribe successfully!`
], {unAuth: true}]);

// Unsubscribe user by email link
SubscribeRoute.POST.push([["remove"], [
	`A.verifyKObject:: email!: verify.emailType`,

	`A.checkExistItem: Public.subscribe: {email: "@email"}: true: You were not being subscribed!`,

	`A.generateUniqueID > otp`,
	`A.setKValue: @otp: @_id: 1800: true`, // token exists 30 minutes

	`A.sendMail(*) > tmpMail: {
        "to" 		: ["@P.body.email"],
		"subject" 	: "[GitGam] Confirm unsubscribe to GitGam!",
		"view" 		: "subscribe",
        "data" 		: "unsubscribe"
    }`,

	//`A.printObject`,
	`A.responseObject: 200: Please check your email!`
], {unAuth: true}]);

SubscribeRoute.POST.push([["confirm/:otp"], [
	`A.verifyKObject(P.route):: otp!: verify.tokenType`,
	`A.getKValue(*): @otp: true`,

	`A.deleteById(*): Public.subscribe: {_id: "@P.body._id"}`,
	`A.responseObject: 200: Unsubscribe successfully!`
], {unAuth: true}]);

module.exports = SubscribeRoute;
