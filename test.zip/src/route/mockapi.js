const MockAPIRoute = {
	route	: "/mock/:serverId/api",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

MockAPIRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.verifyInput:: mockapi: groupId, projectId!, serverId!, number-, ...`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.insertOne: mockapi`,

	`A.pipeRoute: mockapi: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockAPIRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.findOne(P.route): mockapi: {_id: "@_id", serverId: "@serverId"}`,
	`A.assertKeyExisted:: _id: Invalid request!`,

	`A.verifyInput:: mockapi: _id-, number-, ...`,
	`A.formatString > name: "{{name}} - cloned"`,

	/*
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;
		return Req.UNRESULT;
	}],
	*/

	`A.insertOne: mockapi`,

	`A.pipeRoute: mockapi: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockAPIRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessMockServer: {role: ""}`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`<F1>A.findOne(P.route): mockapi: {serverId: "@serverId", $or: [{_id: "@_id"}, {number: "@_id"}]}`,

], {F1: {IgnoreSanitized: true}} ]);

MockAPIRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mockapi: number-, projectId-, serverId-, ...`,
	`A.updateById(*): mockapi: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: @P.body`,

	`A.pipeRoute: mockapi: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockAPIRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessMockServer: {role: "delete"}`,

	`A.deleteById(*): mockapi: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,

	`A.pipeRoute: mockapi: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = MockAPIRoute;
