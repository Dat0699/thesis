const MentionRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		// checkKeyFeature	: "project.feature.dashboard",
		// checkMIFs 		: ["project", "dashboard"],
		// imProject 		: true,
		// keepRole		: true,
	}
};

MentionRoute.POST.push([["/s"], [
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];
		var body = Req.body || {};

		var user = Req.user || {};
		ops.push({ $in: [user._id, "$mentionToIds"] })

		// var search = (body.search || body.text) || (body.name || "");
		// if (search) {
		// 	search = Req.func.getASCIISearch(search, "gmi");
		// 	ops.push({ $regexMatch: { input: "$name", regex: search } })
		// }

		var startDate = body.fromDate || body.startDate;
		var endDate = body.toDate || body.endDate;
		if (startDate && endDate) {
			ops.push({ $gte: ["$createdAt", new Date(startDate)] });
			ops.push({ $lte : ["$createdAt", new Date(endDate)] });
		}

		if (ops.length <= 0) {
			body.ops = {};
		} else {
			body.ops = { $expr: { $and: ops }};
		}
		
		return Req.UNRESULT;
	}],

	[`A.aggregate(*): mention`, [
		{ $match: "@P.body.ops" },
		{ $populateFilter: ["user", "mentionById:_id", "mentionBy", true, 1, "_id", "name", "userId", "avt"]},
		{ $addFields: {
			readIds: { $ifNull: ["$readIds", []] }
		}},
		{ $addFields: {
			hadRead: { $in: ["@P.user._id", "$readIds"] }
		}},
		{
			$project: {
				feature       : 1,
				featureNumber : 1,
				featureName   : 1,
				featureId     : 1,
				hasComment    : 1,
				commentId     : 1,
				hadRead		  : 1,
				createdAt	  : 1,
				mentionBy 	  : 1,
			}
		}
	]]
]]);

MentionRoute.POST.push([[""], [
	`A.verifyInput > reqData:: mention: feature!, featureId!, featureNumber!, featureName!, projectShortname!, projectId!, mentionById!, mentionToIds!, ...`,
	`A.updateById: mention: {"projectShortname": "@reqData.projectShortname", "feature": "@reqData.feature", "featureId": "@reqData.featureId"}: @reqData: true`,
	`A.responseObject: 200: Create Mention successfully!`,
]]);

MentionRoute.PUT.push([["/:_id/seen"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.insertSubItem(*): mention: @P.route._id: readIds: @P.user._id`,
	`A.responseObject: 200: Mark as read successfully!`,
]]);

MentionRoute.PUT.push([["/:_id/unseen"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.removeSubItem(*): mention: @P.route._id: readIds: @P.user._id`,
	`A.responseObject: 200: Mark as unread successfully!`,
]]);

module.exports = MentionRoute;
