const TestResultRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.testcase",
        checkMIFs		: ["project", "testcase"],
		imProject		: true,
    }
};

TestResultRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject:: number: verify.idNumberType`,
    `A.verifyInput > reqData:: testresult: testflowId, testcaseId!, projectId!, ...`,

	[`A.aggregateOne > testFlow: testflow`, [
		{ $match: { $or: [
			{ _id: "@reqData.testflowId" },
			{ number: "@reqData.testflowId" },
			{ _id: "@number" },
			{ number: "@number" }
		]}},
	]],

	`A.updateOne:
		testresult:
		{
			projectId: "@reqData.projectId",
			testflowId: "@testFlow._id",
			testcaseId: "@reqData.testcaseId",
		}:
		@reqData:
		true `,

	`A.pipeRoute: testresult: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

// TestResultRoute.POST.push([["/s"], [
//     "A.findMany: testresult",
//     "A.populate: user, creatorId, _id",
//     "A.refactorOutput:: creatorId._id-",
// ]]);
//
// TestResultRoute.GET.push([[":_id"], [
//     "A.findOne: testresult",
//     "A.refactorOutput",
// ]]);

// TestResultRoute.PUT.push([[":_id"], [
//     "A.verifyInput:: testresult: creatorId-, createdAt-",
// 	`A.printObject`,
//     "A.updateById: testresult",
//     "A.refactorOutput",
// ]]);

TestResultRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.deleteById(*): testresult: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: testresult: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = TestResultRoute;
