const DepartmentRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

DepartmentRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyInput:: department: name!, name2, members!, descr, avt, leaderId, viceLeaderIds`,
	`A.insertOne: department`,
	`A.refactorOutput:: _id, name, name2, avt, descr, leaderId, viceLeaderIds`
]]);

DepartmentRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findMany > dbData: department:`,
	//`A.populate(dbData): user, members, _id, members, +, _id, name, name2, userId, email, avt`,
	`A.refactorOutput(dbData):: _id, name, name2, avt`
]]);

DepartmentRoute.POST.push([["/full"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	//`A.findMany > dbData: department`,
	//`A.populate(dbData): user, members, _id, members, +, _id, name, name2, userId, email, avt`,
	//`A.refactorOutput:: _id, name, name2, descr, avt, members`

	[`A.jsScript:`, async (Req, pipeData, ctx) => {
		var matchOps = {};

		var body = Req.body;
		var name = body.name || body.search || body.text;
		var userIds = (body.users || body.userIds) || (body.members || body.memberIds);

		if(name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
			matchOps["$or"] = [{ name: nameReg }, { name2: nameReg }];
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				matchOps.members = { $elemMatch: { $in: userIds } };
			}
		}

		body.matchOps = matchOps;
		return Req.UNRESULT;
	}],

	[`A.aggregate: department`, [
		{ $match: "@matchOps" },

		{ $populateFilter: ["user", [
			{ $let: { members: "$members"} },
			{ $expr: { $and: [
				{ $in: ["$_id", "$$members"] },
				{ $not: [{$in: ["$hasActived", [false]] }]},
				{ $not: [{$in: ["$hasDeleted", [true]] }]},
				{ $not: [{$in: ["$hasLocked", [true]] }]},
			]}},
			// { $match: {
			// 	hasDeleted: { $nin: [true] }
			// }}
		], "members", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $addFields: {
            viceLeaderIds: { $ifNull: ["$viceLeaderIds", []] },
        }},
		
		{ $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
        { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			descr: 1,
			members: 1,
			leader: 1,
			viceLeaders: 1,
		}}
	]],
]]);

DepartmentRoute.GET.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	//`A.findOne > dbData: department:`,
	//`A.printObject`,
	//`A.lookupObject: @dbData: hrcontract, _id, overview.departmentId, users, 500000, <-, userId`,
	//`A.printObject: @dbData`,

	//`A.lookupObject: @dbData: user, users, _id, users, 50000, _id, name, name2, userId, email, avt`,
	//`A.populate(dbData): user, members, _id, members, +, _id, name, name2, userId, email, avt`,
	//`A.printObject`,

	//`A.refactorOutput:: _id, name, name2, descr, avt, members`

	[`A.aggregateOne(*): department`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$_id", "@P.route._id"] }
		]}}},
		{ $populateFilter: ["user", [
			{ $let: { members: "$members"}},
			{ $expr: { $and: [
				{ $in: ["$_id", "$$members"] },
				{ $not: [{$in: ["$hasActived", [false]] }]},
				{ $not: [{$in: ["$hasDeleted", [true]] }]},
				{ $not: [{$in: ["$hasLocked", [true]] }]},
			]}},
		], "members", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $addFields: {
			viceLeaderIds: { $ifNull: ["$viceLeaderIds", []]}
		}},

		{ $populateFilter: ["user", "leaderId:_id", "leader", true, 1, "_id", "name", "name2", "userId", "avt"] },
        { $populateFilter: ["user", "viceLeaderIds$:_id", "viceLeaders", true, 1, "_id", "name", "name2", "userId", "avt"] },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			descr: 1,
			members: 1,
			leader: 1,
			viceLeaders: 1,
		}}
	]],
]]);

DepartmentRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: department:name, name2, descr, members, avt, leaderId, viceLeaderIds`,
	`A.updateOne: department`,
    `A.responseObject: 200: Update successfully!`
]]);

DepartmentRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: department`,
	`A.pipeRoute: deleteDepartment`,
    `A.responseObject: 200: Delete Department successfully!`
]]);

// DepartmentRoute.POST.push([["/:_id/member/:userId/add"], [
// 	`A.updateSubItem(*): hrcontract: {"userId": "@P.route.userId"}: overview.departmentId: @P.route._id:: false`,
//     `A.responseObject: 200: Add member successfully!`
// ]]);
//
// DepartmentRoute.POST.push([["/:_id/member/:userId/remove"], [
// 	`A.updateSubItem(*): hrcontract: {"userId": "@P.route.userId"}: overview.departmentId: #null:: false`,
//     `A.responseObject: 200: Delete successfully!`
// ]]);

module.exports = DepartmentRoute;
