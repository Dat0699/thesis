const CostRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.cost",
        checkMIFs		: ["project", "cost"],
		imProject		: true,
    }
};

CostRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject`,
    `A.verifyInput:: cost: projectId!, name!, name2, amount!, status-, ...`,

    `A.insertOne: cost`,

	`A.pipeRoute(*): cost: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

// CostRoute.POST.push([["/s"], [
//     "A.findMany: cost",
// 	"A.populate: user, assignId, _id, assignId, +, _id, name, name2, userId, avt",
// 	"A.populate: task, taskId, _id, taskId, +, _id, name, name2, number, type, priority, status",
// 	//"A.populate: label, labelIds, _id, assignId, +, _id, name, name2, avt",
//
//     "A.refactorOutput:: creatorId._id-",
// ]]);

CostRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): cost`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		{ $populate: ["user", "approverIds", "_id", "approvers"]},
		{ $addFields: {
			name: { $ifNull: ["$name", "$descr"]},
		}},

		{ $project: {
			_id: 1,
			number: 1,
			projectId: 1,
			taskId: 1,
			type: 1,
			date: 1,
			name: 1,
			name2: 1,
			descr: 1,
			amount: 1,
			assignId: 1,
			labelIds: 1,
			status: 1,
			
			milestoneId: 1,
			sprintId: 1,
			featureId: 1,
			taskId: 1,
			
			modifiedAt: 1,
			rejectedMessage: 1,
			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			"approvers._id": 1,
			"approvers.name": 1,
			"approvers.name2": 1,
			"approvers.avt": 1,
			"approvers.userId": 1,
		}}
	]],

    //`<F1>A.findById(P.route): cost: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,

	//`A.populate: user, approverId, _id, approvedBy, +, name, name2, userId, avt`,
	//		   //: user, approverIds, _id, approvers, +, name, name2, userId, avt, `,
    //`A.refactorOutput`,
]]);

CostRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.trimObject`,

    `A.verifyInput:: cost: number-, projectId-, creatorId-, createdAt-, ...`,
    `A.updateById(*): cost: {
		_id: "@P.route._id",
		projectId: "@P.project._id",
	}: @P.body`,

	`A.pipeRoute(*): cost: { type: "update" }`,
	`A.responseObject(*): 200: Update Cost successfully!`
]]);

CostRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.deleteById(*): cost: {
		_id: "@P.route._id",
		projectId: "@P.project._id",
	 }`,

	`A.pipeRoute(*): cost: { type: "delete" }`,
	`A.responseObject: 200: Delete Cost successfully!`
]]);


CostRoute.POST.push([["/by/ledger/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		const name = pipeData.name || (pipeData.title || pipeData.descr) || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		const projectId = Req.project._id; // || Req.query.projectId || Req.route.projectId; ////pipeData.projectId;
		const members = (pipeData.member || pipeData.members || pipeData.memberIds) ||
						(pipeData.user ||  pipeData.users || pipeData.userIds);
		//var milestoneId = pipeData.milestoneId;

        var matchOps = {};
		if(projectId) {
        	matchOps.projectId = projectId;
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				matchOps.status = { $in: status };
			}
		}

		if(members) {
			if(!Array.isArray(members)) {
				members = [members];
			}

			if(members.length > 0) {
				matchOps.assignId = { $in: members };
			}
		}

        if(name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            matchOps["$or"] = [
				{ descr: nameReg },
				{ descr2: nameReg },
				{ name: nameReg },
				{ name2: nameReg },
				{ number: (name-0) || -1 },
			];
        }

		if(fromDate && toDate) {
			matchOps["$and"] = [
				{ date: {"$gte" : new Date(fromDate)} },
				{ date: {"$lte" : new Date(toDate)} }
			];
        }

		// if(milestoneId) {
		// 	if(!Array.isArray(milestoneId)) {
		// 		milestoneId = [milestoneId];
		// 	}
		//
		// 	matchOps.milestoneId = { $in: milestoneId };
		// }

		//pipeData.skipTask = skipTask;
		//pipeData.numberTask = numberTask;


        pipeData.matchOps = matchOps;
		//console.log("pipeData: ", matchOps);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: cost`, [
		{ $match: "@matchOps" },

		{ $sort: {
			date: -1,
			amount: -1,
			//createdAt: -1,
			//modifiedAt: -1,
		}},

		{ $getTotalLength: "@page" },

		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		//{ $populate: ["user", "approverIds", "_id", "approvers"]},

		// related to Task
		{ $populate: ["task", "taskId", "_id", "taskId", true]},

		// related to creatorId
		{ $populate: ["user", "creatorId", "_id", "creatorId", true]},

		// related to assignId
		{ $populate: ["user", "assignId", "_id", "assignId", true]}, // Keep this case

		{ $addFields: {
			name: { $ifNull: ["$name", "$descr"]},
		}},

		{ $convertDate: ["date -> dateLocal"]},
		{ $group: {
			_id: {
                month: { $month: "$dateLocal" },
                day: { $dayOfMonth: "$dateLocal" },
                year: { $year: "$dateLocal" }
            },
			date: { $min: "$date" },
			amount: { $sum: "$amount"},
			costs: {
				$push: "$$ROOT"
			},
			totalLength: { $first: "$totalLength" }
		}},
		{ $sort: {
			date: -1,
		}},

		{ $project: {
			_id: 1,
			amount: 1,
			date: 1,

			totalLength: 1,

			"costs._id": 1,
			"costs.number": 1,
			"costs.type": 1,
			"costs.date": 1,
			"costs.name": 1,
			"costs.name2": 1,
			"costs.descr": 1,
			"costs.amount": 1,
			"costs.status": 1,
			"costs.modifiedAt": 1,
			"costs.rejectedMessage": 1,

			"costs.assignId._id": 1,
			"costs.assignId.name": 1,
			"costs.assignId.name2": 1,
			"costs.assignId.avt": 1,
			"costs.assignId.userId": 1,

			"costs.taskId._id": 1,
			"costs.taskId.name": 1,
			"costs.taskId.name2": 1,
			"costs.taskId.number": 1,
			"costs.taskId.type": 1,

			"costs.creatorId._id": 1,
			"costs.creatorId.name": 1,
			"costs.creatorId.name2": 1,
			"costs.creatorId.avt": 1,
			"costs.creatorId.userId": 1,

			"costs.approvedBy._id": 1,
			"costs.approvedBy.name": 1,
			"costs.approvedBy.name2": 1,
			"costs.approvedBy.avt": 1,
			"costs.approvedBy.userId": 1,

			// "costs.approvers._id": 1,
			// "costs.approvers.name": 1,
			// "costs.approvers.name2": 1,
			// "costs.approvers.avt": 1,
			// "costs.approvers.userId": 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "costs"] }
	]],

	//`A.printObject:`,
	//`A.responseObject: 200: {"costs": "@dbData"}`
], {useZip: true}]);


CostRoute.POST.push([["/by/task/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {

		const name = pipeData.name || (pipeData.search || pipeData.text);

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		const projectId = Req.project._id; // || Req.query.projectId || Req.route.projectId; ////pipeData.projectId;

		var milestoneId = (pipeData.milestone || pipeData.milestones) ||
						  (pipeData.milestoneId || pipeData.milestoneIds);

		const members = (pipeData.member || pipeData.members || pipeData.memberIds) ||
						(pipeData.user ||  pipeData.users || pipeData.userIds);

		//var numberTask = (pipeData.numberTask || 5) - 0;
		//var skipTask = (pipeData.skipTask || 0) - 0;
		//var scale = (pipeData.scale || 5) - 0;

		pipeData.keepMember = true;
		var logtimeOps = [
			{ $eq: [ "$taskId", "$$taskId"] },
			//{ $eq: [ "$status", 2] } // Approve only
		];

		var matchOps = [];
		if(projectId) {
        	matchOps.push({ projectId: projectId });
		}

		if(members) {
			if(!Array.isArray(members)) {
				members = [members];
			}

			if(members.length > 0) {
				matchOps.push({ "$or": [
					{ assigneeIds: { $elemMatch: { $in: members }} },
					{ testerIds: { $elemMatch: { $in: members }} },
					{ reviewerIds: { $elemMatch: { $in: members }} },
				]});

				logtimeOps.push({$in: ["$creatorId", members]});
				pipeData.keepMember = false;
			}
		}

        if(name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
			matchOps.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg },
			]});
        }

        if(fromDate) {
            matchOps.push({ dueDate: {
                "$gte" : new Date(fromDate)
            }})
        }

		if(toDate) {
            matchOps.push({ startDate: {
                "$lte" : new Date(toDate)
            }});
        }

		if(milestoneId) {
			if(!Array.isArray(milestoneId)) {
				milestoneId = [milestoneId];
			}

			if(milestoneId.length > 0) {
				matchOps.push({ milestoneId: { $in: milestoneId } });
			}
		}

		//pipeData.skipTask = skipTask;
		//pipeData.numberTask = numberTask;

        pipeData.matchOps = { $and: matchOps };
		pipeData.logtimeOps = logtimeOps;
		//console.log("pipeData: ", pipeData);

        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: task`, [
		{ $match: "@matchOps"},

		{ $getTotalLength: "@page" },

		{ $addFields: {
			duration: {$ceil: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000] }},
			remainingDay: {$ceil: { $divide: [{$subtract: ["$dueDate", "$$NOW"]}, 86400000] }},
		}},

		// Get all log time belog to this task
		{ $lookup: {
			from: "logtime",
			let: {taskId: "$_id"},
			pipeline: [
				{ $match: {
					$expr: {
						$and: "@logtimeOps"
					}
				}},

				// Find Salary
				{ $populate: ["hrcontract", "creatorId", "userId", "hrcontract", false]},

				// { $project: {
				// 	"hrcontract.overview.hourlySalary": 1,
				// 	"hrcontract.overview.monthlySalary": 1,
				// 	creatorId: 1,
				// 	hour: 1,
				// }},

				{ $addFields: {
					//hourlySalary: "$hrcontract.overview.hourlySalary",
					//monthlySalary: "$hrcontract.overview.monthlySalary",

					// when approve logtime, calculate this logtime to amount
					amount: { $multiply: ["$hour", "$hrcontract.overview.hourlySalary"]},
				}},

				{ $project: {
					creatorId: 1,
					amount: 1,
					hour: 1,
				}},

			],
			as: "logtimes"
		}},

		{ $addFields: {
			logAmount: { $sum: "$logtimes.amount" },
			logHour: { $sum: "$logtimes.hour" },

			// Merge assignee, tester, reviewer
			users: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] }
		}},


		// Get Ledger cost
		{ $populate: ["cost", "_id", "taskId", "ledger"]},

		// Get the HRContract with user in "$users"
		{ $populate: ["hrcontract", "users", "userId", "contracts"]},

		// Populate user
		// Get the HRContract with user in "$users"
		{ $populateFilter: ["user", "assigneeIds$:_id", "assignees", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Tester
		{ $populateFilter: ["user", "testerIds$:_id", "testers", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Reviewer
		{ $populateFilter: ["user", "reviewerIds$:_id", "reviewers", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Approver list user
		//{ $populateFilter: ["user", "approverIds$:_id", "approvers", undefined, 1, "_id", "name", "avt"]},

		// for people who press apporove
		{ $populateFilter: ["user", "approverId:_id", "approvedBy", true, 1, "_id", "name", "userId", "avt"]},

		{ $addFields: {
			ledgerCost: { $sum: "$ledger.amount"},

			estHour: { $multiply: ["$duration",  {$size: "$contracts"}, 8] }, // 8 hour perday
			estAmount: { $multiply: ["$duration",  {$sum: "$contracts.overview.hourlySalary"}, 8] }, // 8 hour perday
		}},

		{ $addFields: {
			diffHour: { $subtract: ["$estHour", "$logHour"] },
			diffAmount: { $subtract: ["$estAmount", "$logAmount"] },

			//{ $cond: [ { $eq: [ "$downvotes", 0 ] }, 0, {"$divide":["$upvotes", "$downvotes"]} ] }

			percentHour: { $cond: [{$eq:["$estHour",0]}, 0, {$divide: [{$subtract: ["$estHour", "$logHour"]}, "$estHour"]}]},
			percentAmount: { $cond: [{$eq:["$estAmount",0]}, 0, {$divide: [{$subtract: ["$estAmount", "$logAmount"]}, "$estAmount"]}]},
		}},

		{ $sort: {
			estAmount: -1,
			logAmount: 1,

			estHour: -1,
			logHour: -1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			type: 1,
			status: 1,
			priority: 1,
			duration: 1,
			startDate: 1,
			dueDate: 1,
			remainingDay: 1,
			budget: 1,

			assignees: 1,
			testers: 1,
			reviewers: 1,
			approvedBy: 1,
			//approvers: 1,

			ledgerCost: 1,
			milestoneId: 1,

			//users: 1,
			//logtimes: 1,

			estHour: 1,
			estAmount: 1,

			logHour: 1,
			logAmount: 1,

			diffHour: 1,
			diffAmount: 1,

			percentHour: 1,
			percentAmount: 1,

			totalLength: 1,
		}},

		// Populate milestone and filter
		{ $populate: ["milestone", "milestoneId", "_id", "milestone", true]},
		{ $addFields: {
			milestone: {
				_id: { $ifNull: ["$milestone._id", ""]},
				name: { $ifNull: ["$milestone.name", ""]},
				avt: { $ifNull: ["$milestone.avt", 0]},
                number: { $ifNull: ["$milestone.number", 0]},
				startDate: "$milestone.startDate",
				endDate: "$milestone.endDate", //{ $ifNull: ["$milestone.dueDate", 0]},
			}
		}},

		{ $group: {
			_id: "$milestone._id",
			tasks: { $push: "$$ROOT"},
			totalLength: { $first: "$totalLength" },

			totalBudget: { $sum: "$budget"},
			totalLedgerCost: { $sum: "$ledgerCost"},

			totalEstHour: { $sum: "$estHour"},
			totalEstAmount: { $sum: "$estAmount"},

			totalLogHour: { $sum: "$logHour"},
			totalLogAmount: { $sum: "$logAmount"},

			totalDiffHour: { $sum: "$diffHour"},
			totalDiffAmount: { $sum: "$diffAmount"},

			totalPercentHour: { $avg: "$percentHour"},
			totalPercentAmount: { $avg: "$percentAmount"},
			milestone: { $first: "$milestone" }
		}},

		{ $sort: {
			"milestone.endDate": -1,
			"milestone.startDate": -1
		}},

		{ $project: {
			"tasks.totalLength": 0
		}},

		{ $addFields: {
			duration: {$ceil: { $divide: [{$subtract: ["$milestone.endDate", "$milestone.startDate"]}, 86400000] }},
			remainingDay: {$ceil: { $divide: [{$subtract: ["$milestone.endDate", "$$NOW"]}, 86400000] }},

			fixedBudget: "$milestone.budget",

			_id: { $ifNull: ["$_id", ""] },
			name: { $ifNull: ["$milestone.name", ""] },
			startDate: "$milestone.startDate",
			endDate: "$milestone.endDate",
            number: "$milestone.number",

			// totalBudget: { $sum: "$budget"},
			// totalLedgerCost: { $sum: "$ledgerCost"},
			//
			// totalEstHour: { $sum: "$estHour"},
			// totalEstAmount: { $sum: "$estAmount"},
			//
			// totalLogHour: { $sum: "$logHour"},
			// totalLogAmount: { $sum: "$logAmount"},
			//
			// totalDiffHour: { $sum: "$diffHour"},
			// totalDiffAmount: { $sum: "$diffAmount"},
			//
			// totalPercentHour: { $avg: "$percentHour"},
			// totalPercentAmount: { $avg: "$percentAmount"},
		}},

		// { $sort: {
		// 	startDate: -1
		// }},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
            number: 1,
			startDate: 1,
			endDate: 1,
			duration: 1,
			remainingDay: 1,

			fixedBudget: 1,
			tasks: 1,

			totalBudget: 1,
			totalLedgerCost: 1,

			totalEstHour: 1,
			totalEstAmount: 1,

			totalLogHour: 1,
			totalLogAmount: 1,

			totalDiffHour: 1,
			totalDiffAmount: 1,

			totalPercentHour: 1,
			totalPercentAmount: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "costs"]}
	]],

	//`A.printObject:`,
	//`A.responseObject: 200: {"costs": "@dbData"}`
], {useZip: true}]);


CostRoute.POST.push([["/by/team/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body;

        const projectId = Req.project._id; // body.projectId || body.projectIds;
		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

		var milestoneIds = (body.milestone || body.milestones) ||
						   (body.milestoneId || body.milestoneIds);
		//let name = (body.name || body.content) || (body.text || body.search);

		var teamIds = (body.team || body.teams) ||
					  (body.teamId || body.teamIds);

		var memberIds = (body.users || body.userIds) ||
						(body.members || body.memberIds) ||
						(body.creatorId || body.userId);

		var user = Req.user;
		var hasAdmin = user.hasAdmin || user.hasAgent;

		body.keepMilestone = true;
		body.keepTeam = true;
		body.keepMember = true;

		var ops = {};
		// if(!hasAdmin) { //} && (!roleProject || !(roleProject.setting||{}).view)) {
		// 	memberIds = [user._id];
		// }

		if(projectId) {
			ops["projectId"] = projectId;
		}

        if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds]
			}
			if(memberIds.length > 0) {
            	ops.creatorId = { $in: memberIds };
				body.keepMember = false;
			}
        }

		body.teamIds = [];
		if(teamIds) {
			if(!Array.isArray(teamIds)) {
				teamIds = [teamIds]
			}
			if(teamIds.length > 0) {
            	body.teamIds = teamIds;
				body.keepTeam = false;
			}
        }

        if(fromDate && toDate) {
			fromDate = new Date(fromDate);
			toDate = new Date(toDate);

            ops["$and"] = [
				{ fromTime: {"$gte": fromDate} },
				{ fromTime: {"$lte": toDate} }
			];
        }
		body.duration = (toDate - fromDate) / 3600000;
		body.workingHour = await pipeData.U.Date.calendarWorkingDay(Req, pipeData, fromDate, toDate) * 8;

		body.milestoneIds = [];
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				body.milestoneIds = milestoneIds;
				body.keepMilestone = false;
			}
		}

		body.projectBudget = Req.project.budget || 0;
		body.projectId = projectId;
		body.ops = ops;
		//console.log(ops);

		return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
    [`A.aggregateOne: logtime`, [
		{ $match: "@ops" },

		// Filter by milestone
		{ $populateFilter: ["task", [
			{ $let: { taskId: "$taskId" }},
			{ $expr: { $and : [
				{ $eq: ["$$taskId", "$_id"] },
				{ $or: [
					{ $in: ["@milestoneIds", [false, null, undefined, []]] },
					{ $in: ["$milestoneId", "@milestoneIds"] },
				]}
			]}}
		], "task", false, 1, "_id", "milestoneId"]},

		// Group all unamed milestone
		{ $populateFilter: ["milestone", "task.milestoneId:_id", "milestone", "@keepMilestone", 1, "_id", "name", "name2", "avt", "number", "startDate", "endDate", "budget", "userIds"]},
		{ $addFields: {
			milestone: {
				_id: { $ifNull: ["$milestone._id", ""]},
				name: { $ifNull: ["$milestone.name", ""]},
				avt: { $ifNull: ["$milestone.avt", 0]},
                number: { $ifNull: ["$milestone.number", 0]},
				userIds: { $ifNull: ["$milestone.budget", []]},
				budget: { $ifNull: ["$milestone.budget", 0]},
				startDate: "$milestone.startDate",
				endDate: "$milestone.endDate",
			}
		}},

		// Group all unamed team
		{ $populateFilter: ["team", [
			{ $let: { userId: "$creatorId" }},
			{ $expr: { $and : [
				{ $in: ["$$userId", "$members"] },
				{ $eq: ["$projectId", "@projectId"] },
				{ $or: [
					{ $in: ["@teamIds", [false, null, undefined, []]] },
					{ $in: ["$_id", "@teamIds"] },
				]}
			]}}
		], "team", "@keepTeam", 1, "_id", "name", "avt"]},
		{ $addFields: {
			team: {
				_id: { $ifNull: ["$team._id", ""]},
				name: { $ifNull: ["$team.name", ""]},
				avt: { $ifNull: ["$team.avt", 0]},
			}
		}},

		// Group all unamed user
		{ $populateFilter: ["user", [
			{ $let: { userId: "$creatorId" }},
			{ $expr: { $and : [
				{ $eq: ["$$userId", "$_id"] },
			]}},
		], "user", "@keepMember", 1, "_id", "name", "userId", "avt"]},
		// Get hourly salary
		{ $populate: ["hrcontract", "user._id", "userId", "hrcontract", false] },
		{ $addFields: {
			"user.hourlySalary": "$hrcontract.overview.hourlySalary",
		}},
		{ $addFields: {
			logAmount: { $multiply: ["$user.hourlySalary", "$hour"]},
			user: {
				_id: { $ifNull: ["$user._id", ""]},
				name: { $ifNull: ["$user.name", ""]},
				avt: { $ifNull: ["$user.avt", 0]},
				userId: { $ifNull: ["$user.userId", 0]},
				hourlySalary: { $ifNull: ["$user.hourlySalary", 0]},
			}
		}},

		// Group by User
		{ $group: {
			_id: {
				user: "$user._id",
				milestone: "$milestone._id",
				team: "$team._id"
			},
			logHour: { $sum: "$hour" },
			logAmount: { $sum: "$logAmount" },
			user: { $first: "$user" },
			team: { $first: "$team" },
			task: { $first: "$task" },
			milestone: { $first: "$milestone" },
		}},
		// { $addFields: {
		// 	estAmount: { $multiply: [ "$user.hourlySalary", "@workingHour" ]},
		// }},
		{ $project: {
			_id: 0
		}},
		{ $sort: {
			logHour: -1,
		}},

		// Group by Team
		{ $group: {
			_id: {
				team: "$team._id",
				milestone: "$milestone._id",
			},
			userCosts: { $push: {
				logHour: "$logHour",
				logAmount: "$logAmount",
				//estAmount: "$estAmount",
				user: "$user",
			}},
			logHour: { $sum: "$logHour" },
			logAmount: { $sum: "$logAmount" },
			//estAmount: { $sum: "$estAmount" },
			team: { $first: "$team" },
			milestone: { $first: "$milestone" },
		}},
		{ $project: {
			_id: 0,
		}},
		{ $sort: {
			"team.name$": 1
		}},

		// Group by Milestone
		{ $group: {
			_id: "$milestone._id",
			teamCosts: { $push: {
				logHour: "$logHour",
				logAmount: "$logAmount",
				//estAmount: "$estAmount",
				userCosts: "$userCosts",
				team: "$team",
			}},
			logHour: { $sum: "$logHour" },
			logAmount: { $sum: "$logAmount" },
			//estAmount: { $sum: "$estAmount" },
			milestone: { $first: "$milestone" },
			budget: { $first: "$milestone.budget" },
		}},
		{ $project: {
			_id: 0,
			"milestone.budget": 0
		}},
		{ $sort: {
			"milestone.startDate": -1
		}},

		// Group by summary
		{ $group: {
			_id: null,
			summaryCosts: { $push: {
				budget: "$budget",
				logHour: "$logHour",
				logAmount: "$logAmount",
				//estAmount: "$estAmount",
				milestone: "$milestone",
				teamCosts: "$teamCosts"
			}},
			logHour: { $sum: "$logHour" },
			logAmount: { $sum: "$logAmount" },
			//estAmount: { $sum: "$estAmount" },
			budget: { $sum: "$budget" },
		}},
		{ $addFields: {
			projectBudget: "@projectBudget",
			duration: "@duration",
			workingHour: "@workingHour"
		}},
		{ $project: {
			_id: 0,
		}}
	]],

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var project = Req.project || {};
		var DateUtil = pipeData.U.Date;

		var data = Req.body;
		data.estAmount = 0;
		data.estHour = 0;
		data.calendarWorkingHour = 0;
		data.summaryCosts = data.summaryCosts || [];

		for (var i = 0; i < data.summaryCosts.length; i++) {
			var msItem = data.summaryCosts[i];

			var milestone = msItem.milestone || {};
			if(!milestone.userDate) {
				milestone.userDate = {};
				var users = milestone.users || milestone.userIds || [];
				for (var m = 0; m < users.length; m++) {
					var u = users[m];
					milestone.userDate[u._id+""] = u;
				}
			}

			var msd = Math.max(milestone.startDate, project.startDate);
			var med = Math.min(milestone.endDate, project.dueDate);

			var msWorkingHour = await DateUtil.calendarWorkingDay(Req, pipeData, msd, med) * 8;
			msItem.calendarWorkingHour = msWorkingHour;
			data.calendarWorkingHour += msWorkingHour;

			msItem.estAmount = 0;
			msItem.estHour = 0;
			msItem.teamCosts = msItem.teamCosts || [];

			for (var j = 0; j < msItem.teamCosts.length; j++) {
				var teamItem = msItem.teamCosts[j];

				teamItem.estAmount = 0;
				teamItem.estHour = 0;
				teamItem.userCosts = teamItem.userCosts || [];

				for (var k = 0; k < teamItem.userCosts.length; k++) {
					var msUser = teamItem.userCosts[k];

					var user = msUser.user || {};
					var k = user._id || "";
					var usd = Math.max(msd, (milestone.userDate[k]||{}).joinAt||0); // check user
					var ued = Math.min(med, (milestone.userDate[k]||{}).leftAt||99999999999999999); // check user

					var userSalary = user.hourlySalary || 0;
					var userEstHour = await DateUtil.calendarWorkingDay(Req, pipeData, usd, ued) * 8;
					var userEstAmount = userSalary * userEstHour;

					msUser.estAmount = userEstAmount; // count for this milestone
					msUser.estHour = userEstHour;

					msUser.diffAmount = (msUser.logAmount||0) - (userEstAmount||0);
					msUser.diffPercentAmount = parseInt(msUser.diffAmount / (userEstAmount||1) * 100);

					msUser.diffHour = (msUser.logHour||0) - (userEstHour||0);
					msUser.diffPercentHour = parseInt(msUser.diffHour / (userEstHour||1) * 100);

					teamItem.estAmount += userEstAmount;
					teamItem.estHour += userEstHour;

					delete user.hourlySalary;
					delete user.monthlySalary;
				}

				msItem.estAmount += teamItem.estAmount;
				msItem.estHour += teamItem.estHour;

				teamItem.diffAmount = (teamItem.logAmount||0) - (teamItem.estAmount||0);
				teamItem.diffPercentAmount = parseInt(teamItem.diffAmount / (teamItem.estAmount||1) * 100);

				teamItem.diffHour = (teamItem.logHour||0) - (teamItem.estHour||0);
				teamItem.diffPercentHour = parseInt(teamItem.diffHour / (teamItem.estHour||1) * 100);
			}

			data.estAmount += msItem.estAmount;
			data.estHour += msItem.estHour;

			msItem.diffAmount = (msItem.logAmount||0) - (msItem.estAmount||0);
			msItem.diffPercentAmount = parseInt(msItem.diffAmount / (msItem.estAmount||1) * 100);

			msItem.diffHour = (msItem.logHour||0) - (msItem.estHour||0);
			msItem.diffPercentHour = parseInt(msItem.diffHour / (msItem.estHour||1) * 100);

			delete milestone.users;
			delete milestone.userIds;
			delete milestone.userDate;
		}

		data.diffAmount = (data.logAmount||0) - (data.estAmount||0);
		data.diffPercentAmount = parseInt(data.diffAmount / (data.estAmount||1) * 100);

		data.diffHour = (data.logHour||0) - (data.estHour||0);
		data.diffPercentHour = parseInt(data.diffHour / (data.estHour||1) * 100);

		return data;
	}]
], {useZip: true}]);


// ---------------------- Cost by sumary
CostRoute.POST.push([["/summary"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,


    `A.trimObject`,
    [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var DateUtil = pipeData.U.Date;

		var body = Req.body || {};
		var project = Req.project || {};

		const name = body.name || (body.search || body.text);

		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

		var scale = body.scale || "day";
		body.scale = scale;

		// Should Calculate by Day then group by JS
		// if(scale == "week") {
		// 	body.scaleGroup = { $concat: [
		// 		{ $toString: {$year: "$dateLocal"}},
		// 		{ $cond: [{$lte: [{$week: "$dateLocal"}, 9]}, "-0", "-"] },
		// 		{ $toString: {$week: "$dateLocal"}}
		// 	]};
		//
		// } else if(scale == "month") {
		// 	body.scaleGroup = { $concat: [
		// 		{ $toString: {$year: "$dateLocal"}},
		// 		{ $cond: [{$lte: [{$month: "$dateLocal"}, 9]}, "-0", "-"] },
		// 		{ $toString: {$month: "$dateLocal"}}
		// 	]};
		//
		// } else { // Default is day
			body.scaleGroup = { $concat: [
				{ $toString: {$year: "$dateLocal"}},
				{ $cond: [{$lte: [{$month: "$dateLocal"}, 9]}, "-0", "-"] },
				{ $toString: {$month: "$dateLocal"}},
				{ $cond: [{$lte: [{$dayOfMonth: "$dateLocal"}, 9]}, "-0", "-"] },
				{ $toString: {$dayOfMonth: "$dateLocal"}}
			]};
		//}

		var milestoneId = (body.milestone || body.milestones) ||
						  (body.milestoneId || body.milestoneIds);

		body.projectId = project._id;
		fromDate = new Date(Math.max(new Date(fromDate || "1880-01-01"), project.startDate));
		toDate = new Date(Math.min(new Date(toDate || "2100-12-31"), project.dueDate||project.endDate));

		var cpnTimePoint = (DateUtil.companyTimePoint(Req, pipeData) || {});
		body.cpnTimePoint = cpnTimePoint;

		body.wd = cpnTimePoint.wd;
		body.workingDay = await DateUtil.calendarWorkingDay(Req, pipeData, fromDate, toDate);
		body.fromDate = fromDate;
		body.toDate = toDate;

		body.milestoneIds = [];
		body.milestoneIds = [];
		if(milestoneId) {
			if(!Array.isArray(milestoneId)) {
				milestoneId = [milestoneId];
			}

			if(milestoneId.length > 0) {
				body.milestoneIds = milestoneId;
			}
		}

		body.projectBudget = project.budget || 0;

		//console.log("pipeData: ", body);
        return Req.UNRESULT;
    }],

	[`A.aggregateOne > data::`, [
		// Milestone Salary => Need JS next step
		{ $lookup: {
			from: "milestone",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"]},
					{ $or: [
						{ $in: ["$_id", "@milestoneIds"]},
						{ $in: ["@milestoneIds", ["", undefined, null, 0, [] ]]},
					]},
					{ $and: [
						{ $lte: ["$startDate", "@toDate"] },
						{ $gte: ["$endDate", "@fromDate"] },
					]}
				]}}},
				{ $addFields: {
					members: { $ifNull: ["$members", [] ]},
					budget: { $ifNull: ["$budget", 0 ]}
				}},

				{ $loopArray: ["members", false, "members", [
					{ $let: {
						milestoneStart: "$startDate",
						milestoneEnd: "$dueDate",
					}},

					{ $addFields: {
						"joinAt": {$ifNull: ["$joinAt", "$$milestoneStart"] },
						"leftAt": {$ifNull: ["$leftAt", "$$milestoneEnd"] }
					}},
					{ $addFields: {
						"joinAt": {$max: ["$joinAt", "@fromDate"] },
						"leftAt": {$min: ["$leftAt", "@toDate"] }
					}},

					//Filter out of range
					{ $match: { $expr: { $and: [
						// Filter limit
						{ $lte: ["$joinAt", "@toDate"] },
						{ $gte: ["$leftAt", "@fromDate"] },
					]}}},

					{ $populateFilter: ["hrcontract", "user:userId", "hrcontract", true, 1, "overview.hourlySalary", "overview.monthlySalary"]},
					{ $addFields: {
						hourlySalary: "$hrcontract.overview.hourlySalary",
						monthlySalary: "$hrcontract.overview.monthlySalary",
					}},

					{ $project: {
						user: 1,
						joinAt: 1,
						leftAt: 1,
						hourlySalary: 1,
						monthlySalary: 1,
					}},
				]]},

				{ $sort: {
					number: 1,
					name: 1,
				}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					budget: 1,
					members: 1,
				}}
			],
			as: "milestoneSalaries"
		}},

		// Project Salary => Need JS to calculate next step
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: { _id: "@projectId" }},
				{ $project: { members: 1, startDate: 1, dueDate: 1, budget: 1}},
				{ $project: { _id: 0 }},
			],
			as: "project"
		}},
		{ $unwind: {
			path: "$project",
			preserveNullAndEmptyArrays: true
		}},

		{ $loopArray: ["project.members", false, "projectSalaries", [
			{ $let: {
				projectStart: "$project.startDate",
				projectEnd: "$project.dueDate",
			}},

			{ $addFields: {
				joinAt: { $ifNull: ["$joinAt", "$$projectStart"]},
				leftAt: { $ifNull: ["$leftAt", "$$projectEnd"]},
			}},

			// Get the date Range inside scope date filter
			{ $addFields: {
				joinAt: { $max: ["$joinAt", "@fromDate"]},
				leftAt: { $min: ["$leftAt", "@toDate"]},
			}},

			//Filter out of range
			{ $match: { $expr: { $and: [
				// Filter limit
				{ $lte: ["$joinAt", "@toDate"] },
				{ $gte: ["$leftAt", "@fromDate"] },
			]}}},

			// Add Salary
			{ $populateFilter: ["hrcontract", "user:userId", "hrcontract", true, 1, "overview.hourlySalary", "overview.monthlySalary"]},
			{ $addFields: {
				hourlySalary: "$hrcontract.overview.hourlySalary",
				monthlySalary: "$hrcontract.overview.monthlySalary",
			}},
			{ $project: {
				user: 1,
				joinAt: 1,
				leftAt: 1,
				hourlySalary: 1,
				monthlySalary: 1,
			}}
		]]},

		// Graph Project Salary
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: { _id: "@projectId" }},
				{ $project: { members: 1, startDate: 1, dueDate: 1}},
				{ $project: { _id: 0 }},

				{ $addFields: {
					members: { $ifNull: ["$members", [] ]},
				}},

				{ $loopArray: ["members", false, "members", [
					{ $let: {
						projectStart: "$startDate",
						projectEnd: "$dueDate",
					}},

					{ $addFields: {
						"joinAt": {$ifNull: ["$joinAt", "$$projectStart"] },
						"leftAt": {$ifNull: ["$leftAt", "$$projectEnd"] }
					}},
					{ $addFields: {
						"joinAt": {$max: ["$joinAt", "@fromDate"] },
						"leftAt": {$min: ["$leftAt", "@toDate"] }
					}},

					//Filter out of range
					{ $match: { $expr: { $and: [
						// Filter limit
						{ $lte: ["$joinAt", "@toDate"] },
						{ $gte: ["$leftAt", "@fromDate"] },
					]}}},

					{ $populateFilter: ["hrcontract", "user:userId", "hrcontract", true, 1, "overview.hourlySalary", "overview.monthlySalary"]},
					{ $addFields: {
						hourlySalary: "$hrcontract.overview.hourlySalary",
						monthlySalary: "$hrcontract.overview.monthlySalary",
					}},

					// --------------- Clone multiple item ---------------
					{ $convertDate: ["joinAt -> joinAtLocal", "leftAt -> leftAtLocal"]},
					{ $addFields: {
						numDay: { $ceil: { $divide: [{ $subtract: [{$add: ["$leftAtLocal", 1000]}, "$joinAtLocal"] }, 86400000]}}
					}},
					{ $addFields: {
						startRange: { $range: [
							0,
							"$numDay",
							1,
						]},
					}},
					{ $addFields: {
						startRange: { $slice: ["$startRange", "$numDay"]},
						numDay: "$numDay"
					}},
					{ $unwind: {
						path: "$startRange",
						preserveNullAndEmptyArrays: true,
					}},
					{ $addFields: {
						dateLocal: { $add: [
							"$joinAtLocal", {$multiply: ["$startRange", 86400000]}
						]},
					}},

					//Filter out of range
					{ $match: { $expr: { $and: [
						{ $gte: ["$dateLocal", "$joinAtLocal" ]},
						{ $lte: ["$dateLocal", "$leftAtLocal" ]},
					]}}},

					{ $addFields: {
						hour: "@wd",
						dayString: "@scaleGroup",
						sm: { $multiply: ["@wd", "$hourlySalary"]},
					}},

					{ $sort: {
						dayString: 1
					}},

					{ $group: {
						_id: "$dayString",
						sm: { $sum: "$sm" },
						// members: { $push: {
						// 	user: "$user",
						// 	// joinAt: "$joinAt",
						// 	// leftAt: "$leftAt",
						// 	us: "$hourlySalary",
						// 	ms: "$monthlySalary",
						// }}
					}},

					{ $project: {
						_id: 1,
						sm: 1, // Salary amount
						//members: 1,
					}},
				]]},
			],
			as: "graphSalaries"
		}},
		{ $unwind: {
			path: "$graphSalaries",
			preserveNullAndEmptyArrays: true,
		}},
		{ $addFields: {
			graphSalaries: "$graphSalaries.members"
		}},


		// Graph Log time for project and milestone
		{ $lookup: {
			from: "logtime",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $gte: ["$fromTime", "@fromDate"] },
					{ $lte: ["$fromTime", "@toDate"] },
				]}}},

				{ $populateFilter: ["taskId", "taskId:_id", "task", true, 1, "_id", "milestoneId"]},
				{ $convertDate: ["fromDate -> dateLocal"]},
				{ $addFields: {
					dayString: "@scaleGroup",
					milestoneId: { $ifNull: ["$task.milestoneId", 0] },
				}},
				{ $sort: {
					dayString: 1
				}},
				// group by date, then group by milestone
				{ $group: {
					_id: "$dayString",
					lt: { $sum: "$amount" }, // Logtime amount
				}},
			],
			as: "graphLogtimes"
		}},

		// Milestone Log time for project and milestone
		{ $lookup: {
			from: "logtime",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $gte: ["$fromTime", "@fromDate"] },
					{ $lte: ["$fromTime", "@toDate"] },
				]}}},

				{ $populateFilter: ["taskId", "taskId:_id", "task", true, 1, "_id", "milestoneId"]},
				// group by date, then group by milestone
				{ $group: {
					_id: "$task.milestoneId",
					logtimeAmount: { $sum: "$amount" }
				}},
			],
			as: "milestoneLogtimes"
		}},

		// Graph Ledger cost
		{ $lookup: {
			from: "cost",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $gte: ["$date", "@fromDate"] },
					{ $lte: ["$date", "@toDate"] },
				]}}},

				{ $populateFilter: ["taskId", "taskId:_id", "task", true, 1, "_id", "milestoneId"]},
				{ $convertDate: ["date -> dateLocal"]},
				{ $addFields: {
					dayString: "@scaleGroup",
					milestoneId: { $ifNull: ["$task.milestoneId", 0] },
				}},
				{ $sort: {
					dayString: 1
				}},
				// group by date, then group by milestone
				{ $group: {
					_id: "$dayString",
					lg: { $sum: "$amount" }, // Ledger Amount
				}},
			],
			as: "graphLedgers"
		}},

		// Milestone Ledger cost
		{ $lookup: {
			from: "cost",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $gte: ["$date", "@fromDate"] },
					{ $lte: ["$date", "@toDate"] },
				]}}},

				{ $populateFilter: ["taskId", "taskId:_id", "task", true, 1, "_id", "milestoneId"]},
				// group by date, then group by milestone
				{ $group: {
					_id: "$task.milestoneId",
					ledgerAmount: { $sum: "$amount" }
				}},
			],
			as: "milestoneLedgers"
		}},

		// Formation data
		{ $addFields: {
			milestoneLogtimes: { $ifNull: ["$milestoneLogtimes", [] ]},
			graphLogtimes: { $ifNull: ["$graphLogtimes", [] ]},
			milestoneLedgers: { $ifNull: ["$milestoneLedgers", [] ]},
			graphLedgers: { $ifNull: ["$graphLedgers", [] ]}
		}},

		{ $addFields: {
			projectBudget: { $ifNull: ["$project.budget", "@projectBudget"] },
			projectLogAmount: { $sum: "$milestoneLogtimes.logtimeAmount" },
			projectLedgerAmount: { $sum: "$milestoneLedgers.ledgerAmount" },
		}},

		{ $project: {
			projectBudget: 1,

			projectLedgerAmount: 1,
			projectLogAmount: 1,

			milestones: 1,
			projectSalaries: 1,

			milestoneSalaries: 1,
			milestoneLogtimes: 1,
			milestoneLedgers: 1,


			// For graph
			graphSalaries: 1,
			graphLogtimes: 1,
			graphLedgers: 1,
		}}
	]],

	//`A.printObject: @data.`,

	// Salary of Partime, Intern type of user ???
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var DateUtil = pipeData.U.Date;

		var body = Req.body || {};
		var data = body.data || {};

		var project = {};

		var scale = body.scale || "day";
		var budget = data.projectBudget || 1;
		var workingDay = body.workingDay || 1;

		// User salary
		var userSalary = {};
		data.projectSalaries.map(i => {
			userSalary[i.user] = i;
		});

		/*
			Project:
				[x] Budget
				[ ] Total Salary
				[x] Total Logtime
				[x] Total Ledger
				[x] Revenue by logtime+ledger
				[x] Revenue by salary+ledger

			Milestone
				[x] Budget
				[x] Total Salary
				[x] Total Logtime
				[x] Total Ledger
				[x] total by Milestone
				[x] Revenue by logtime+ledger
				[x] Revenue by salary+ledger

		*/

		// ======================== For Project Data =========================
		// Calculate Project Salary Amount
		var projectSalaryAmount = 0;
		(data.projectSalaries||[]).map(async (obj) => {
			var hour = await DateUtil.calendarWorkingDay(Req, pipeData, obj.joinAt, obj.leftAt) * 8;
			var amount = hour * obj.hourlySalary;
			projectSalaryAmount += amount;
		});

		// Calculate
		project.budget = data.projectBudget;
		project.workingDay = body.workingDay;

		project.logtime = {
			amount: data.projectLogAmount,
			percent: ((data.projectLogAmount / budget) * 100).toFixed(0)-0,
		};

		project.ledger = {
			amount: data.projectLedgerAmount,
			percent: ((data.projectLedgerAmount / budget) * 100).toFixed(0)-0,
		};

		project.salary = {
			amount: projectSalaryAmount,
			percent: ((projectSalaryAmount / budget) * 100).toFixed(0)-0,
		};

		project.revenue = {
			logtime: {
				amount: (project.budget - project.logtime.amount - project.ledger.amount),
				percent: ((1 - (project.logtime.amount + project.ledger.amount) / budget) * 100).toFixed(0)-0,
			},
			salary: {
				amount: (project.budget - project.salary.amount - project.ledger.amount),
				percent: ((1 - (project.salary.amount + project.ledger.amount) / budget) * 100).toFixed(0)-0,
			}
		};


		// ======================== For Milestone Data =========================
		// Milestone Ledger
		var milestoneLedger = {};
		(data.milestoneLedgers||[]).map(item => {
			milestoneLedger[(item._id||0).toString()] = item;
		});

		// Milestone Logtime
		var milestoneLogtime = {};
		(data.milestoneLogtimes||[]).map(item => {
			milestoneLogtime[(item._id||0).toString()] = item;
		});

		//console.log("ARR: ", data.milestoneSalaries);
		(data.milestoneSalaries||[]).map(async (ms) => {
			var budgetMs = ms.budget || 1;

			var msAmount = 0;
			(ms.members||[]).map(async (obj) => {
				var hour = await DateUtil.calendarWorkingDay(Req, pipeData, obj.joinAt, obj.leftAt) * 8;
				var amount = hour * obj.hourlySalary;
				msAmount += amount;
			});

			delete ms.members; // Remove unused data

			msAmount = msAmount || 1;
			var msId = (ms._id || ms.milestoneId || 0).toString();

			var ledger = milestoneLedger[msId] || {};
			ms.ledger = {
				amount: ledger.ledgerAmount || 0,
				percent: (((ledger.ledgerAmount || 0) / budgetMs) * 100).toFixed(0)-0,
			};

			var logtime = milestoneLogtime[msId] || {};
			ms.logtime = {
				amount: logtime.logtimeAmount || 0,
				percent: (((logtime.logtimeAmount || 0) / budgetMs) * 100).toFixed(0)-0,
			};

			ms.salary = {
				amount: msAmount,
				percent: ((msAmount / budgetMs) * 100).toFixed(0)-0,
			};

			ms.revenue = {
				logtime: {
					amount: (ms.budget - ms.logtime.amount - ms.ledger.amount),
					percent: ((1 - (ms.logtime.amount + ms.ledger.amount) / budgetMs) * 100).toFixed(0)-0,
				},
				salary: {
					amount: (ms.budget - ms.salary.amount - ms.ledger.amount),
					percent: ((1 - (ms.salary.amount + ms.ledger.amount) / budgetMs) * 100).toFixed(0)-0,
				}
			};
		});

		// ======================== For Graph Data =========================
		var graph = {};

		// Salary
		//console.log("Graph Salary: ", JSON.stringify(data.graphSalaries));
		(data.graphSalaries||[]).map(s => {
			if(!s) return;

			var id = s._id || 0;
			var obj = graph[id];
			if(!obj) {
				obj = { _id: id };
				graph[id] = obj;
			}
			obj.sm = (s.sm||0) - 0;
		});

		// Logtime
		// /console.log("Graph Logtime: ", JSON.stringify(data.graphLogtimes));
		(data.graphLogtimes||[]).map(s => {
			if(!s) return;

			var id = s._id || 0;
			var obj = graph[id];
			if(!obj) {
				obj = { _id: id };
				graph[id] = obj;
			}
			obj.lt = (s.lt||0) - 0;
		});

		// Ledger
		//console.log("Graph Ledger: ", JSON.stringify(data.graphLedgers));
		(data.graphLedgers||[]).map(s => {
			if(!s) return;

			var id = s._id || 0;
			var obj = graph[id];
			if(!obj) {
				obj = { _id: id };
				graph[id] = obj;
			}
			obj.lg = (s.lg||0) - 0;
		});

		// Check for Header and Trailing data incase of missing data


		// Refactor Data
		//console.log("Graph: ", graph);
		var dayBudget = ((data.projectBudget||0) / workingDay).toFixed(1)-0;

		var allValues = Object.values(graph) || [];
		allValues.sort((a, b) => {
			return (a._id < b._id) ? -1 : 1;
		});

		var objGroup = {};
		//console.log("Graph Sort: ", allValues);
		var dates = [];

		var budgets = [];
		var salaries = [];
		var logtimes = [];
		var ledgers = [];
		var revenueSalaries = [];
		var revenueLogtimes = [];

		function getDayBudget(dd) {
			var rs = DateUtil.isPolicyDay(Req, pipeData, false, dd, true);
			return rs ? 0 : dayBudget;
		}

		function pushData(key, db, sm, lt, lg, rs, rl) {
			//console.log("Push: ", key, db, sm, lt, lg, rs, rl);
			dates.push(key);
			budgets.push((db||0).toFixed(1)-0);

			salaries.push((sm||0).toFixed(1)-0);
			logtimes.push((lt||0).toFixed(1)-0);
			ledgers.push((lg||0).toFixed(1)-0);

			revenueSalaries.push((rs||0).toFixed(1)-0);
			revenueLogtimes.push((rl||0).toFixed(1)-0);
		}

		function pushCollectedData(dd, key, db, sm, lt, lg, rs, rl) {
			if(scale == "day") {
				pushData(key, db, sm, lt, lg, rs, rl);

			} else {
				if(scale == "month") {
					key = `${dd.getFullYear()}-${("0"+(dd.getMonth()+1)).substr(-2)}`;

				} else if(scale == "week") {
					var weekObj = A.getWeekNumber(Req, pipeData, dd);
					key = `${weekObj.year}-${("0"+weekObj.week).substr(-2)}`;
				}

				var obj = objGroup[key];
				if(!obj) {
					//console.log("New Item Week/Month: ", weekObj, key);
					obj = { _id:key, db:0, sm:0, lt:0, lg:0, rs:0, rl:0 };
					objGroup[key] = obj;
				}

				obj.db += ((db||0)-0);
				obj.sm += ((sm||0)-0);

				obj.lt += ((lt||0)-0);
				obj.lg += ((lg||0)-0);
				obj.rs += ((rs||0)-0);
				obj.rl += ((rl||0)-0);
			}
		}

		var lastDate = 0;
		lastDate = new Date(lastDate);
		for (var i = 0; i < allValues.length; i++) {
			var obj = allValues[i];

			var d = obj._id;
			if(!d || (d-0) <= 1) continue;

			//console.log("DD: ", d, lastDate);
			var date = new Date(d);
			if((i > 0) && (lastDate > 1)) {
				var delta = parseInt((date - lastDate) / 86400000);
				if(delta > 1.5) {
					// Fill empty Day
					//console.log("Fill Empty Days: ", delta, i, " :: ", obj._id, " :: ", lastDate);
					for(var k=1; k<delta; k++) {

						var dd = new Date(lastDate.getTime() + (k*86400000));
						var kk = `${dd.getFullYear()}-${("0"+dd.getMonth()).substr(-2)}-${("0"+dd.getDate()).substr(-2)}`;

						pushCollectedData(dd,  kk, getDayBudget(dd),  0, 0, 0,  0, 0);
					}
				}
			}

			// Push data to array of graph
			pushCollectedData(
				date,
				obj._id, dayBudget,
				obj.sm||0, obj.lt||0, obj.lg||0,
				(dayBudget - (obj.sm||0) - (obj.lg||0)),
				(dayBudget - (obj.lt||0) - (obj.lg||0))
			);

			// Save for last
			lastDate = date;
		}

		//console.log("OO: ", scale, dates, objGroup);

		// For case group by week or month
		if(scale != "day") {
			scale = "day";
			//console.log("Graph: ", graph);
			var allGroupedValues = Object.values(objGroup) || [];
			allGroupedValues.sort((a, b) => {
				return (a._id < b._id) ? -1 : 1;
			});

			for (var i = 0; i < allGroupedValues.length; i++) {
				var obj = allGroupedValues[i];
				pushData(obj._id, obj.db, obj.sm, obj.lt, obj.lg, obj.rs, obj.rl);
			}
		}

		var milestones = data.milestoneSalaries || [];
        return { project, milestones, graph: { dates, budgets, salaries, logtimes, ledgers, revenueSalaries, revenueLogtimes } };
    }],

	//`A.responseObject: 200: {"costs": "@dbData"}`
], {useZip: true}]);


// ------------------- Cost adjust for some kind Milestone, Project
CostRoute.POST.push([["/adjust/project"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,
	`A.verifyKObject:: budget!: verify.numberType`,

	`A.updateById(*): project: {_id: "@P.project._id"}: {budget: "@P.body.budget"}`,
	`A.responseObject: 200: Update successfully!`,
]]);

CostRoute.POST.push([["/adjust/milestone"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,
	`A.verifyKObject:: milestoneId!: verify.idType:
					   budget!: verify.numberType`,

	`A.updateById(*): milestone: {_id: "@P.body.milestoneId", projectId: "@P.project._id"}: {budget: "@P.body.budget"}`,
	`A.responseObject: 200: Update successfully!`,
]]);

/*
CostRoute.POST.push([["/adjust/milestone/member"], [
	`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,
	`A.verifyInput:: milestone: _id, members`,
	`A.updateById(*): milestone: {_id: "@P.body._id", projectId: "@P.project._id"}: {members: "@P.body.members"}`,
]]);
*/

module.exports = CostRoute;
