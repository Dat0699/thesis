const PipeDeleteRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	PIPE	: [],

	config	: {
	}
};

PipeDeleteRoute.PIPE.push([["deleteTask"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "ksat" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteTask" } ]);

// PipeDeleteRoute.PIPE.push([["deleteWiki"], [
//
// ]]);

PipeDeleteRoute.PIPE.push([["deleteMilestone"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "enotselim" }:
		{ "user-token": "@(P.header['user-token'])" }: `
], { name: "deleteMilestone" } ]);

PipeDeleteRoute.PIPE.push([["deleteChangeLog"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "golegnahc" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteChangeLog" } ]);

PipeDeleteRoute.PIPE.push([["deleteCost"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "tsoc" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteCost" } ]);

PipeDeleteRoute.PIPE.push([["deleteLeaving"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "gnivael" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteLeaving" } ]);

PipeDeleteRoute.PIPE.push([["deleteMeeting"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "gniteem" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteMeeting" } ]);

PipeDeleteRoute.PIPE.push([["deleteOvertime"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "emitrevo" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteOvertime" } ]);

PipeDeleteRoute.PIPE.push([["deleteAnnouncement"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "tnemecnuonna" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteAnnouncement" } ]);

PipeDeleteRoute.PIPE.push([["deletePenalty"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "ytlanep" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deletePenalty" } ]);

PipeDeleteRoute.PIPE.push([["deleteReportBug"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "gubtroper" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteReportBug" } ]);

PipeDeleteRoute.PIPE.push([["deleteUser"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "resu" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteUser" } ]);

PipeDeleteRoute.PIPE.push([["deleteTeam"], [
	`A.sendData(*) > tmp: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "maet" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteTeam" } ]);

PipeDeleteRoute.PIPE.push([["deleteDepartment"], [
	`A.sendData(*) > pipeDeteleData: PURGE: @(K.API.SvrIntFile + '/s1n9l3'):
		{ refId: "@P.route._id", refModel: "tnemtraped" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteDepartment" } ]);


// -------------------------------- Delete Project ---------------------------
PipeDeleteRoute.PIPE.push([["deleteProject"], [
	`A.sendData(*) > pipeDeteleData: UNLINK: @(K.API.SvrIntFile + '/pr0j3ct'):
		{ refId: "@P.route._id", refModel: "jectpro" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteProject" } ]);

// CHeck delete Docuemnt?
PipeDeleteRoute.PIPE.push([["deleteProjectResource"], [
	`A.deleteById(*): task: 		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): wiki: 		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): milestone:	{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): roledocument: { projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): source:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): review:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): pullrequest:	{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): testcase:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): testflow:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): testresult:	{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): postapi:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): postflow:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): postenv:		{ projectId: "@P.route._id" }: true: true`,
	//`A.deleteById(*): postapifolder: { projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): logtime:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): changelog:	{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): performance:	{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): penalty:		{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): cost:			{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): risk:			{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): mission:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): activity:		{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): label:		{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): group:		{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): team:			{ projectId: "@P.route._id" }: true: true`,

	`A.deleteById(*): taskcomment:	{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): wikicomment:	{ projectId: "@P.route._id" }: true: true`,
	`A.deleteById(*): riskcomment:	{ projectId: "@P.route._id" }: true: true`,
	//`A.deleteById(*): changelogcomment:	{ projectId: "@P.route._id" }: true: true`,

	// @Delete Comment Docuemnt ???
	// @Delete Source Code ???

	`A.sendData(*) > pipeDeteleData: UNLINK: @(K.API.SvrIntFile + '/pr0j3ct'):
		{ refId: "@P.route._id", refModel: "jectpro" }:
		{ "user-token": "@(P.header['user-token'])" }`,

	`A.sendData(*) > pipeDeteleData: UNLINK: @(K.API.SvrIntDocument + '/pr0j3ct'):
		{ refId: "@P.route._id", refModel: "jectpro" }:
		{ "user-token": "@(P.header['user-token'])" }`,

	`A.sendData(*) > pipeDeteleData: UNLINK: @(K.API.SvrIntSource + '/pr0j3ct'):
		{ refId: "@P.route._id", refModel: "jectpro" }:
		{ "user-token": "@(P.header['user-token'])" }`

], { name: "deleteProjectResource" } ]);


// -------------------------------- Delete Company ---------------------------
PipeDeleteRoute.PIPE.push([["deleteCompany"], [
	`A.sendData(*) > pipeDeteleData: UNLINK: @(K.API.SvrIntFile + '/c0mp4nq'):
		{ refId: "@P.route._id", refModel: "panymoc" }:
		{ "user-token": "@(P.header['user-token'])" }`
], { name: "deleteCompany" } ]);

module.exports = PipeDeleteRoute;
