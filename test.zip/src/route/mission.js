const MissionRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.dashboard",
		checkMIFs		: ["project", "dashboard"],
		imProject		: true,
	}
};

/* TODO: body truyen lên làm cách nào để verify ids đó */
MissionRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view, dashboard.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mission: projectId!, content!, date!, weekYear!`,
	// `A.assertObject::: (
	// 	startDate < endDate
	// ):({
	// 	"respCode": 400, "respData": "To Time invalid", "respReturn": true
	// })`,

	`A.findById(*) > P.missionDto: mission: { projectId: "@P.body.projectId", weekYear: "@P.body.weekYear" }`,
	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		if(Req.missionDto) {
			return {
				respCode: 500,
				respData: "Misison existed!",
				respReturn: true
			}
		}

		return UNRESULT;
	}],

	`A.insertById(*): mission: @P.body`,

	`A.pipeRoute: mission: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`,
]]);

MissionRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view, dashboard.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mission: content, date, weekYear`,
	// `A.assertObject::: (
	// 	startDate < endDate
	// ):({
	// 	"respCode": 400, "respData": "To Time invalid", "respReturn": true
	// })`,

	`A.updateById(*): mission: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: mission: { type: "update" }`,
	`A.responseObject(*): 200: Update misison successfully!`,
]]);

MissionRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view, dashboard.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.deleteOne(*): mission: { "_id": "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: mission: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);


MissionRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findById(*): mission: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	//`A.printObject`,
	//`A.responseObject: 200: @dbData[0]`
]]);

MissionRoute.POST.push([["s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var matchOps = {};

		var content = (pipeData.content || pipeData.title) || (pipeData.search || pipeData.text);
		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;
		var projectIds = pipeData.projectId || pipeData.projectIds;

        if(content) {
            matchOps.content = Req.func.getASCIISearch(content, "gmi");
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				matchOps.projectId = { $in: projectIds };
			}
		}

        if(fromDate && toDate) {
			matchOps["$and"] =  [
				{ date: {"$gte" : new Date(fromDate) }},
				{ date: {"$lte" : new Date(toDate) }},
			];
        }

        pipeData.matchOps = matchOps;
		//console.log("pipeData: ", pipeData);
        return Req.UNRESULT;
    }],

	[`A.aggregate: mission`, [
		{ $match: "@matchOps" },

		{ $sort: {
			date: -1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			content: 1,
			date: 1,
			weekYear: 1,
			modifiedAt: 1,
		}},
	]],
], { useZip: true }]);

module.exports = MissionRoute;
