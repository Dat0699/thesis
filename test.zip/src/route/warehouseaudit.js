const WarehouseAuditRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkMIFs		: ["warehouse"],
		roleUserIdKey	: "userId"
    }
};

WarehouseAuditRoute.POST.push([[""], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, auditors"}`,

	`A.copyKObject(*):: P.query.warehouseId: P.body.warehouseId`,
	`A.copyKObject(*):: P.user._id: P.body.auditorId`,

    `A.verifyInput:: warehouseaudit: name!, warehouseId!, ...`,

    `A.insertOne: warehouseaudit`,
    `A.refactorOutput:: _id, number, name, name2, descr, status, code, color, type`,
]]);

WarehouseAuditRoute.GET.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	`A.verifyKObject(*):: P.route._id!: verify.idNumberType`,

	[`A.aggregateOne(*): warehouseaudit:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$_id", "@P.route._id"]},
			{ $eq: ["$number", "@P.route._id"]},
			{ $eq: ["$code", "@P.route._id"]},
		]}}},

		// { $project: {
		// 	_id: 1,
		//
		// }}
	]],
]]);

// User for list warehouseaudit picker
WarehouseAuditRoute.POST.push([["/s"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	//`A.verifyKObject(*):: P.query.warehouseId!: verify.idType`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	[`A.aggregate: warehouseaudit:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			type: 1,
			code: 1,
			color: 1,
			name: 1,
			name2: 1,
			descr: 1,
			auditedAt: 1,
			status: 1,
		}},
	]],
]]);

// Used for full warehouseaudit list store, not liust product
WarehouseAuditRoute.POST.push([["full/s"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	//`A.verifyKObject(*):: P.query.warehouseId!: verify.idType`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg },
			]});
        }

		var types = (body.type || body.types) || (body.typeId || body.typeIds);
		if(types) {
			if(!Array.isArray(types)) {
				types = [types];
			}

			if(types.length > 0) {
				ops.push({type: { $in: types }});
			}
		}

		var status = (body.status || body.statuses) || (body.statusId || body.statusIds);
		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				ops.push({status: { $in: status }});
			}
		}

		var userIds = (body.user || body.userId) || (body.users || body.userIds);
		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				ops.push( {auditorId: { $in: userIds }} );
			}
		}

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne: warehouseaudit:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $getTotalLength: ["@page", "totalLength"]},
		{ $populateFilter: ["user", "auditorId:_id", "auditor", true, 1, "_id", "name", "name2", "userId", "avt"]},
		// { $addFields: {
		// 	totalAmount: { $sum: },
		// }},

		{ $populate: ["warehouseitem", "allItems", "_id", "allItems"]},
		{ $populate: ["warehouseitem", "auditItems", "_id", "auditItems"]},
		{ $populate: ["warehouseitem", "missedItems", "_id", "missedItems"]},

		{ $addFields: {
			totalAmount: { $sum: "$allItems.importPrice" },
			totalAuditAmount: { $sum: "$auditItems.importPrice" },
			totalMissedAmount: { $sum: "$missedItems.importPrice" },

			totalItem: { $size: "$allItems" },
			totalAuditItem: { $size: "$auditItems" },
			totalMissedItem: { $size: "$missedItems" },
		}},

		{ $project: {
			_id: 1,
			number: 1,
			type: 1,
			code: 1,
			color: 1,
			name: 1,
			name2: 1,
			descr: 1,

			totalItem: 1,
			totalAuditItem: 1,
			totalMissedItem: 1,

			auditedAt: 1,
			auditor: 1,

			status: 1,

			totalAmount: 1,
			totalAuditAmount: 1,
			totalMissedAmount: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "audits"]},
	]],
]]);

WarehouseAuditRoute.PUT.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, importers"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idNumberType`,

	`A.verifyInput:: warehouseaudit: creatorId-, createdAt-, number-, warehouseId-, ...`,

    `A.updateById(*): warehouseaudit: { _id: "@P.route._id" }: @P.body`,
    `A.refactorOutput:: _id, number, name, name2, descr, status, code, color, type`,
]]);

WarehouseAuditRoute.DELETE.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.delete`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

    `A.deleteById(*): warehouseaudit: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete warehouseaudit successfully!`
]]);

module.exports = WarehouseAuditRoute;
