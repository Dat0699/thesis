const LoginRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
    PIPE    : [],

    config: {
        // unIPAccess	: true,
		unAuth				: true,
		imCompany			: true,
        imCache		        : true,
        // unParseBody	: false, // true: to let controller parse the body.
        // unStatistic	: false, // true: to avoid statistic API.
        // imChat		: false, // true: to import notifyFarmServer(),
        imCodec		        : true, // To import createPassword, comparePassword
        // checkMIFs	        : [],
		imMail		        : true,
        imPush		        : true,
        IgnoreModifiedAt    : true,
        imBase		        : true,

		permitAgent			: true,
    }
};

LoginRoute.POST.push([["signup"], [
	//`A.decodeOTPData`,
	`A.pipeRoute: checkOTPResource`,
	`A.pipeRoute: signupNewAccount`,
], { otpMode: "data" }]);

LoginRoute.PIPE.push([["signupNewAccount"], [
	//`A.printObject:`,
    `A.verifyInput(data):: register: email!, password!, phone!, name!, shortName!, ...`,
    //`A.findOne > userDb: Main.usercompany: email`,
	[`A.aggregateOne > userDb: Main.usercompany`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$email", "@email"] },
			//{ $in: ["$status", [1] ]},
			{ $not: [{$in: ["$hasActived", [false]] }] }
		]}}}
	]],

    //`A.findOne > companyDb: main.company: shortName`,
    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		const A = pipeData.A;
		const body = Req.body;
        const userDb = body.userDb;

        if(userDb && userDb._id) {
			// In case an user being exist and not company attached as Agent owner, permit to create new company
			//var rs = await A.findById(Req, pipeData, "Main.company", {agentId: userDb._id});
			//if(rs) {
		 		return {
					respData: "User has existed!",
					respReturn: true,
					respCode : 500
				};
			//}
        }

		pipeData.D.IgnoreSanitized = true;
		var companyDb = await A.findOne(Req, pipeData, "Main.company", {
			shortName: { $regex : new RegExp(`^${body.shortName}$`, "i") }
		});

        if(companyDb) {
			return {
				respData: "Company has existed!",
				respReturn: true,
				respCode : 500
			};
        }

		body.code = A.hashOTP(Req, pipeData);
		body.otp = `otp_^_${body.shortName}_^_${body.code}`;

		var data = {
			name		: body.name,
			name2		: body.name2,
			email   	: body.email,
	    	password	: body.password,
			shortName	: body.shortName,
	    };

		body.data = data;

		delete body.userDb;
        delete body.companyDb;

		return Req.UNRESULT;
	}],

	//`A.printObject`,
    `A.setKValue: @otp: @data: 900: true`, // token exists 15 minutes
    `A.mixObject(*)::({
        "to" 		: "@Req.body.data.email",
		"subject" 	: "[GitGam] Activate your account",
		"view" 		: "verifyCode",
        "data" 		: "@Req.body"
    })`,

    `A.sendMail(*): @P.body`,
    `A.responseObject: 200: Sign up successfully!`

], { name: "signupNewAccount" }]);

// Signup -> Verify to active company, active user
LoginRoute.POST.push([["verify"], [
	//`A.decodeOTPString`,

	//`A.printObject`,
    `A.getKValue: @otp: true: true`, // Read and clear (last true param, param 3 (from 1))
	//`A.printObject`,

    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		//console.log("Body: ", body);
        if(!body || (!body.shortName || !body.email) || (!body.password || !body.name)) {
            return {
				respData: "OTP Invalid!",
				respReturn: true,
				respCode: 503
			};
        }

		var A = pipeData.A;
		var Mongo = pipeData.K.Mongo;
		var companyModel = Mongo.CompanyModel || "Main.company";
		//var company = await A.findById(Req, pipeData, companyModel, {shortName: body.shortName});
		pipeData.D.IgnoreSanitized = true;
		var company = await A.findOne(Req, pipeData, "Main.company", {
			shortName: { $regex : new RegExp(`^${body.shortName}$`, "i") }
		});
		if(company) {
			return {
				respData: "Company was existed!",
				respReturn: true,
				respCode: 503
			};
		}

		var email = body.email;
		var userCompanyModel = Mongo.UserCompanyModel || "Main.usercompany";
		var userCompany = await A.findById(Req, pipeData, userCompanyModel, { email });
		if(userCompany && (userCompany.hasActived !== false)) {
			// User Exist but check it own any company?
			//console.log("User company: ", userCompany);
			//var owningCompany = await A.findById(Req, pipeData, companyModel, {agentId: userCompany._id});
			//if(owningCompany) {
				return {
					respData: "User was existed!",
					respReturn: true,
					respCode: 503
				};
			//}

			// Task care, it can be a stoolen case account!
			// Update status of user if it locked or unactive
			// await A.updateById(Req, pipeData, userCompanyModel, {_id: userCompany._id}, {
			// 	password	: body.password,
			// 	status		: 1,
			// });

		} else {
			// Create User
			// Not owning company, and not existing User -> Create new user
			// Currently fond and create new user if not exist
			// !!!!! ================== Secure that this api create override being existed user, bug ===============!!!!!

			// Delete All account trash
			await A.deleteById(Req, pipeData, userCompanyModel, {email, hasActived: false, status: 0}, true, true);
			userCompany = await A.insertById(Req, pipeData, userCompanyModel, {
				email   	: body.email,
		    	password	: body.password,
				hasActived	: true,
				status		: 1,
		    });
		}

		if(!userCompany) {
			return {
				respData: "Internal Error!",
				respReturn: true,
				respCode: 503
			};
		}

		// Create Company
		company = await A.insertById(Req, pipeData, companyModel, {
			name		: body.name,
			name2		: body.name2,
			email   	: body.email,
			agentId		: userCompany._id,
			shortName	: body.shortName,
			members		: [],
			status		: 1,
	    });

		if(!company) {
			return {
				respData: "Internal Problem!",
				respReturn: true,
				respCode: 503
			};
		}

		body.company = company;
		body.userCompany = userCompany;

		//console.log("ABC: ", pipeData);
		Req.body = body;
        return Req.UNRESULT;
    }],

    // `A.findById > userCompanyDb: Main.usercompany: ({"_id": "@user"})`,
    // `A.findById > companyDb: Main.company: shortName`,
    // `A.updateOne > abc: Main.usercompany: {"_id": "@userCompanyDb._id"}: {
    //     "status" : 1
    // }`,

    `A.refreshDB: @company`,
    `A.insertOne > user: user: {
        "hasAgent"  : true,
		"hasAdmin"	: true,
		"name"		: "Agent",
        "userId"    : "@userCompany._id",
        "email"     : "@userCompany.email",
		"hasActived": true,
        "status"    : 1,
    }`,

    `A.findOne > xyz: Payment.payment : {"companyId": "@company._id"} : {"companyId": "@company._id"}`,
    `A.pipeRoute: roleAdmin`,
    // `A.updateOne > abc: main.company: {"_id" : "@company._id"}: {
    //     "status" : 1,
    //     "members" : [{
	// 		"userId" : "@user._id",
    //         "roleId" : "@rolecompany._id"
	// 	}]
	//  }`,
    `A.pipeRoute: group`,
    `A.pipeRoute: label`,
	`A.pipeRoute: seniority`,
	`A.pipeRoute: department`,
	`A.pipeRoute: createProject`,

	// Get Role and Insert User Role into Company
	`A.updateById(*) > tmp: main.company: {_id: "@P.company._id" }:
		{ members: [{userId: "@P.company.agentId", roleId: "@P.body.rolecompany._id", hasActived: true }] }`,

    `A.responseObject: 200: Verify successfully!`
], { otpMode: "string" }]);

// signin -> OK Login | -> signincompany
LoginRoute.POST.push([["signin"], [
	//`A.decodeOTPData`,
	`A.pipeRoute: signinAccount`,
], { otpMode: "data" }]);


LoginRoute.PIPE.push([["signinAccount"], [
	//`A.printObject`,
    `A.verifyInput:: register: email!, password!, ssoService`,

	//`A.printObject`,
    //`A.findOne > userCompany: Main.usercompany: email`,
	[`A.aggregateOne > userCompany: Main.usercompany`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$email", "@email"] },
			{ $in: ["$status", [1] ] },
			{ $not: [{$in: ["$hasActived", [false]] }] },
			{ $or: [
				// It pass ssoService, check correct sso account
				{ $in: ["@ssoService", [undefined, "", null, [], false]] },
				{ $in: ["@ssoService", "$ssoService"] },
			]}
		]}}}
	]],

	//`A.printObject: userCompany`,
	//`A.printObject: password`,
	//`A.printObject:`,

    // `<SkipPass>A.checkPassword: @password: @userCompany.password`,

    [`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var A = pipeData.A;

		if(!(Req.skipCheckPassword == true) && !(Req.skipCheckingPassword == true)) {
			var rs = false;
			if(body.password) {
				rs = await A.checkPassword(Req, pipeData, body.password, body.userCompany.password);
			}

			if(rs != Req.UNRESULT) {
				// return {
				// 	respData: "Incorrect information!",
				// 	respReturn: true,
				// 	respCode: 503
				// };
				// this function 'A.checkPassword' returned data -> so dont nedd to return second.
				// Req.respReturn = true; // stop the pipeline flow
				return;
			}
		}

		var userCompany = body.userCompany;
        if(!userCompany || !userCompany._id) {
            return {
				respData: "Email address was not exist!",
				respReturn: true,
				respCode: 503
			};
        }

        if(userCompany.status != 1) {
            return {
				respData: "Email has not been activated or Account has been block!",
				respReturn: true,
				respCode: 503
			};
        }

        return Req.UNRESULT;
    }],

	[`A.aggregate > dbCompany: Main.company`, [
		{ $match: { $or: [
			{ agentId: "@userCompany._id" },
			{ $and: [
				{ members: { $elemMatch: {
					userId: "@userCompany._id",
					hasLocked: { $nin: [true] },
					hasDeleted: { $nin: [true] },
					hasActived: { $nin: [false] },
				}}},
				{ status: 1 }
			]}
		]}},
		// { $addFields: {
		// 	members: { $filter: {
		// 		input: "$members",
		// 		as: "member",
		// 		cond: { $eq: ["$$member.userId", "@userCompany._id"]}}
		// 	}}
		// }},
		{ $project: {
			_id: 1,
			//agentId: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			feature: 1,
			featurePackage: 1,
			status: 1,
			members: 1,
			config: 1,
			hasAgent: { $cond: [{$eq: ["$agentId", "@userCompany._id"]}, true, false]},
		}},

		// { $$unwind: {
		// 	path: "$members",
		// 	preserveNullAndEmptyArrays: false
		// }},
		// { $lookup: {
		// 	from: "user",
		//
		// }}
	]],

    //`A.findMany > companyDB: main.company: ({$or : [{"agentId" : "@usercompany._id"}, {"members.userId" : "@usercompany._id"}]})`,
    //`A.populate: user, company.members.userId, _id, company.members.users, +, userId, avt, name`,
    //`A.refactorOutput(companyDB) > companyDB:: _id+, agentId+, name+, shortName+, avt+, members-`,

	//`A.generateUniqueID > tmpToken: @user._id`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		var userCompany = body.userCompany || {};

		var dbCompany = body.dbCompany || [];
		if((dbCompany === undefined) || (dbCompany === null)) {
			return {
				respCode: 500,
				respData: "Sign in failed!",
				respReturn: true,
			}
		}

		var length = (dbCompany || []).length;
		if((length > 1) || (length <= 0)) {
			// This case more company
			var func = Req.func;
			var token = func.generateUniqueID(64, userCompany._id);
			await func.setKValue(token, userCompany._id, 900);
			//var rs = await func.getKValue(token, false, false);
			//console.log("RS: ", rs);

			// add exchange token
			token = pipeData.A.exchangeToken(Req, body, token, userCompany._id.toString());

			dbCompany.map(company => {
				delete company.feature;
				delete company.featurePackage;
				delete company.members;
				delete company.config;
			});

			return {
				respCode: 200,
				respReturn: true,
				respData: {
					shouldCreateCompany: true,
					companies: dbCompany,
					user: {
						_id: userCompany._id,
						name: userCompany.name,
						name2: userCompany.name2,
						email: userCompany.email,
						status: userCompany.status,
					},
					token: token
				}
			}
		}

		// This case ony one company
		var company = dbCompany[0];
		Req.company = company;
		Req.body = { company, userCompany: body.userCompany };

		return Req.UNRESULT;
	}],

    //`A.setKValue: @token: @user._id: 900`, // token exists 15 minutes
    // `A.jsScript::(
    //     if(pipeData.companyDB.length > 1) {
    //         return {"respData": { companies:  pipeData.companyDB, token : pipeData.token }, "respReturn": true }
    //     }
    //     return pipeData;
    // )`,
    // `A.findOne > company: company: {"_id" : "@companyDB[0]._id"}`,

    `A.refreshDB: @company`,
    //`A.findOne > user: user: email`,
	[`A.aggregateOne > user: user`, [
		{ $match: {
			userId: "@userCompany._id",
		}},
		{ $limit: 1 },
		{ $project: {
			_id: 1,
			email: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			hasAgent: 1,
			hasAdmin: 1,
			hasSupport: 1,
			hasUpdated: 1,
			userId: 1,
			status: 1,
			show2N: 1,
		}}
	]],

	//`A.printObject:`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var UtilFn = pipeData.U.Func;

		var body = Req.body;
		var user = Req.body.user || {};
		var company = Req.company || {};

		var hasAgent = user.hasAgent && (company.hasAgent || ((user.userId||"-^-").toString() == (company.agentId||"").toString()));
		if(!user || (!hasAgent && (user.status != 1))) {
			return {
				respReturn: true,
				respData: "User was locked!",
				respCode: 500
			}
		}

		Req.user = user;
		var userCompany = body.userCompany || Req.usercompany || {};

		// syncUser date from userCompanyModel -> userModel
		await UtilFn.syncUser(Req, pipeData, A, userCompany, user);

		user.name = userCompany.name || user.name;
		user.name2 = userCompany.name2 || user.name2;
		user.hasAgent = hasAgent;
		user.hasAdmin = user.hasAdmin || hasAgent;
		company.hasAgent = hasAgent;

		body.user = user;
		user.loginEmail = userCompany.email || user.email;

		var func = Req.func;
		var token = func.generateUniqueID(64, company._id);

		// Device Login Add
		var rs = await A.addDeviceLogin(Req, pipeData, token);
		if(!rs) return undefined;

		// add exchange token
		await func.setKValue(token, user._id, 52704000);
		token = A.exchangeToken(Req, pipeData, token, user._id.toString());

		// Disable feature
        var feature = UtilFn.featureConfig({
            ...(company.feature||{}),
			...(company.featurePackage||{}),
            ...(pipeData.K.API.FeatureConfig||{})
        });

		var roleModel = pipeData.K.Mongo.RoleCompanyModel || "rolecompany";
		var companyRole = A.getRoleId(Req, pipeData, Req.company, user.userId);
		if(!companyRole) {
			if(!user.hasAdmin) {
				return {
					respReturn: true,
					respData: "User was locked!",
					respCode: 500
				}
			}
			companyRole = {};

		} else {
			companyRole = await A.getDBCachedObject(Req, pipeData, roleModel, companyRole);
			companyRole = (companyRole||{}).permit || {};
		}

		delete company.members;
		company = { ...(company||{}), feature };
		delete company.__memberIds;

		var cf = company.config;
		company.config = {
			currency			: cf.currency,
			currencyDecimal		: cf.currencyDecimal,
			formatFullDay		: cf.formatFullDay,
			formatShortDay		: cf.formatShortDay,
			maxDocSize			: cf.maxDocSize,

			moringStartTime		: cf.moringStartTime,
			moringEndTime		: cf.moringEndTime,
			afternoonStartTime	: cf.afternoonStartTime,
			afternoonEndTime	: cf.afternoonEndTime,
			nightStartTime		: cf.nightStartTime,
			nightEndTime		: cf.nightEndTime,
		};

		return {
			respReturn: true,
			respCode: 200,
			respData: { user, company, companyRole, token }
		};
	}],

	//`A.printObject:`,
    // `A.generateUniqueID > token: 64: @company._id`,
    // `A.setKValue: @token: @user._id: 52704000`, // token exists 61 days
	//
    // // `A.populate: user, company.members.userId, _id, company.members.users, +, userId, avt, name`,
    // // `A.refactorOutput:: token, company._id, company.name, company.shortName, company.email, compnay.agentId, compnay.phone, compnay.fax, compnay.address, compnay.country, compnay.feature, company.members.users, company.createdAt, compnay.modifiedAt, user._id, user.name, user.name2, user.hasAgent, user.phone, user.userId, user.email, user.staffCode, user.userId, user.shortName, user.avt. company.avt`
	//
	// `A.responseObject: 200: {
	// 	user: "@user",
	// 	company: "@company",
	// 	token: "@token"
	// }`
], { name: "signinAccount" }]);

LoginRoute.POST.push([["listcompany"], [
	//`A.decodeOTPData`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var companyId = (Req.body||{}).companyId;
		if(Req.company._id.toString() != companyId) {
			return {
				respCode: 200,
				respReturn: true,
				respData: [],
			};
		}

		return Req.UNRESULT;
	}],

	[`A.aggregate(*) > dbCompany: Main.company`, [
		{ $match: { $or: [
			{ agentId: "@P.user.userId" },
			{ $and: [
				{ members: { $elemMatch: {
					userId: "@P.user.userId",
					hasLocked: { $nin: [true] },
					hasDeleted: { $nin: [true] },
					hasActived: { $nin: [false] },
				}}},
				{ status: 1 }
			]}
			//{ "members.userId": "@P.user.userId" },
		]}},
		// { $addFields: {
		// 	members: { $filter: {
		// 		input: "$members",
		// 		as: "member",
		// 		cond: { $eq: ["$$member.userId", "@userCompany._id"]}}
		// 	}}
		// }},
		{ $project: {
			_id: 1,
			agentId: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			//avatarURL: { $concat: [{$toString: "$_id"}, "/", {$ifNull: ["$avt", ""]}] },
			//feature: 1,
			status: 1,
			hasAgent: { $cond: [{$eq: ["$agentId", "@P.user.userId"]}, true, false]},
		}},

		// { $$unwind: {
		// 	path: "$members",
		// 	preserveNullAndEmptyArrays: false
		// }},
		// { $lookup: {
		// 	from: "user",
		//
		// }}
	]],

	`A.pipeRoute: adjustListCompany`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var data = ((Req.body||{}).dbCompany) || [];
		var uid = Req.user.userId.toString();

		var comId = Req.company._id.toString();
		data.map(com => {
			if(com._id == comId) {
				com.hasLogin = true;
			}
			com.hasAgent = (uid == com.agentId.toString());
			delete com.agentId;
		});

		return {
			respCode: 200,
			respData: data,
			respReturn: true,
		}
	}]

], { unAuth: false, ignoreCheckLock: true, otpMode: "data" }]);

// Used for switch company inside company
LoginRoute.POST.push([["selectcompany"], [
	//`A.decodeOTPData`,

	[`A.aggregateOne(*) > company: Main.company`, [
		{ $match: { $and: [
			{ _id: "@P.body.companyId" },
			{ $or: [
				{ agentId: "@P.user.userId" },
				{ $and: [
					{ members: { $elemMatch: {
						userId: "@P.user.userId",
						hasLocked: { $nin: [true] },
						hasDeleted: { $nin: [true] },
						hasActived: { $nin: [false] },
					}}},
					{ status: 1 }
				]}
			]}
		]}},

		{ $populateFilter: ["usercompany", [
			{ $expr: { $and : [
				{ $eq: ["$_id", "@P.user.userId"] },
			]}}
		], "loginUser", false, 1, "name", "avt", "email", "status"]},
	]],

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var UtilFn = pipeData.U.Func;

		var func = Req.func;
		var user = Req.user || {};
		Req.user = user;
		var companyUserId = (user||{}).userId;

		var company = Req.body.company || {};
		var userCompany = company.loginUser || {};
		delete company.loginUser;

		if((!userCompany || !userCompany._id) || (userCompany.status != 1)) {
			return {
				respReturn: true,
				respCode: 500,
				respData: "User was locked!"
			}
		}

		var hasAgent = (company.agentId||"-^-").toString() == (companyUserId||"").toString();
		if((!company || !company._id) || (!hasAgent && company.status != 1)) {
			return {
				respReturn: true,
				respCode: 500,
				respData: "Company was locked!"
			}
		}

		// backup old company data
		var oldToken = Req.header["user-token"];

		// Signout old company
		await A.setKValue(Req, pipeData, oldToken, user._id, 0);
		await A.removeDeviceLogin(Req, pipeData, oldToken);

		// Swicth to new company
		Req.company = company;
		await A.refreshDB(Req, pipeData, company);
		var token = func.generateUniqueID(64, company._id);

		// add exchange token, get user in this company store in toke redis
		var userModel = pipeData.K.Mongo.UserModel;
		var newUser = await A.findById(Req, pipeData, userModel, {userId: companyUserId});

		//console.log("New user: ", newUser, user, userModel, Req.ctxDB, company._id, companyUserId);
		if(!newUser) {
			// Wrong acces
			return {
				respReturn: true,
				respCode: 500,
				respData: "Invalid action!"
			};
		}

		//console.log("company._id: ", company._id);
		// Device Login Add
		Req.user = newUser;
		var rs = await A.addDeviceLogin(Req, pipeData, token);
		if(!rs) return undefined;

		var newUserId = newUser._id.toString();
		await func.setKValue(token, newUserId, 52704000);
		token = A.exchangeToken(Req, pipeData, token, newUserId);


		var cf = company.config || {};
		var hasAgent = (company.agentId||"-^-").toString() == (newUser.userId||"").toString();
		var hasAdmin = hasAgent || newUser.hasAdmin;

		// syncUser date from userCompanyModel -> userModel
		await UtilFn.syncUser(Req, pipeData, A, userCompany, newUser);

		// Get Role company
		var roleModel = pipeData.K.Mongo.RoleCompanyModel || "rolecompany";
		var companyRole = A.getRoleId(Req, pipeData, Req.company, companyUserId);
		if(!companyRole) {
			if(!hasAdmin) {
				return {
					respReturn: true,
					respData: "User was locked!",
					respCode: 500
				}
			}
			companyRole = {};

		} else {
			companyRole = await A.getDBCachedObject(Req, pipeData, roleModel, companyRole);
			companyRole = (companyRole||{}).permit || {};
		}

		// Disable feature
		company = {
			_id			: company._id,
			agentId		: company.agentId,
			name		: company.name,
			name2		: company.name2,
			shortName	: company.shortName,
			avt			: company.avt,
			status		: company.status,
			feature		: UtilFn.featureConfig({
				...(company.feature||{}),
				...(company.featurePackage||{}),
	            ...(pipeData.K.API.FeatureConfig||{})
			}),
			config		:  {
				currency			: cf.currency,
				currencyDecimal		: cf.currencyDecimal,
				formatFullDay		: cf.formatFullDay,
				formatShortDay		: cf.formatShortDay,
				maxDocSize			: cf.maxDocSize,

				moringStartTime		: cf.moringStartTime,
				moringEndTime		: cf.moringEndTime,
				afternoonStartTime	: cf.afternoonStartTime,
				afternoonEndTime	: cf.afternoonEndTime,
				nightStartTime		: cf.nightStartTime,
				nightEndTime		: cf.nightEndTime,
			},
		};

		user = {
			_id			: newUser._id,
			email		: newUser.email,
			name		: newUser.name,
			name2		: newUser.name2,
			shortName	: newUser.shortName,
			avt			: newUser.avt,
			hasAgent	: hasAgent,
			hasAdmin	: hasAdmin,
			hasSupport	: newUser.hasSupport,
			hasUpdated	: newUser.hasUpdated,
			userId		: newUser.userId,
			status		: newUser.status,
			show2N		: newUser.show2N,
		};

		return {
			respReturn: true,
			respCode: 200,
			respData: { user, company, companyRole, token }
		}
    }],

], { unAuth: false, ignoreCheckLock: true, otpMode: "data", F1: { IgnoreSanitized: true } }]);


// Use for login screen
LoginRoute.POST.push([["signincompany"], [
	//`A.decodeOTPData`,

    `A.verifyInput:: Main.usercompany: companyId!`,
    //`A.copyKObject(*):: P.header.user-token, P.body.token`,
    //`A.getKValue(*) > userCompanyId: @P.header["user-token"]`,

    [`A.jsScript`, async (Req, pipeData, ctx) => {
		var token = Req.header["user-token"];

        //console.log("pipeData: ", pipeData);
		//console.log("userToken: ", token);

		var userCompanyId = await Req.func.getKValue(token, false, false);

		//console.log("userCompanyId: ", userCompanyId);
        if(!userCompanyId) {
            return {
				respCode: 500,
				respData: "Signin company failed!",
				respReturn: true
			};
        }

		pipeData.userCompanyId = userCompanyId;
        return Req.UNRESULT;
    }],

	//`A.findById > company: company: ({"_id" : "@companyId"})`,
	[`A.aggregateOne > dbCompany: Main.company`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$_id", "@companyId"] },
			{ $or: [
				{ $in: ["$status", [1]] },
				{ $eq: ["$agentId", "@userCompanyId"] }
			]}
		]}}},
		{ $match: { $or: [
			{ agentId: "@userCompanyId" },
			{ members: { $elemMatch: {
				userId: "@userCompanyId",
				hasLocked: { $nin: [true] },
				hasDeleted: { $nin: [true] },
				hasActived: { $nin: [false] },
			}}}
		]}},

		{ $populateFilter: ["usercompany", [
			{ $expr: { $and : [
				{ $eq: ["$_id", "@userCompanyId"] },
			]}}
		], "loginUser", false, 1, "name", "avt", "email", "status"]},

		{ $project: {
			_id: 1,
			agentId: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			userId: 1,
			feature: 1,
			featurePackage: 1,
			status: 1,
			members: 1,
			config: 1,
			loginUser: 1,
		}},
	]],

    `A.refreshDB: @dbCompany`,
	[`A.aggregateOne > dbUser: user:`, [
		{ $match: {
			userId: "@userCompanyId",
		}},
		{ $limit: 1 },
		{ $project: {
			_id: 1,
			email: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			avt: 1,
			hasAgent: 1,
			hasAdmin: 1,
			hasSupport: 1,
			hasUpdated: 1,
			userId: 1,
			status: 1,
			show2N: 1,
		}}
	]],

    // `A.modifyObject(*):: (
	// 	P.company = P.body.dbCompany,
	// 	P.user = P.body.user,
	// 	P.rsData.conpany = P.company,
	// 	P.rsData.user = P.user,
	// )`,
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var UtilFn = pipeData.U.Func;

		var user = Req.body.dbUser || {};
		Req.user = user;

		var company = Req.body.dbCompany || {};
		var hasAgent = (company.agentId||"-^-").toString() == (user.userId||"").toString();

		//console.log("Company: ", company);
		if((!company || !company._id) || (!hasAgent && company.status != 1)) {
			return {
				respReturn: true,
				respCode: 500,
				respData: "Company was locked!"
			}
		}

		//console.log("Company: ", user);
		var userCompany = company.loginUser || {};
		if( (!user || (!user.hasAgent && user.status != 1) || user.hasDeleted) ||
			(!userCompany || (userCompany.status != 1) ) ) {
			return {
				respReturn: true,
				respCode: 500,
				respData: "User was locked!"
			}
		}

		// syncUser date from userCompanyModel -> userModel
		await UtilFn.syncUser(Req, pipeData, A, userCompany, user);

		var func = Req.func;
		var token = func.generateUniqueID(64, company._id);

		// Device Login Add
		var rs = await A.addDeviceLogin(Req, pipeData, token);
		if(!rs) return undefined;

		// add exchange token
		await func.setKValue(token, user._id, 52704000);
		token = A.exchangeToken(Req, pipeData, token, user._id.toString());

		var hasAgent = user.hasAgent && ((user.userId||"-^-").toString() == (company.agentId||"").toString());
		user.hasAgent = hasAgent;
		user.hasAdmin = user.hasAdmin || hasAgent;
		user.loginEmail = userCompany.email || user.email;
		user.name = user.name || userCompany.name;
		user.name2 = user.name2 || userCompany.name2;
		company.hasAgent = hasAgent;

		// Disable feature
        var feature = UtilFn.featureConfig({
            ...(company.feature||{}),
			...(company.featurePackage||{}),
            ...(pipeData.K.API.FeatureConfig||{})
        });


		var roleModel = pipeData.K.Mongo.RoleCompanyModel || "rolecompany";
		var companyRole = A.getRoleId(Req, pipeData, Req.company, user.userId);
		if(!companyRole) {
			if(!user.hasAdmin) {
				return {
					respReturn: true,
					respData: "User was locked!",
					respCode: 500
				}
			}
			companyRole = {};

		} else {
			companyRole = await A.getDBCachedObject(Req, pipeData, roleModel, companyRole);
			companyRole = (companyRole||{}).permit || {};
		}

		delete company.members;

		company = { ...(company||{}), feature };
		delete company.__memberIds;
		delete company.loginUser;
		delete company.featurePackage;

		var cf = company.config;
		company.config = {
			currency			: cf.currency,
			currencyDecimal		: cf.currencyDecimal,
			formatFullDay		: cf.formatFullDay,
			formatShortDay		: cf.formatShortDay,
			maxDocSize			: cf.maxDocSize,

			moringStartTime		: cf.moringStartTime,
			moringEndTime		: cf.moringEndTime,
			afternoonStartTime	: cf.afternoonStartTime,
			afternoonEndTime	: cf.afternoonEndTime,
			nightStartTime		: cf.nightStartTime,
			nightEndTime		: cf.nightEndTime,
		};

		// Clear token
		var tokenHeader = Req.header["user-token"];
		await Req.func.getKValue(tokenHeader, false, true);

		return {
			respReturn: true,
			respCode: 200,
			respData: { user, company, companyRole, token }
		}
    }],

	// //`A.printObject`,
    // `A.generateUniqueID > rsData.token: 64: @companyId`,
    // `A.setKValue: @rsData.token: @user._id: 52704000`, // token exists 61 days
	// //`A.printObject`,
	//
    // //`A.populate: user, company.members.userId, _id, company.members.users, +, userId, avt, name`,
    // //`A.refactorOutput:: token, company._id, company.name, company.shortName, company.email, company.agentId, compnay.phone, compnay.fax, compnay.address, compnay.country, compnay.feature, company.members.users, compnay.createdAt, compnay.modifiedAt,user._id, user.name, user.name2, user.hasAgent, user.phone, user.userId,user.email, user.staffCode, user.shortName, user.avt`,
	// `A.responseObject: 200: @rsData`
], { otpMode: "data" }]);

LoginRoute.POST.push([["signout"], [
	`A.pipeRoute: signout`,
    `A.responseObject: 200: Signout successfully!`
], { unAuth: false }]);

LoginRoute.PIPE.push([["signout"], [
	// Delete token in Redis
	`A.setKValue(*): @P.header["user-token"]: @P.user._id: 0`,
	`A.removeDeviceLogin(*): @P.header["user-token"]`,

	// Delete all device related
	//`A.deleteById(*): device: {token: "@P.header['user-token']", user:"@P.user._id"}: true: true`,
], { name: "signout" }]);

// Inside company -> create new company from dropdown menu


LoginRoute.POST.push([["create/new/company"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var userId = Req.header["user-token"];

		if(userId) {
			userId = await Req.func.getKValue(userId, false, false);
		}

        if(!userId) {
            return {
				respCode: 500,
				respData: "User was not permitted!",
				respReturn: true
			};
        }

		userId = await pipeData.A.findById(Req, pipeData, "Main.usercompany", {_id: userId });
		if(!userId) {
            return {
				respCode: 500,
				respData: "User was not permitted!",
				respReturn: true
			};
        }

		Req.user = userId;

		//console.log("User: ", userId);
        return Req.UNRESULT;
    }],
	`A.pipeRoute: createnewcompany`
], { otpMode: "data" } ]);

LoginRoute.POST.push([["create/inside/company"], [
	`A.pipeRoute: checkRegCompany`,
	`A.pipeRoute: createnewcompany`
], { unAuth: false, otpMode: "data" } ]);

LoginRoute.PIPE.push([["createnewcompany"], [
	//`A.decodeOTPData`,
	`A.pipeRoute: checkOTPResource`,

	//`A.printObject`,
    `A.verifyInput > reqData:: company: shortName!, name!`,
    //`A.verifyInput > userdb:: user: password!, email!`,
    [`A.aggregate(*) > companies: Main.company:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$agentId", "@P.user.userId" ]},
			{ $eq: ["$members.userId", "@P.user.userId" ]}
		]}}}
	]],

    [`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var reqData = body.reqData;

		var companies = body.companies || [];
		var len = companies.length;
		if(len > 10) {
            return {
				respData: "Limitation for your account at 10 companies!",
				respReturn: true,
				respCode : 503
			};
        }

		pipeData.D.IgnoreSanitized = true;
		var rs = await pipeData.A.findOne(Req, pipeData, "Main.company", {
			shortName: { $regex : new RegExp(`^${reqData.shortName}$`, "i") }
		});

		if(rs) {
			return {
				respData: "Company was existed!",
				respReturn: true,
				respCode : 503
			};
		}

		var shortName = (reqData.shortName||"").toLowerCase();
		var user = Req.user;

		//console.log("::: ", shortName, user, len);
        if(!shortName || !user /* || (len <= 0)*/) {
            return {
				respData: "Invalid request!",
				respReturn: true,
				respCode : 503
			};
        }

		// Companies means only user owning company, not all company
		for (var i = 0; i < companies.length; i++) {
			var newShortName = ((companies[i]||{}).shortName||"").toLowerCase();
			if(!newShortName || (newShortName == shortName)) {
				return {
					respData: "Company was existed!",
					respReturn: true,
					respCode : 503
				};
			}
		}

		var userCompanyId = user.userId || user._id;
		var company = Req.company;
		// Cache this company
		body.company = {
			name		: reqData.name,
			name2		: reqData.name2,
			shortName	: reqData.shortName,
			email		: user.email,
			agentId		: userCompanyId,
			members		: [{ userId:userCompanyId, roleId:"5fae996830f9a845431ad9de" }],
			userName	: user.name || (Req.usercompany||{}).name || (Req.userCompany||{}).name,
			status		: 1
		};

		body.userId = userCompanyId;
		body.email = user.email;

        return Req.UNRESULT;
    }],

    // `A.insertOne > company: Main.company: ({
    //     name		: "@companydb.name",
	//     name2	: "@companydb.name2",
    //     shortName	: "@companydb.shortName",
	// 	email		: "@email",
    //     agentId		: "@userId",
	// 	members		: [{ userId: "@userId" }],
    // })`,

    //`A.refreshDB: @company`,
    // `A.uniquizedObject(company) > company._id: @_id`,
    // `A.modifyObject::
    //     user.userId = usercompany._id,
    //     user.companyId = company._id,
    //     user.name = usercompany.name,
	//     user.name2 = usercompany.name2,
    //     user.email = usercompany.email,
    //     user.phone = usercompany.phone,
    //     user.status = 0,
    //     user.hasAgent = true
    // `,

    // `A.insertOne(P.user) > userdb: user: {
	// 	userId: "@userId",
	// 	name: "@name",
	// 	email: "@email",
	// 	phone: "@phone",
	// 	status: 1,
	// 	hasAgent: true
	// }`,

    `A.generateUniqueID > token: 64: @userId`,
    //`A.setKValue: @token: {"userId":"@userId", "companyId":"@company._id", "userName":"@P.user.name"}: 900: true`,
	`A.setKValue: @token: @company: 900: true`,

	// Used for Test
	//`A.getKValue > P.reqData2: @token: true: false`,
	//`A.printObject(*): @P.reqData2`,

    `A.refactorOutput:: userdb, token, company`,

    `A.mixObject(*)::({
        "to" 		: "@Req.user.email",
		"subject" 	: "[GitGam] Created company",
		"view" 		: "createCompany",
		"data" 		: "@Req.body"
    })`,

    `A.sendMail(*): @P.body`,

    `A.responseObject: 200: Create company successfully!`
], { name: "createnewcompany" }]);

// Create new company inside company -> Confirm create new company
LoginRoute.POST.push([["confirmcompany"], [
	//`A.decodeOTPData`,

	`A.getKValue > P.reqData: @verifyToken: true: true`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var name = body.name;

		var reqData = Req.reqData;

		//console.log("verifyToken: ", body.verifyToken);
		//console.log("Req: ", Req);
		//console.log("db: ", reqData);

		if((!name || !body.verifyToken) || (!reqData || (name != reqData.name))) {
			return {
				respCode: 503,
				respData: "Request invalid!",
				respReturn: true,
			};
		}

		Req.userName = reqData.userName || "Agent";
		delete reqData.userName;

		return Req.UNRESULT;
	}],


	//`A.findById > P.company: main.company: {_id: "@companyId"}`,
	`A.insertById(*) > P.company: Main.company: @P.reqData`,
	`A.refreshDB: @P.company`,
    //`A.updateOne > P.company: main.company: {_id: "@companyId"}: ({"status" : 1})`,

    `A.pipeRoute: roleAdmin`,
    `A.pipeRoute: group`,
    `A.pipeRoute: label`,
	`A.pipeRoute: seniority`,
	`A.pipeRoute: department`,

	//`A.refreshDB: @company`,
    `A.insertOne(*) > user: user: {
        "hasAgent"  : true,
		"hasAdmin"	: true,
        "userId"    : "@P.company.agentId",
        "email"     : "@P.company.email",
        "status"    : 1,
		"name"		: "@P.userName"
    }`,

	`A.pipeRoute: createProject`,
	// Get Role and Insert User Role into Company
	`A.updateById(*) > tmp: main.company: {_id: "@P.company._id" }:
		{ members: [{userId: "@P.company.agentId", roleId: "@P.body.rolecompany._id", hasActived: true }] }`,

    //`A.updateOne: user: {"_id" : "@db.userId"}: ({"status" : 1})`,
    `A.responseObject: 200: Confirm company successfully!`
], { otpMode: "data" }]);

// Invite member into a company -> he press accept join!
// company/member/invite -> login/confirmjoin
LoginRoute.POST.push([["confirmjoin"], [
	//`A.decodeOTPData`,
	`A.verifyKObject::
		confirmToken!: user.name:
		hashCode!: user.name:
		name: user.name:
		name2: user.name2`,

	`A.getKValue > P.reqData: @confirmToken: true: true`, // Read and Clear Redis
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};
		var companyId = (body.hashCode||"").split("").reverse().join("");

		var reqData = Req.reqData || {};
		var userId = reqData.userId;

		// This in not login API, so hide this
		// var rs = false;
		// if(userId) {
		// 	rs = await A.findById(Req, pipeData, "freeobject", {type: "invite-member", key: userId});
		// }

		//console.log("confirmToken: ", reqData, body);
		//console.log("db: ", db);
		if( /* (!rs || !rs._id) || */
			(!companyId || !body.confirmToken || !reqData) ||
			(!reqData.userId || !reqData.roleId || !reqData.companyId) ||
			(!reqData || (companyId != reqData.companyId)) ) {

			return {
				respCode: 503,
				respData: "Request invalid!",
				respReturn: true,
			};
		}

		return Req.UNRESULT;
	}],

	`A.findById(*) > P.company: Main.company: @P.reqData.companyId`,
	`A.findById(*) > P.usercompany: Main.usercompany: @P.reqData.userId`,
	`A.insertSubItem(P.reqData) > addDB: Main.company: {_id: "@companyId"}: members: {userId: "@userId", roleId: "@roleId", hasActived: true}`,

	`A.refreshDB`,
	`A.insertOne(*) > P.user: user: {
        userId	: "@P.usercompany._id",
        email	: "@P.usercompany.email",
		name	: "@(P.usercompany.name || P.reqData.name || P.usercompany.email)",
		name2	: "@(P.usercompany.name2 || P.reqData.name2 || P.usercompany.email)",
        status	: 1,
     }`,

	 // Delete on temporary , This is not login api, so hide this api
	 //`A.deleteById(*) > tmp: freeobject: {type: "invite-member", key: "@P.usercompany._id"}: true: true`,

    `A.responseObject: 200: Confirm company successfully!`
], { otpMode: "data" }]);

// login/forget -> login/forget/submit ->
LoginRoute.POST.push([["forget"], [
	//`A.decodeOTPData`,
	//`A.printObject`,
    `A.verifyInput:: user: email!`,
	[`A.aggregateOne > userdb: Main.usercompany`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$email", "@email"] },
			{ $in: ["$status", [1] ]},
			{ $not: [{$in: ["$hasActived", [false]] }] }
		]}}}
	]],
	//`A.findOne > userdb: Main.usercompany: {"email" : "@email", status: }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var db = (Req.body||{}).userdb || {};
		if(!db || !db._id) {
	 		return {
				respData: "Could not recognize your email!",
				respReturn: true,
				respCode: 503
			};
		}

	 	return Req.UNRESULT;
    }],

    `A.hashOTP > code`,
    `A.formatString > otp: 'otp_^_{{userdb.email}}_^_{{code}}'`,
	//`A.printObject: opt`,
    `A.setKValue: @otp: @userdb._id: 900: true`, // Code exists 15 minute
    `A.mixObject(*)::({
		"to" 		: "@Req.body.userdb.email",
		"subject" 	: "[GitGam] Request to change password.",
		"view" 		: "forget",
		"data" 		: "@Req.body"
    })`,
    `A.sendMail(*): @P.body`,
    `A.responseObject: 200: Send otp successfully!`

], { otpMode: "data" }]);

// forgot -> submit
LoginRoute.POST.push([["forget/submit"], [
	//`A.decodeOTPString`,

    `A.getKValue > otp: @otp: true: true`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		if(!pipeData.otp) {
	 		return {
				respData: "OTP Code was not existed!",
				respReturn: true,
				respCode: 503
			};
		}

	 	return Req.UNRESULT;
    }],

    `A.uniquizedObject`,
    `A.generateUniqueID > token: 64: @otp`,
    `A.setKValue: @token: @otp: 900: true`, // Code exists 15 minutes
    `A.refactorOutput:: token`

], { otpMode: "string" }]);

// Inside company -> Create member -> act -> forget/submit -> modpass
LoginRoute.POST.push([["actuser"], [
	`A.pipeRoute: decodeOTPResource`,
	`A.printObject:`,
    `A.getKValue > userCompanyId: @otp: true: false`, // must be false, only delete when success!
	`A.printObject:`,

	//`A.printObject`,
	`A.assertKeyExisted:: userCompanyId: This request may be expired or unavailable!`,

	// Assert in freeObject collection -> because this is in Company, and this APi in Global not login
	//`A.findById(*) > freeObj: freeobject: {type: "addnew-member", key: "@P.body.userCompanyId"}`,
	//`A.assertKeyExisted: @freeObj: _id: Invalid request!`,

	`A.updateById > userCompanyDb: Main.usercompany: {_id: "@userCompanyId"}: {status: 1, hasActived: true}`,
	`A.assertKeyExisted: @userCompanyDb: _id: User has been activated!`,

	[`A.aggregateOne > P.company: Main.company:`, [
		{ $match: {
			status: { $in: [1] },
			members: { $elemMatch: {
				userId: "@userCompanyId",
				hasActived: { $in: [false] },
			}}
		}}
	]],
	//`A.printObject`,
	//`A.printObject(*): P.company`,
	`A.assertKeyExisted(*): @P.company: _id: This member may be activated!`,

	`A.refreshDB`,
	`A.updateById > ups1: user: {userId: "@userCompanyId"}: {status: 1}`,
	`A.deleteById > ups2: Main.usercompany: {email: "@userCompanyDb.email", hasActived: false, status: 0}: true: true`, // delete trash item
	`A.updateSubItem(*) > tmp: Main.company: { _id: "@P.company._id" }: members: {userId: "@P.body.userCompanyId", hasActived: true}: userId`,
	//`A.updateSubItem(*) > tmp: Main.company: { _id: "@P.company._id" }: members: {userId: "@P.userCompanyDb._id", hasDeleted: true}: userId`,

	// Delete on temporary -> this is not in company login, so hide this one
	//`A.deleteById(*) > tmp: freeobject: {type: "addnew-member", key: "@P.body.userCompanyId"}: true: true`,

	`A.getKValue > userCompanyId: @otp: true: true`, // must be true to delete
	`A.responseObject: 200: Activate user successfully!`
], { otpMode: "string" }]);

LoginRoute.POST.push([["modpass"], [
	//`A.decodeOTPData`,
    `A.getKValue > id: @token: true: true`, // Read and clear value code
    `A.uniquizedObject`,
	//`A.printObject`,
    `A.updateOne: Main.usercompany: {_id: "@id"}: {password: "@password"}`,
    `A.responseObject: 200: Forgot password successfully!`
], { otpMode: "data" }]);

LoginRoute.POST.push([["checkregname/new"], [
	// // later decision add token for call this api
	// [`A.jsScript:`, async (Req, pipeData, ctx) => {
	//
	// 	var type = (Req.body || {}).type;
	// 	if(type != "user") {
	// 		var token = Req.header["user-token"];
	// 		if(token) {
	// 			token = await Req.func.getKValue(token, false, false);
	// 		}
	//
	//         if(!token) {
	//             return {
	// 				respCode: 500,
	// 				respData: "User was not permitted!",
	// 				respReturn: true
	// 			};
	//         }
	// 	}
	//
    //     return Req.UNRESULT;
    // }],
	`A.pipeRoute: checkregname`
], { otpMode: "data" }]);

LoginRoute.POST.push([["checkregname/inside"], [
	`A.pipeRoute: checkregname`,
], { unAuth: false, otpMode: "data", imCompany: true }]);

LoginRoute.PIPE.push([["checkregname"], [
	//`A.decodeOTPData`,
    [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var type = body.type;

		var rs = false;
		if(type == "user") {
			var userCompanyId = body.userId;
			var companyId = body.companyId;

			// check user email
			var email = body.email;
			email = A.isEmail(email);
			if(email) {
				pipeData.D.IgnoreSanitized = true;

				var filter = {};
				if(userCompanyId) {
					filter._id = { $ne: userCompanyId };
				}

				var obj = await A.findById(Req, pipeData, "Main.usercompany", {
					email: { $regex : new RegExp(`^${email}$`, "i") },
					...filter
				});

				if(!obj) {
					rs = true;

				} else {
					var existOnly = body.existOnly;
					if(false && !existOnly) { // Current let this user invalid and they have to reset password
						// In case an user being exist and not company attached as Agent owner, permit to create new company
						var rs = await A.findById(Req, pipeData, "Main.company", {agentId: obj._id});
						if(!rs) {
							rs = true;
						}
					}
				}

				// Check User in company, fo other user was be owning this new email
				if(rs) {
					if(companyId) {
						var obj = await A.findById(Req, pipeData, "Main.company", {_id: companyId });
						if(obj) {
							Req.company = obj;
							await A.refreshDB(Req, pipeData, obj);
							var rsUser = await A.findById(Req, pipeData, "user", {email: new RegExp(`^${email}$`, "i"), userId: {$ne: userCompanyId }});
							if(rsUser && rsUser._id) {
								rs = false;
							}
						}
					}
				}
			}

		} else if(type == "company") {
			// check company shortName
			var shortName = body.shortName;
			pipeData.D.IgnoreSanitized = true;
			shortName = await A.isShortNameCheck(shortName);
			if(shortName) {
				var obj = await A.findById(Req, pipeData, "Main.company", {
					shortName: { $regex : new RegExp(`^${shortName}$`, "i") }
				});

				if(!obj) {
					rs = true;
				}
			}
		}

		return {
			respData: rs,
			respCode: 200,
			respReturn: true
		};
	}],
], { name: "checkregname" }]);

// LoginRoute.POST.push([["userexternal"], [
// 	`A.trimObject`,
//     [`A.jsScript`, (Req, pipeData, ctx) => {
//         const name = pipeData.searchName || "";
//
//         pipeData.members = Req.company?.members.map(x => x.userId);
//         pipeData.SearchText = Req.func.getASCIISearch(name, "gmi");
//         return pipeData;
//     }],
//     `A.findMany: Main.usercompany: {
//         $or: [ { email: "@SearchText" }, { name: "@SearchText" } ],
//         _id: { $nin: "@members" }
//     }`,
//     `A.refactorOutput:: _id, email, avatarNamne, name`,
// ], { unAuth: false,  IgnoreSanitized: true}]);

module.exports = LoginRoute;
