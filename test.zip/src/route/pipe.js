const PipeRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	PIPE	: [],

	config	: {
	}
};

PipeRoute.PIPE.push([["defaultgroup"], [
    `A.insertMany > group: group: [
        {
            "shortName" : "backlog",
            "name"      : "Backlog",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#9A9A9A",
            "hasGlobal" : true,
            "value"     : 1
        },
        {
            "shortName" : "assigned",
            "name"      : "Assigned",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#5763AC",
            "hasGlobal" : true,
            "value"     : 2
        },
        {
            "shortName" : "indoing",
            "name"      : "In Doing",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#2F80ED",
            "hasGlobal" : true,
            "value"     : 3
        },
        {
            "shortName" : "intesting",
            "name"      : "In Testing ",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#FF7E00",
            "hasGlobal" : true,
            "value"     : 4
        },
        {
            "shortName" : "inreviewing",
            "name"      : "In Reviewing",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#9B51E0",
            "hasGlobal" : true,
            "value"     : 5
        },
        {
            "shortName" : "done",
            "name"      : "Done",
            "hasGlobal" : true,
            "type"      : "task",
            "color"     : "#219653",
            "hasGlobal" : true,
            "value"     : 6
        },
    ]`

], {name : "group"}]);

PipeRoute.PIPE.push([["defaultRole"], [
    `A.insertOne > rolecompany: rolecompany: ({
        "name" : "Admin Company Role",
        "permit" : {
            "project"		: {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "user"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            }
        }
    })`,
    `A.insertOne > roleproject: roleproject: ({
        "name" : "Admin Project Role",
        "permit" : {
            "task"			: {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "wiki"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "label"         : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "feature"       : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "team"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "role"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "postapi"       : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "testcase"      : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "changelog"     : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "logtime"       : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "milestone"     : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "sourcecode"    : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
			"cicd"			: {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
			"vmmachine"		: {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
			"automation"      : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
				"approve"   : true
            },
            "performance"   : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "cost"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "risk"          : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
			"issuelog"      : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
				"approve"   : true
            },
            "document"      : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            },
            "snippet"       : {
                "view"      : true,
                "modify"    : true,
                "delete"    : true,
                "approve"   : true
            }
        }
    })`
], {name : "roleAdmin"}]);

PipeRoute.PIPE.push([["defaultSeniority"], [
	`A.insertMany > seniority: seniority : ([
		{
			title : "Master",
	        descr : "Senior level, >= 5 years experiences"
		},
		{
			title : "Senior",
	        descr : "Senior level, >= 3 years experiences"
		},
		{
			title : "Junior",
	        descr : "Junior level, >= 1 years experiences"
		},
		{
			title : "Newbie",
	        descr : "Newbie level, < 1 years experiences"
		}
	]): 5`
], {name: "seniority"}]);

PipeRoute.PIPE.push([["defaultDepartment"], [
	`A.insertMany > department: department : ([
		{
			name	: "BOD",
			descr	: "Board of Directors",
		},
		{
			name	: "Admin Dept",
			descr	: "Administration Department",
		},
		{
			name	: "HR Dept",
			descr	: "Human Resource Department",
		},
		{
			name	: "Accounting Dept",
			descr	: "Accounting Department",
		},
		{
			name	: "Sale & Marketing Dept",
			descr	: "Sale & Marketing Department",
		},
		{
			name	: "Legal & Audit Dept",
			descr	: "Legal & Audit Department",
		},
		{
			name	: "IT Dept",
			descr	: "Information Technology Department",
		},
		{
			name	: "QC Dept",
			descr	: "Quality Control Department",
		},
		{
			name	: "QA Dept",
			descr	: "Quality Assurance Department",
		}
	]): 10`
], {name: "department"}]);

PipeRoute.PIPE.push([["defaultLabel"], [
    `A.insertMany > label: label : ([
	    {
	        "name"      : "iOS",
	        "type"      : "task",
	        "color"     : "#60BD4F",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Android",
	        "type"      : "task",
	        "color"     : "#EB5B46",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Web",
	        "type"      : "task",
	        "color"     : "#538CF0",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Design",
	        "type"      : "task",
	        "color"     : "#FF9E1A",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Server",
	        "type"      : "task",
	        "color"     : "#02BC77",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Idea",
	        "type"      : "task",
	        "color"     : "#0479C0",
	        "hasGlobal" : true
	    }, {
	        "name"      : "QC",
	        "type"      : "task",
	        "color"     : "#AF78FF",
	        "hasGlobal" : true
	    }, {
	        "name"      : "QA",
	        "type"      : "task",
	        "color"     : "#F283C3",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Marketing",
	        "type"      : "task",
	        "color"     : "#27ADA1",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Analytic",
	        "type"      : "task",
	        "color"     : "#1F8039",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Procedure",
	        "type"      : "task",
	        "color"     : "#1F80ED",
	        "hasGlobal" : true
	    }, {
	        "name"      : "Planing",
	        "type"      : "task",
	        "color"     : "#596B8C",
	        "hasGlobal" : true
		}
	]): 15`
], {name : "label"}]);

PipeRoute.PIPE.push([["defaultboard"], [
    `A.findAll > group: group`,
    `A.jsScript::(
        var groupIds = [];
        pipeData.group.forEach((item) => {
            groupIds.push(item._id);
        })
        pipeData.groupIds = groupIds;
        return pipeData;
    )`,
    `A.insertOne > board: board: ({
        "name" : "Defaut board",
        "groupIds" : "@groupIds",
        "shortName" : "default",
        "hasGlobal" : true
    })`
], {name : "board"}]);

PipeRoute.PIPE.push([["createProject"], [
    `A.insertOne > P.project: project: ({
        name: "First Project",
        shortName: "default",
		startDate: "@(new Date())",
		dueDate: "@(new Date((new Date()).getTime() + 30 * 86400000))",
		members: [{
			user: "@user._id",
			role: "@roleproject._id"
		}]
    })`,
	`A.findById > P.firstGroup: group: { hasGlobal: true, type: "task", shortName: "backlog" }`,
	`A.insertOne(*) > newTask: task: ({
		projectId: "@P.project._id",
		name: "Welcome to project First Task!",
		groupId: "@P.firstGroup._id",
		assigneeIds: ["@P.body.user._id"]
    })`,
], {name : "createProject"}]);

PipeRoute.PIPE.push([["/Checktasks"], [
    [`A.jsScript`, (Req, pipeData, ctx) => {
        const taskDb = (pipeData.dbBody || pipeData.taskDb) || (Req.taskDb || Req.dbBody) || pipeData;
        if(taskDb && taskDb.isLock === true) {
            return {
				respData: "E-01",
				respReturn: true ,
				respCode: 500
			};
        }
        return Req.UNRESULT;
    }],
], {name: "Checktask"}]);

PipeRoute.PIPE.push([["/checkTaskValidToEdit"], [
    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
        const taskId = Req.route._id;
		if(taskId) {
			var task = await A.findById(Req, pipeData, "task", {_id: taskId });
			if(task && task._id && (!task.isLock)) {
				Req.task = task;
				return Req.UNRESULT;
			}
		}

        return {
			respData: "Task was being locked!",
			respReturn: true,
			respCode: 500
		};
    }],

], {name: "checkTaskValidToEdit"}]);

PipeRoute.PIPE.push([["/checkadmin"], [
    [`A.jsScript`, (Req, pipeData, ctx) => {
        if (Req.user.hasAgent || Req.user.hasAdmin) {
            return pipeData;
        }

        return {
			respData: "E-02",
			respReturn: true ,
			respCode : 500
		};
    }],
], {name: "checkadmin"} ]);


PipeRoute.PIPE.push([["/checkEditPermit"], [
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

		var item = Req.body;
		var permit = item && (hasAdmin || (item.creatorId.equals(user._id) && [2,3].includes(item.status)));
		if (!permit) {
			return {
				respData: "E-02",
				respReturn: true,
				respCode : 500
			};
		}
		return Req.UNRESULT;
	}],
], {name: "checkEditPermit"} ]);

PipeRoute.PIPE.push([["/checkDeletePermit"], [
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

		var item = Req.body;
		var permit = item && (hasAdmin || (item.creatorId.equals(user._id) && [2].includes(item.status)));
		if (!permit) {
			return {
				respData: "E-02",
				respReturn: true,
				respCode : 500
			};
		}
		return Req.UNRESULT;
	}],
], {name: "checkDeletePermit"} ]);


PipeRoute.PIPE.push([["/featureUpdateRelatedItem"], [
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		//console.log("featureUpdateRelatedItem -> Req: ", Req);
		//console.log("featureUpdateRelatedItem -> pipeData: ", pipeData);

		var body = Req.body || {};
		body = body.taskDb || body;

		var featureId = body.featureId;
		if(featureId) {
			var hasPermit = Req.project.feature.feature && Req.company.feature.feature;
			if(hasPermit) {
				var key = Req.url.match(/task|wiki|post|testcase/i) || [];
				key = key[0] || "";
				if(key) {
					key = ({post: "postapi"}[key] || key) + "Ids";
					var valId = body._id || pipeData._id;
					//console.log("featureUpdateRelatedItem ------------------ valId-Key: ", valId, key);
					await pipeData.A.insertSubItem(Req, pipeData, "feature", {_id: featureId}, key, valId);
				}
			}
		}

		return Req.UNRESULT;
	}],
], {name: "featureUpdateRelatedItem"} ]);

module.exports = PipeRoute;
