const UserRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
        imBase			: true,
        imCodec    	 	: true,
        // checkMIFs	: [],
        imBase			: true,
		//imMail		: true,
        //imPush		: true,
        imCompany		: true,
		imCompanyRole	: true
        //keepRawPassword: true

    }
};


// M: Model, C:Controller (default), R:defRoute, A: Route
// A:insertOne:wiki:true:otherExtra1:otherExtra2:...

UserRoute.GET.push([["/token"], [
	//`A.printObject(*)`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var UtilFn = pipeData.U.Func;

		var user = Req.user || {};
		var company = Req.company || {};
		var hasAgent = user.hasAgent && ((user.userId||"").toString() == (company.agentId||"_^_").toString());

		// Check for different agent user
		var token = Req.header["user-token"];
		var device = await A.getDeviceLogin(Req, pipeData);

		var reqAgent = A.getUserAgentType(Req) || {osType:'1', type:'2'};
		var dbAgent = A.getUserAgentType(Req, (device||{}).descr) || {osType:'', type:''};

		var isDevMode = pipeData.K.API.isDevMode;
		if( !device || !token ||
			(!isDevMode && (reqAgent.type != dbAgent.type)) ||
			(!isDevMode && (reqAgent.osType != dbAgent.osType))) {

			await A.removeDeviceLogin(Req);
			return {
				respData: 'Invalid request!',
				respCode: 503,
				respReturn: true
			};
		}

		var userCompany = Req.usercompany;
		if(!userCompany) {
			userCompany = await A.getDBCachedObject(Req, pipeData, "Main.usercompany", user.userId);
			if(!userCompany || (userCompany.status != 1)) {
				return {
					respData: 'User was locked!',
					respCode: 503,
					respReturn: true,
				};
			}
		}

		// syncUser date from userCompanyModel -> userModel
		await UtilFn.syncUser(Req, pipeData, A, userCompany, user);

		var feature = {};
		if(company.status != 1) {
			feature = { setting: (company.feature||{}).setting };

		} else {
			feature = UtilFn.featureConfig({
				...(company.feature||{}),
				...(company.featurePackage||{}),
				...(pipeData.K.API.FeatureConfig||{})
			});
		}

		var role = Req.roleCompany || Req.rolecompany || {};
		role = role.permit || role;

		var cf = company.config || {};

		var rs = {
			user: {
				_id			: user._id,
				name		: user.name,
				name2		: user.name2,
				email		: user.email,
				loginEmail	: (Req.usercompany||{}).email || user.email,
				avt			: user.avt,
				userId		: user.userId,

				type		: user.type,
				status		: user.status,
				hasAdmin	: hasAgent || user.hasAdmin,
				hasAgent	: hasAgent,
				hasSupport	: user.hasSupport,
				hasUpdated	: user.hasUpdated,
				show2N		: user.show2N,
			},

			company: {
				_id			: company._id,
				name		: company.name,
				shortName	: company.shortName,
				avt			: company.avt,
				feature		: feature,
				status		: company.status,
				hasAgent	: hasAgent,
				config: {
					currency			: cf.currency,
				    currencyDecimal		: cf.currencyDecimal,
				    formatFullDay		: cf.formatFullDay,
				    formatShortDay		: cf.formatShortDay,
					maxDocSize			: cf.maxDocSize,

					moringStartTime		: cf.moringStartTime,
				    moringEndTime		: cf.moringEndTime,
				    afternoonStartTime	: cf.afternoonStartTime,
				    afternoonEndTime	: cf.afternoonEndTime,
				    nightStartTime		: cf.nightStartTime,
				    nightEndTime		: cf.nightEndTime,
				}
			},

			companyRole: role,
		};

		//console.log("RS: ", rs);
		Req.respCode = 200;
		return rs;
	}],

	//`A.copyKObject(*):: P.user, P.body.user : P.company, P.body.company`,
	`A.updateDeviceLogin`,
    `A.refactorOutput:: user, company, companyRole`
], { permitAgent: true }]);

// UserRoute.POST.push([["/verify"], [
//     `A.findOne > P.company: main.company: ({ "_id" : "@companyId"})`,
//     `A.getKValue > userId: @verifyToken`,
//     `A.refreshDB(*): @P.company`,
//     `A.verifyInput > password:: user: password!`,
//     `A.hashPassword(password)   > password: @password`,
//     `A.updateOne: user: {"_id" : "@userId"}: {"password" : "@password", "status" : 1 }`,
//     `A.responseObject: 201: Verify user successfully!`
//
// ], {
//     unAuth : true
// }]);

UserRoute.POST.push([["/s"], [
    //   "A.checkPermission(*): rolecompany: @P.user.roleId: user.view",
    //`<F1>A.findMany: user: { status:1, hasDeleted: { $nin: [true] }}`,
	`A.getPaginate > page`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var search = body.name || body.search || "";

		var filter = {
			status: 1
		};

		if(search) {
			search = Req.func.getASCIISearch(search, "gmi");
			filter["$or"] = [
				{ name: search },
				{ email: search },
			];
		}

		body.filter = filter;
		body.page.pageLength = 500;

		return Req.UNRESULT;
	}],

	[`A.aggregate: user`, [
		{ $match: "@filter" },
		{ $sort: {
			name$: 1
		}},

		{ $skip: "@page.pageStart" },
		{ $limit: "@page.pageLength" },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			userId: 1,
			type: 1,
			staffCode: 1,
			hasAgent: 1,
			hasAdmin: 1,
			status: 1
		}}
	]],

    // `A.populate: position, positionId, _id, position, +, name, name2,
    //             : seniority, seniorityId, _id, seniority , +, title
    //             : department, departmentId, _id, department, +, title`,
    //`A.refactorOutput:: _id, name, name2, userId, avt, type, staffCode, hasAgent, hasAdmin, status`
], { useZip: true } ]);

UserRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.view",
    `A.pipeRoute: checkadmin`,
    "A.findOne:user",
    // `A.populate: position, positionId, _id, position, +, name, name2,
    //             : seniority, seniorityId, _id, seniority , +, title
    //             : department, departmentId, _id, department, +, title`,
    `A.refactorOutput:: _id, name, name2, userId, avt, email, informEmail, employeeCode, type, sendMessage, hasAgent, hasAdmin, status, show2N`

]]);

// UserRoute.POST.push([[""], [
// 	//`A.printObject`,
// 	`A.verifyInput:: user: name!, email!, status-, hasAdmin-, hasAgent-, ...`,
// 	//`A.printObject`,
//
// 	// Find and upsert to create item, onluy email key
//     `A.findOne > userCompany: Main.usercompany: ({
//         "email": "@email"
//     }) : {
//         email       : "@email",
// 	}`,
//
// 	//`A.printObject`,
//
// 	// Find and upsert to create item, onluy email key
//     `<F1>A.findOne > userDB: user: ({
//         "$or": [{"email": "@email"}, {"userId": "@userCompany._id"}]
//
//     }): {
// 		userId      : "@userCompany._id",
//         email       : "@email",
//         name        : "@name",
//         informEmail : "@informEmail",
//         type        : "@type",
// 		status		: 1
// 	}`,
//
//     //`A.printObject:`,
//
//     `A.insertOne > hrcontractDb: hrcontract: {
//         userId : "@userCompany._id",
//         "overview": {
//             "seniorityId": "@seniorityId",
//             "positionId": "@positionId",
//             "staffCode": "@staffCode"
//         }
//     }`,
//     //`A.printObject`,
//
// 	// Currently accept constant role id
//     `A.insertSubItem(*): main.company: @P.company._id: members: ({userId : "@P.body.userCompany._id", roleId: "5fae996830f9a845431ad9de"})`,
// ], { F1: { IgnoreSanitized : true }}]);

// UserRoute.PUT.push([[":_id"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
//     `A.pipeRoute: checkadmin`,
//     "A.verifyInput:: user:name, name2,userId,  avt, email, informEmail, password, employeeCode, type, sendMessage",
//     "A.updateById:user",
//     // `A.populate: position, positionId, _id, position, +, name, name2,
//     //             : seniority, seniorityId, _id, seniority , +, title
//     //             : department, departmentId, _id, department, +, title`,
//     `A.refactorOutput:: _id, name, name2, userId, avt, email, informEmail, employeeCode, type, sendMessage, hasAgent, hasAdmin, status`
// ]]);
//
// UserRoute.PUT.push([[":_id/admin"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
//     `A.pipeRoute: checkadmin`,
//     `A.updateOne: user:: {"hasAdmin" : true}`,
//     `A.responseObject: 200: Update admin for the account`
//
// ]]);
//
// UserRoute.DELETE.push([[":_id/admin"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
//     `A.pipeRoute: checkadmin`,
//     `A.updateOne: user:: {"hasAdmin" : false}`,
//     `A.responseObject: 200: Update not admin for the account`
//
// ]]);
//
// UserRoute.DELETE.push([[":_id"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: user.delete",
//     `A.pipeRoute: checkadmin`,
//     "A.deleteById:user",
//     "A.refactorOutput"
// ]]);

// UserRoute.POST.push([["/reset"], [
//     // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
//     `A.verifyInput:: user: password!, newpassword!`,
//     `A.checkPassword(*): @P.body.password: @P.user.password`,
//     `A.hashPassword > password: @passwordnew`,
//     `A.updateOne(*): user: @P.user: ({"password" : "@P.body.password"}) `,
//     `A.refactorOutput:: password-, createdAt-, modifiedAt-, creatorId-, modifierId-`
// ]]);


// @Toan, save in commondb
// ssh-keygen -lf <(cat ~/.ssh/id_rsa.pub)
UserRoute.POST.push([["/:_id/s/ssh"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // `A.checkPermission(*): rolecompany: @P.user.roleId: user.edit`,
	//`A.verifyInput > reqBody:: login: fingers!`,
	`A.findById > dbBody: user`,

	//`A.useAdminDB: true`,
	`A.findById > dbMainBody: Main.usercompany: {_id: "@dbBody.userId"}`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var now = new Date();
		var fingers = ((Req.body||{}).dbMainBody||{}).fingers || [];

		// Adjust color for status fo ssh key
		fingers.map(f => {
			var t = (now - (f.lastActive||0)) / 86400000;
			if(t < 2) {
				f.status = "green";

			} else if(t < 7) {
				f.status = "blue";

			} else if(t < 31) {
				f.status = "orange";

			} else {
				f.status = "grey";
			}
		});

		return {
			respData: fingers,
			respCode: 200,
			respReturn: true
		}
	}]
]]);

UserRoute.POST.push([["/:_id/add/ssh"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
	//`A.printObject`,
    `A.verifyInput > reqBody:: usercompany: fingers!`,
	//	`A.printObject`,

	`A.getKeyFinger(reqBody.fingers) > fingers`,
	//`A.printObject: fingers`,

	`A.findById(reqBody) > dbBody: user`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};
		Req.body = body;

		var newFinger = body.fingers;
		if(Array.isArray(newFinger)) {
			newFinger = newFinger[0];
		}

		var user = body.dbBody;
		if((newFinger && newFinger.finger) && (user && user.userId)) {
			var newFinger = body.fingers;
			if(Array.isArray(newFinger)) {
				newFinger = newFinger[0];
			}

			body.newFinger = newFinger;
			var companyUser = await A.findById(Req, pipeData, "Main.usercompany", {_id: user.userId});
			if(companyUser) {
				var fingers = companyUser.fingers || [];
				for (var i = 0; i < fingers.length; i++) {
					var finger = fingers[i];
					if(finger.finger == newFinger.finger) {
						return {
							respCode: 503,
							respData: "SSH Key exist!",
							respReturn: true
						};
					}
				}

				// sucess to add finger
				body.cuId = companyUser._id;
				return Req.UNRESULT;
			}
		}

		return {
			respCode: 500,
			respReturn: true,
			respData: "Failed to add ssh key!",
		};
	}],

	`A.insertSubItem > rsFingers: Main.usercompany: {"_id": "@cuId"}: fingers: @newFinger`,
	`A.responseObject: 200: @rsFingers[0]`,


	//
	// "A.findById(reqBody) > dbBody: user",
	//
	// `A.mixObject(dbBody) > dbCompanyQuery:: ({
	// 	"_id": "@userId"
	// })`,
	//
	// //"A.useAdminDB: true",
	// "A.findById(dbCompanyQuery) > dbBody: Main.usercompany",
	// "A.getKeyFinger > fingers",
	//
    // `A.modifyObject::
    //     dbBody.fingers = */fingers,
	// 	respData = 200`,
	//
    // "A.updateById(dbBody) > tmpBody: Main.usercompany",
]]);

UserRoute.POST.push([["/:_id/remove/ssh"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
	//`A.verifyInput > reqBody:: user: fingers!`,

	`A.findById(reqBody) > dbBody: user`,
	//`A.printObject`,

	`A.removeSubItem: Main.usercompany: {"_id": "@dbBody.userId"}: fingers: @finger: finger`, // -> client send just a key
	//`A.removeSubItem: Main.usercompany: {"_id": "@dbBody.userId"}: fingers: @finger: finger`, // -> client send object
	`A.responseObject: 200: Delete successfully!`,

	// `A.verifyInput > reqBody:: login: fingers!`,
	// "A.findById(reqBody) > dbBody: user",
	//
	// `A.mixObject(dbBody) > dbCompanyQuery:: ({
	// 	"_id": "@userId"
	// })`,
	//
	// //"A.useAdminDB: true",
	// "A.findById(dbCompanyQuery) > dbBody: Main.usercompany",
	// "A.getKeyFinger > fingers",
	//
	// `A.modifyObject::
    //     dbBody.fingers = //fingers,
	// 	respData = 200`,
	//
    // "A.updateById(dbBody) > tmpBody: Main.usercompany",
]]);

UserRoute.POST.push([["/enable/show2n"], [
	`A.updateById(*): user: { _id: "@P.user._id" }: { show2N: "@P.body.show2N" }`,
	`A.responseObject: 200: Update successfully!`,
]]);

UserRoute.POST.push([["/social/add/:mode:(/^(google|apple|microsoft|github|gitlab)$/)"], [
	`A.removeSubItem(*) > dbData: Main.usercompmany: { _id: "@P.user.userId" }: ssoServices: [{name: "@P.route.name"}]: name`,
    `A.insertSubItem(*) > dbData: Main.usercompmany: { _id: "@P.user.userId" }: ssoServices: [{"<=": "@P.body", name: "@P.route.name"}]`,
	`A.responseObject: 200: Enable successfully!`,
]]);

UserRoute.POST.push([["/social/disable/:mode:(/^(google|apple|microsoft|github|gitlab)$/)"], [
	`A.removeSubItem(*) > dbData: Main.usercompmany: { _id: "@P.user.userId" }: ssoServices: [{name: "@P.route.name"}]: name`,
    // `A.insertSubItem(*) > dbData: Main.usercompmany: { _id: "@P.user.userId" }: ssoServices: [{"<=": "@P.body", name: "@P.route.name"}]`,
	`A.responseObject: 200: Disable successfully!`,
]]);

module.exports = UserRoute;
