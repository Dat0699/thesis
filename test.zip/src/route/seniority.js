const SeniorityRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
        // checkMIFs	: [],
		roleUserIdKey	: "userId"
    }
};

SeniorityRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	"A.verifyInput:: seniority: title, descr",
	"A.insertOne: seniority",
	`A.refactorOutput:: _id, title, descr`
]]);

SeniorityRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	"A.findMany: seniority",
	`A.refactorOutput:: _id, title, descr`
]]);

SeniorityRoute.GET.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	"A.findOne: seniority",
	`A.refactorOutput:: _id, title, descr`
]]);

SeniorityRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.verifyInput:: seniority: title, descr",
	"A.updateOne: seniority",
    `A.responseObject: 200: Update successfully!`
]]);

SeniorityRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.deleteOne: seniority",
    `A.responseObject: 200: Delete successfully!`
]]);

module.exports = SeniorityRoute;
