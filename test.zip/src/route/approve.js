const ApproveRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		imCache			: true,
		roleUserIdKey	: "userId"
	}
};

ApproveRoute.POST.push([[""], [
	`A.verifyInput:: approve: refId!, refModel!, status!, projectId, message, modifiedAt`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {

		var A = pipeData.A;
		var U = pipeData.U;

		var body = Req.body;
		var user = Req.user;
		var header = Req.header;

		var approveRequest = [2,3].indexOf(body.status) >= 0;
		if(approveRequest) {
			var role = body.refModel;
			role = {"penalty": "performance"}[role] || role;

			// Get user approve permission
			var isProject = body.projectId ? true : false;
			if(isProject) {
				//`A.checkRole(*): project: @P.project._id: roleproject: cost.view, cost.modify`,
				Req.config.roleUserIdKey = "_id";
				var rs = await A.checkRole(Req, pipeData, "project", body.projectId, "roleproject", `${role}.approve`);
				//console.log("Project: ", body);
				if(!rs) {
					return undefined;
				}

			} else {
				var rs = await A.checkRole(Req, pipeData, "Main.company", Req.company._id, "rolecompany", `${body.refModel}.approve`);
				//console.log("Company: ", body, Req.company._id);
				if(!rs) {
					return undefined;
				}
			}
		}

		var refModel = body.refModel;
		var filter = { _id: body.refId };
		var dbData = await A.findById(Req, body, refModel, filter);
		
		if(!dbData || !dbData._id) {
			return Req.onResponse(false, "Approved/Rejected failed!");
		}

		// Permit edit out of date item
		// if(approveRequest) {
		// 	if((body.modifiedAt||"").toString() != (dbData.modifiedAt||"").toString()) {
		// 		return Req.onResponse(false, "You can not edit out of date item!");
		// 	}
		// }

		// get List of user that reportToIds and approvedIds list.
		const isApproved = (dbData.approverIds||dbData.reportToIds||[]).some(x => x.equals(user._id));
		const canApprove = (user.hasAdmin || user.hasAgent) || isApproved;

		// if([2, 3].includes(body.status)) {
		// 	if(!canApprove) {
		// 		return Req.onResponse(false, "Approved/Rejected invalid!");
		// 	}
		// }

		if([2].includes(dbData.status)) {
			if(!canApprove) {
				return Req.onResponse(false, "You can not edit approved item!");
			}
		}

		var dataUpdate = {
			status: body.status,
			approvedAt: new Date(),
			approverId: user._id,
		}

		if(body.message) {
			dataUpdate.rejectedMessage = body.message;
		}

		// Must used RAW function
		//var rs1 = await A.updateById(Req, pipeData, refModel, {_id: body.refId}, {
		var rs1 = await A.dbRaw(Req, pipeData, refModel, 'updateOne', filter, {$set: dataUpdate});
		if(!rs1) {
			return Req.onResponse(false, "Approved/Rejected failed!");
		}

		var originData = JSON.stringify(dbData);
		originData = Req.func.mergeToken(user._id.toString(), originData);

		// Record approve item
		await A.insertById(Req, pipeData, "approve", {
			refId: dbData._id,
			refModel: refModel,
			approverId: user._id,
			approvedAt: new Date(),
			projectId: body.projectId,
			originData,
		});

		// Process Overtime
		if(refModel == "overtime") {
			// Delete all data in Leaving Bonus
			await A.deleteById(Req, pipeData, "leaving", {type: "bonus", refId: dbData._id}, true, true);

			// Insert all new data, if approved request
			if((body.status == 2) && (dbData.mkDuration > 0)) {
				var wd = U.Date.companyTimePoint(Req, pipeData);
				wd = wd.wd || 8.0;

				var members = dbData.userIds || rs1.userIds;
				if(members && members.length > 0) {
					var date = new Date();
					var year = dbData.createdAt.getFullYear();

					await Promise.all(members.map(id => {
						return new Promise(async cb => {
							var data = A.uniquizedObject(Req, pipeData, {
								type: "bonus",
								isBonus: true,
								reason: `[Bonus by OT] ${dbData.title}`,
								creatorId: id,
								createdAt: dbData.createdAt,
								startDate: date,
								endDate: date,
								duration: (dbData.duration || dbData.totalHour || 0) / wd,
								year: year,
								status: 2, // approved
								refId: dbData._id,
								approverId: user._id,
							});

							var r = await A.dbCall(Req, pipeData, "leaving", "insertOne", data);
							cb(r);
						});
					}));
				}
			}
		}

		// Send mail
		const STATUS = {
			1: "New",
			2: "Approved",
			3: "Rejected",
			4: "Submitted",
		}
		var templateName = {
			"dailyreport"	: "dailyReport",
			"leaving" 		: "leavingView",
			"announcement"	: "announcementView",
			"cost"			: "ledgeCostView",
			"risk"			: "riskView",
			"changelog"		: "changeLogView",
			"issuelog"		: "issueLogView",
			"logtime"		: "logtime",
			"milestone"		: "milestoneView",
			"sprint"		: "sprintView",
		}[refModel] || 'approve';

		var status = STATUS[body.status];
		var isValidSendMail = (status == "Approved") || (status == "Rejected") || (status == "Submitted") ;
		if(!isValidSendMail) return Req.UNRESULT;
		
		var annUsers = {};
		var userIds = [...(dbData.approverIds||dbData.reportToIds||[]), dbData.creatorId, Req.user._id];

		if (refModel == "overtime") {
 			if (status == "Submitted") {
				userIds = [...(dbData.approverIds || []), dbData.creatorId, Req.user._id];
			} else if (status == "Rejected") {
				userIds = [...(dbData.approverIds||dbData.reportToIds||[]), dbData.creatorId, Req.user._id];
			} else if (status == "Approved") {
				userIds = [...(dbData.approverIds||dbData.reportToIds||[]), dbData.userIds, dbData.creatorId, Req.user._id];
			}
		} 

		if (refModel == "dailyreport") {
			if (status == "Submitted") {
			   userIds = [...(dbData.reportToIds || [])];
		   } else if (status == "Rejected") {
			   userIds = [ ...(dbData.reportToIds || []) , Req.user._id, dbData.creatorId ];
		   } else if (status == "Approved") {
			   userIds = [ dbData.creatorId ];
		   }
	   	}

		if (refModel == "announcement") {
			if (status == "Submitted") {
				userIds = [ ...(dbData.reportToIds || []) , Req.user._id, dbData.creatorId, ...(dbData.approverIds || []) ];
			} else if (status == "Rejected") {
				userIds = [ ...(dbData.reportToIds || []) , Req.user._id, dbData.creatorId, ...(dbData.approverIds || []) ];
			} else if (status == "Approved") {
				annUsers = await A.aggregateOne(Req, pipeData, "announcement", [
					{ $match: {
						_id: dbData._id
					}},
					{ $populateFilter: ["department", "departmentIds$:_id", "departments", undefined, 1, "members"] },
					{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members"]},
					{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

					{ $populateFilter: ["seniority", "seniorityIds$:_id", "seniority", undefined, 1, "_id"]},

					{ $populateFilter: ["hrcontract", "seniorityIds$:overview.seniorityId", "hrcontract", undefined, 1, "userId"]},

					{ $lookup: {
						from: "user",
						let: { sendToAll: "$sendToAll" },
						pipeline: [
							{ $match: { $expr: { $and: [
								{ $eq: ["$$sendToAll", true] },
							]}}},
							{ $match: {
								hasDeleted: { $nin: [true] }
							}},
							{ $project: {
								_id: 1
							}}
						],
						as: "allUsers"
					}},

					{ $flatArray: {
						listMemberDepartments: "$departments.members",
						listMemberProjects: "$projects.members.user",
						listMemberTeams: "$teams.members",
					}},

					{ $addFields: {
						listMembers: { $setUnion: ["$allUsers", "$userIds", "$hrcontract.userId", "$listMemberDepartments", "$listMemberProjects", "$listMemberTeams" ]},
					}},

					// { $populateFilter: ["user", "listMembers$:_id", "listMembers", undefined, 1, "email"]},
					// { $addFields: {
					// 	listMembers: "$listMembers.email"
					// }},

					{ $project: {
						listMembers: 1,
					}}
				]);

				userIds = [ dbData.approverId , ...(dbData.userIds || []), Req.user._id, dbData.creatorId, ...(annUsers?.listMembers||[]) ];
			}
		}

		if(refModel == 'logtime') {
			if(status === 'Submitted') {
				userIds = [ dbData.assignId ];
			}

			if(status === 'Rejected') {
				userIds = [dbData.approverId  , dbData.creatorId, dbData.assignId ];
			}

			if(status === 'Approved') {
				userIds = [dbData.approverId  , dbData.creatorId, dbData.assignId];
			}
		}
		if(["risk", "cost", "changelog", "issuelog", "milestone", "sprint"].indexOf(refModel) >= 0) {
		 	annUsers = await A.aggregateOne(Req, pipeData, "", [
				{ $lookup: {
					from: "roleproject",
					pipeline: [
						{ $match: {
							[`permit.${refModel}.view`]: true
						}},
		
						{ $project: {
							_id: 1
						}},
					],
					as: "listRoles"
				}},

				{$addFields: {
					listRoleIds : '$listRoles._id',
				}},

				{ $lookup: {
					from: "project",
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: [ "$_id", Req.body.projectId ] },
							{ $or: [
								{ $in: [ Req.user._id , "$members.user"] },
								{ $eq: [Req.user.hasAgent, true]},
								{ $eq: [Req.user.hasAdmin, true]}
							]}
						]}}},
		
						{ $project: {
							_id: 1,
							members: 1,
							name: 1,
							name2: 1,
							shortName: 1,
						}},
					],
					as: "project"
				}},

				{ $unwind: {
					path: "$project",
					preserveNullAndEmptyArrays: false
				}},

				{ $addFields: {
					listUsers: { $filter: {
						input: "$project.members",
						as: "item",
						cond: { $and: [
							{ $in: ["$$item.role", "$listRoleIds"] }]},
					}}
				}},

				{ $addFields: {
					listUserIds: "$listUsers.user"
				}},

				{ $project: {
					listUserIds: 1,
					project: 1
				}}

			]);
			userIds = [...(annUsers.listUserIds || [])];
		}

		var filterUser = {
			$or: [
				{ hasAgent: true },
				{ _id: { $in: userIds} }
			]
		};
		var users = await A.findMany(Req, body, "user", filterUser);

		if(dbData?.projectId || Req.body.projectId) {
			var filterProject = {
				$or: [
					{ hasAgent: true },
					{ _id: { $in: [dbData?.projectId || Req.body.projectId]} }
				]
			};
			var project = await A.findOne(Req, body, "project", filterProject);
		}

		var data = {
			status,
			refId: body.refId,
			number: dbData?.number,
			name: dbData?.name || Req.user.name,
			nameSender: Req.user.name,
			date: new Date(),
			type:  dbData?.type,
			startDate:  dbData?.startDate,
			endDate:  dbData?.endDate,
			project: annUsers?.project || project || {},
			idItem: dbData?._id || "",
			milestoneId: dbData?.milestoneId,
		};

		const subject = `[${refModel[0].toUpperCase()+refModel.substr(1)}] ${Req.user.name} ${data.status.toLowerCase()} item #${dbData.number || dbData.name}`;
		await A.sendMail(Req, pipeData, {
			"to" 		: users.map(x => x.email),
			"subject" 	: subject,
			"view" 		: templateName,
			"data" 		: data
		});

		return Req.onResponse(true, `${status} successfully!`);
	}],

], { IgnoreSanitized: true }]);

ApproveRoute.POST.push([["verify"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var refId = body.refId;
		var refModel = body.refModel;
		var data = body.originData;
		var userId = body.userId || body.approverId || body.approver;

		if(userId && refModel) {
			var data = await A.findById(Req, pipeData, "approve", {refId, refModel, approverId:userId});
			if(data && data._id) {
				var obj = data.originData;
				if(obj) {
					obj = Req.func.parseToken(obj);
					if(obj) {
						var originApprover = obj[0];
						var originData = JSON.parse(obj[1]);
						if((originApprover == userId) && (userId == originData.approverId)) {
							var strOps = Req.func.mergeToken(userId, data);
							if(strOps == data.originData) {
								return {
									respData: true,
									respCode: 200,
									respReturn: true,
								}
							}
						}
					}
				}
			}
		}

		return {
			respData: false,
			respCode: 200,
			respReturn: true,
		}
	}],
]]);

module.exports = ApproveRoute;
