const PostServerRoute = {
	route	: "/post/server",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

PostServerRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var user = Req.user || {};

		if(!body.members || (body.members.length <= 0)) {
			body.members = [{
				user: user._id,
				role: {
					//create: true,
					modify: true,
					delete: true,
					action: true,
				}
			}];
		}

		return Req.UNRESULT;
	}],

	`A.verifyInput:: postserver: groupId, projectId!, number-, ...`,
	`A.insertOne: postserver`,

	`A.pipeRoute: postserver: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostServerRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.findOne: postserver:`,
	`A.verifyInput:: postserver: _id-, number-, ...`,

	`A.formatString > name: "{{name}} - cloned"`,
	`A.insertById > P.server: postserver`,

	`A.cloneById(*) > P.lookUp: postgroup:: {serverId: "@P.route._id"}: {serverId: "@P.server._id"}: 1000: true: _id-, number-`,
	`A.cloneById(*) > P.newApis: postapi:: {serverId: "@P.route._id"}: {serverId: "@P.server._id"}: 1000:: _id-, number-, P.lookUp.map.$ => groupId`,

	// Replace Cloned folder with changed parentFolder parentId
	`A.getKObject(*) > P.allParentIds: @P.lookUp.lists: _id`,
	`A.replaceById(*) > P.subFolder: postgroup: {serverId: "@P.route._id", parentId: "@P.allParentIds"}:: 1000: _id-, number-, P.lookUp.map.$ => parentId`,

	//`A.printObject(*): P.newApis`,
	//`A.printObject(*): P.lookUp`,

	/*
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;

		var A = pipeData.A;
		var server = await A.insertById(Req, pipeData, "postserver", body);

		var ngs = [];
		var groups = await A.findMany(Req, pipeData, "postgroup", {serverId: Req.route._id});
		for (var i = 0; i < groups.length; i++) {
			var group = groups[i] || {};
			group.serverId = server._id;

			ngs[i] = group._id;
			delete group._id;
			delete group.number;
		}

		var ng = {};
		var ngroups = await A.insertMany(Req, pipeData, "groupgroup", groups, 500);
		for (var i = 0; i < ngroups.length; i++) {
			ng[(ngs[i]||"").toString()] = (ngroups[i]||{})._id;
		}

		var apis = await A.findMany(Req, pipeData, "postapi", {serverId: Req.route._id});
		for (var i = 0; i < apis.length; i++) {
			var api = apis[i];
			if(api) {
				api.serverId = server._id;
				api.groupId = ng[(api.groupId||"").toString()];

				delete api._id;
				delete api.number;
			}
		}

		var napis = await A.insertMany(Req, pipeData, "postapi", apis, 2000);
		return Req.UNRESULT;
	}],
	*/

	`A.pipeRoute: postserver: { type: "clone" }`,
	`A.responseObject(*): 200: Clone server successfully!`
]]);

PostServerRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = [{
			$eq: ["$projectId", Req.project._id]
		}];

		var name = (pipeData.name || pipeData.search) || (pipeData.title || pipeData.text);

		pipeData.searchExistFilter = {};
		if(name) {
			// use to filter empty list
			var number = (name - 0) || -1;
			name = Req.func.getASCIISearch(name||"", "gmi");

			ops.push({$or: [
				{ $regexMatch: { input : "$name", regex: name }},
				{ $eq: ["$number", number] }
			]});
		}

		var user = Req.user;
		pipeData.userId = user._id;
		pipeData.isAdmin = user.hasAdmin || user.hasAgent;

		pipeData.ops = ops;
		//console.log(JSON.stringify(ops));
        return pipeData;
    }],

    [`A.aggregate: postserver:`, [
		{ $match: { $expr: { $and: "@ops" }}},

		// Check permitted
		{ $addFields: {
			permit: { $cond: [
				{ $eq: ["@isAdmin", true]},
				[{ user: "__anyValue__", role: {
					create: true,
					modify: true,
					delete: true,
					action: true,
				}}],
				{ $filter: {
					input: "$members",
					as: "member",
					cond: { $eq: ["$$member.user", "@userId"] }
				}},
			]}
		}},
		{ $unwind: {
			path: "$permit",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			permit: "$permit.role"
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			permit: 1,
		}},
	]]
]]);

PostServerRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var _id = Req.route._id;

		pipeData._id = _id;
		pipeData.number = (_id-0);

		var user = Req.user;
		pipeData.userId = user._id;
		pipeData.isAdmin = user.hasAdmin || user.hasAgent;

		//console.log(JSON.stringify(pipeData));
        return pipeData;
    }],

	//`<F1>A.findOne(P.route): postserver: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
	[`A.aggregateOne: postserver:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$_id", "@_id"]},
			{ $eq: ["$number", "@number"]},
		]}}},

		// Check permitted
		{ $addFields: {
			permit: { $cond: [
				{ $eq: ["@isAdmin", true]},
				[{ user: "__anyValue__", role: {
					//create: true,
					modify: true,
					delete: true,
					action: true,
				}}],
				{ $filter: {
					input: "$members",
					as: "member",
					cond: { $eq: ["$$member.user", "@userId"] }
				}},
			]}
		}},
		{ $unwind: {
			path: "$permit",
			preserveNullAndEmptyArrays: false,
		}},
		{ $addFields: {
			permit: "$permit.role"
		}},
	]],

	`A.assertKeyExisted:: _id: Invalid request!`,
	`A.responseObject(*): 200: @P.body`

]]);

PostServerRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: postserver: number-, ...`,

	`A.updateById(*): postserver: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: postserver: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostServerRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,

	`A.deleteById(*): postserver: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.deleteById(*): postgroup: { serverId: "@P.route._id", projectId: "@P.project._id" }: true: true`,
	`A.deleteById(*): postapi: { serverId: "@P.route._id", projectId: "@P.project._id" }: true: true`,

	`A.pipeRoute: postserver: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);


// ----------- Member update -------------------
PostServerRoute.POST.push([[":_id/member/add"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.verifyInput:: postserver: members!`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = pipeData.members;
		if(!Array.isArray(data)) {
			data = [data];
		}

		// to make sure data alway correct.
		//console.log("Data: ", data);
		data = data.filter(item => {
			return item.user && item.role;
		});

		Req.body = { members: data };
		return Req.UNRESULT;
	}],

	//`A.printObject`, // Remove than insert
	`A.removeSubItem(*) > dbData: postserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body.members: user`,
    `A.insertSubItem(*) > dbData: postserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body.members`,
    `A.responseObject: 200: Add member successfully!`
]]);

PostServerRoute.POST.push([[":_id/member/remove/:userId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.checkRole(*): project: @P.query.projectId: roleproject: postapi.view, postapi.modify`,
	`A.printObject`,

    `A.removeSubItem(*): postserver: {_id: "@P.route._id", projectId: "@P.project._id"}: members: {user: "@P.route.userId"}`,
    `A.responseObject: 200: Remove member successfully!`
]]);

PostServerRoute.POST.push([[":_id/member/update"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,

	`A.verifyInput:: postserver: members!`,
	//`A.printObject`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var data = pipeData.members;
		if(Array.isArray(data)) {
			data = data[0];
		}

		Req.body = data;
		return Req.UNRESULT;
	}],

	//`A.printObject`,
    `A.updateSubItem(*) > dbData: postserver: { _id: "@P.route.sourceId", projectId: "@P.project._id" }: members: @P.body: user`,
    `A.responseObject: 200: Update member successfully!`
]]);

PostServerRoute.PIPE.push([["checkAccessPostServer"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var user = Req.user || {};
		var userId = user._id.toString();

		var checkRoles = Object.keys(Req.body || {}).role || "";
		checkRoles = checkRoles.split(/[\s\t]{0,}[,:]{1,}[\s\t]{0,}/gmi);

		var passed = false;
		var server = await A.findOne(Req, pipeData, "postserver", {_id: Req.route._id});
		if(server && server._id) {
			if(!user.hasAdmin && !user.hasAgent) {
				var members = server.members;
				if(member && (members.length > 0)) {
					for (var i = 0; i < members.length; i++) {
						var n = members[i];
						if((m.user||"").toString() == userId) {
							passed = true;

							if(checkKeys.length > 0) {
								passed = false;

								var role = m.role;
								if(role) {
									passed = true;

									for (var i = 0; passed && (i < checkRoles.length); i++) {
										var key = checkRoles[i];
										if(!role[key]) {
											passed = false;
											break;
										}
									}
								}
							}
						}
					}
				}
			}

			if(!passed) {
				return {
					respCode: 500,
					respReturn: true,
					respData: "You were not permitted!",
				};
			}

			//await A.checkExistItem(Req, pipeData, "postserver", {_id: Req.route.serverId, "members.user": user._id}, true, "You were not permitted!");
		}

		return Req.UNRESULT;
	}],
], { name: "checkAccessPostServer" }]);

module.exports = PostServerRoute;
