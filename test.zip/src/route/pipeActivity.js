const PipeRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	PIPE	: [],

	config	: {
	}
};

// ----------------------- Task -----------------------
PipeRoute.PIPE.push([["/task"], [
    [`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
        var A = pipeData.A;
		var body = Req.body;
        var task =  body.task;
        var member;

        if(body.memberId) {
            member = await A.findById(Req, body, "user", { _id: body.memberId[0] })
        }

        // get project
        var project = Req.project;

        if(!project) {
            return UNRESULT;
        }

        var query = { _id: { $in: [...(task.assigneeIds||[]), ...(task.testerIds||[]), ...(task.reviewerIds||[]), ...(task.watcherIds||[])] } };

        // get users
        var users = await A.aggregate(Req, body, "user", { $match: query });

        if(!users || !users.length) {
            return UNRESULT;
        }

        var view = body.mode === 'member' ? 'taskMember' : 'task';
        var time = new Date();

		await A.sendMail(Req, pipeData, {
			"to" 		: users.map(x => x.email),
			"subject" 	: `[${project.name}] [Task-${task.number}] ${body.type.toUpperCase()}`,
			"view" 		: view,
			"data" 		: {
                time        : time.toLocaleString(),
			    type        : body.type,
                number      : task.number,
                shortName   : project.shortName,
                projectName : project.name,
                subType     : body.subType,
                member,
            }
		});
    }],
], {name: "task", IgnoreSanitized: true } ]);

PipeRoute.PIPE.push([["/taskDelete"], [
    [`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
        var A = pipeData.A;
		var body = Req.body;
        var task =  body.task;

        var query = { _id: { $in: [...task.assigneeIds, ...task.testerIds, ...task.reviewerIds, ...task.watcherIds] } };
        var users = await A.aggregate(Req, body, "user", { $match: query });

        if(!users || !users.length) {
            return UNRESULT;
        }
        var time = new Date();

        await A.sendMail(Req, pipeData, {
			"to" 		: users.map(x => x.email),
			"subject" 	: `[${Req.project.name}] [Task-${task.number}] DELETE`,
			"view" 		: 'deleteTask',
			"data" 		: {
                time    : time.toLocaleString(),
                number  : task.number,
            }
		});
    }],

], {name: "taskDelete"} ]);

PipeRoute.PIPE.push([["/taskMoreAction"], [
	`A.sendData(*) > pipeTaskMoreActionData: PURGE: @(K.API.SvrIntFile + '/taskmoreaction'):
		@P.body: { "user-token": "@(P.header['user-token'])" }`
], {name: "taskMoreAction"} ]);

PipeRoute.PIPE.push([["/taskChangeGroup"], [

], {name: "taskChangeGroup"} ]);

PipeRoute.PIPE.push([["/taskLock"], [

], {name: "taskLock"} ]);

PipeRoute.PIPE.push([["/taskAddUser"], [

], {name: "taskAddUser"} ]);


// ----------------------- Wiki -----------------------
PipeRoute.PIPE.push([["/wiki"], [

], {name: "wiki"} ]);

PipeRoute.PIPE.push([["/wikiUpdate"], [

], {name: "wikiUpdate"} ]);

PipeRoute.PIPE.push([["/wikiDelete"], [

], {name: "wikiDelete"} ]);


// ----------------------- Milestone -----------------------
PipeRoute.PIPE.push([["/milestone"], [

], {name: "milestone"} ]);


// ----------------------- Checkin -----------------------
PipeRoute.PIPE.push([["/checkin"], [ // It means submit
	`A.sendMail(*) > tmpMail: ({
		"to" 		: "@Req.user.email",
		"subject" 	: "[Checkin] {{P.user.name}} just {{P.body.action}}.",
		"view" 		: "checkin",
		"data" 		: {
			time: "@P.body.time",
			hour: "@P.body.hour",
			type: "@P.body.action",
			comeLateHour: "@P.body.comeLateHour",
			backEarlyHour: "@P.body.backEarlyHour",
		}
	})`,
	`A.logActivity(*):: checkin: @P.body.action: :: ' at {{P.body.time}}'`,
], {name: "checkin"} ]);

// ----------------------- Logtime -----------------------
PipeRoute.PIPE.push([["/logtime"], [ // It means submit
	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		// Use for refactor data
		var p = (Req.deletedItem || Req.popBody) || (Req.body || {});

		if(!p || !p._id) {
			return {
				respCode: 500,
				respData: "Internal problem!",
				respReturn: true,
			};
		}

		Req.popBody = { ...p, number: p.number-0, hour: p.hour-0, taskId: p.taskId };
		return Req.UNRESULT;
	}],

	//`A.printObject(*): P.popBody: P.body`,
	//`A.printObject(*): P.popBody: P.deletedItem`,

	`A.sendMail(*) > tmpMail: ({
		"to" 		: "@Req.user.email",
		"subject" 	: "[Logtime] {{P.user.name}} created logtime #{{P.popBody.number}}, effort {{P.popBody.hour}} hours.",
		"view" 		: "logtime",
		"data" 		: {
			body: "@P.popBody",
			type: "@P.body.action"
		}
	})`,

	// colName, type, subType, refId, refNum, content, oldContent, userId, projectId, milestoneId, taskId
	`A.logActivity(*):: logtime: @P.body.action: @P.popBody._id: @P.popBody.number: ' which {{P.popBody.hour}} hours' ::::: @P.popBody.taskId`,
], {name: "logtime"} ]);

// ----------------------- Document -----------------------
PipeRoute.PIPE.push([["/documentCreate"], [ // It means submit

], {name: "documentCreate"} ]);

PipeRoute.PIPE.push([["/documentDelete"], [ // It means submit

], {name: "documentDelete"} ]);


// ----------------------- Testcase -----------------------
PipeRoute.PIPE.push([["/testcase"], [ // It means submit

], {name: "testcase"} ]);


// ----------------------- Post API -----------------------
PipeRoute.PIPE.push([["/postapi"], [ // It means submit

], {name: "postapi"} ]);

PipeRoute.PIPE.push([["/postenv"], [

], {name: "postenv"} ]);

PipeRoute.PIPE.push([["/postflow"], [

], {name: "postflow"} ]);

PipeRoute.PIPE.push([["/postresult"], [

], {name: "postresult"} ]);


// ----------------------- Performance -----------------------
PipeRoute.PIPE.push([["/performance"], [ // It means submit

], {name: "performance"} ]);

PipeRoute.PIPE.push([["/penalty"], [ // It means submit

], {name: "penalty"} ]);

// ----------------------- Risk -----------------------
PipeRoute.PIPE.push([["/risk"], [ // It means submit

], {name: "risk"} ]);

PipeRoute.PIPE.push([["/riskUpdate"], [

], {name: "riskUpdate"} ]);

PipeRoute.PIPE.push([["/riskDelete"], [

], {name: "riskDelete"} ]);


// ----------------------- Change Log -----------------------
PipeRoute.PIPE.push([["/changelog"], [ // It means submit

], {name: "changelog"} ]);


// ----------------------- Cost -----------------------
PipeRoute.PIPE.push([["/cost"], [ // It means submit

], {name: "cost"} ]);


// ----------------------- Mission -----------------------
PipeRoute.PIPE.push([["/mission"], [ // It means submit

], {name: "mission"} ]);


// ----------------------- Source Code -----------------------
PipeRoute.PIPE.push([["/sourcecodeCreate"], [ // It means submit

], {name: "sourcecodeCreate"} ]);

PipeRoute.PIPE.push([["/sourcecodeUpdate"], [

], {name: "sourcecodeUpdate"} ]);

PipeRoute.PIPE.push([["/sourcecodeDelete"], [

], {name: "sourcecodeDelete"} ]);

PipeRoute.PIPE.push([["/sourcecodeCommit"], [

], {name: "sourcecodeCommit"} ]);

PipeRoute.PIPE.push([["/sourcecodeAddUser"], [

], {name: "sourcecodeAddUser"} ]);

PipeRoute.PIPE.push([["/sourcecodeLock"], [

], {name: "sourcecodeLock"} ]);

PipeRoute.PIPE.push([["/sourcecodeProtect"], [

], {name: "sourcecodeProtect"} ]);

PipeRoute.PIPE.push([["/sourcecodeCICD"], [

], {name: "sourcecodeCICD"} ]);

// ----------------------- Meeting -----------------------
PipeRoute.PIPE.push([["/addMeetingReminder"], [
	
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		// console.log('Req >>', Req);
		// console.log('pipeData >>', pipeData);
		// console.log('ctx >>', ctx);

		var A = pipeData.A;
		var body = Req.body || {};
		var meetingObj = body.respData || body.updateDb || body;
		// console.log('ctx >>', body.members);
		// console.log('list User >>', body.db2.members);
		
		if(!meetingObj._id) {
			meetingObj = Req.route;
		}

		var modelName = "Main.mailReminder";
		
		await A.deleteById(Req, pipeData, modelName, {
			refCompanyId: Req.company._id,
			refModel: "meeting",
			refId: meetingObj._id,
		}, true, true);

		if(Req.method.toUpperCase() != 'DELETE') {
			var data = {
				refCompanyId: Req.company._id,
				refModel: "meeting",
				refId: meetingObj._id,
				refNumber: meetingObj.number,
				title: 	meetingObj.title,
				date: meetingObj.startDate,
				listEmails: body?.db2?.members || [Req.user.email],
				startDate: meetingObj?.startDate,
				remindBefore: meetingObj?.remindBefore + ""
			};

			await A.insertById(Req, pipeData, modelName, data);
			
			//console.log("Date: ", data.date, new Date(data.date));
			var newDate = new Date((new Date(data.date)).getTime() - (meetingObj.remindBefore || 15)*60*1000);
			data.date = newDate;
			data.type = 'remind';
			await A.insertById(Req, pipeData, modelName, data);
		}

		return Req.UNRESULT;
	}],

], {name: "addMeetingReminder"} ]);


// ----------------------- Reminder -----------------------
PipeRoute.PIPE.push([["/addReminderReminder"], [
	
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};
		var reminderObj = body.reminderDb || body;

		if(!reminderObj._id) {
			reminderObj = Req.route;
		}

		console.log('reminderObj >>>', reminderObj);

		var modelName = "Main.mailReminder";
		
		await A.deleteById(Req, pipeData, modelName, {
			refCompanyId: Req.company._id,
			refModel: "reminder",
			refId: reminderObj._id,
		}, true, true);

		if(Req.method.toUpperCase() != 'DELETE') {
			var data = {
				refCompanyId: Req.company._id,
				refModel: "reminder",
				refId: reminderObj._id,
				refNumber: reminderObj?.number,
				title: 	reminderObj?.title,
				date: reminderObj?.date,
				listEmails: [...(reminderObj?.userEmails||[]), Req.user.email],
				remindBefore: reminderObj?.remindBefore + ""
			};

			await A.insertById(Req, pipeData, modelName, data);
			
			//console.log("Date: ", data.date, new Date(data.date));
			var newDate = new Date((new Date(data.date)).getTime() - (reminderObj.remindBefore || 15)*60*1000);
			data.date = newDate;
			data.type = 'remind';
			await A.insertById(Req, pipeData, modelName, data);
		}

		return Req.UNRESULT;
	}],

], {name: "addReminderReminder"} ]);




module.exports = PipeRoute;
