const WorkSchedulingRoute = {
	route	: "work",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["working"],
		roleUserIdKey	: "userId"
	}
};

WorkSchedulingRoute.POST.push([["inspecting/full"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: working.view`,

	[`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body;
		body.userId = Req.user._id;

		var memberIds = (body.memberId || body.memberIds) ||
						(body.member || body.members);
		if(memberIds && !Array.isArray(memberIds)) {
			memberIds = [memberIds];
		}
		body.memberIds = memberIds;

		var name = (body.name || body.search) || (body.text || "");
		body.name = Req.func.getASCIISearch(name, "gmi");

		var date = (body.date || body.dayString) || (body.startDate || body.fromDate) || new Date();
		date = await A.convertToLocalTime(Req, pipeData, date);
		body.date = `${date.getFullYear()}-${("0"+(date.getMonth()+1)).substr(-2)}-${("0"+date.getDate()).substr(-2)}`;

		body.lastDate = new Date((new Date()).getTime() - 60 * 1000);

		return Req.UNRESULT;
	}],

	//`A.printObject`,
	`A.getPaginate > page`,
	[`A.aggregateOne: user:`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $in: ["$_id", "@memberIds"]},
				{ $in: ["@memberIds", [null, undefined, 0, "", []]]}
			]},
			{ $regexMatch: { input: "$name", regex: "@name" }},
			//{ $eq: ["$hasUpdated", true] },

			{ $not: [{$in: ["$hasActived", [false]] }]},
			{ $not: [{$in: ["$hasDeleted", [true]] }]},
			{ $not: [{$in: ["$hasLocked", [true]] }]},
		]}}},
		{ $sort: {
			name$: 1
		}},
		{ $getTotalLength: "@page" },

		// Get Capture information
		{ $lookup: {
			from: "working",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$userId", "$$userId"] },
					{ $eq: ["$dayString", "@date"] },
				]}}},
				{ $addFields: {
					//lastShoot: { $last: "$shoots" }
					lastShoot: { $arrayElemAt: [ "$shoots", -1 ] },
					totalFrame: { $size: "$shoots" },
					totalApp: { $size: "$apps" },
					//length: { $sum: "$shoots.length" },
					length: { $reduce: {
						input: "$shoots",
						initialValue: 0,
						in: { $sum : ["$$value", "$$this"] }
					}}
				}},
				{ $addFields: {
					duration_op$: "$totalFrame * 30",
					status: { $cond: [{$gte: ["$lastShoot.date", "@lastDate"]}, true, false]}
				}},
				{ $project: {
					_id: 0
				}},
				{ $project: {
					lastShoot: 1,
					totalFrame: 1,
					totalApp: 1,
					length: 1,
					duration: 1,
					status: 1,
				}}
			],
			as: "capture"
		}},
		{ $unwind: {
			path: "$capture",
			preserveNullAndEmptyArrays: true
		}},
		{ $addFields: {
			capture: { $ifNull: ["$capture", {}]}
		}},
		{ $addFields: {
			"capture.hasUpdated": { $ifNull: ["$hasUpdated", false]}
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			email: 1,
			userId: 1,
			avt: 1,

			capture: 1,
			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "users"] }
	]],
], {useZip: true}]);

WorkSchedulingRoute.POST.push([["inspecting/update/:userId/:status:(/(updated|unupdated)$/)"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: working.view, working.modify`,
	`A.verifyKObject(P.route):: userId!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    //`A.pipeRoute: checkadmin`,
    `A.updateOne(*) > P.updatedUser: user: {_id: "@P.route.userId"}: {"hasUpdated": "@(P.route.status==='updated'?true:false)"}`,

	//`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Update member inspecting successfully!`
]]);

WorkSchedulingRoute.POST.push([["scheduling/full"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: working.view`,

	//`A.fillingDateWorking:: startDate: endDate: 720`, // 1 month ~ 30 days ~ 720 hours
	[`A.jsScript(*)::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var user = Req.user;

		//const content = pipeData.content || pipeData.search;
		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

		var groupIds = (body.groupId || body.groupIds) ||
 					  (body.group || body.groups);

		var projectIds = (body.projectId || body.projectIds) ||
						 (body.project || body.projects);

		var memberIds = (body.memberId || body.memberIds) ||
 						(body.member || body.members);

		var name = (body.name || body.search) || (body.text || "");
		name = Req.func.getASCIISearch(name, "gmi");

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
		}

		if(groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}
		}

		if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds];
			}
		}

		if(!fromDate) {
			fromDate = new Date((new Date()).getTime() - 7*86400000);

		} else {
			fromDate = new Date(fromDate);
		}

		if(!toDate) {
			toDate = new Date(fromDate.getTime() + 21*86400000);

		} else {
			toDate = new Date(toDate);
		}

		if(!user.hasAgent || !user.hasAdmin) {
		}

		body.groupIds = groupIds || [];
		body.memberIds = memberIds || [];
		body.projectIds = projectIds || [];
		body.startDate = fromDate;
		body.endDate = toDate;
		body.name = name;

		body.scale = body.scale || 1.0;
		body.paddingWeek = body.scale > 1 ? 14 : 4;

        return Req.UNRESULT;
    }],

	//`A.printObject`,
	`A.getPaginate > page`,
	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $or: [
							{ $in: ["$_id", "@groupIds"] },
							{ $in: ["$shortName", "@groupIds"] },
							{ $in: ["@groupIds", [[], undefined, false, null]] }
						]},
						{ $or: [
							//{ $eq: ["$projectId", "@projectId"] }, // all projejct
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupIds: "$groups._id"
		}},

		{ $lookup: {
			from: "user",
			let: {
				groupIds: "$groupIds",
				groups: "$groups"
			},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $in: ["@memberIds", [null, undefined, 0, []]]},
						{ $in: ["$_id", "@memberIds"] },
					]},

					{ $not: [{$in: ["$hasActived", [false]] }]},
					{ $not: [{$in: ["$hasDeleted", [true]] }]},
					{ $not: [{$in: ["$hasLocked", [true]] }]},
					{ $eq: ["$status", 1] }
				]}}},
				{ $sort: {
					name$: 1,
					name$: 1,
				}},
				{ $getTotalLength: "@page" },

				{ $lookup: {
					from: "project",
					let: {
						userId: "$_id",
						groups: "$$groups",
						groupIds: "$$groupIds"
					},
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $in: ["$$userId", "$members.user"]},
							{ $eq: ["$status", 1] },
							{ $or: [
								{ $in: ["@projectIds", [null, undefined, 0, []]]},
								{ $in: ["$_id", "@projectIds"]},
							]},
							// { $and: [
							// 	{ $gte: ["$dueDate", "@startDate"] },
							// 	{ $lte: ["$startDate", "@endDate"] }
							// ]},
						]}}},
						{ $sort: {
							startDate: 1,
							dueDate: 1,
						}},
						{ $limit: "@page.pageLength" },
						// { $project: {
						// 	_id: 1,
						// 	name: 1,
						// 	name2: 1,
						// 	avt: 1,
						// 	shortName: 1,
						// 	startDate: 1,
						// 	dueDate: 1,
						// }},

						// Add Task into project
						{ $lookup: {
							from: "task",
							let: {
								projectId: "$_id",
								userId: "$$userId",
								groups: "$$groups",
								groupIds: "$$groupIds"
							},
							pipeline: [
								{ $match: { $expr: { $and: [
									{ $eq: ["$projectId", "$$projectId"]},
									{ $or: [
										{ $in: ["$groupId", "$$groupIds"] },
										{ $in: ["@groupIds", [[], undefined, false, null]] }
									]},
									{ $or: [
										{ $in: ["$$userId", "$assigneeIds"]},
										{ $in: ["$$userId", "$testerIds"]},
										{ $in: ["$$userId", "$reviewerIds"]},
									]},
									{ $regexMatch: { input: "$name", regex: "@name" }},
									{ $and: [
										{ $gte: ["$dueDate", "@startDate"] },
										{ $lte: ["$startDate", "@endDate"] }
									]},
								]}}},
								{ $sort: {
									startDate: 1,
									dueDate: 1,
								}},
								{ $limit: "@page.pageLength" },

								{ $addFields: {
									statusObj: { $arrayElemAt: [
										"$$groups",
										{ $indexOfArray: ["$$groupIds", "$groupId"] },
									]},
								}},
								{ $addFields: {
									status: "$statusObj.value",
									hasTaskDone: { "$cond": [{ $eq:["$statusObj.shortName", "done"] }, 1, 0] },
									duration: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000]},
									complete: { $cond: [
										{ $or: [
											{ $eq:["$statusObj.shortName", "done"] },
											{ $gte:[{ $ifNull: ["$doneTodo", 0]}, 100] }
										]},
										100,
										{ $multiply: [{$divide: [{$ifNull: ["$doneTodo", 0]}, {$max: ["$totalTodo", 1]}]}, 100]},
									]},
								}},
								//{ $convertDate: ["startDate -> startDateLocal", "dueDate -> dueDateLocal"]},
								{ $project: {
									_id: 1,
									name: 1,
									name2: 1,
									type: 1,
									number: 1,
									status: 1,
									priority: 1,
									duration: 1,
									startDate: 1,
									//startDateLocal: 1,
									dueDate: 1,
									//dueDateLocal: 1,
									hasTaskDone: 1,
									complete: 1,
									isLock: 1,
								}},
							],
							as: "tasks"
						}},
						{ $match: { $expr: { $and: [
							{ $gt: [{$size: "$tasks"}, 0] }
						]}}},

						// Calulate duration, status, completed
						{ $addFields: {
							countTask: { $size: "$tasks" },
							countTaskDone: { $sum: "$tasks.hasTaskDone" },
							duration: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000]},
						}},
						{ $addFields: {
							countTaskOps: { $cond:[ {$lte: ["$countTask", 1]}, 1, "$countTask" ]}
						}},
						{ $addFields: {
							complete_op$: "($countTaskDone / $countTaskOps) * 100",
							//complete: { $multiply: [{$divide: ["$countTaskDone", {$cond:[{$lte: ["$countTask", 1]}, 1, "$countTask"]}]}, 100]},
							//countTask: { $sum: "$tasks.countTask" },
							//countTaskDone: { $sum: "$tasks.countTaskDone" },
						}},
						//{ $convertDate: ["startDate -> startDateLocal", "dueDate -> dueDateLocal"]},
						{ $project: {
							_id: 1,
							name: 1,
							name2: 1,
							avt: 1,
							number: 1,
							shortName: 1,
							duration: 1,
							complete: 1,
							countTask: 1,
							countTaskDone: 1,
							startDate: 1,
							//startDateLocal: 1,
							dueDate: 1,
							//dueDateLocal: 1,
							tasks: 1,
							countTask: 1,
							countTaskDone: 1,
						}}
					],
					as: "projects"
				}},
				{ $match: { $expr: { $and: [
					{ $gt: [{$size: "$projects"}, 0] }
				]}}},

				{ $addFields: {
					countTask: { $sum: "$projects.countTask" },
					countTaskDone: { $sum: "$projects.countTaskDone" },
				}},

				// Filter to keep user that has project item
				{ $project: {
					_id: 1,
					avt: 1,
					name: 1,
					name2: 1,
					userId: 1,
					projects: 1,
					totalLength: 1,
					countTask: 1,
					countTaskDone: 1,
				}},
				{ $groupTotalLength: ["@page", "totalLength", "users"]},
			],
			as: "workings"
		}},
		{ $project: {
			workings: 1,
		}},
		{ $unwind: {
			path: "$workings",
			preserveNullAndEmptyArrays: true,
		}}
	]],

	//`A.printObject:`,
	`A.moveKObject:: dbData.workings, dbData`,
	//`A.printObject:`,

	`A.getKObject > allProjects:: dbData.users.projects`,
	`A.getKObject > allTasks:: dbData.users.projects.tasks`,

	// arrs, weekBoundary=false, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false, keyPaths
	`A.dateMinMax > dbDateProjects: @allProjects: true:: true: true: @paddingWeek: startDate, dueDate`,
	// //`A.printObject: dbDateProjects`,
	`A.dateMinMax > dbDateTasks: @allTasks: true:: true: true: @paddingWeek: startDate, dueDate`,
	//`A.printObject: dbDateTasks`,
	`A.dateMinMax > dbDate: ["@dbDateTasks", "@dbDateProjects"]: true:: true: true: @paddingWeek: minDate, maxDate`,
	//`A.printObject:dbDate`,

	//`A.convertToLocalTime > dbDate.minDateLocal: @dbDate.minDate`,

	// arrs, startDate, scale=1.0, adjust=0.0, toLocalTime=false, ...keyPaths
	`A.dateFillDayIndex: @allProjects: @dbDate.minDate: @scale:: true: startDate, startIndex, dueDate, endIndex`,
	`A.dateFillDayIndex: @allTasks: @dbDate.minDate: @scale:: true: startDate, startIndex, dueDate, endIndex`,

	//`A.printObject:`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var DateUtil = pipeData.U.Date;

		var body = Req.body || {};
		var dbData = body.dbData || {};
		var users = dbData.users || [];
		var page = dbData.page || {};

		var date = body.dbDate;
		var scale = body.scale || 1.0;

		var width = body.width || 1024;
		var totalDay = date.totalDay || 0;

		var minDate = date.minDate || new Date();
		var maxDate = date.maxDate || new Date();

		if(!date.minDate) {
			minDate = new Date(minDate.getTime() - minDate.getDay()*86400000);
		}

		//console.log("------------------- 1");
		var maxWeek = date.maxWeek;
		if(!maxWeek && maxWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, 1, true);
			maxWeek = rw.week || 0;
		}

		var minWeek = date.minWeek;
		if(!minWeek && minWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, true, true);
			minWeek = rw.week || 0;
		}

		//console.log("------------------- 2");
		var week = Math.ceil(width / (body.itemWidth||336));
		var nWeek = week - (maxWeek - minWeek);
		if (nWeek > 0) {
			nWeek = Math.max(nWeek, 1);
			totalDay += (nWeek * 7);

			maxWeek += (nWeek);
			//minWeek += (-1);

			maxDate = new Date(maxDate.getTime() + (nWeek)*7*86400000);
			//minDate = new Date(minDate.getTime() + (-1)*7*86400000);
		}

		date.maxWeek = maxWeek;
		date.minWeek = minWeek;

		date.maxDate = maxDate;
		date.minDate = minDate;

		//console.log("------------------- 3");
		//console.log("Max: ", maxDate, maxDate.getDay(), body.dbDate1);
		//date.todayIndex = td;
		date.totalDay = Math.ceil(totalDay / scale);
		DateUtil.getUpdateTodayMonthList(Req, pipeData, date, scale);

		//console.log("local Start: ", localStart, localEnd);

		var summary = {
			budget: 0,

			//countTodo: 0,
			//countDoneTodo: 0,

			countTask: 0,
			countTaskDone: 0,

			duration: 0,
		};

		var tz = DateUtil.getCompanyTimeZone(Req);
		var objComponent = DateUtil.companyTimePoint(Req, pipeData);

		//console.log("------------------- 4", users);
		for (var i = 0; i < users.length; i++) {
			var user = users[i];
			user.itemType = "user";

		//}
		//users = users.map(async (user) => {
			// remove unused data
			user.duration = (user.duration || 0);

			var projects = user.projects || [];
			for (var j = 0; j < projects.length; j++) {
				var project = projects[j];
				project.itemType = "project";

			//}
			//user.projects = (user.projects||[]).map(async (project) => {
				//console.log("------------------- 5");
				var rs1 = await DateUtil.calendarWorkingDay(Req, project, project.startDate, project.dueDate, [], true, false, false, false, objComponent, tz);
				project.duration = (rs1 / 8.0).toFixed(1)-0;
				//user.duration += rs1;

				project.startIndex = Math.max(project.startIndex, 0);
				project.endIndex = Math.min(Math.max(project.endIndex, 0), date.totalDay-1);

				project.complete = (project.complete||0.0).toFixed(1)-0;
				delete project.startDateLocal;
				delete project.dueDateLocal;

				var tasks = project.tasks || [];
				for (var k = 0; k < tasks.length; k++) {
					var task = tasks[k];
					task.itemType = "task";
					task.projectId = project._id;
				//}
				//project.tasks = (project.tasks||[]).map(async (task) => {
					var rs2 = await DateUtil.calendarWorkingDay(Req, task, task.startDate, task.dueDate, [], true, false, false, false, objComponent, tz);
					task.duration = (rs2 / 8.0).toFixed(1)-0;
					task.complete = (task.complete||0.0).toFixed(1)-0;

					user.duration += rs2;

					//delete task.startDateLocal;
					//delete task.dueDateLocal;

					//console.log("Task duration: ", task.name, task.duration, rs2, task);
					//return task;
				}

				//return project;
			}
			//console.log("------------------- 6");

			//summary.budget += user.budget;

			//console.log("ms: ", user);
			summary.countTask += user.countTask;
			summary.countTaskDone += user.countTaskDone;

			//summary.countTodo += user.countTodo;
			//summary.countDoneTodo += user.countDoneTodo;

			summary.duration += user.duration;
			//summary.passedDay += user.passedDay;
			//summary.remainingDay += user.remainingDay;

			//return user;
		}

		// Format number of digit
		summary.duration = summary.duration.toFixed(1)-0;

		//body.date = date;
		//body.summary = summary;

		return { users, page, summary, date };
	}],

	//`A.printObject`,
	//`A.responseObject: 200: {"users": "@dbData", "date": "@dbDate"}`
], {useZip: true}]);

module.exports = WorkSchedulingRoute;
