const TestCaseRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.testcase",
        checkMIFs		: ["project", "testcase"],
		imProject		: true,
    }
};

TestCaseRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: testcase: projectId!, number-, title!, ...`,
    `A.insertOne(*): testcase: @P.body`,
    // `A.insertOne: testcasecomment: {
    //     ({"projectId" : "@projectId", "testcaseId" : "@_id"})
    // }`,

	`A.pipeRoute: testcase: { type: "create" }`,
	`A.pipeRoute: featureUpdateRelatedItem`,
    `A.refactorOutput`,
]]);

TestCaseRoute.GET.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	[`A.aggregateOne(*): testcase:`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		//{ $populateFilter: ["group", "groupId:_id", "group", true, 1, "_id", "name", "name2",]},
		//{ $populateFilter: ["label", "labelIds$:_id", "labels", undefined, 1, "_id", "name", "name2", "color"]},
	]],
]]);

TestCaseRoute.POST.push([["/clone/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	[`A.aggregateOne(*): testcase:`, [
		{ $match: {
			projectId: "@P.project._id",
			_id: "@P.route._id",
		}},
	]],

	`A.verifyInput:: testcase: _id-, number-, creatorId-, createdAt-, modifierId-, modifiedAt-, ...`,
	`A.insertOne: testcase`
]]);

TestCaseRoute.POST.push([["/select"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqBody:: testcase: groupId, projectId, featureId`,

	[`A.aggregate(*): testcase`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@P.project._id"] },
			// { $or: [
			// 	{ $in: ["$featureId", ['', undefined, null, 0, [], false]] },
			// 	{ $not: [{ $in: ["$featureId", ["@P.body.reqBody.featureId"]] }] },
			// ]}
		]}}},
		{ $project: {
			_id: 1,
			number: 1,
			title: 1,
			title2: 1,
		}}
	]],

	// `A.findMany: testcase: @reqBody`,
	// `A.refactorOutput:: _id, number, title, title2`,
]]);

TestCaseRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];

        var projectIds = pipeData.projectId || pipeData.projectIds;
		var groupIds = pipeData.groupId || pipeData.groupIds;
		var labelIds = pipeData.labelId || pipeData.labelIds;

		var startDate = pipeData.fromDate || pipeData.startDate;
		var endDate = pipeData.toDate || pipeData.endDate;
		var title = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds } });
			}
		}

		if(groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}
			if(groupIds.length > 0) {
				ops.push({ groupId: { $in: groupIds } });
			}
		}

		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				ops.push({ labelIds: { $elemMatch: { $in: labelIds }}});
			}
		}

		if(startDate) {
			ops.push({ createdAt: { $gte: new Date(startDate) } });
		}

		if(endDate) {
			ops.push({ createdAt: { $lte: new Date(endDate) } });
		}

        if(title) {
            ops.push({ $or: [
				{ title : Req.func.getASCIISearch(title, "gmi") },
				{ number: (title-0) || -1 }
			]});
        }

		if(!ops || ops.length <= 0) {
			pipeData.ops = {};

		} else {
        	pipeData.ops = { $and: ops };
		}

        //console.log(ops);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

    [`A.aggregateOne: testcase`, [
		{ $match: "@ops"},
		{ $sort: {
			number: 1,
			position: 1,
			//priority: -1,
			createdAt: -1,
			modifiedAt: -1,
		}},

		{ $populate: ["group", "groupId", "_id", "group", true]},
		{ $sort: {
            "group.name$": 1,
			//position: 1,
		}},

		{ $getTotalLength: "@page" },

		// Labels
		//{ $populate: ["label", "labelIds", "_id", "labels"]},

		{ $project: {
			_id : 1,
	        title: 1,
			title: 2,
	        content: 1,
			number: 1,
	        condition: 1,
	        result: 1,
	        priority: 1,
	        groupId: 1,

			totalLength: 1,

			// "labels._id": 1,
			// "labels.name": 1,
			// "labels.name2": 1,
			// "labels.color": 1,

			group: 1,
		}},

		{ $group: {
            _id : "$groupId",
            testcases: {
                $push: {
                    _id         : "$_id",
                    number      : "$number",
                    priority    : "$priority",
                    title       : "$title",
                    //content     : "$content",
                    //condition	: "$condition",
                    //labels      : "$labels",
                }
            },
			name: { $first: "$group.name" },
			totalLength: { $first: "$totalLength" }
        }},
		{ $groupTotalLength: ["@page", "totalLength", "testcases"] }
    ]],

    //`A.populate: label, testcases.labels, _id, testcases.labels, +, name, name2, color`
], { useZip: true }]);

TestCaseRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];

        var projectIds = pipeData.projectId || pipeData.projectIds;
		var groupIds = pipeData.groupId || pipeData.groupIds;
		var labelIds = pipeData.labelId || pipeData.labelIds;

		var startDate = pipeData.fromDate || pipeData.startDate;
		var endDate = pipeData.toDate || pipeData.endDate;
		var title = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds } });
			}
		}

		if(groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}
			if(groupIds.length > 0) {
				ops.push({ groupId: { $in: groupIds } });
			}
		}

		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				ops.push({ labelIds: { $elemMatch: { $in: labelIds }}});
			}
		}

		if(startDate) {
			ops.push({ createdAt: { $gte: new Date(startDate) } });
		}

		if(endDate) {
			ops.push({ createdAt: { $lte: new Date(endDate) } });
		}

        if(title) {
            ops.push({ $or: [
				{ title : Req.func.getASCIISearch(title, "gmi") },
				{ number: (title-0) || -1 }
			]});
        }

		if(!ops || ops.length <= 0) {
			pipeData.ops = {};

		} else {
        	pipeData.ops = { $and: ops };
		}

        //console.log(ops);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

    [`A.aggregateOne: testcase`, [
		{ $match: "@ops"},
		{ $sort: {
			number: 1,
			position: 1,
			//priority: -1,
			createdAt: -1,
			modifiedAt: -1,
		}},

		{ $populateFilter: ["group", "groupId:_id", "group", true, 1, "_id", "name", "name2"]},
		{ $addFields: {
			group: {
				_id: { $ifNull: ["$group._id", ""]},
				name: { $ifNull: ["$group.name", ""]},
			}
		}},
		{ $sort: {
            "group.name$": 1,
			//position: 1,
		}},

		{ $getTotalLength: "@page" },

		// Labels
		{ $populate: ["label", "labelIds", "_id", "labels"]},

		{ $project: {
			_id : 1,
	        title: 1,
			title2: 1,
	        content: 1,
			number: 1,
	        condition: 1,
	        result: 1,
	        priority: 1,
	        groupId: 1,

			totalLength: 1,

			"labels._id": 1,
			"labels.name": 1,
			"labels.name2": 1,
			"labels.color": 1,

			group: 1,
		}},

		{ $group: {
            _id : "$group._id",
            testcases: {
                $push: {
                    _id         : "$_id",
                    number      : "$number",
                    priority    : "$priority",
                    title       : "$title",
                    content     : "$content",
                    condition	: "$condition",
                    labels      : "$labels",
                }
            },
			name: { $first: "$group.name" },
			totalLength: { $first: "$totalLength" }
        }},
		{ $sort: {
            "name$": 1,
			//position: 1,
		}},
		{ $groupTotalLength: ["@page", "totalLength", "testcases"] }
    ]],

    //`A.populate: label, testcases.labels, _id, testcases.labels, +, name, name2, color`
], {useZip: true}]);

TestCaseRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: testcase: colIndex, groupId, projectId!`,

	`A.updateById(*) > testcaseDb : testcase: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update test case successfully!`
]]);

TestCaseRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: testcase: projectId!, number-, ...`,

    `A.updateById(*): testcase: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.reqBody`,

	`A.pipeRoute: testcase: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

TestCaseRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: testcase.view, testcase.delete`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.deleteOne(*): testcase: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: testcase: { type: "delete" }`,
	`A.responseObject(*): 200: Delete successfully!`,
]]);

// TestCaseRoute.POST.push([["/:_id/label"], [
// 	`A.insertSubItem(*) > labelId: testcase: @P.route._id: labelIds: @P.body.labelIds`,
//     `A.populate: label, labelId, _id, label, +, name, name2, color`,
//     `A.refactorOutput:: label`
// ]]);
//
// TestCaseRoute.PUT.push([["/:_id/label"], [
//     `A.removeSubItem(*): testcase: @P.route._id: labelIds: @P.body.labelIds[0]`,
//
// ]]);

module.exports = TestCaseRoute;
