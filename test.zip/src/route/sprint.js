const SprintRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.sprint",
        checkMIFs		: ["project", "sprint"],
		imProject		: true,
    }
};

SprintRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: sprint.view, sprint.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.printObject`,
	`A.fillingDateWorking:: startDate: dueDate: 80`, // 80h => 10 days
    `A.verifyInput:: sprint: name!, name2, projectId!, milestoneId!, color, startDate, dueDate`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;

		body.startDate = new Date(body.startDate || new Date());
		body.dueDate = new Date(body.dueDate || ((new Date()).getTime() + 86400000));

		// For year maximum
		var y = body.startDate.getFullYear();
		if(body.dueDate.getFullYear() - y > 2) {
			body.dueDate.setFullYear(y + 1);
		}

		if((body.dueDate - body.startDate) / 86400000 > 720) {
			return {
				respData: "Sprint duration should be around 720 days",
				respReturn: true,
				respCode: 500
			};
		}

		return Req.UNRESULT;
	}],

    `A.insertOne: sprint`,

	`A.pipeRoute: sprint: { type: "create" }`,
    `A.refactorOutput:: _id, name, name2, number, color, descr, status, startDate, dueDate`
]]);

SprintRoute.POST.push([["/s"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: sprint.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    //`A.verifyInput > reqBody:: sprint: projectId!`,

    //`A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var ops = {};
		ops.projectId = Req.project._id;

 		var milestoneIds = (body.milestoneId || body.milestoneIds) || (body.milestone || body.milestones);
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				ops.milestoneId = { $in: milestoneIds };
			}
		}

		var name = body.name || "";
		if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops["$or"] = [
				{ name: nameReg },
				{ name2: nameReg },
				{ number: (name-0) || -1 }
			];
        }

        body.ops = ops;
        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	[`A.aggregate: sprint:`, [
		{ $match: "@ops" },
		{ $limit: 1000 },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			number: 1,
			colIndex: 1,
            milestoneId: 1,
		}},

		{ $sort: {
			colIndex: 1,
			createdAt: 1,
			name$: 1
		}},
	]],

	//`A.printObject:`,

]]);

SprintRoute.POST.push([["full/s"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: sprint.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    //`A.verifyInput > reqBody:: sprint: projectId!`,

    //`A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var ops = [];
		var milestoneOps = [];
		var status = body.statusIds || body.statuses || body.status || [];

        ops.push({ $eq: ["$projectId", Req.project._id] });
		ops.push({ $eq: ["$milestoneId", "$$milestoneId"] });

		milestoneOps.push({$eq: ["$projectId", Req.project._id]});

		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

        if(fromDate) {
			fromDate = new Date(fromDate);
			ops.push({ $gte: ["$dueDate", fromDate] });
			milestoneOps.push({ $gte: ["$endDate", fromDate] });
        }

		if(toDate) {
			toDate = new Date(toDate);
			ops.push({ $lte: ["$startDate", toDate] });
			milestoneOps.push({ $lte: ["$startDate", toDate] });
        }

 		var milestoneIds = (body.milestoneId || body.milestoneIds) || (body.milestone || body.milestones);
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				//ops.push({ $in: ["$milestoneId", milestoneIds] });
				milestoneOps.push({$in: ["$_id", milestoneIds]});
			}
		}

		var orMilestoneNames = [];
		var name = (body.name || body.search) || (body.text || "");
		if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({"$or": [
				{ $regexMatch: { input: "$name", regex: nameReg }},
				{ $regexMatch: { input: "$name2", regex: nameReg }},
				{ $eq: ["$number", (name-0) || -1 ]},
			]});

			orMilestoneNames = [
				{ $regexMatch: { input: "$name", regex: nameReg }},
				{ $eq: ["$number", (name-0) || -1] },
			];
        }

		body.status = status;
        body.ops = { $expr: { $and: ops }};
		body.milestoneOps ={ $expr: { $and:  milestoneOps }};
		body.orMilestoneNames = orMilestoneNames;
		body.keepMilestone = (!milestoneIds || milestoneIds.length<=0) && (!name || name.length <= 0);

		body.scale = body.scale || 1.0;
		body.paddingWeek = body.scale > 1 ? 14 : 4;

        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	[`A.aggregate > dbData: milestone:`, [
		{ $match: "@milestoneOps" },

		{ $lookup: {
			from: "sprint",
			let: { milestoneId: "$_id" },
			pipeline: [
				{ $match: "@ops" },
				{ $limit: 200 },

				// Get all feature and calculate complete
				{ $lookup: {
					from: "feature",
					let: { sprintId: "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$sprintId", "$$sprintId"]},
							{ $or: [
								{$in: ["$status", [null, undefined, '', [] ]]},
								{$in: ["$status", "@status"]},
							]}
						]}}},
						{ $addFields: {
							hasFeatureDone: { $cond: [
								{$in: ["$status", [2]]},
								1,
								0
							]}
						}},
						{ $project: {
							_id: 0
						}},
						{ $project: {
							hasFeatureDone: 1,
						}}
					],
					as: "features"
				}},
				{ $addFields: {
					totalFeature: { $size: "$features" },
					featureComplete: { $sum: "$features.hasFeatureDone" },
				}},
				{ $addFields: {
					totalFeatureOps: { $max: ["$totalFeature", 1] }
				}},

				{ $addFields: {
					complete_op$: "(($featureComplete / ($totalFeatureOps ?max 1)) * 100.0) ?fixed 0"
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
					number: 1,
					startDate: 1,
					dueDate: 1,
					colIndex: 1,
					status: 1,
					complete: 1,
					totalFeature: 1,
					featureComplete: 1,
					milestoneId: 1,
				}},

				{ $addFields: {
					expanded: true,
					itemType: "sprint",
				}},

				{ $sort: {
					colIndex: 1,
					createdAt: 1,
					name$: 1
				}},
			],
			as: "sprints"
		}},

		{ $addFields: {
			sprintCount: { $size: "$sprints" }
		}},

		// Filter Milestone
		{ $match: { $expr: { $or: [
			{ $or: "@orMilestoneNames" },
			{ $eq: ["@keepMilestone", true] },
			{ $gt: ["$sprintCount", 0] },
		]}}},

		// Group by milestone
		{ $addFields: {
			totalFeature: { $sum: "$sprints.totalFeature" },
			featureComplete: { $sum: "$sprints.featureComplete" },
		}},

		{ $addFields: {
			itemType: "milestone",
			complete_op$: "($featureComplete / ($totalFeature ?max 1)) ?fixed 0",
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			status: 1,
			number: 1,
			startDate: 1,
			endDate: 1,

			sprints: 1,
			featureComplete: 1,
			totalFeature: 1,
			complete: 1,
			itemType: 1,
		}}
	]],

	//`A.printObject:`,
	`A.dateMinMax > dbDateMs: @dbData: true:: true: true: @paddingWeek: startDate, endDate`, // old save in dbDate1
	`A.dateMinMax > dbDateSp: @dbData.sprints: true:: true: true: @paddingWeek: startDate, dueDate`, // old save in dbDate1

	`A.dateMinMax > dbDate: ["@dbDateMs", "@dbDateSp"]: true:: true: true: @paddingWeek: minDate, maxDate`, // not need this step
	//`A.printObject:`,

	// arrs, startDate, scale=1.0, adjust=0.0, toLocalTime=false, ...keyPaths
	`A.dateFillDayIndex: @dbData: @dbDate.minDate: @scale:: true: startDate, startIndex, endDate, endIndex`,
	`A.dateFillDayIndex: @dbData.sprints: @dbDate.minDate: @scale:: true: startDate, startIndex, dueDate, endIndex`,
	//`A.printObject:`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var DateUtil = pipeData.U.Date;

		var body = Req.body;
		var milestones = body.dbData;
		var date = body.dbDate;

		var scale = body.scale || 1.0;

		var width = body.width || 1024;
		var totalDay = date.totalDay || 0;

		var minDate = date.minDate || new Date();
		var maxDate = date.maxDate || new Date();

		if(!date.minDate) {
			minDate = new Date(minDate.getTime() - minDate.getDay()*86400000);
		}

		var maxWeek = date.maxWeek;
		if(!maxWeek && maxWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, 1, true);
			maxWeek = rw.week || 0;
		}

		var minWeek = date.minWeek;
		if(!minWeek && minWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, true, true);
			minWeek = rw.week || 0;
		}

		var week = Math.ceil(width / (body.itemWidth||336));
		var nWeek = week - (maxWeek - minWeek);
		if (nWeek > 0) {
			nWeek = Math.max(nWeek, 1);
			totalDay += (nWeek * 7);

			maxWeek += (nWeek);
			//minWeek += (-1);

			maxDate = new Date(maxDate.getTime() + (nWeek)*7*86400000);
			//minDate = new Date(minDate.getTime() + (-1)*7*86400000);
		}

		date.maxWeek = maxWeek;
		date.minWeek = minWeek;

		date.maxDate = maxDate;
		date.minDate = minDate;

		//console.log("Max: ", maxDate, maxDate.getDay(), body.dbDate1);
		//console.log("minDate: ", minDate.toString());
		// nên filter theo 1 milestone vaf chinir start time cura milestone laij ddeer thaasy today index bij sai.
		date.totalDay = Math.ceil(totalDay / scale);
		DateUtil.getUpdateTodayMonthList(Req, pipeData, date, scale); // -1

		var summary = {
			//budget: 0,

			//countTodo: 0,
			//countDoneTodo: 0,

			//countTask: 0,
			//countTaskDone: 0,

			duration: 0,
			//remainingDay: 0,

			milestoneDone: 0,
			milestoneCount: 0,
		};

		var tz = DateUtil.getCompanyTimeZone(Req);
		var objComponent = DateUtil.companyTimePoint(Req, pipeData);

		// Dont use map, it is async and the result maybe wrong
		for (var i = 0; i < milestones.length; i++) {
			var ms = milestones[i];
		//}
		//await milestones.map(async () => {
			//summary.budget += ms.budget;

			//ms.complete = ((ms.countTaskDone||0) / (ms.countTask||1) * 100.0).toFixed(0)-0;

			//summary.countTask += (ms.countTask||0);
			//summary.countTaskDone += (ms.countTaskDone||0);

			//summary.countTodo += ms.countTodo;
			//summary.countDoneTodo += ms.countDoneTodo;

			var rs = await DateUtil.calendarWorkingDay(Req, ms, ms.startDate, ms.endDate||ms.dueDate, [], true, false, false, false, objComponent, tz) / 8;

			//console.log("rs: ", rs, ms.startDate, ms.endDate, ms.dueDate);
			ms.duration = rs;
			summary.duration += rs;

			//summary.passedDay += ms.passedDay;
			//summary.remainingDay += ms.remainingDay;

			summary.milestoneCount += 1;
			summary.milestoneDone += (([2, 6].indexOf(ms.status) >= 0) ? 1 : 0);

			var sprints = ms.sprints || [];
			for (var k = 0; k < sprints.length; k++) {
				var sprint = sprints[k];
			//}
			//await (task.subTasks||[]).map(async (subTask) => {
				var rs2 = await DateUtil.calendarWorkingDay(Req, sprint, sprint.startDate, sprint.dueDate, [], true, false, false, false, objComponent, tz);
				sprint.duration = (rs2 / 8.0).toFixed(1)-0;

				ms.duration += rs2;
				//sprint.complete = (sprint.complete||0.0).toFixed(1)-0;

				//delete subTask.startDateLocal;
				//delete subTask.dueDateLocal;
			}


			//console.log("ms.startDateLocal: ", ms.startDateLocal, ms.startDateLocal.toString());
			//console.log("ms.endDateLocal: ", ms.endDateLocal, ms.endDateLocal.toString());

			//console.log("ms.testStartDate: ", ms.testStartDate);
			//console.log("ms.testEndDate: ", ms.testEndDate);

			// remove unused data
			//delete ms.startDateLocal;
			//delete ms.endDateLocal;
		//});
		}

		//var test1 = await A.getServerTimeZone(Req, pipeData);
		//var test2 = await A.getCompanyTimeZone(Req, pipeData);

		//console.log("getServerTimeZone: ", test1);
		//console.log("getCompanyTimeZone: ", test2);

		//console.log("localStart Date: ", localStart, minDate, body.minDateLocal);

		//console.log("minDateLocal: ", body.minDateLocal, body.minDateLocal.toString());

		//console.log("body: ", body);
		if(!body.flatData) {
			return { milestones, date, summary };
		}

		milestones = await A.flatGroupObject(Req, pipeData, milestones, "parentId", "sprints", "totalSprint", "accTotalSprint", "indentLevel", "index");
		return { milestones, date, summary };
	}],

]]);

SprintRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: sprint.view, sprint.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: sprint: colIndex, milestoneId, projectId!`,

	`A.updateById(*) > sprintDb : sprint: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update sprint successfully!`
]]);

SprintRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: sprint.view, sprint.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: sprint: colIndex-, name, name2, color, startDate, dueDate, colIndex`, // status mus be update by api update status

    `A.findOne(*) > sprintDb: sprint: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const sprintDb = pipeData.sprintDb;
        //console.log(pipeData);

		//var permit = sprintDb && (hasAdmin || (sprintDb.creatorId.equals(user._id) && sprintDb.status != 2));
        if(!sprintDb || (!hasAdmin && [2, 4].indexOf(sprintDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

		var body = (Req.body||{}).reqBody || {};
		if(body.startDate && body.dueDate) {
			if((body.dueDate - body.startDate) / 86400000 > 720) {
				return {
					respData: "Sprint duration should be around 720 days",
					respReturn: true,
					respCode: 500
				};
			}
		}

        return Req.UNRESULT;
    }],

    `A.updateById(reqBody): sprint`,

	`A.pipeRoute: sprint: { type: "update" }`,
    `A.responseObject: 200: Update successfully!`
]]);

SprintRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: sprint.view, sprint.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > sprintDb: sprint: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const sprintDb = body.sprintDb;
        //console.log(body);

		//var permit = sprintDb && (hasAdmin || (sprintDb.creatorId.equals(user._id) && sprintDb.status != 2));
        if(!sprintDb || (!hasAdmin && [4].indexOf(sprintDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	// colName, idKey, hardDelete=true, deleteMany=false)
	`A.deleteById: sprint: {_id: "@sprintDb._id"}: true: true`,

	`A.pipeRoute: sprint: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);


SprintRoute.POST.push([["/planning"], [
	`A.checkRole(*): project: @P.project._id: roleproject: sprint.view`, //milestone.view, sprint.view, task.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    //`A.verifyInput > reqBody:: feature: projectId!`,

    //`A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

        var ops = {};

		var projectId = Req.project._id;
        ops.projectId = projectId;
		body.projectId = projectId;

		var name = (body.name || body.search) || (body.text || "");
		var nameReg = Req.func.getASCIISearch(name, "gmi");
		body.name = nameReg;
		body.nameNumber = (name-0) || -1;

		if (name) {
            ops["$or"] = [
				{ name: nameReg },
				{ number: body.nameNumber }
			];
        }

		// 1 for Poking, 2 for Approved, 3 for Rejected, 4 for Submitted/Approved point, 6: for Completed, 7 for Polking
		var status = body.statusIds || body.statuses || body.status;
		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				//ops.push({$in: ["$status", status] });
                ops["status"] = { "$in": status };
			}
		}
		body.status = status || [];

		var sprintIds = (body.sprint || body.sprints) || (body.sprintId || body.sprintIds);
		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}

			if(sprintIds.length > 0) {
				body.sprintIds = sprintIds;
				//ops.push({$in: ["$sprintId", sprintIds] });
                ops["sprintIds"] = { "$in": sprintIds };
			}
		}
		body.sprintIds = sprintIds || [];

		var milestoneIds = (body.milestone || body.milestones) || (body.milestoneId || body.milestoneIds);
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				body.milestoneIds = milestoneIds;
				//ops.push({$in: ["$milestoneIds", milestoneIds] });
                ops["milestoneIds"] = { "$in": milestoneIds };
			}
		}
		body.milestoneIds = milestoneIds || [];

        body.ops = ops;
        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $eq: ["$shortName", "done"] },
						{ $or: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $sort: {
					colIndex: 1,
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
					colIndex: 1,
				}},
			],
			as: "groups"
		}},

		{ $addFields: {
			groupDone: { $arrayElemAt: [ "$groups", 0 ] },
			// 	 { $filter: {
			// 		 input: "$groups",
			// 		 as: "group",
			// 		 cond: { "$in": ["$$group.shortName", "done"] }
			// 	 }},
			// 	 0
			// ]}
		}},

		{ $lookup: {
			from: "milestone",
			let: { groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: { $expr: { $and: [
                    { $eq: ["$projectId", "@projectId"] },
                    { $or: [
                        { $in: ["$_id", "@milestoneIds"] },
                        { $in: ["@milestoneIds", [null, undefined, false, "", [] ]] }
				    ]}
                ]}}},

				{ $lookup: {
					from: "sprint",
					let: { milestoneId: "$_id", groupDoneId: "$$groupDoneId" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$milestoneId", "$$milestoneId"] },
							{ $or: [
								{ $in: ["$_id", "@sprintIds"] },
								{ $in: ["@sprintIds", [undefined, null, false, "", [] ]] },
							]}
						]}}},
						{ $addFields: {
							taskIds: { $ifNull: ["$taskIds", []] }
						}},

						// List story, filter by feature, return list feature
						{ $lookup: {
							from: "feature",
							let: { sprintId: "$_id", milestoneId: "$$milestoneId" },
							pipeline: [
								{ $match: { $expr: { $and: [
									{ $eq: ["$projectId", "@projectId"] },
									//{ $eq: ["$milestoneId", "$$milestoneId"]},
									{ $eq: ["$sprintId", "$$sprintId"]},
									// { $or: [ // Status only use for filter task
									// 	{ $in: ["$status", "@status"]},
									// 	{ $in: ["@status", [null, undefined, false, "", []]]},
									// ]},
									{ $or: [
                                        { $in: ["@name", [null, undefined, false, "", []]]},
										{ $regexMatch: { input: "$name", regex: "@name" }},
										{ $regexMatch: { input: "$name2", regex: "@name" }},
										{ $eq: ["$number", "@nameNumber"] },
									]}
								]}}},
								{ $addFields: {
									featurePoint: { $ifNull: ["$featurePoint", {
										// doing		: 0,
										// testing		: 0,
										// reviewing	: 0,
										// total		: 0,
									} ]}
								}},
								{ $addFields: {
									donePoint: { $cond: [ { $eq: ["$hasTaskDone", 1]}, "$featurePoint", {
										// doing		: 0,
										// testing		: 0,
										// reviewing	: 0,
										// total		: 0,
									} ]}
								}},
								{ $project: {
									_id: 1,
									name: 1,
									name2: 1,
							        color: 1,
									number: 1,
                                    colIndex: 1,
									startDate: 1,
									dueDate: 1,
									complete: 1,
									status: 1,
									featurePoint: 1,
									donePoint: 1,
								}},
                                { $sort: {
                                    colIndex: -1,
                                }},
							],
							as: "features"
						}},

						// List Task, filter by  task, return list task
						{ $lookup: {
							from: "task",
							let: { sprintId: "$_id", milestoneId: "$$milestoneId", taskIds: "$taskIds", groupDoneId: "$$groupDoneId" },
							pipeline: [
								{ $match: { $expr: { $and: [
									{ $eq: ["$projectId", "@projectId"] },
									//{ $eq: ["$milestoneId", "$$milestoneId"]},
									{ $or: [
										{ $eq: ["$sprintId", "$$sprintId"] },
										{ $in: ["$_id", "$$taskIds"] }
									]},
									{ $or: [
										{ $in: ["$status", "@status"]},
										{ $in: ["@status", [null, undefined, false, "", []]]},
									]},
									{ $or: [
                                        { $in: ["@name", [null, undefined, false, "", []]]},
										{ $regexMatch: { input: "$name", regex: "@name" }},
										{ $regexMatch: { input: "$name2", regex: "@name" }},
										{ $eq: ["$number", "@nameNumber"] },
									]}
								]}}},
								{ $addFields: {
									hasTaskDone: { $cond: [{ $eq: ["$groupId", "$$groupDoneId"] }, 1, 0] },
									complete: { $cond: [
										{ $eq: ["$groupId", "$$groupDoneId"] },
										100,
										{ $multiply: [{ $divide: [{$max: ["$doneTodo", 0]}, {$max: ["$totalTodo", 1]} ]}, 100] },
									]},
									featurePoint: { $ifNull: ["$featurePoint", {
										// doing		: 0,
										// testing		: 0,
										// reviewing	: 0,
										// total		: 0,
									} ]},
                                    duration: {$max: ["$estHour", "$duration"]},
								}},
								{ $addFields: {
									donePoint: { $cond: [ { $eq: ["$hasTaskDone", 1]}, "$featurePoint", {
										// doing		: 0,
										// testing		: 0,
										// reviewing	: 0,
										// total		: 0,
									} ]},
                                    userIds: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] },
								}},

                                // Add user
                        		// { $flatArray: {
                        		// 	userIds: "$users",
                        		// }},
                        		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "_id", "name", "avt", "userId"]},

								{ $project: {
									_id: 1,
									name: 1,
									name2: 1,
									type: 1,
									priority: 1,
									number: 1,
									colIndex: 1,
									status: 1,
									complete: 1,
									hasTaskDone: 1,
                                    startDate: 1,
                                    dueDate: 1,
                                    duration: 1,
									groupId: 1,
									featurePoint: 1,
									donePoint: 1,
                                    users: 1,
								}},
                                { $sort: {
                                    colIndex: -1,
                                }},
							],
							as: "tasks"
						}},

						{ $addFields: {
							taskDonePoint: {
								doing		: { $sum: "$tasks.donePoint.doing"},
								testing		: { $sum: "$tasks.donePoint.testing"},
								reviewing	: { $sum: "$tasks.donePoint.reviewing"},
								total		: { $sum: "$tasks.donePoint.total"},
							},
							totalTaskPoint: {
								doing		: { $sum: "$tasks.featurePoint.doing"},
								testing		: { $sum: "$tasks.featurePoint.testing"},
								reviewing	: { $sum: "$tasks.featurePoint.reviewing"},
								total		: { $sum: "$tasks.featurePoint.total"},
							},
							featureDonePoint: {
								doing		: { $sum: "$features.donePoint.doing"},
								testing		: { $sum: "$features.donePoint.testing"},
								reviewing	: { $sum: "$features.donePoint.reviewing"},
								total		: { $sum: "$features.donePoint.total"},
							},
							totalFeaturePoint: {
								doing		: { $sum: "$features.featurePoint.doing"},
								testing		: { $sum: "$features.featurePoint.testing"},
								reviewing	: { $sum: "$features.featurePoint.reviewing"},
								total		: { $sum: "$features.featurePoint.total"},
							},
                            duration: { $sum: "$tasks.duration" },
						}},

                        { $addFields: {
                            countTask: { $size: "$tasks" },
                            countTaskDone: { $sum: "$tasks.hasTaskDone" },
                        }},

                        { $addFields: {
                            complete_op$: "(($countTaskDone / ($countTask ?max 1)) * 100.0) ?fixed 0"
                        }},

						{ $project: {
							_id: 1,
							name: 1,
							name2: 1,
							number: 1,
							startDate: 1,
							dueDate: 1,
                            duration: 1,
							color: 1,
							status: 1,
							tasks: 1,
							features: 1,
                            colIndex: 1,
                            rejectedMessage: 1,

                            complete: 1,
                            countTask: 1,
                            countTaskDone: 1,

							taskDonePoint: 1,
							totalTaskPoint: 1,
							featureDonePoint: 1,
							totalFeaturePoint: 1,
						}},
                        { $sort: {
                            colIndex: -1,
                        }},
					],
					as: "sprints"
				}},

				// Test, filter milestone has sprint count > 0
				{ $addFields: {
					countSprint: { $size: "$sprints" },
                    countTask: { $sum: "$sprints.countTask" },
                    countTaskDone: { $sum: "$sprints.countTaskDone" },
				}},
                { $addFields: {
                    duration: { $sum: "$sprints.duration" },
                    complete_op$: "(($countTaskDone / ($countTask ?max 1)) * 100.0) ?fixed 0"
                }},

				// { $match: {
				// 	countSprint: { $gt: 0 }
				// }},

				{ $project: {
					_id: 1,
					color: 1,
					name: 1,
					name2: 1,
					number: 1,
                    colIndex: 1,
					startDate: 1,
					endDate: 1,
                    duration: 1,
					status: 1,
					sprints: 1,
					countSprint: 1,

                    complete: 1,
                    countTask: 1,
                    countTaskDone: 1,

            		rejectedMessage: 1,
				}},
                { $sort: {
                    colIndex: -1,
                }},
			],
			as: "milestones",
		}},
		{ $project: {
			milestones: 1,
		}}
	]]
]]);

SprintRoute.POST.push([[":_id/status"], [
	// 2 is completed
	`A.checkRole(*): project: @P.project._id: roleproject: milestone.view, sprint.view, task.Review`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyKObject(P.route):: _id: verify.idType`,
	`A.verifyKObject:: sprintId: verify.idType:
					   status: verify.numberType`,

    //`A.trimObject`,
    [`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		var sprintId = Req.route._id;

		var remainingTasks = [];
		var projectId = Req.project._id;
		var nextSprintId = body.sprintId;
		if((body.status === 2) && nextSprintId) {
			var A = pipeData.A;
			var rs = await A.aggregateOne(Req, pipeData, "", [
				{ $lookup: {
					from: "group",
					pipeline: [
						{ $match : {
							type: "task",
							$expr: { $and: [
								{ $eq: ["$shortName", "done"] },
								{ $or: [
									{ $eq: ["$projectId", projectId] },
									{ $eq: ["$hasGlobal", true] },
								]}
							]}
				        }},
						{ $addFields: {
							shortName: { $toLower: "$shortName" }
						}},
						{ $sort: {
							colIndex: 1,
						}},
						{ $project: {
							_id: 1,
							shortName: 1,
							value: 1,
							colIndex: 1,
						}},
					],
					as: "groups"
				}},
				{ $addFields: {
					groupDone: { $arrayElemAt: [ "$groups", 0 ] },
					// 	 { $filter: {
					// 		 input: "$groups",
					// 		 as: "group",
					// 		 cond: { "$in": ["$$group.shortName", "done"] }
					// 	 }},
					// 	 0
					// ]}
				}},

				{ $lookup: {
					from: "task",
					let: { groupDoneId: "$groupDone._id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$sprintId", sprintId] },
							{ $not: [{$eq: ["$groupId", "$$groupDoneId"]}] },
						]}}}
					],
					as: "remainingTasks"
				}},
				{ $addFields: {
					remainingTasks: "$remainingTasks._id"
				}},
				{ $project: {
					_id: 0
				}},
				{ $project: {
					remainingTasks: 1,
				}}
			]);

			remainingTasks.push(...((rs||{}).remainingTasks||[]));
		}

		if(remainingTasks && (remainingTasks.length > 0)) {
			Req.config.IgnoreSanitized = true;
			await A.updateById(Req, pipeData, "task", { _id: { $in: remainingTasks }}, { sprintId: nextSprintId }, false, true);
		}

		return Req.UNRESULT;
	}],

	`A.updateById(*): sprint: {_id: "@P.route._id"}: {status: "@P.body.status"}`,
	`A.responseObject: 200: Update sprint successfully!`,
]]);

module.exports = SprintRoute;
