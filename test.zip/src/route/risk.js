const RiskRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.risk",
        checkMIFs		: ["project", "risk"],
		imProject		: true,
    }
};

RiskRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view, risk.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: risk: projectId!, labelId!, ...`,

    `A.insertOne: risk`,
    `A.populate: label, labelId, _id, label, +, name, name2, color
               : milestone, milestoneId, _id, milestone, +, name`,

	`A.pipeRoute: risk: { type: "create" }`,
    `A.refactorOutput:: modifiedAt-, modifierId-, creatorId-, ...`
]]);

RiskRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        const content = pipeData.content || pipeData.search;
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		let milestoneIds = pipeData.milestoneId || pipeData.milestoneIds;
		let sprintIds = pipeData.sprintId || pipeData.sprintIds;
		let featureIds = pipeData.featureId || pipeData.featureIds;

		var projectIds = pipeData.projectId || pipeData.projectIds;

		var type = pipeData.type || pipeData.types || [];
		if(!Array.isArray(type)) {
			type = [type];
		}

		var hasResolved = type.indexOf("resolved") >= 0;
		var hasUnresolved = type.indexOf("unresolved") >= 0;

		var ops = {};
		if(hasResolved != hasUnresolved) {
			if(hasResolved) {
				ops.status = 2;
			} else {
				ops.status = { $ne: 2 };
			}
		}

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.status = { $in: status };
			}
		}

        if (content) {
            var contentRegex = Req.func.getASCIISearch(content, "gmi");
            ops["$or"] = [
				{ content : contentRegex },
            	{ mitigate: contentRegex },
				{ number: (content-0) || -1 },
			];
        }

		if(fromDate && toDate) {
            ops["$and"] = [
				{ dueDate: { "$gte" : new Date(fromDate) }},
				{ dueDate: { "$lte" : new Date(toDate) }},
			];
        }
        // if(fromDate && toDate) {
        //     ops.dueDate =  {
        //         "$gte" : new Date(fromDate),
        //         "$lte" : new Date(toDate)
        //     }
        // }

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
			if(milestoneIds.length > 0) {
				ops.milestoneId = { $in: milestoneIds };
			}
		}

		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}
			if(sprintIds.length > 0) {
				ops.sprintId = { $in: sprintIds };
			}
		}

		if(featureIds) {
			if(!Array.isArray(featureIds)) {
				featureIds = [featureIds];
			}
			if(featureIds.length > 0) {
				ops.featureId = { $in: featureIds };
			}
		}

        pipeData.ops = ops;
        return pipeData;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: risk`, [
		{ $match: "@ops"},
		{ $sort: {
			status: 1,
			priority: -1,
			dueDate: -1,
			modifiedAt: -1
		}},

		{ $addFields: {
			hasResolved: { $cond: [{$eq: ["$status", 2]}, 1, 0]}
		}},

		{ $getTotalLength: ["@page", "totalLength", {
			totalResolved: { $sum: "$hasResolved" }
		}]},

		{ $populate: ["label", "labelId", "_id", "label", true]},
		{ $populate: ["milestone", "milestoneId", "_id", "milestone", true]},

		{ $project: {
			_id: 1,

			labelId: 1,
			milestoneId: 1,
			priority: 1,

			dueDate: 1,
			number: 1,

			content: 1,
			mitigate: 1,

			weight: 1,
			status: 1,

			resolvedAt: 1,

			totalLength: 1,
			totalResolved: 1,

			"label._id": 1,
			"label.name": 1,
			"label.name2": 1,
			"label.color": 1,

			"milestone._id": 1,
			"milestone.name": 1,
			"milestone.name2": 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "risks", "", { totalResolved: {$first: "$totalResolved"} }]}
	]]
    //"A.findMany: risk: @ops",
    //`A.populate: label, labelId, _id, label, +, name, name2, color
    //           : milestone, milestoneId, _id, milestone, +, name`,
    //`A.refactorOutput:: modifiedAt-, modifierId-, creatorId-, ...`
], {
	//IgnoreSanitized: true,
	useZip: true
}]);

RiskRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): risk`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populateFilter: ["label", "labelId:_id", "label", true, 1, "_id", "name", "name2", "color"] },
		//{ $populateFilter: ["label", "labelId:_id", "label", true, 1, "_id", "name", "name2", "color"] },

		{ $project: {
			modifierId: 0,
			creatorId: 0,
		}}
	]],

    // `<F1>A.findOne(P.route): risk: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
    // `A.populate: label, labelId, _id, label, +, name, name2, color
    //            : milestone, milestoneId, _id, milestone, +, name`,
    // "A.refactorOutput:: modifierId-, creatorId-, ...",
]]);

RiskRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view, risk.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: risk: status-, projectId-, number-, ...`,
    `A.refactorOutput:: number-, ...`,

    `A.findOne(*) > riskDb: risk: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    // [`A.jsScript`, (Req, pipeData, ctx) => {
	// 	var user = Req.user;
	// 	var hasAdmin = user.hasAgent || user.hasAdmin;
	//
	// 	var risk = Req.body.riskDb || {};
	// 	var permit = risk._id && (hasAdmin || risk.creatorId.equals(user._id));
	// 	if (!permit) {
	// 		return {
	// 			respData: "E-02",
	// 			respReturn: true,
	// 			respCode : 500
	// 		};
	// 	}
	// 	return pipeData;
    // }],

	[`A.aggregateOne(*) > riskDb: risk:`, [
		{ $match: {
			_id: "@P.route._id",
			projectId: "@P.project._id"
		}},
		
		{ $populateFilter: ["user", "creatorId:_id", "creators", undefined, 1, "email", "name", "name2"] },
		{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "name", "name2", "shortName", "members"] },
		{ $populateFilter: ["user", "project.members.user$:_id", "users", undefined, 1, "email",] },

		
		{ $addFields: {
			creator: "$creator.email",
			userEmails: { $setUnion: [ {$ifNull: ["$users.email", []]}, {$ifNull: ["$creators.email", []]} ] },
			creator: { $ifNull: [{$first: "$creators"}, {}]}
		}},
		{ $project: {
			_id: 1,
			userEmails: 1,
			creator: 1,
			project: 1,
			number: 1,
		}}
	]],

	`A.printObject:`,
    `A.updateById(*) > temp: risk: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,
    `A.populate: label, labelId, _id, label, +, name, name2, color
                : milestone, milestoneId, _id, milestone, +, name`,

	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.riskDb.userEmails",
		"subject" 	: "[ Risk ] Your were mention in Risk",
		"view" 		: "riskView",
		"data" 		: "@P.body.riskDb"
	}`,

	`A.pipeRoute: risk: { type: "update" }`,
    `A.refactorOutput:: modifierId-, creatorId-, ...`,
]]);

RiskRoute.PUT.push([[":_id/resolve"], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view, risk.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.verifyInput:: risk: status!, projectId!`,
    `A.refactorOutput:: number-, ...`,

    `A.updateById(*): risk: { _id: "@P.route._id", projectId: "@P.project._id" }: { status: "@P.body.status", resolvedAt: "@(new Date())" }`,

	`A.pipeRoute: risk: { type: "resolve" }`,
    `A.responseObject: 200: Update successfully!`
]]);

RiskRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: risk.view, risk.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.findOne(*) > riskDb: risk: { _id: "@P.route._id", projectId: "@P.project._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var risk = Req.body.riskDb;

        if(!risk || (risk.status == 2)) {
			var user = Req.user || {};

			if(!user.hasAdmin && !user.hasAgent) {
	            return {
					respData: "E-02",
					respReturn: true,
					respCode: 500
				};
			}
        }
        return Req.UNRESULT;
    }],

    `A.deleteById: risk`,

	`A.pipeRoute: risk: { type: "delete" }`,
    `A.responseObject: 200: Delete successfully!`
]]);

module.exports = RiskRoute;
