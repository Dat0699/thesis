const AutomationRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		imCompany	: true,
		imProject	: true,
	}
};

AutomationRoute.POST.push([[""], [
	`A.verifyInput:: automation: name!, script, ...`,
	`A.insertOne: automation`,
]]);

AutomationRoute.GET.push([["/:_id"], [
	`A.findById: automation`,
	`A.responseObject(*): 200: @P.body`,
]]);

AutomationRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: automation: number-, ...`,
	`A.updateById(*): automation: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject: 200: Update successfully!`,
]]);

AutomationRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: automation`,
]]);

module.exports = AutomationRoute;
