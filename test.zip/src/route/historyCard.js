const HistoryCardRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

HistoryCardRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyInput:: historyCard: content, amount`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		Req.company.companyCost.yourBalance += pipeData.amount;
		return pipeData;
	}],
	`A.updateOne(P.company) > xyz: main.company`,
	`A.insertOne:  historyCard: {
		amount: @amount,
		content: @content
	}`
]]);

HistoryCardRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findMany: historyCard: ...`
]]);


module.exports = HistoryCardRoute;
