const PostEnvRoute = {
    route	: "post/:serverId/env",
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.postapi",
        checkMIFs		: ["project", "postapi"],
		imProject		: true,
    }
};

PostEnvRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.trimObject:`,
    `A.verifyInput:: postenv: name!, projectId!, serverId!, ...`,
    `A.insertOne: postenv`,

	`A.pipeRoute: postenv { type: "create" }`,
	`A.refactorOutput:: _id, name, name2, descr, variables`,
]]);

PostEnvRoute.POST.push([["/s"], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

    `A.findMany(*): postenv: { serverId: "@P.route.serverId", projectId: "@P.project._id" }`,
    //`A.populate:user, creatorId, _id`,
    `A.refactorOutput:: _id, name, name2, descr, variables`,
]]);

PostEnvRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    `A.findOne(*): postenv: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,
    `A.refactorOutput:: _id, name, name2, descr, variables`,
]]);

PostEnvRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: postenv: projectId-, serverId-, creatorId-, createdAt-, modifierId-, modifiedAt-, ...`,

	`A.updateById(*): postenv: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: @P.body`,

	`A.pipeRoute: postenv { type: "update" }`,
    `A.refactorOutput:: _id, name, name2, descr, variables`,
]]);

PostEnvRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessPostServer: {role: "delete"}`,

	`A.deleteById(*): postenv: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,

	`A.pipeRoute: postenv { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = PostEnvRoute;
