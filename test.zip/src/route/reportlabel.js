const ReportlabelRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
	}
};

ReportlabelRoute.POST.push([[""], [
	"A.verifyInput:: reportlabel: ...",
	"A.insertOne: Public.reportlabel",
]]);

ReportlabelRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	"A.findOne: Public.reportlabel",
]]);

ReportlabelRoute.POST.push([["/s"], [
	"A.verifyInput:: reportlabel: ...",
	"A.findMany: Public.reportlabel",
]]);

ReportlabelRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.deleteOne: Public.reportlabel",
]]);

ReportlabelRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	"A.verifyInput:: reportlabel: ...",
	"A.updateOne: Public.reportlabel",
]]);

module.exports = ReportlabelRoute;
