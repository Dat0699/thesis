const TemplateRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		// checkKeyFeature	: "project.feature.task",
        checkMIFs		: ["project"],
		imProject		: true,
    }
};

/// CREATE NEW TEMPLATE
TemplateRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: template: projectId!, name!, ...`,
    `A.insertOne(*): template: @P.body`,

    `A.responseObject: 200: Create Successfully!`,
]]);

/// GET ALL TEMPLATE
TemplateRoute.POST.push([["/s"], [
    `A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.findMany: template`,
    `A.refactorOutput:: _id, name`
]]);

/// GET DELTAIL TEMPLATE
TemplateRoute.GET.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.findOne(*): template: _id:@P.route._id`,
    `A.refactorOutput:: _id, name, content, refId, refModel`
]]);

/// UPDATE TEMPLATE
TemplateRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task .view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.verifyInput:: template: name!, content!`,
    `A.updateById(*): template: {_id: "@P.route._id"}: @P.body`, //: shouldCreated=false`,
    `A.responseObject: 200: Update Successfully!`,
]]);

/// DELETE TEMPLATE
TemplateRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
    `A.deleteOne(*): template: { _id: "@P.route._id"}`,
    `A.responseObject: 200: Delete Successfully!`,
	
]]);



module.exports = TemplateRoute;
