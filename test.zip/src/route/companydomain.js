const CompanydomainRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

CompanydomainRoute.POST.push([["s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findMany: companydomain`
]]);

CompanydomainRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    `A.findOne: companydomain`
]]);

CompanydomainRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyInput:: companydomain: ...`,
	`A.insertOne: companydomain`
]]);

CompanydomainRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: companydomain: ...`,
	`A.updateOne: companydomain`
]]);

CompanydomainRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    "A.deleteById: companydomain",
]]);

module.exports = CompanydomainRoute;
