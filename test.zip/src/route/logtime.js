const LogTimeRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.logtime",
        checkMIFs		: ["project", "logtime"],
		imProject		: true,
    }
};

LogTimeRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,
    // `A.verifyInput:: logtime: projectId!, taskId!, ...`,

    `A.findMany(*): logtime: {
		projectId: "@P.project._id"
	}`,

    `A.populate: user, creatorId, _id, creator, +, name, name2, avatarId`,
    `A.refactorOutput:: amount-`,
]]);

LogTimeRoute.POST.push([["/by/list"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
        const projectId = Req.project._id; //pipeData.projectId || pipeData.projectIds;
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		var milestoneIds = (pipeData.milestone || pipeData.milestones) ||
						   (pipeData.milestoneId || pipeData.milestoneIds);
		const content = pipeData.content || pipeData.text || pipeData.search;
		var memberIds = (pipeData.users || pipeData.userIds) ||
						(pipeData.members || pipeData.memberIds) ||
						(pipeData.creatorId || pipeData.userId);

		var user = Req.user;
		var hasAdmin = user.hasAdmin || user.hasAgent;

		var ops = {};
		var opsLater = {};

		pipeData.keepMember = true;
		pipeData.keepMilestone = true;

		if(projectId) {
			ops.projectId = projectId;
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.status = { $in: status };
			}
		}

		var type = pipeData.type || pipeData.types;
		if((type != undefined) && (type != null) && (type != "")) {
			if(!Array.isArray(type)) {
				type = [type];
			}
			if(type.length > 0) {
				ops.type = { $in: type };
			}
		}

        if(content) {
            var contentRegex = Req.func.getASCIISearch(content, "gmi");
            ops["$or"] = [
				{ content: contentRegex },
				{ content2: contentRegex },
            	{ mitigate: contentRegex },
				{ number: (content-0) || -1 },
			];
        }

		var roleProject = (Req.roleproject||Req.roleProject||{}).permit || {};
		if(hasAdmin || roleProject.logtime.approve) {
	        if(memberIds) {
				if(!Array.isArray(memberIds)) {
					memberIds = [memberIds]
				}
				if(memberIds.length > 0) {
	            	ops.creatorId = { $in: memberIds };
					pipeData.keepMember = false;
				}
	        }

		} else {
			ops.creatorId = { $in: [user._id] };
		}

        if(fromDate && toDate) {
            ops["$and"] = [
				{ fromTime: {"$gte": new Date(fromDate)} },
				{ fromTime: {"$lte": new Date(toDate)} }
			];
        }

		pipeData.milestoneIds = false;
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
			if(milestoneIds.length > 0) {
				pipeData.milestoneIds = milestoneIds;
				pipeData.keepMilestone = false;
			}
		}

		if(!hasAdmin) {
			// Not Admin, just see you and approved, rejected, submited items.
			opsLater = { $expr: { $or: [
				{ $eq: ["$creatorId", user._id] },
				{ $in: ["$status", [2, 3, 4] ] },
				{ $eq: ["@P.roleproject.logtime.approve", true] },
				{ $eq: ["@P.roleproject.setting.view", true] },
			]}}
		}

		pipeData.ops = ops;
		pipeData.opsLater = opsLater;
		// console.log(ops);

		return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
    [`A.aggregateOne: logtime`, [
		{ $match: "@ops" },
		{ $match: "@opsLater" },
		{ $sort: {
			//status: -1,
			//creatorId: 1,
			fromTime: -1,
			createdAt: -1,
			//modifiedAt: -1,
		}},

		//{ $populate: ["task", "taskId", "_id", "taskId", true]},
		{ $populateFilter: ["task", [
			{ $let: { taskId: "$taskId" }},
			{ $expr: { $and : [
				{ $or: [
					{ $in: ["@milestoneIds", [false, null, undefined]] },
					{ $in: ["$milestoneId", "@milestoneIds"] },
				]},
				{ $eq: ["$_id", "$$taskId"] },
			]}}
		], "taskId", true, 1, "_id", "number", "type", "name", "name2"]},


		{ $populate: ["user", "creatorId", "_id", "creatorId", "@keepMember"]}, // Remove deleted user
		{ $populate: ["user", "approverIds", "_id", "approverIds"]},
		{ $populate: ["user", "approverId", "_id", "approverId", true]},

		{ $getTotalLength: ["@page", "totalLength", {
			totalLogtime: { $sum: "$hour" }
		}]},

		{ $project: {
			_id: 1,
			number: 1,
			taskId: 1,
			fromTime: 1,
			hour: 1,
			content: 1,
			type: 1,

			modifiedAt: 1,
			rejectedMessage: 1,
			status: 1,

			totalLength: 1,
			totalLogtime: 1,

			"creatorId._id": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,

			//"taskId.number": 1,
			//"taskId.name": 1,
			//"taskId.name2": 1,
			//"taskId.type": 1,

			// approvers
			"approverIds._id": 1,
			"approverIds.name": 1,
			"approverIds.name2": 1,
			"approverIds.avt": 1,
			"approverIds.userId": 1,

			// approver
			"approverId._id": 1,
			"approverId.name": 1,
			"approverId.name2": 1,
			"approverId.avt": 1,
			"approverId.userId": 1,
		}},
		{ $group: {
            _id: {
                month: { $month: "$fromTime" },
                day: { $dayOfMonth: "$fromTime" },
                year: { $year: "$fromTime" }
            },
            logtimes : {
                $push : {
                    _id : "$_id",
                    number: "$number",
					taskId: "$taskId",
					fromTime: "$fromTime",
                    hour : "$hour",
                    content : "$content",
					content2 : "$content2",
                    //amount: "$amount",
                    type : "$type",
					rejectedMessage: "$rejectedMessage",
                    status : "$status",
                    creatorId: "$creatorId",
					modifiedAt: "$modifiedAt",
					approvers: "$approverIds",
					approvedBy: "$approverId"
                }
            },
            totalHour: {$sum : "$hour"},
            //totalAmount: {$sum : "$amount"},
            date : {$first: "$fromTime"},
			totalLength: { $first: "$totalLength" },
			totalLogtime: { $first: "$totalLogtime" },
        }},

		{ $sort: {
			date: -1,
			totalHour: -1
		}},

		{ $groupTotalLength: ["@page", "totalLength", "logtimes", "", {
			totalLogtime: { $first: "$totalLogtime" },
		}]},

		{ $project: {
			"logtimes.totalLogtime": 0
		}}
	]],
    //`A.populate:task, logtimes.taskId, _id, logtimes.task, +, name, name2, type, number `,
    //`A.deleteKObject:: _id`,
    //"A.refactorOutput::",
], { useZip: true } ]);


LogTimeRoute.POST.push([["/by/team"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
        const projectId = Req.project._id; // pipeData.projectId || pipeData.projectIds;
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		//let name = (pipeData.name || pipeData.content) || (pipeData.text || pipeData.search);
		var milestoneIds = (pipeData.milestone || pipeData.milestones) ||
						   (pipeData.milestoneId || pipeData.milestoneIds);

		//let name = (pipeData.name || pipeData.content) || (pipeData.text || pipeData.search);
		var memberIds = (pipeData.user || pipeData.users || pipeData.userIds) ||
						(pipeData.member || pipeData.members || pipeData.memberIds) ||
						(pipeData.creator || pipeData.creatorId || pipeData.userId);

		var teamIds = (pipeData.team || pipeData.teams) ||
						(pipeData.teamId || pipeData.teamIds);

		var user = Req.user;
		var hasAdmin = user.hasAdmin || user.hasAgent;

		pipeData.keepMilestone = true;
		pipeData.keepTeam = true;
		pipeData.keepMember = true;

		var ops = {};
		if(!hasAdmin) { //} && (!roleProject || !(roleProject.setting||{}).view)) {
			//memberIds = [user._id]; // Will discuss this case, user can see other logtime list
		}

		if(projectId) {
			ops["projectId"] = projectId;
		}

        if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds]
			}
			if(memberIds.length > 0) {
            	ops.creatorId = { $in: memberIds };
				pipeData.keepMember = false;
			}
        }

        if(fromDate && toDate) {
            ops["$and"] = [
				{ fromTime: {"$gte": new Date(fromDate)} },
				{ fromTime: {"$lte": new Date(toDate)} }
			];
        }

		// pipeData.teamName = "";
		// if(name) {
		// 	// Taskname, name2, task number
		// 	name = Req.func.getASCIISearch(name, "gmi");
		// 	pipeData.teamName = name;
		// 	//pipeData.userName["user.name"] = name;
		// }

		pipeData.teamIds = [];
		if(teamIds) {
			if(!Array.isArray(teamIds)) {
				teamIds = [teamIds];
			}

			if(teamIds.length > 0) {
				pipeData.teamIds = teamIds;
				pipeData.keepTeam = false;
			}
		}

		pipeData.milestoneIds = [];
		pipeData.keepItemLogtime = true;
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				pipeData.keepItemLogtime = false;
				pipeData.milestoneIds = milestoneIds;
				pipeData.keepMilestone = false;
			}
		}

		pipeData.projectId = projectId;
		pipeData.ops = ops;
		//console.log(ops);

		return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
    [`A.aggregateOne: logtime`, [
		{ $match: "@ops" },

		// Filter by milestone
		{ $populateFilter: ["task", [
			{ $let: { taskId: "$taskId" }},
			{ $expr: { $and : [
				{ $eq: ["$$taskId", "$_id"] },
				{ $or: [
					{ $in: ["@milestoneIds", [false, null, undefined, []]] },
					{ $in: ["$milestoneId", "@milestoneIds"] },
				]}
			]}}
		], "task", true, 1, "_id", "milestoneId"]},

		{ $sort: {
			fromTime: -1,
			modifiedAt: -1,
			createdAt: -1,
		}},

		{ $populateFilter: ["team", [
			{ $let: { userId: "$creatorId" }},
			{ $expr: { $and : [
				{ $in: ["$$userId", "$members"] },
				{ $eq: ["$projectId", "@projectId"] },
				// { $or: [
				// 	{ $eq: ["@teamName", ""] },
				// 	{ $regexMatch: {
				// 		input: "$name",
				// 		regex: "@teamName"
				// 	}},
				// ]},
				{ $or: [
					{ $in: ["@teamIds", [[], undefined, null]] },
					{ $in: ["$_id", "@teamIds"]},
				]},
			]}}
		], "team", "@keepTeam", 1, "_id", "name", "avt"]},
		// Group all unamed team
		{ $addFields: {
			team: {
				_id: { $ifNull: ["$team._id", ""]},
				name: { $ifNull: ["$team.name", ""]},
				avt: { $ifNull: ["$team.avt", 0]},
			}
		}},

		// Group all unamed milestone
		{ $populateFilter: ["milestone", "task.milestoneId:_id", "milestone", "@keepMilestone", 1, "_id", "name", "name2", "avt", "number", "startDate", "endDate"]},
		{ $addFields: {
			milestone: {
				_id: { $ifNull: ["$milestone._id", ""]},
				name: { $ifNull: ["$milestone.name", ""]},
				avt: { $ifNull: ["$milestone.avt", 0]},
                number: { $ifNull: ["$milestone.number", 0]},
				startDate: "$milestone.startDate",
                endDate: "$milestone.endDate",
			}
		}},

		// Begin get Total Logtime
		// Due to below has many unwin operator so count on first
		// Group by user and unwwin again to get totalLogtime

		// Level 1
		{ $group: {
			_id: "$_id",
			kwy: { $push: "$$ROOT" },
			hour: { $first: "$hour" },
		}},
			// Level 2
			// Begin get Total Logtime
			// Due to below has many unwin operator so count on first
			// Group by user and unwwin again to get totalLogtime
			{ $group: {
				_id: null,
				kwy: { $push: "$$ROOT" },
				totalLogtime: { $sum: "$hour" },
			}},
			{ $unwind: {
				path: "$kwy"
			}},
			{ $addFields: {
				"kwy.totalLogtime": "$totalLogtime"
			}},
			{ $replaceRoot: {
				newRoot: "$kwy"
			}},
			// End get Total Logtime
			// End Level 2

		{ $unwind: {
			path: "$kwy"
		}},
		{ $addFields: {
			"kwy.totalLogtime": "$totalLogtime"
		}},
		{ $replaceRoot: {
			newRoot: "$kwy"
		}},
		// End get Total Logtime
		// End Level 1

		// Group by Type
		{ $group: {
			_id: {
				user: "$creatorId",
				type: "$type",
				milestone: "$milestone._id",
				team: "$team._id"
			},
			hour: { $sum: "$hour" },
			type: { $first: "$type" },
			user: { $first: "$creatorId" },
			team: { $first: "$team" },
			milestone: { $first: "$milestone" },
			totalLogtime: { $first: "$totalLogtime" },
		}},
		{ $project: {
			_id: 0
		}},
		{ $sort: {
			hour: -1,
		}},

		// Update type of logtime
		{ $addFields: {
			logtime: {
				working		: { $cond: [{$eq: ["$type", "working"]}, "$hour", 0] }, // will remove later
				implementing: { $cond: [{$eq: ["$type", "implementing"]}, "$hour", 0] },
				correcting	: { $cond: [{$eq: ["$type", "correcting"]}, "$hour", 0] },
				reviewing	: { $cond: [{$eq: ["$type", "reviewing"]}, "$hour", 0] },
				designing	: { $cond: [{$eq: ["$type", "designing"]}, "$hour", 0] },
				training	: { $cond: [{$eq: ["$type", "training"]}, "$hour", 0] },
				meeting		: { $cond: [{$eq: ["$type", "meeting"]}, "$hour", 0] },
				optimizing	: { $cond: [{$eq: ["$type", "optimizing"]}, "$hour", 0] },
				testing		: { $cond: [{$eq: ["$type", "testing"]}, "$hour", 0] },
				coding		: { $cond: [{$eq: ["$type", "coding"]}, "$hour", 0] }, // will remove later
				planning	: { $cond: [{$eq: ["$type", "planning"]}, "$hour", 0] },
				other		: { $cond: [{$eq: ["$type", "other"]}, "$hour", 0] },
			}
		}},

		// get user information
		{ $populateFilter: ["user", "user:_id", "userObj", "@keepMember", 1, "_id", "name", "userId", "avt"]}, // Remove deleted user
		// Group all unamed user
		{ $addFields: {
			user: {
				_id: { $ifNull: ["$userObj._id", "$user"]},
				name: { $ifNull: ["$userObj.name", ""]},
				avt: { $ifNull: ["$userObj.avt", 0]},
				userId: { $ifNull: ["$userObj.userId", 0]},
			}
		}},

		// Group by User
		{ $group: {
			_id: {
				user: "$user._id",
				team: "$team._id",
				milestone: "$milestone._id",
			},
			typeLogs: { $push: "$logtime" },
			hour: { $sum: "$hour" },
			user: { $first: "$user" },
			team: { $first: "$team" },
			milestone: { $first: "$milestone" },
			totalLogtime: { $first: "$totalLogtime" },
		}},
		{ $addFields: {
			logtime: {
				working		: { $sum: "$typeLogs.working" },
				correcting	: { $sum: "$typeLogs.correcting" },
				implementing: { $sum: "$typeLogs.implementing" },
				reviewing	: { $sum: "$typeLogs.reviewing" },
				designing	: { $sum: "$typeLogs.designing" },
				training	: { $sum: "$typeLogs.training" },
				meeting		: { $sum: "$typeLogs.meeting" },
				optimizing	: { $sum: "$typeLogs.optimizing" },
				testing		: { $sum: "$typeLogs.testing" },
				coding		: { $sum: "$typeLogs.coding" },
				planning	: { $sum: "$typeLogs.planning" },
				other		: { $sum: "$typeLogs.other" },
			},
		}},

		// Sort by user name
		//{ $match: "@userName" },
		{ $sort: {
			"user.name$": 1
		}},

		// Group by Team
		{ $group: {
			_id: {
				team: "$team._id",
				milestone: "$milestone._id",
			},
			userLogs: { $push: {
				hour: "$hour",
				logtime: "$logtime",
				user: "$user",
			}},
			hour: { $sum: "$hour" },
			team: { $first: "$team" },
			milestone: { $first: "$milestone" },
			totalLogtime: { $first: "$totalLogtime" },
		}},
		{ $addFields: {
			logtime: {
				working		: { $sum: "$userLogs.logtime.working" },
				correcting	: { $sum: "$userLogs.logtime.correcting" },
				implementing: { $sum: "$userLogs.logtime.implementing" },
				reviewing	: { $sum: "$userLogs.logtime.reviewing" },
				designing	: { $sum: "$userLogs.logtime.designing" },
				training	: { $sum: "$userLogs.logtime.training" },
				meeting		: { $sum: "$userLogs.logtime.meeting" },
				optimizing	: { $sum: "$userLogs.logtime.optimizing" },
				testing		: { $sum: "$userLogs.logtime.testing" },
				coding		: { $sum: "$userLogs.logtime.coding" },
				planning	: { $sum: "$userLogs.logtime.planning" },
				other		: { $sum: "$userLogs.logtime.other" },
			},
		}},
		{ $sort: {
			"team.name$": 1
		}},

		// Group by Milestone
		{ $group: {
			_id: "$milestone._id",
			teamLogs: { $push: {
				hour: "$hour",
				logtime: "$logtime",
				team: "$team",
				userLogs: "$userLogs",
			}},
			//hour: { $sum: "$hour" },
			milestone: { $first: "$milestone" },
			totalLogtime: { $first: "$totalLogtime" },
		}},
		// Start Hide1 ----------------------
		// Due to one persion can be in many team, so result only in total or member
		// { $addFields: {
		// 	logtime: {
		// 		working		: { $sum: "$teamLogs.logtime.working" },
		// 		correcting	: { $sum: "$teamLogs.logtime.correcting" },
		// 		implementing: { $sum: "$teamLogs.logtime.implementing" },
		// 		reviewing	: { $sum: "$teamLogs.logtime.reviewing" },
		// 		designing	: { $sum: "$teamLogs.logtime.designing" },
		// 		training	: { $sum: "$teamLogs.logtime.training" },
		// 		meeting		: { $sum: "$teamLogs.logtime.meeting" },
		// 		optimizing	: { $sum: "$teamLogs.logtime.optimizing" },
		// 		testing		: { $sum: "$teamLogs.logtime.testing" },
		// 		coding		: { $sum: "$teamLogs.logtime.coding" },
		// 		planning	: { $sum: "$teamLogs.logtime.planning" },
		// 		other		: { $sum: "$teamLogs.logtime.other" },
		// 	},
		// }},
		// END Hide1 ----------------------
		{ $sort: {
			"milestone.name$": 1,
			"milestone.startDate": -1
		}},

		// Summary
		{ $group: {
			_id: null,
			milestoneLogs: { $push: {
				hour: "$hour",
				logtime: "$logtime",
				milestone: "$milestone",
				teamLogs: "$teamLogs"
			}},
			totalLogtime: { $first: "$totalLogtime" },
		}},
		{ $project: {
			_id: 0,
			"milestoneLogs.totalLogtime": 0,
			"milestoneLogs.teamLogs.totalLogtime": 0,
			"milestoneLogs.teamLogs.userLogs.totalLogtime": 0,
		}}
	]],

	`A.trimObject:: false: false: true`,

	// Calculate Milestone logtime based on team-member
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		body = body.dbData || body || {};
		(body.milestoneLogs||[]).map(ms => {
			var msHour = 0;
			var msLogtime = {};

			var userObj = {};
			(ms.teamLogs||[]).map(team => {
				(team.userLogs||[]).map(user => {
					var key = user.user._id || "";
					if(!userObj[key]) {
						var logtime = user.logtime || {};
						Object.keys(logtime).map(k => {
							msLogtime[k] = (msLogtime[k]||0) + (logtime[k]||0);
						});
						msHour += (user.hour || 0);
						userObj[key] = true;
					}
				});
			});

			ms.logtime = msLogtime;
			ms.hour = msHour;
		});

		return body;
	}],

	//`A.printObject`,
	//`A.collectKVToObject: @teams.users: logtime: type: hour`,
	//`A.responseObject(*): 200: @P.body`
	// [`A.jsScript:`, (Req, pipeData, ctx) => {
	// 	var arrs = (pipeData||{}).teams || [];
	// 	arrs.map(item => {
	// 		var logtime = {};
	// 		item.logtime = logtime;
	//
	// 		(item.users||[]).map(user => {
	// 			var log = user.logtime || {};
	// 			var keys = Object.keys(log);
	//
	// 			keys.map(key => {
	// 				logtime[key] = (logtime[key]||0) + log[key];
	// 			});
	// 		});
	// 	});
	//
	// 	return {
	// 		respCode: 200,
	// 		respReturn: true,
	// 		respData: Req.body || {}
	// 	};
	// }],

    //`A.populate:task, logtimes.taskId, _id, logtimes.task, +, name, name2, type, number `,
    //`A.deleteKObject:: _id`,
    //"A.refactorOutput::",
], { useZip: true } ]);


LogTimeRoute.POST.push([["/by/task"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
        const projectId = Req.project._id; // pipeData.projectId || pipeData.projectIds;
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		var milestoneIds = (pipeData.milestone || pipeData.milestones) ||
						   (pipeData.milestoneId || pipeData.milestoneIds);
		let name = (pipeData.name || pipeData.content) || (pipeData.text || pipeData.search);
		var memberIds = (pipeData.users || pipeData.userIds) ||
						(pipeData.members || pipeData.memberIds) ||
						(pipeData.creatorId || pipeData.userId);

		var user = Req.user;
		var hasAdmin = user.hasAdmin || user.hasAgent;

		pipeData.keepTask = true;
		pipeData.keepTeam = true;
		pipeData.keepMember = true;
		pipeData.keepMilestone = true;

		var ops = {};
		if(!hasAdmin) { //} && (!roleProject || !(roleProject.setting||{}).view)) {
			//memberIds = [user._id]; // Will discuss this case, user can see other logtime list
		}

		if(projectId) {
			ops.projectId = projectId;
		}

        if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds]
			}
			if(memberIds.length > 0) {
            	ops.creatorId = { $in: memberIds };
				pipeData.keepMember = false;
			}
        }

        if(fromDate && toDate) {
            ops["$and"] = [
				{ fromTime: {"$gte": new Date(fromDate)} },
				{ fromTime: {"$lte": new Date(toDate)} }
			];
        }

		pipeData.taskName = "";
		pipeData.taskNumber = -1;
		if(name) {
			// Taskname, name2, task number
			pipeData.taskNumber = (name-0)||-1;
			name = Req.func.getASCIISearch(name, "gmi");
			pipeData.taskName = name;
			pipeData.keepTask = false;
		}

		pipeData.milestoneIds = [];
		pipeData.keepItemLogtime = true;
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				pipeData.keepMilestone = false;
				pipeData.keepItemLogtime = false;
				pipeData.milestoneIds = milestoneIds;
			}
		}

		pipeData.projectId = projectId;
		pipeData.ops = ops;
		//console.log(ops);

		return Req.UNRESULT;
    }],

	//`A.getPaginate > page`,
    [`A.aggregateOne: logtime`, [
		{ $match: "@ops" },

		// Filter by milestone
		{ $populateFilter: ["task", [
			{ $let: { taskId: "$taskId" }},
			{ $expr: { $and : [
				{ $eq: ["$$taskId", "$_id"] },
				{ $or: [
					{ $eq: ["@taskName", ""]},
					{ $regexMatch: { input: "$name", regex: "@taskName" }},
					{ $regexMatch: { input: "$name2", regex: "@taskName" }},
					{ $eq: ["$number", "@taskNumber"]},
				]},
				{ $or: [
					{ $in: ["@milestoneIds", [false, null, undefined, []]] },
					{ $in: ["$milestoneId", "@milestoneIds"] },
				]}
			]}}
		], "task", "@keepTask", 1, "_id", "type", "name", "name2", "number", "milestoneId"]},

		{ $sort: {
			fromTime: -1,
			modifiedAt: -1,
			createdAt: -1,
		}},

		// Group by Type
		{ $group: {
			_id: {
				type: "$type",
				task: "$task._id"
			},
			hour: { $sum: "$hour" },
			type: { $first: "$type" },
			task: { $first: "$task" },
			milestone: { $first: "$task.milestoneId" },
		}},
		{ $project: {
			"task.milestoneId": 0
		}},
		{ $sort: {
			hour: -1,
		}},

		// Update type of logtime
		{ $addFields: {
			logtime: {
				working		: { $cond: [{$eq: ["$type", "working"]}, "$hour", 0] },
				correcting	: { $cond: [{$eq: ["$type", "correcting"]}, "$hour", 0] },
				implementing: { $cond: [{$eq: ["$type", "implementing"]}, "$hour", 0] },
				reviewing	: { $cond: [{$eq: ["$type", "reviewing"]}, "$hour", 0] },
				designing	: { $cond: [{$eq: ["$type", "designing"]}, "$hour", 0] },
				training	: { $cond: [{$eq: ["$type", "training"]}, "$hour", 0] },
				meeting		: { $cond: [{$eq: ["$type", "meeting"]}, "$hour", 0] },
				optimizing	: { $cond: [{$eq: ["$type", "optimizing"]}, "$hour", 0] },
				testing		: { $cond: [{$eq: ["$type", "testing"]}, "$hour", 0] },
				coding		: { $cond: [{$eq: ["$type", "coding"]}, "$hour", 0] },
				planning	: { $cond: [{$eq: ["$type", "planning"]}, "$hour", 0] },
				other		: { $cond: [{$eq: ["$type", "other"]}, "$hour", 0] },
			}
		}},

		// Group by Task
		{ $group: {
			_id: "$task._id",
			typeLog: { $push: {
				logtime: "$logtime"
			}},
			hour: { $sum: "$hour" },
			task: { $first: "$task"},
			milestone: { $first: "$milestone" }
		}},
		{ $addFields: {
			logtime: {
				working		: { $sum: "$typeLog.logtime.working" },
				correcting	: { $sum: "$typeLog.logtime.correcting" },
				implementing: { $sum: "$typeLog.logtime.implementing" },
				reviewing	: { $sum: "$typeLog.logtime.reviewing" },
				designing	: { $sum: "$typeLog.logtime.designing" },
				training	: { $sum: "$typeLog.logtime.training" },
				meeting		: { $sum: "$typeLog.logtime.meeting" },
				optimizing	: { $sum: "$typeLog.logtime.optimizing" },
				testing		: { $sum: "$typeLog.logtime.testing" },
				coding		: { $sum: "$typeLog.logtime.coding" },
				planning	: { $sum: "$typeLog.logtime.planning" },
				other		: { $sum: "$typeLog.logtime.other" },
			},
		}},
		{ $sort: {
			"task.number": -1,
		}},

		{ $populateFilter: ["milestone", "milestone:_id", "milestone", "@keepMilestone", 1, "_id", "name", "name2", "avt", "number", "startDate", "endDate"]},
		// Group all unamne user
		{ $addFields: {
			milestone: {
				_id: { $ifNull: ["$milestone._id", ""]},
				name: { $ifNull: ["$milestone.name", ""]},
				avt: { $ifNull: ["$milestone.avt", 0]},
                number: { $ifNull: ["$milestone.number", 0]},
				startDate: "$milestone.startDate",
				endDate: "$milestone.endDate",
			}
		}},

		// Group by Milestone
		{ $group: {
			_id: "$milestone._id",
			taskLogs: { $push: {
				hour: "$hour",
				logtime: "$logtime",
				task: "$task",
			}},
			hour: { $sum: "$hour" },
			milestone: { $first: "$milestone" }
		}},
		{ $addFields: {
			logtime: {
				working		: { $sum: "$taskLogs.logtime.working" },
				correcting	: { $sum: "$taskLogs.logtime.correcting" },
				implementing: { $sum: "$taskLogs.logtime.implementing" },
				reviewing	: { $sum: "$taskLogs.logtime.reviewing" },
				designing	: { $sum: "$taskLogs.logtime.designing" },
				training	: { $sum: "$taskLogs.logtime.training" },
				meeting		: { $sum: "$taskLogs.logtime.meeting" },
				optimizing	: { $sum: "$taskLogs.logtime.optimizing" },
				testing		: { $sum: "$taskLogs.logtime.testing" },
				coding		: { $sum: "$taskLogs.logtime.coding" },
				planning	: { $sum: "$taskLogs.logtime.planning" },
				other		: { $sum: "$taskLogs.logtime.other" },
			},
		}},

		// Sort by user name
		//{ $match: "@userName" },
		{ $sort: {
			"milestone.name$": 1,
			"milestone.startDate": 1
		}},

		// Group all to summary
		{ $group: {
			_id: null,
			milestoneLogs: { $push: {
				hour: "$hour",
				logtime: "$logtime",
				milestone: "$milestone",
				taskLogs: "$taskLogs"
			}},
			totalLogtime: { $sum: "$hour" }
		}},
		{ $project: {
			_id: 0,
		}}
	]],

	`A.trimObject:: false: false: true`,
], { useZip: true } ]);


LogTimeRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view, logtime.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > logtime:: logtime: projectId!, taskId, content, type, fromTime, hour, amount, approverIds`,
    // `A.findOne > dbBody: task: {_id: "@taskId"}`,
    // `A.pipeRoute: Checktask`,
	// 'A.printObject',

	`A.findById(*) > hrcontract: hrcontract: { userId: "@P.user._id" }`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var logtime = body.logtime;
		logtime.amount = logtime.hour * (((body.hrcontract||{}).overview||{}).hourlySalary||0);

		return logtime;
	}],

    `A.insertOne(*): logtime: @P.body`,

    `A.populate: user, creatorId, _id, creator, +, name, name2, userId, avt:
				 task, taskId, _id, task, +, name, name2, type, number`,
    //`A.populate: task, taskId, _id, task, +, name, name2, type, number`,

    `A.pipeRoute: logtime: {action: "created"}`,
    `A.refactorOutput:: _id, number, name, name2, content, fromTime, creator, hour, createdAt, task, type`
]]);

LogTimeRoute.POST.push([["/task"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: logtime: projectId!, taskId!`,
    [`A.aggregateOne > logtimeDb: logtime`, [
		{ $limit: 1},
        { $lookup: {
            from: 'logtime',
            let: { taskId: "@taskId", projectId: "@projectId" },
            pipeline: [{
                $match: { $expr: { $and: [
					{ $eq: ["$projectId", "$$projectId"] },
					{ $eq: ["$taskId", "$$taskId"] }]}
                }},
				{ $group: {
                    _id: "$creatorId",
                    hour: { $sum: "$hour" },
                }},

				{ $populate: ["user", "_id", "_id", "creator", false]}, // Remove deleted user
				{ $project: {
                    hour: 1,
                    "creator._id": 1,
                    "creator.name": 1,
					"creator.name2": 1,
                    "creator.avt": 1,
					"creator.userId": 1,
                }},
				{ $project: {
					"_id": 0,
				}}
			],
            as: "logtimes"
        }},
        { $addFields: {
			totalLogtime: { $sum: "$logtimes.hour" }
		}},
        { $project: {
            logtimes: 1,
            totalLogtime: 1
		}}
    ]],

    `A.findOne > task: task: { _id: "@taskId" }`,
    `A.deUniquizedObject > task : @task`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		let body = Req.body || {};
		let logtimeDb = body.logtimeDb || {};
        let logtimes = logtimeDb.logtimes || [];

        let task = pipeData.task;
        if(logtimes.length == 0) {
            return { respData: { logtime: [], totalLogtime: 0 }, respCode: 200 };
        }

        for (let i = 0; i < logtimes.length; i++) {
            let creator = ((logtimes[i].creator||"")._id||"").toString() || "^-^";
            logtimes[i].isAssignee = false;
            logtimes[i].isTester = false;
            logtimes[i].isReviewer = false;
            if (task.assigneeIds.indexOf(creator) >= 0) {
                logtimes[i].isAssignee = true;
            }

            if (task.testerIds.indexOf(creator) >= 0) {
                logtimes[i].isTester = true;
            }

            if (task.reviewerIds.indexOf(creator) >= 0) {
                logtimes[i].isReviewer = true;
            }
        }

        pipeData = { logtimes: logtimes, totalLogtime: logtimeDb.totalLogtime };
        return pipeData;
    }],
]]);

LogTimeRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): logtime`, [
		{ $match: {
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			],
			projectId: "@P.project._id"
		}},

		{ $addFields: {
			approverIds: { $ifNull: ["$approverIds", []] },
		}},

		{ $populateFilter: ["user", "creatorId:_id", "creator", true, 1, "_id", "name", "userId", "avt"]},
		{ $populateFilter: ["task", "taskId:_id", "task", true, 1, "_id", "name", "name2", "type", "number"]},
		{ $populateFilter: ["user", "approverIds$:_id", "approvers", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			type: 1,
			number: 1,
			content: 1,
			totalHour: 1,
			fromTime: 1,

			milestoneId: 1,
			sprintId: 1,
			featureId: 1,
			taskId: 1,
			
			hour: 1,
			//amount: 1,
			createdAt: 1,
			modifiedAt: 1,
			creatorId: 1,

			task: 1,
			creator: 1,
			approvers: 1,
			rejectedMessage: 1
		}}

	]],

    // `<F1>A.findOne(*): logtime: {$or: [{_id: "@P.route._id"}, {number: "@P.route._id"}]}`,
    // `A.populate :user, creatorId, _id, creator, +, userId, avt, name
    //             :task, taskId, _id, task, +, name, name2, type, number
	// 			:user, approverIds, _id, approvers, +, name, name2, userId, avt`,
    // `A.refactorOutput:: _id, name, name2, number, content, totalHour, fromTime, creator, hour, amount,  createdAt, creatorId, task, type, approvers, rejectedMessage`

]]);

LogTimeRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view, logtime.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.verifyInput > reqData:: logtime: taskId, content, fromTime, hour, status, type, approverIds, projectId-, amount-, ...`,

	[`A.aggregateOne(*) > dbData::`, [
		{ $addFields: {
			logtimeId: "@P.route._id"
		}},
		{ $populate: ["logtime", "logtimeId", "_id", "logtime", true]},
		{ $populate: ["hrcontract", "logtime.creatorId", "userId", "hrcontract", true]}, // get salary of creator
	]],

    //`A.findOne(*) > logtime: logtime: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

		const reqData = pipeData.reqData;
		const dbData = pipeData.dbData;

		const logtime = dbData.logtime;
		var permit = (logtime && logtime._id) &&
					 (hasAdmin || ((logtime.creatorId.toString() == user._id.toString()) && (![2].includes(logtime.status)) ));

        if (!permit) {
            return {
				respData: "E-02",
				respReturn: true,
				respCode : 500
			};
        }

		reqData.amount = reqData.hour * (((dbData.hrcontract||0).overview||{}).hourlySalary||0);

        return reqData;
    }],

    `A.updateById(*): logtime: {_id: "@P.route._id", projectId: "@P.project._id"}: @P.body`,

	`A.pipeRoute: logtime: { action: "updated" }`,
	`A.responseObject: 200: Update logtime successfully!`
]]);

LogTimeRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: logtime.view, logtime.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.deleteById(*) > P.popBody: logtime: {
		_id: "@P.route._id",
		projectId: "@P.project._id"
	 }`,

	`A.assertKeyExisted(*): @P.deletedItem: _id: Item was not found!`,

	`A.pipeRoute: logtime: { action: "deleted" }`,
	`A.responseObject: 200: Delete logtime successfully!`
]]);

module.exports = LogTimeRoute;
