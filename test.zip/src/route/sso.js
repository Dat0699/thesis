const SSORoute = {
	route	: "sso/auth",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],
    config: {
		unAuth				: true,
		imCompany			: true,
        imCache		        : true,
        imCodec		        : true, // To import createPassword, comparePassword
		imMail		        : true,
        imPush		        : true,
        IgnoreModifiedAt    : true,
        imBase		        : true,

		permitAgent			: true,
    }
};

// ------------------ Bio Metric Checking ------------------
SSORoute.POST.push([["/bio/register"], [
	`A.verifyKObject:: biometric!: verify.stringType`,
	`A.updateById(*): Company.userCompany: { _id: "@P.user.userId" }, { useBio: true, bioToken: "@P.body.biometric", bioUpdatedAt: "@(new Date())" }`
]]);

SSORoute.POST.push([["/bio/revoke"], [
	// `A.verifyKObject:: biometric!: verify.stringType`,
	`A.updateById(*): Company.userCompany: { _id: "@P.user.userId" }, { useBio: false, bioToken: "", bioUpdatedAt: "@(new Date())" }`
]]);

SSORoute.POST.push([["/bio/checking"], [
	`A.verifyKObject:: biometric!: verify.stringType`,
	`A.updateById(*) > data: Company.userCompany: { _id: "@P.user.userId", useBio: true, bioToken: "@P.body.biometric" }`,
	`A.verifyKObject(data):: email!: verify.emailType`, // check make sure this is an email
	`A.responseObject: 200: true`
]]);


// ------------------ QR Login ------------------
SSORoute.POST.push([["/qr/request"], [
	// Check more condition for secure

	// Generate token for polling and QRCode
	`A.generateUniqueID > token: 36`,
	// `A.printObject`,

    `A.setKValue: @token: true-value-random-type: 60: true`,
	`A.responseObject: 200: { token: "@token" }`,
]]);

SSORoute.GET.push([["/qr/image/:token1/:token2/imageQR.svg"], [
	// Check more condition for secure
	`A.verifyKObject(P.route):: token1!: verify.qrType:
								token2!: verify.qrType`,

	`A.getKValue(P.route) > qrToken: @(token2 + token1): true`,
	// `A.printObject:`,
	`A.verifyKObject:: qrToken!: verify.qrType`,

	`A.generateQRCode > qrCode: @("QR:Login:" + qrToken):: {result: "string", type: "svg"}`,
	`A.pipeString: @qrCode: loginQR.svg`,
	// `A.responseObject: 200: { token: "@token", qrCode: "@qrCode"}`,
]]);

SSORoute.POST.push([["/qr/approve"], [
	`A.verifyKObject:: token!: verify.qrType`,
	// `A.printObject`,

	`A.getKValue > validToken: @token: true`,
	// `A.printObject`,

	// check make sure this is an Bool and True
	//`A.verifyKObject:: validToken!: verify.boolType`,

	// Or verify it exactly by using assertObject
	`A.assertObject:: and: (
		validToken type string,
		validToken == 'true-value-random-type'
	): {
		respData: "Could not approve!",
		respCode: 500,
		respReturn: true
	}`,

	`A.setKValue(*): @P.body.token: @P.user.email: 30: true`,
	`A.responseObject: 200: Approve sign-in Successfully!`,
], { unAuth: false}]);


// notify for user 
SSORoute.POST.push([["/qr/polling"], [
	`A.verifyKObject:: token!: verify.qrType`,
	// `A.printObject`,
	
	`A.getKValue > email: @token: true`,
	// `A.printObject`,

	`A.assertObject:: and: (
		email type string,
		email !== 'true-value-random-type'
	): {
		msg: "Have not approved yet",
	}`,

	`A.verifyKObject:: email!: verify.emailType`, // check make sure this is an email
	// `A.printObject`,

	// Clear token, by set value with expired in 1 seconds
	`A.setKValue: @token: false: 1: true`,
	`A.setKObject(*): @P: skipCheckingPassword: #true`,
	// `A.printObject(P):`,
	`A.pipeRoute: signinAccount: {email: "@email", password: "a%N*$y^Pa#s-s7!8&0?z_Z"}`
]]);


// ------------------ Google Login ------------------
SSORoute.POST.push([["/google/signin"], [
/*
// Lan dau chua login
{
    "credential": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjFhYWU4ZDdjOTIwNThiNWVlYTQ1Njg5NWJmODkwODQ1NzFlMzA2ZjMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2ODAxMDA1NjAsImF1ZCI6IjEwMDcyODEyNDUyNDYtdHNsMDlyNTR1YnZyNzNuanQ3NGtuMGszbGtsOHN1cjYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDQxNjkxOTY2NDczMjkzOTgwNjAiLCJlbWFpbCI6ImhpZ2FtLnZuQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxMDA3MjgxMjQ1MjQ2LXRzbDA5cjU0dWJ2cjczbmp0NzRrbjBrM2xrbDhzdXI2LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwibmFtZSI6IkdhbSBIZWxsbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BR05teXhaOU5fZENMMWZBaU1wUUdScjUtT1RiYWY5NTM1bVBfWUItQ1BUTz1zOTYtYyIsImdpdmVuX25hbWUiOiJHYW0iLCJmYW1pbHlfbmFtZSI6IkhlbGxvIiwiaWF0IjoxNjgwMTAwODYwLCJleHAiOjE2ODAxMDQ0NjAsImp0aSI6IjFhNTVlODQwNTA1NmE0OTYwMGZiNDRkYmI2MDA4YmRmNjk2ZTAzMjIifQ.OGFhitJ45VG83YSlMeP1QKWzkSsidIbejPHvONuUZBCE6M8_DL_gObwllY_PfVCpObPIS2SvHfrhoUUFgzhiqqylEicp1dd6vKV3prsAIaDCuQhZi4Kgl0LYrVk0nyyViLbhwo4AIFAyHZlfsifLruq_Wq-Nqo0TwnOihFY9rddz02gb44fUefigULq9rBXicwQ5AwpVTHeBsTYlQdKZUoJ_Dk0Z5Ws23QwGqpqu6-I8L44UMGHyQlp5W4UYAvaofuEd3JHfhD3IH7PHsOXzriTaxF_UjTJ-YCQHTRq4hmzYD9GtfJFA4bXC4qLCNhPM91l5NsMYXDFP6hs_A1rbsg",
    "clientId": "1007281245246-tsl09r54ubvr73njt74kn0k3lkl8sur6.apps.googleusercontent.com",
    "selectBy": "btn_confirm_add_session"
}

// Lan thu 2 khi da login duoc 1 lan roi
{
    "credential": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjFhYWU4ZDdjOTIwNThiNWVlYTQ1Njg5NWJmODkwODQ1NzFlMzA2ZjMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2ODAxMDIzNjgsImF1ZCI6IjEwMDcyODEyNDUyNDYtdHNsMDlyNTR1YnZyNzNuanQ3NGtuMGszbGtsOHN1cjYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDQxNjkxOTY2NDczMjkzOTgwNjAiLCJlbWFpbCI6ImhpZ2FtLnZuQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxMDA3MjgxMjQ1MjQ2LXRzbDA5cjU0dWJ2cjczbmp0NzRrbjBrM2xrbDhzdXI2LmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwibmFtZSI6IkdhbSBIZWxsbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BR05teXhaOU5fZENMMWZBaU1wUUdScjUtT1RiYWY5NTM1bVBfWUItQ1BUTz1zOTYtYyIsImdpdmVuX25hbWUiOiJHYW0iLCJmYW1pbHlfbmFtZSI6IkhlbGxvIiwiaWF0IjoxNjgwMTAyNjY4LCJleHAiOjE2ODAxMDYyNjgsImp0aSI6IjU0OWE4YzgzYjA0YzNmZmJjMmU1OWEyY2Y1YzU2NzMyNGU4OGU3ZGYifQ.mWaubJ_L0xjBZNB3gJYKdg4GJva7fAsYxwZ9WPDgRTp3egn7kI1j9oiSjDD0Soavhn1TLmMb1-cGMN4d0O0Kfei58s6e_edFmEWxulMrXk572wp3HaxKrtMdvvVHIj5JsIUh5eBV76ZUnaSqGua8IXk5lmMMklJL2O-KJJeYWR-XdkSEbpHwApqP_HF5mUhT8hCgbEaZG96sS9gUll-cS667MaTKsEdfXrDPE2SnJnHBAC8qOIpa2VWAbYZ1eMSONYwfDOcqE18v5WxH2ynbnRaqRAGuVjastASRf1g9kCpYhQoQTJFS_oh1vlNFxgemigAacbPSTCA3QoW4qcSGXA",
    "clientId": "1007281245246-tsl09r54ubvr73njt74kn0k3lkl8sur6.apps.googleusercontent.com",
    "selectBy": "btn"
}

// Decode Token
{
  "iss": "https://accounts.google.com",
  "nbf": 1680100560,
  "aud": "1007281245246-tsl09r54ubvr73njt74kn0k3lkl8sur6.apps.googleusercontent.com",
  "sub": "104169196647329398060",
  "email": "higam.vn@gmail.com",
  "email_verified": true,
  "azp": "1007281245246-tsl09r54ubvr73njt74kn0k3lkl8sur6.apps.googleusercontent.com",
  "name": "Gam Hello",
  "picture": "https://lh3.googleusercontent.com/a/AGNmyxZ9N_dCL1fAiMpQGRr5-OTbaf9535mP_YB-CPTO=s96-c",
  "given_name": "Gam",
  "family_name": "Hello",
  "iat": 1680100860,
  "exp": 1680104460,
  "jti": "1a55e8405056a49600fb44dbb6008bdf696e0322"
}

*/

	`A.verifyKObject::  credential!: verify.stringType:
						clientId!: verify.stringType:
						selectBy!: verify.stringType`,
	// `A.printObject`,
	
	`A.formObject(*) > reqData:: {
		client_id: "@K.SSO.Google.client_id",
		client_secret: "@K.SSO.Google.client_secret",
		grant_type: "@K.SSO.Google.grant_type",
		redirect_uri: "@K.SSO.Google.redirect_uri",
		code: "@P.body.credential"
	}`,
	// 
	// `A.printObject(reqData):`,

	// Call Google Server to verify (pick one from three)
	// `A.sendData(*) > googleAccount: POST: @K.SSO.Google.ExchangeTokenURL: @P.body.reqData: {"content-type": "application/json"}: json:: true`,
	// `A.printObject:`,
	
	// `A.getGoolgeToken > googleAccount: @credential`,
	// `A.printObject:`,

	`A.verifyGoolgeIdToken > googleAccount: @credential`,
	// `A.printObject: googleAccount: googleAccount.payload: googleAccount.payload.email`,
	// `A.printObject: googleAccount`,
	
	// Recheck email format
	`A.verifyKObject(googleAccount.payload):: email!: verify.emailType`, // check make sure this is an email
	// `A.printObject:`,

	// Approve Google login
	`A.setKObject(*): @P: skipCheckingPassword: #true`,
	`A.pipeRoute: signinAccount: {email: "@googleAccount.payload.email", password: "a%N*$y^Pa#s-s7!8&0?z_Z"}`
]]);

SSORoute.POST.push([["/github/signin"], [
	`A.verifyKObject::  code!: verify.stringType`,

	`A.formObject(*) > reqData:: {
		client_id: "@K.SSO.Github.client_id",
		client_secret: "@K.SSO.Github.client_secret",
		redirect_uri: "@K.SSO.Github.redirect_uri",
		code: "@P.body.code"
	}`,

	`A.sendData(*) > githubAccessToken: POST: @K.SSO.Github.ExchangeTokenURL: @P.body.reqData: {"content-type": "application/json", "Accept": "application/json"}: json:: true`,
	// `A.printObject: githubAccessToken`,
	
	`A.formObject > reqHeader:: ({"Authorization": "@('Bearer ' + githubAccessToken.data['access_token'])"})`,
	// `A.printObject: reqHeader`,

	`A.sendData(*) > githubProfile: GET: @K.SSO.Github.GetProfileUrl:: @P.body.reqHeader: json:: true`,
	// `A.printObject:`,
]]);

SSORoute.POST.push([["/gitlab/signin"], [

]]);

SSORoute.POST.push([["/apple/signin"], [

]]);

SSORoute.POST.push([["/microsoft/signin"], [
	`A.verifyKObject:: otp!: verify.qrType`,
]]);

module.exports = SSORoute;
