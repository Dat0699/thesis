const KpiRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
	}
};


KpiRoute.POST.push([[""], [
	`A.verifyInput:: kpi: title!, fromDate!, toDate!, enable!`,
	`A.insertOne: kpi`,
	`A.refactorOutput:: title, fromDate, toDate, enable, missions, status`,
]]);

KpiRoute.POST.push([["/s"], [
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {

		const name = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		const projectId = pipeData.projectId;
		var milestoneId = pipeData.milestoneId;

        var matchOps = {};
		if(projectId) {
        	matchOps.projectId = projectId;
		}

        if(name) {
            matchOps.name = Req.func.getASCIISearch(name, "gmi");
        }

        if(fromDate) {
            matchOps.startDate =  {
                "$gte" : new Date(fromDate)
            }
        }

		if(toDate) {
            matchOps.endDate =  {
                "$lte" : new Date(toDate)
            }
        }

		if(milestoneId) {
			if(!Array.isArray(milestoneId)) {
				milestoneId = [milestoneId];
			}

			matchOps.milestoneId = { $in: milestoneId };
		}

        pipeData.matchOps = matchOps;
		//console.log("pipeData: ", pipeData);

        return pipeData;
    }],

	[`A.aggregate: kpi`, [
		{ $match: "@matchOps" },
		{ $addFields: {
			collectCount: { $size: "$collects" },
			memberCount: { $size: "$missions"},
			memberDoneCount: {
				$size: {
					$filter: {
						input: "$missions",
						as: "missions",
						cond: { "$or": [
							{"$eq": ["$$missions.result", "passed"] },
							{"$gte": ["$$missions.complete", 100] }
						]}
					}
				}
			}
		}},

		{ $addFields: {
			complete: { $divide: ["$memberCount", "$memberDoneCount"] }
		}},

		{ $project: {
			title: 1,
			fromDate: 1,
			toDate: 1,
			memberCount: 1,
			memberDoneCount: 1,
			collectCount: 1,
			status: 1
		}}
	]]
]]);

KpiRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.findOne: kpi`,
	`A.refactorOutput:: title, fromDate, toDate, enable, missions, status`,
]]);

KpiRoute.PUT.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: kpi: title, fromDate, toDate, enable, missions, status`,
	`A.updateById: kpi`,
	`A.refactorOutput:: title, fromDate, toDate, enable, mission, status`,
]]);

KpiRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: kpi`,
	`A.responseObject: 200: Delete successfully!`,
]]);


KpiRoute.POST.push([[":_id/mission/s"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.trimObject`,
	[`A.aggregateOne(*): kpi`, [
		{ $match: {
			_id: "@P.route._id"
		} },

		// { $addFields: {
		// 	collectCount: { $size: "$collects" },
		// 	memberCount: { $size: "$missions"},
		// 	memberDoneCount: {
		// 		$size: {
		// 			$filter: {
		// 				input: "$missions",
		// 				as: "missions",
		// 				cond: { $or: [
		// 					{ $eq: ["$$missions.result", "passed"] },
		// 					{ $gte: ["$$missions.complete", 100] }
		// 				]}
		// 			}
		// 		}
		// 	}
		// }},
		//
		// { $addFields: {
		// 	complete: { $divide: ["$memberCount", "$memberDoneCount"] }
		// }},

		{ $project: {
			missions: 1,
			// title: 1,
			// fromDate: 1,
			// toDate: 1,
			// memberCount: 1,
			// memberDoneCount: 1,
			// collectCount: 1
		}}
	]],
	`A.responseObject: 200: @dbData.missions`
]]);

KpiRoute.POST.push([[":_id/mission/get/:userId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								userId: verify.idType`,

	`A.trimObject`,
	[`A.aggregateOne(*): kpi`, [
		{ $match: {
			_id: "@P.route._id"
		} },

		{ $addFields: {
			// collectCount: { $size: "$collects" },
			// memberCount: { $size: "$missions"},
			memberDoneCount: {
				$size: {
					$filter: {
						input: "$missions",
						as: "missions",
						cond: { $or: [
							{ $eq: ["$$missions.userId", "@P.route.userId"] },
						]}
					}
				}
			}
		}},

		{ $project: {
			missions: 1,
			// title: 1,
			// fromDate: 1,
			// toDate: 1,
			// memberCount: 1,
			// memberDoneCount: 1,
			// collectCount: 1
		}}
	]],
	`A.responseObject: 200: @missions`
]]);

// KpiRoute.POST.push([[":_id/mission/update/:userId"], [
//
// ]]);
//
// KpiRoute.POST.push([[":_id/mission/calculate"], [
//
// ]]);


// @Toan update this api
KpiRoute.POST.push([[":_id/mission/collect"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findOne > dbData: kpi`,
	`A.setKObject(*): @dbData.missions.criteria.collectedBy: @P.user._id`,
	`A.setKObject(*): @dbData.missions.criteria.collectedAt: @(new Date())`,
	`A.insertSubItem(*) > tmp: kpi: @P.route._id: collects: @P.body.dbData.missions: true`,
	`A.responseObject: 200: @dbData.missions`
]]);

// API Get KPI full list by projectId, fromDate, to Date, name -> done API POST: /s

// API Get List Mission -> POST :_id/misison/s
// API Get User Mission -> POST :_id/misison/get/:userId
// API Update User Mission -> POST :_id/misison/update/:userId

// API Recalculate User Mission -> POST :_id/misison/calculate
// API Collect All Users Mission  POST :_id/misison/collect

module.exports = KpiRoute;
