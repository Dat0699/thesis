const LabelRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		imProject		: true,
        // checkMIFs	: [],
    }
};

LabelRoute.POST.push([[""], [
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view, label.modify`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: label: name!, type! ...`,
	`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"], type: "@type"}`,

	// [`A.jsScript(*):`, (Req, pipeData, ctx) => {
	// 	var A = pipeData.A;
	//
	// 	var type = (Req.body || {}).type;
	// 	if(type == "all") {
	// 		type = "setting";
	// 	}
	//
	// 	Req.body.permit = [`${type}.view`, `${type}.modify`];
	// 	return Req.UNRESULT;
	// }],
	//
	// `A.checkRole(*): project: @P.project._id: roleproject: @P.body.permit`,

	// [`A.aggregateOne > rs: label`, [
	// 	{ $match: {
	// 		name: "@name",
	// 		type: { $in: ["@type", "all"] },
	// 		$or: [
	// 			{ projectId: "@projectId" },
	// 			{ hasGlobal: true },
	// 		]
	// 	}}
	// ]],

	`A.checkLimitItem: label: { $expr: { $and: [
		{ $eq: ["$name", "@name"] },
		{ $or: [
			{ $eq: ["@type", "all"] },
			{ $in: ["$type", ["@type", "all"]] }
		]},
		{ $or: [
			{ $eq: ["$projectId", "@projectId"] },
			{ $eq: ["$hasGlobal", true] }
		]},
	]}}: 0: true: Label was being existed!`,

	// [`A.jsScript(*):`, async (Req, pipeData, ctx) => {
	// 	var body = Req.body;
	// 	var rs = body.rs;
	//
	// 	if(rs && rs._id) {
	// 		return {
	// 			respData: "Label existed!",
	// 			respCode: 500,
	// 			respReturn: true,
	// 		};
	// 	}
	// 	return Req.UNRESULT;
	// }],

    `A.insertOne: label`,
    `A.refactorOutput:: _id, name, name2, color, projectId, type, hasGlobal`
]]);

// User for project function
LabelRoute.POST.push([["/s"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject`,
    `A.verifyInput > reqBody:: label: projectId!, type, hasGlobal, ...`,

	`A.pipeRoute: checkLabelGroup: {permit: "view", type: "@type"}`,
	// /`A.checkRole(*): project: @P.project._id: roleproject: @(P.body.type + ".view")`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
        var ops = [];
        let { projectId, hasGlobal, name, name2, type } = ((Req.body||{}).reqBody||{});
        if (type) {
            ops.push({ type: { $in: ["all", type] }});
        }

        if (pipeData.name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

		if(projectId) {
			ops.push({ $or: [
				{ projectId : projectId },
	            { hasGlobal : true }
			]});
        }

        if(hasGlobal) {
            ops.push({ hasGlobal: !!hasGlobal })
        }

		if(ops && (ops.length > 0)) {
        	pipeData.ops = { $and: ops };

		} else {
			pipeData.ops = {};
		}
        return pipeData;
    }],

	[`A.aggregate: label:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			type: 1,
			hasGlobal: 1,
		}},
	]],
], {useZip: true}]);

// User for Company Setting and other function -> it useing it own in company route
// LabelRoute.POST.push([["/full"], [
// 	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,
// 	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
//
// 	`A.trimObject`,
//     `A.verifyInput > reqBody:: label: type, ...`,
//
//     `A.trimObject`,
//     [`A.jsScript`, (Req, pipeData, ctx) => {
//         var ops = [];
//         let { hasGlobal, name, name2, type } = ((Req.body||{}).reqBody||{});
//         if (type) {
//             ops.push({ type: type });
//         }
//
//         if (pipeData.name) {
// 			var nameReg = Req.func.getASCIISearch(name, "gmi");
//             ops.push({ $or: [{ name: nameReg }, { name2: nameReg } ]});
//         }
//
//         ops.push({ hasGlobal: hasGlobal })
//
// 		if(ops && (ops.length > 0)) {
//         	pipeData.ops = { $and: ops };
//
// 		} else {
// 			pipeData.ops = {};
// 		}
//
//         return pipeData;
//     }],
//
// 	[`A.aggregate: label:`, [
// 		{ $match: "@ops" },
// 		{ $limit: 50 },
// 		{ $project: {
// 			_id: 1,
// 			name: 1,
// 			name2: 1,
// 			color: 1,
// 			type: 1,
// 			hasGlobal: 1,
// 		}},
// 		{ $sort: {
// 			name$: 1
// 		}}
// 	]],
// ]]);

// LabelRoute.GET.push([[":_id"], [
// 	//`A.checkRole(*): project: @P.project._id: roleproject: label.view`,
// 	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
//
// 	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
//     `A.findOne: label: { _id: "@P.route._id" }`,
//     `A.refactorOutput`,
// ]]);

LabelRoute.PUT.push([[":_id"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.verifyInput:: label: projectId-, creatorId-, createdAt-, ...`,
	`A.pipeRoute: checkLabelGroup: {permit: ["view", "modify"]}`,

	`A.checkLimitItem: label: { $expr: { $and: [
		{ $eq: ["$name", "@name"] },
		{ $or: [
			{ $eq: ["@type", "all"] },
			{ $in: ["$type", ["@type", "all"]] }
		]},
		{ $or: [
			{ $eq: ["$projectId", "@projectId"] },
			{ $eq: ["$hasGlobal", true] }
		]},
	]}}: 0: true: Label existed!`,

    `A.updateById(*): label: { _id: "@P.route._id" }: @P.body`,
    `A.refactorOutput:: _id, name, name2, color, projectId, type, hasGlobal`
]]);

LabelRoute.DELETE.push([[":_id"], [
	//`A.checkRole(*): project: @P.project._id: roleproject: setting.view, setting.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkLabelGroup: {permit: ["view", "delete"]}`,

    `A.deleteById(*): label: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete label successfully!`
]]);

module.exports = LabelRoute;
