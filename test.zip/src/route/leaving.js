const LeavingRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar", "leaving"],
		roleUserIdKey	: "userId"
	}
};

LeavingRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view, leaving.modify`,
	`A.fillingDateWorking:`,
	//`A.printObject`,

	`A.verifyInput:: leaving: reason!, reason2, approverIds, number-, status-, approverId-, amount-, ...`,

	`U.Date.calculateLeavingDuration`,
	`A.pipeRoute: calculateLeavingAmount`,

	`A.insertOne: leaving`,
	`A.populate: user, creatorId, id, userId, +, name, name2, userId, avt`,
	`A.refactorOutput:: createdAt-, creatorId-, modifiedAt-, modifierId-, ...`
]]);

LeavingRoute.POST.push([["update/yearly/holiday"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view`,
	`A.verifyInput > reqData:: leaving: startDate!, userId!, duration!, reason!, reason2`,
	`A.dateRangeFromYear > dbDate: @startDate`,
	//`A.printObject`,
	`A.updateOne: leaving: {
		"$and": [
			{ startDate: { "$gte": "@dbDate.minDate" }},
			{ startDate: { "$lte": "@dbDate.maxDate" }},
			{ userId: { "$eq": "@reqData.userId" }}
		]
	}: @reqData: true`
], {
	IgnoreSanitized: true
}]);

LeavingRoute.GET.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	//`U.Date.companyTimePoint > companyTimePoint`,
	[`A.aggregateOne(*): leaving`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $or: [
				{ $eq: ["@P.user._id", "$creatorId"] },
				{ $eq: ["@P.user.hasAgent", true] },
				{ $eq: ["@P.user.hasAdmin", true] },
				{ $and: [
					{ $eq: ["@P.rolecompany.permit.leaving.approve", true] },
					{ $in: ["@P.user._id", { $ifNull: ["$approverIds", [] ]} ]},
					{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
				]},
			]}
		]}}},
		{ $limit: 1 },

		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $populate: ["user", "creatorId", "_id", "userId", false]}, // Remove deleted user
		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		//{ $populate: ["user", "informToIds", "_id", "informTos", undefined]},
		// { $populate: ["user", "approverIds", "_id", "approvers"]},


		// { $lookup: {
		// 	from: "attach",
		// 	localField: "attachIds",
		// 	foreignField: "_id",
		// 	as: "attachs"
		// }},

		// { $addFields: {
		// 	duration: { $divide: ["$duration", "@P.body.companyTimePoint.wd"] }
		// }},

		{ $project: {
			_id: 1,
			type: 1,
			number: 1,
			startDate: 1,
			endDate: 1,
			duration: 1,
			reason: 1,
			reason2: 1,
			//amount: 1,
			isBonus: 1,

			projectId: 1,
			milestoneId: 1,
			sprintId: 1,
			featureId: 1,

			modifiedAt: 1,
			rejectedMessage: 1,
			status: 1,

			informToIds: 1,
			approverIds: 1,

			"userId._id": 1,
			"userId.name": 1,
			"userId.name2": 1,
			"userId.avt": 1,
			"userId.userId": 1,

			// "informTos._id": 1,
			// "informTos.name": 1,
			// "informTos.name2": 1,
			// "informTos.avt": 1,
			// "informTos.userId": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			// "approvers._id": 1,
			// "approvers.name": 1,
			// "approvers.name2": 1,
			// "approvers.avt": 1,
			// "approvers.userId": 1,

			// "attachs._id": 1,
			// "attachs.name": 1,
			// "attachs.name2": 1,
			// "attachs.path": 1,
		}},
	]],
	//`A.responseObject: 200: @dbData[0]`
]]);

LeavingRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view, leaving.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: leaving: number-, status-, approverId-, amount-, ...`,
	`A.assertObject::: (
		startDate < endDate
	):({
		"respCode": 400, "respData": "To Time invalid", "respReturn": true
	})`,

	[`A.aggregateOne(*) > leavingDb: leaving`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $and: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.leaving.modify", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(leavingDb):: _id!: verify.idType`,

	`U.Date.calculateLeavingDuration`,
	`A.pipeRoute: calculateLeavingAmount`,

	`A.updateOne: leaving`,
	`A.populate: user, creatorId, _id, userId, +, name, name2, userId, avt
			   : user, approverIds, _id, approverId, +, name, name2, userId, avt, email
			   : user, informToIds, _id, informTos, +, name, name2, userId, avt, email`,
			   //: attach, attachId, _id, attach, +, name, name2, mimeType, length`,
	
	`A.printObject`,
	`A.refactorOutput > P.senderContent:: approverIds.email, type, endDate, startDate, reason, reason2, number `,
	// `A.printObject`,

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		let rs = [];
		let listEmail = Req.senderContent.approverIds || [];
		for (let i=0; i < listEmail.length ; i++) {
			rs.push(listEmail[i]['email']);
		}
		Req.messageSender = Req.user;
		Req.listEmail = rs || [];
		return Req.UNRESULT;
	}],
	
	`A.sendMail(*) > tmpMail: {
		"to" 		: ["@P.listEmail"],
		"subject" 	: "{{P.messageSender.name}} just requested for leaving cause {{P.senderContent.type}}",
		"view" 		: "leavingView",
		"data" 		: "@P.body"
	}`,
	`A.refactorOutput:: createdAt-, creatorId-, modifiedAt-, modifierId-, amount-, ...`
]]);

// LeavingRoute.PUT.push([["/:_id/status"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view, leaving.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput:: leaving: status!`,
//
// 	[`A.jsScript`, (Req, pipeData, ctx) => {
// 		const {status} = pipeData;
// 		if (status == 2) {
// 			pipeData.approvedId = Req.user._id
// 		}
// 		return pipeData;
// 	}],
// 	`A.updateOne: leaving`,
// 	`A.populate: user, creatorId, _id, creator, +, name, name2, userId, avt
// 			   : user, approvedId, _id, approved, +, name, name2, userId, avt`,
// 			   //: attach, attachId, _id, attach, +, name, name2, mimeType, length`,
// 	`A.refactorOutput:: createdAt-, creatorId-, modifiedAt-, modifierId-, ...`
// ]]);

LeavingRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view, leaving.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	[`A.aggregateOne(*) > leavingDb: leaving`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $and: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.leaving.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(leavingDb):: _id!: verify.idType`,

	`A.deleteOne: leaving`,
	`A.pipeRoute: deleteLeaving`,
    `A.responseObject: 200: Delete Leaving successfully!`
]]);

LeavingRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view`,
	`A.trimObject`,

    [`A.jsScript`, (Req, pipeData, ctx) => {

		var status = pipeData.status || pipeData.statuses;
		const reason = pipeData.reason || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		var userIds = (pipeData.memberIds || pipeData.memberId) || (pipeData.userIds || pipeData.userId);
		const projectId = pipeData.projectId;
		//var milestoneId = pipeData.milestoneId;

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAdmin;

		var rolecompany = (Req.rolecompany||{}).permit;
		if(!hasAdmin && (!rolecompany || !rolecompany.leaving.approve)) {
			userIds = [user._id];
		}

        var matchOps = [];
		// if(!Req.user.hasAgent) {
		// 	matchOps.push({ isBonus: { $nin: [true] }});
		// }

		if(projectId) {
        	matchOps.push({ $eq: ["$projectId", projectId] });
		}

        if(reason) {
			var nameReg = Req.func.getASCIISearch(reason, "gmi");
			matchOps.push({ $or: [
				{ $regexMatch: { input: "$reason", regex: nameReg }},
				{ $regexMatch: { input: "$reason2", regex: nameReg }},
				{ $eq: ["$number", (reason-0) || -1] }
			]});
        }

		if(fromDate) {
			matchOps.push({ $lte: ["$startDate", new Date(toDate) ]});
        }

		if(toDate) {
			matchOps.push({ $gte: ["$endDate", new Date(fromDate) ]});
        }

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				var inApprovedList = [];
				if( (((Req.rolecompany||{}).permit||{}).leaving||{}).approve ) {
					inApprovedList.push({ "$in": [user._id, "$approverIds"] });
				}

				matchOps.push({ $or: [
					{ "$in": ["$creatorId", userIds ]},
					{ "$in": [user._id, "$informToIds"]},
					...(inApprovedList||[]),
				]});
			}
		}

		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status && status.length > 0) {
				matchOps.push({ $in: ["$status", status] });
			}
		}

		pipeData.matchOps = {};
		if(matchOps.length > 0) {
        	pipeData.matchOps = { $expr: { $and: matchOps } };
		}

		//console.log("pipeData: ", pipeData.matchOps["$and"]);
        return pipeData;
    }],

	//`U.Date.companyTimePoint > companyTimePoint`,
	`A.getPaginate > page`,

	[`A.aggregateOne: leaving`, [
		{ $match: "@matchOps" },
		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $populate: ["user", "creatorId", "_id", "userId", false]}, // Remove deleted user
		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		// { $populate: ["user", "approverIds", "_id", "approvers"]},

		// { $lookup: {
		// 	from: "attach",
		// 	localField: "attachIds",
		// 	foreignField: "_id",
		// 	as: "attachs"
		// }},

		{ $getTotalLength: ["@page", "totalLength"]},
		// { $addFields: {
		// 	duration: { $divide: ["$duration", "@companyTimePoint.wd"] }
		// }},

		{ $project: {
			_id: 1,
			type: 1,
			number: 1,
			startDate: 1,
			endDate: 1,
			duration: 1,
			reason: 1,
			reason2: 1,
			//amount: 1,
			isBonus: 1,

			modifiedAt: 1,
			rejectedMessage: 1,
			status: 1,

			//informToIds: 1,
			approverIds: 1,

			totalLength: 1,

			"userId._id": 1,
			"userId.name": 1,
			"userId.name2": 1,
			"userId.avt": 1,
			"userId.userId": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,


			// "approvers._id": 1,
			// "approvers.name": 1,
			// "approvers.name2": 1,
			// "approvers.avt": 1,
			// "approvers.userId": 1,

			// "attachs._id": 1,
			// "attachs.name": 1,
			// "attachs.name2": 1,
			// "attachs.path": 1,
		}},

		{ $group: {
			_id: {
                month: { $month: "$startDate" },
                //day: { $dayOfMonth: "$startDate" },
                year: { $year: "$startDate" }
            },
			date: { $first: "$startDate" },

			//amount: { $sum: "$amount" },
			duration: { $sum: "$duration" },

			leavings: { $push: "$$ROOT"},
			totalLength : { "$first" : "$totalLength" }
		}},

		{ $sort: {
			date: -1,
		}},

		{ $project: {
			"leavings.totalLength": 0,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "leavings"]}
	]],
	//`A.responseObject: 200: @dbData`
]]);


// LeavingRoute.POST.push([[":_id/attach"], [
// 	`A.verifyInput:: leaving: attachIds!`,
// 	`A.insertSubItem(*) > attachId: leaving: @P.route._id: attachIds: @P.body.attachIds`,
// 	`A.populate: attach, attachIds, _id, attachIds, +, name, name2, mimeType, length `,
//     `A.responseObject: 200: @attach`
// ]]);
//
// LeavingRoute.PUT.push([[":_id/attach"], [
// 	`A.verifyInput:: leaving: attachIds!`,
//     `A.removeSubItem(*): leaving: @P.route._id: attachIds: @P.body.attachIds[0]`,
// 	`A.responseObject: 200: Remove attach successfully!`
// ]]);

LeavingRoute.POST.push([["remaining/holiday"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: leaving.view`,

	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {

		var matchOps = [{
			$eq: ["$status", 2] // Approve leaving must counted only
		}];

		var matchUserOps = {
			hasDeleted: { $nin: [true] },
			status: 1,
		};

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		var userIds = (pipeData.memberId || pipeData.memberIds) ||
					  (pipeData.userId || pipeData.userIds);

        if(fromDate && toDate) {
            matchOps.push({ "$gte": ["$startDate", new Date(fromDate) ]});
			matchOps.push({ "$lte": ["$startDate", new Date(toDate) ]});
        }

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				matchUserOps._id = { $in: userIds };
			}
		}

		matchOps.push({$eq: ["$creatorId", "$$userId"]});
        pipeData.matchOps = { $expr: { $and: matchOps }};

		pipeData.matchUserOps = matchUserOps;
		pipeData.endYear = new Date((new Date()).getFullYear(), 11, 31, 23, 59, 59);

		//console.log("pipeData: ", matchUserOps);
		//console.log("Match Ops: ", matchOps);
        return pipeData;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne: user`, [
		{ $match: "@matchUserOps" },

		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $getTotalLength: ["@page", "totalLength"]},

		// Get Entry day
		// overview.entranceAt
		{ $populateFilter: ["hrcontract", "_id:userId", "hrcontract", true, 1, "overview.entranceAt", "overview.resignDate"]},
		{ $addFields: {
			entranceAt: { $ifNull: ["$hrcontract.overview.entranceAt", "$createdAt"]},
			endYear: { $ifNull: ["$hrcontract.overview.resignDate", "@endYear"]},
		}},

		// Should not
		{ $addFields: {
			yearlyHoliday: {
				$floor: { $multiply: [{ $divide: [{$subtract: ["$endYear", "$entranceAt"]}, 365*86400000]}, 12*8] } // in hour
			}
		}},

		{ $lookup: {
			from: "leaving",
			let: { userId: "$_id" },
			pipeline: [
				{ $match: "@matchOps" },
				{ $addFields: {
					// sick, personal, holiday, legal, bonus
					leavingCount: { $cond: [
						{ $in: ["$type", ["sick", "personal", "holiday", "legal"]] },
						{ $abs: "$duration" },
						0
					]},

					sickCount: { $cond: [
						{ $eq: ["$type", "sick"] },
						{ $abs: "$duration" },
						0
					]},

					personalCount: { $cond: [
						{ $eq: ["$type", "personal"] },
						{ $abs: "$duration" },
						0
					]},

					holidayCount: { $cond: [
						{ $eq: ["$type", "holiday"] },
						{ $abs: "$duration" },
						0
					]},

					legalCount: { $cond: [
						{ $eq: ["$type", "legal"] },
						{ $abs: "$duration" },
						0
					]},

					// Increase
					bonusCount: { $cond: [
						{ $eq: ["$type", "bonus"] },
						{ $abs: "$duration" },
						0
					]}
				}}
			],
			as: "lists"
		}},

		{ $addFields: {
			totalLeaving: { $sum: "$lists.leavingCount"},

			sick: { $sum: "$lists.sickCount" },
			personal: { $sum: "$lists.personalCount" },
			holiday: { $sum: "$lists.holidayCount" },
			legal: { $sum: "$lists.legalCount" },
			bonus: { $sum: "$lists.bonusCount" },
		}},

		{ $addFields: {
			totalHoliday: { $add: ["$yearlyHoliday", "$bonus"] },
		}},

		{ $addFields: {
			totalRemainingHoliday: { $subtract: ["$totalHoliday", "$totalLeaving"]}
		}},

		{ $project: {
			_id: 1,
			type: 1,
			name: 1,
			name2: 1,
			avt: 1,
			userId: 1,
			type: 1,
			status: 1,

			sick: 1,
			personal: 1,
			holiday: 1,
			legal: 1,

			bonus: 1,
			yearlyHoliday: 1,

			//lists: 1,
			totalLeaving: 1,

			// totalHoliday = yearlyHoliday + bonus
			totalHoliday: 1,

			// Summary: remainingHoliday = totalHoliday - totalLeaving
			totalRemainingHoliday: 1,

			//endYear: 1,
			//entranceAt: 1,

			totalLength: 1,
		}},

		{ $group: {
			_id: null,

			totalLeaving: { $sum: "$totalLeaving" },
			totalHoliday: { $sum: "$totalHoliday" },
			totalRemainingHoliday: { $sum: "$totalRemainingHoliday" },

			yearlyHoliday: { $sum: "$yearlyHoliday" },

			sick: { $sum: "$sick" },
			personal: { $sum: "$personal" },
			holiday: { $sum: "$holiday" },
			legal: { $sum: "$legal"},

			bonus: { $sum: "$bonus"},

			totalLength: { $first: "$totalLength" },
			lists: { $push: "$$ROOT" },
		}},

		{ $addFields: {
			page: {
				totalLength: "$totalLength",
				pageIndex: "@page.pageIndex",
				pageStart: "@page.pageStart",
				pageLength: "@page.pageLength",
			},
			lists: { $ifNull: ["$lists", []] }
		}},

		{ $project: {
			_id: 0,
			totalLength: 0,
			"lists.totalLength": 0,
		}}
	]],
]]);


// --------------- Pipe Calculate amount ------------------
LeavingRoute.PIPE.push([["calculateLeavingAmount"], [
	`A.findById(*) > P.hrcontract: hrcontract: {userId: "@P.user._id"}`,
	[`A.jsScript(*`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var salary = (Req.hrcontract||{}).overview || {};
		var hourlySalary = salary.hourlySalary || 0;

		body.amount = (body.duration||0) * (hourlySalary||0);

		return Req.UNRESULT;
	}]
], { name: "calculateLeavingAmount" }]);


module.exports = LeavingRoute;
