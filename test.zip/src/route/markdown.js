const MarkdownRoute = {
    route	: "markdown",
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
        // checkMIFs	: [],
    }
};


MarkdownRoute.POST.push([["/task"], [
    "A.findMany:task",
    "A.refactorOutput:_id, taskId, name",
]]);

MarkdownRoute.POST.push([["/wiki"], [
	// @Toan, check verify projectId
    "A.findMany:wiki",
    "A.refactorOutput::_id, wikiId, name",
]]);

MarkdownRoute.POST.push([["/project"], [
    "A.findMany:project",
    "A.refactorOutput::_id, projectId, name",
]]);

// when you pass A.modifyObject(*)::, the CARMPUSV is valid to use
// assign into respData means you want this send to client.
MarkdownRoute.POST.push([["/project/:_id/user"], [
	"A.findById: project",
	"A.populate: user, members.user, _id, +, name, name2, email, userId, avt",
	"A.modifyObject:: respData = members.user",
	"A.refactorOutput(respData):: email-",
]]);

MarkdownRoute.POST.push([["/team"], [
    "A.findMany: team",
    "A.refactorOutput:: _id, teamId, name",
]]);

MarkdownRoute.POST.push([["/testcase"], [
    "A.findMany:testcase",
    "A.refactorOutput::_id, testCaseId, name",
]]);

MarkdownRoute.POST.push([["/testflow"], [
    "A.findMany:testflow",
    "A.refactorOutput::_id, testFlowId, name",
]]);

MarkdownRoute.POST.push([["/testresult"], [
    "A.findMany:testresult",
    "A.refactorOutput::_id, testResultId, name",
]]);

MarkdownRoute.POST.push([["/post"], [
    "A.findMany:post",
    "A.refactorOutput::_id, postId, name",
]]);

MarkdownRoute.POST.push([["/changelog"], [
    "A.findMany:changelog",
    "A.refactorOutput::_id, changelogId, name",
]]);

MarkdownRoute.POST.push([["/snippet"], [
    "A.findMany:snippet",
    "A.refactorOutput::_id, snippetId, name",
]]);

MarkdownRoute.POST.push([["/cost"], [
    "A.findMany:cost",
    "A.refactorOutput::_id, costId, name",
]]);

MarkdownRoute.POST.push([["/logtime"], [
    "A.findMany:logtime",
    "A.refactorOutput::_id, logTimeId, name",
]]);

MarkdownRoute.POST.push([["/risk"], [
    "A.findMany:risk",
    "A.refactorOutput::_id, riskId, name",
]]);

module.exports = MarkdownRoute;
