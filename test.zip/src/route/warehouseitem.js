const WarehouseItemRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkMIFs		: ["warehouse"],
		roleUserIdKey	: "userId"
    }
};

WarehouseItemRoute.POST.push([[""], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "importers, admins"}`,

	`A.copyKObject(*):: P.query.warehouseId: P.body.warehouseId`,
    `A.verifyInput:: warehouseitem: name!, warehouseId!, ...`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		body.importBy = body.importBy || Req.user._id;
		body.importAt = body.importAt || new Date();
		body.importPrice = body.importPrice || 0;

		return Req.UNRESULT;
	}],

	// `A.printObject`,
    `A.insertOne: warehouseitem`,
    `A.refactorOutput:: _id, number, name, name2, descr, status, code, color, type`,
]]);

WarehouseItemRoute.GET.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	`A.verifyKObject(*):: P.route._id!: verify.idNumberType`,

	[`A.aggregateOne(*): warehouseitem:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$_id", "@P.route._id"]},
			{ $eq: ["$number", "@P.route._id"]},
			{ $eq: ["$code", "@P.route._id"]},
		]}}},

		{ $populateFilter: ["user", "importBy:_id", "importByUser", true, 1, "_id", "name", "name2", "userId", "avt"]},
		//{ $populateFilter: ["warehousetype", "types$:_id", "types", undefined, 1, "_id", "name", "name2", "color"]},

		// { $project: {
		// 	_id: 1,
		//
		// }}
	]],
]]);

// User for list Asset Item picker
WarehouseItemRoute.POST.push([["/s"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	//`A.verifyKObject(*):: P.query.warehouseId!: verify.idType`,

	//`A.copyKObject(*):: P.query.warehouseId: P.body.warehouseId`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg },
			]});
        }

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	[`A.aggregate: warehouseitem:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			type: 1,
			code: 1,
			color: 1,
			name: 1,
			name2: 1,
			descr: 1,
			status: 1,

			issueAt: 1,
			issueTo: 1,

			importAt: 1,
		}},
	]],
]]);

// Used for full warehouse list store, not liust product
WarehouseItemRoute.POST.push([["full/s"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,
	`A.pipeRoute: checkWarehouseRole`,
	//`A.verifyKObject(*):: P.query.warehouseId!: verify.idType`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

		var types = (body.type || body.types) || (body.typeId || body.typeIds);
		if(types) {
			if(!Array.isArray(types)) {
				types = [types];
			}

			if(types.length > 0) {
				ops.push({type: { $in: types }});
			}
		}

		var status = (body.status || body.statuses) || (body.statusId || body.statusIds);
		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				ops.push({status: { $in: status }});
			}
		}

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne: warehouseitem:`, [
		{ $match: "@ops" },
		//{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $getTotalLength: ["@page", "totalLength"]},

		{ $populateFilter: ["user", "importBy:_id", "importByUser", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["user", "issueTo:_id", "issueToUser", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["warehousetype", "types$:_id", "types", undefined, 1, "_id", "name", "name2", "color"]},

		// { $project: {
		// 	_id: 1,
		// 	number: 1,
		// 	type: 1,
		// 	code: 1,
		// 	color: 1,
		// 	name: 1,
		// 	name2: 1,
		// 	descr: 1,
		// 	status: 1,
		// }},

		{ $groupTotalLength: ["@page", "totalLength", "items"]},
	]],
]]);

WarehouseItemRoute.PUT.push([[":_id/issue"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, exporters"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

	`A.verifyInput:: warehouseitem: issueTo!, issueDate`,

	`A.findById > itemDb: warehouseitem`,
	`A.assertKeyExisted: @itemDb: _id: Item was not being existed!`,

	[`A.jsScript:(*)`, (Req, pipeData, ctx) => {
		var body = Req.body;

		body.issueAt = body.issueAt || new Date();

		var itemDb = body.itemDb||{};
		itemDb.histories = itemDb.histories || [];
		itemDb.histories.push({
			type	: 2,
			at		: body.issueAt,
			to		: body.issueTo,
		});

		return Req.UNRESULT;
	}],

    `A.updateById(*): warehouseitem: { _id: "@P.route._id" }: {status: 2, issueTo: "@P.body.issueTo", issueAt: "@P.body.issueAt"}`,
    `A.responseObject: 200: Issue successfully!`,
]]);

WarehouseItemRoute.PUT.push([[":_id/return"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, exporters"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

	`A.verifyInput:: warehouseitem: issueBack!`,

	`A.findById > itemDb: warehouseitem`,
	// checkExistItem: colName, idKey, hasStop=false, msg, saveAs
	// assertKeyExisted (obj, keyPath, msg)
	`A.assertKeyExisted: @itemDb: _id: Item was not being existed!`,

	[`A.jsScript:(*)`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var itemDb = body.itemDb||{};
		itemDb.histories = itemDb.histories || [];
		itemDb.histories.push({
			type	: itemDb.status,
			at		: itemDb.issueAt,
			to		: itemDb.issueTo,
		});

		return Req.UNRESULT;
	}],

    `A.updateById(*): warehouseitem: { _id: "@P.route._id" }: {status: 1, issueBack: "@P.body.issueBack", histories: "@P.body.itemDb.histories"}`,
    `A.responseObject: 200: Return successfully!`,
]]);

WarehouseItemRoute.PUT.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, importers"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

	`A.verifyInput:: warehouseitem: name, name2, types, code, descr, note, remark, imageIds, warrantyAt, importPrice`,

    `A.updateById(*): warehouseitem: { _id: "@P.route._id" }: @P.body`,
    `A.responseObject: 200: Update successfully!`,
]]);

WarehouseItemRoute.PUT.push([[":_id/status"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, importers"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

	`A.verifyInput:: warehouseitem: status`,

	`A.findById > itemDb: warehouseitem`,
	[`A.jsScript:(*)`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var itemDb = body.itemDb||{};
		itemDb.histories = itemDb.histories || [];
		itemDb.histories.push({
			type	: itemDb.status,
			at		: itemDb.issueAt,
		});

		return Req.UNRESULT;
	}],

    `A.updateById(*): warehouseitem: { _id: "@P.route._id" }: {status: "@P.body.status"}`,
    `A.responseObject: 200: Update successfully!`,
]]);

WarehouseItemRoute.POST.push([[":_id/clone"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins, importers"}`,
	`A.verifyKObject(*):: P.route._id!: verify.idType`,

    `A.findById(*) > itemDb: warehouseitem: { _id: "@P.route._id" }`,
	//`A.deleteKObject:: _id, number, i`,

	`A.formatString(itemDb) > itemDb.name: "{{name}} - cloned"`,
	`A.trimObject(itemDb) > newData: {
		name		: "@name",
		name2		: "@name2",

		types		: "@types",
		code		: "@code",

		descr		: "@descr",
		note 		: "@note",

		imageIds	: "@imageIds",

		importBy	: "@importBy",
		importAt	: "@(new Date())",
		importPrice	: "@importPrice",
		warrantyAt 	: "@warrantyAt",
	}`,

	`A.insertById > newItem: warehouseitem: @newData`,

    `A.responseObject: 200: @newItem`,
]]);

WarehouseItemRoute.DELETE.push([[":_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.delete`,
	`A.pipeRoute: checkWarehouseRole: {role: "admins"}`,

	`A.verifyKObject(*):: P.route._id!: verify.idType`,

    `A.deleteById(*): warehouseitem: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete warehouse item successfully!`
]]);


module.exports = WarehouseItemRoute;
