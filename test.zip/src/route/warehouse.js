const WarehouseRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
		checkMIFs		: ["warehouse"],
		roleUserIdKey	: "userId"
    }
};

WarehouseRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,
    `A.verifyInput:: warehouse: name!, ...`,

	// Creator id admin of this warehouse
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;
		body.admins = body.admins || [Req.user._id];

		return Req.UNRESULT;
	}],

    `A.insertOne: warehouse`,
    `A.refactorOutput:: _id, number, name, name2, descr, status, code, color, type`,
]]);

WarehouseRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): warehouse:`, [
		{ $match: { $expr: { $or: [
			{ $eq: ["$_id", "@P.route._id"]},
			{ $eq: ["$number", "@P.route._id"]},
			{ $eq: ["$code", "@P.route._id"]},
		]}}},

		// { $project: {
		// 	_id: 1,
		//
		// }}
	]],
]]);

// User for list warehouse picker
WarehouseRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	[`A.aggregate: warehouse:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			shortName: 1,
			type: 1,
			code: 1,
			color: 1,
			name: 1,
			name2: 1,
			descr: 1,
			status: 1,
		}},
	]],
]]);

// Used for full warehouse list store, not liust product
WarehouseRoute.POST.push([["full/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var ops = [];

		var name = (body.name || body.title) || (body.search || body.text);
        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg }
			]});
        }

		var types = (body.type || body.types) || (body.typeId || body.typeIds);
		if(types) {
			if(!Array.isArray(types)) {
				types = [types];
			}

			if(types.length > 0) {
				ops.push({type: { $in: types }});
			}
		}

		var status = (body.status || body.statuses) || (body.statusId || body.statusIds);
		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				ops.push({status: { $in: status }});
			}
		}

		var userIds = (body.user || body.userId) || (body.users || body.userIds);
		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				ops.push({$or: [
					{importers: { $elemMatch: { $in: userIds }}},
					{exporters: { $elemMatch: { $in: userIds }}},
					{auditors: { $elemMatch: { $in: userIds }}},
					{reporters: { $elemMatch: { $in: userIds }}},
					{admins: { $elemMatch: { $in: userIds }}},
				]});
			}
		}

		pipeData.warrantyTime = new Date((new Date()).getTime() + 7*86400000);
        pipeData.ops = (ops.length > 0) ? { $and: ops } : {};
        return pipeData;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne: warehouse:`, [
		{ $match: "@ops" },
		{ $limit: 2000 },

		{ $sort: {
			name$: 1,
		}},

		{ $getTotalLength: ["@page", "totalLength"]},

		{ $populateFilter: ["user", "importerIds:_id", "importers", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["user", "exporterIds:_id", "exporters", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["user", "auditorIds:_id", "auditors", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["user", "reporterIds:_id", "reporters", true, 1, "_id", "name", "name2", "userId", "avt"]},
		{ $populateFilter: ["user", "adminIds:_id", "admins", true, 1, "_id", "name", "name2", "userId", "avt"]},

		{ $populateFilter: ["warehouseitem", "_id:warehouseId", "allItems", undefined, 1, "importPrice", "remainPrice", "issueAt", "issueTo", "warrantyAt", "status", "types"]},

		{ $addFields: {
			allItems: { $ifNull: ["$allItems", []] }
		}},

		{ $addFields: {
			alertItems: { $filter: {
				input: "$allItems",
				as: "item",
				cond: { "$lte": ["$$item.warrantyAt", "@warrantyTime"] }
			}},
			remainItems: { $filter: {
				input: "$allItems",
				as: "item",
				cond: { "$in": ["$$item.status", [0, 1, 2]] }
			}},

			allTypes: { $concatArrays: "$allItems.types" },
		}},

		{ $addFields: {
			totalItem: { $size: "$allItems" },
			totalAmount: { $reduce: {
				input: "$allItems",
				initialValue: 0,
				in: { $sum: ["$$value", "$$this.importPrice"] }
			}},
			totalType: { $size: "$allTypes" },
			// totalType: { $reduce: {
			// 	input: "$allItems",
			// 	initialValue: [],
			// 	in: { $concatArrays : ["$$value", "$$this.types"] }
			// }},

			totalAlertItem: { $size: "$alertItems" },
			totalAlertAmount: { $reduce: {
				input: "$alertItems",
				initialValue: 0,
				in: { $sum: ["$$value", "$$this.importPrice"] }
			}},

			totalRemainItem: { $size: "$remainItems" },
			totalRemainAmount: { $reduce: {
				input: "$remainItems",
				initialValue: 0,
				in: { $sum: ["$$value", "$$this.remainPrice"] }
			}},
		}},

		{ $project: {
			_id: 1,
			number: 1,
			shortName: 1,
			type: 1,
			code: 1,
			color: 1,
			name: 1,
			name2: 1,
			descr: 1,
			status: 1,

			importers: 1,
			exporters: 1,
			auditors: 1,
			reporters: 1,
			admins: 1,

			totalItem: 1,
			totalType: 1,
			totalAmount: 1,

			totalAlertItem: 1,
			totalAlertAmount: 1,

			totalRemainItem: 1,
			totalRemainAmount: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "repos"]},
	]],
]]);

WarehouseRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: warehouse: creatorId-, createdAt-, number-, ...`,

    `A.updateById(*): warehouse: { _id: "@P.route._id" }: @P.body`,
    `A.refactorOutput:: _id, number, name, name2, descr, status, code, color, type`,
]]);

WarehouseRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view, warehouse.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.deleteById(*): warehouse: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete warehouse successfully!`
]]);


WarehouseRoute.PIPE.push([["checkWarehouseRole"], [
	`A.verifyKObject(*):: P.query.warehouseId!: verify.idType`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: warehouse.view`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var role = (Req.body||{}).role || "";
		var user = Req.user;
		if(user.hasAdmin || user.hasAgent) {
			return Req.UNRESULT;
		}

		var ops = [];
		var userIds = [user._id];

		var arrs = (role||"").replace(/[\s\t\n\r]{1,}/gmi, '').split(",");
		if(arrs && (arrs.length > 0)) {
			for (var i = 0; i < arrs.length; i++) {
				var key = arrs[i];
				ops.push({[key]: { $elemMatch: { $in: userIds }}});
			}

		} else {
			ops = [
				{ importers: { $elemMatch: { $in: userIds }}},
				{ exporters: { $elemMatch: { $in: userIds }}},
				{ auditors: { $elemMatch: { $in: userIds }}},
				{ reporters: { $elemMatch: { $in: userIds }}},
				{ admins: { $elemMatch: { $in: userIds }}},
			];
		}

		ops = (ops && (ops.length > 0)) ? { $or: ops } : {};

		var rs = await A.aggregateOne(Req, pipeData, "warehouse", [
			{ $match: ops },
		]);

		if(!rs || (rs.status != 1)) {
			return {
				respCode: 500,
				respData: "You were not permitted!",
				respReturn: true,
			};
		}

		Req.warehouse = rs;
		return Req.UNRESULT;
	}],

], {name: "checkWarehouseRole" }]);

module.exports = WarehouseRoute;
