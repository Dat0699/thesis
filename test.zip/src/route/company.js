
const CompanyRoute = {
    //route	: ["company"],
    //ctrl	: require('../controller/company.js'),
    //model	: require('../model/company.js'),
	route	: true,
    ctrl	: true,
    model	: true,

    POST	:[],
    GET		:[],
    PUT		:[],
    DELETE	:[],
	PIPE	: [],

    config	: {
        imCache			: true,
        imBase      	: true,
        // checkMIFs	: [],
        checkCMIFs		: [], // Check Company MIF,
		roleUserIdKey	: "userId"
    },
};

CompanyRoute.__private_import = {
	AppConfig: '__balanceResourceX',
};

CompanyRoute.GET.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
    //`A.copyKObject(*):: P.company, P.body`,

    `A.findOne(*): Main.company: {_id: "@P.company._id"}`,
	[`A.jsScript`, (Req, pipeData, ctx) => {

		var data = Req.body || {};
		var config = data.config || {};
		var user = Req.user || {};

		var hasAgent = user.hasAgent && ((data.agentId||"").toString() == (user.userId||"").toString());
		//console.log("Check Agent: ", data, Req.user);

		data = {
			_id: data._id,
			name: data.name,
			name2: data.name2,
			avt: data.avt,
			shortName: data.shortName,
			descr: data.descr,
			phone: data.phone,
			fax: data.fax,
			email: data.email,
			country: data.country,
			address: data.address,
			status: data.status,
			hasAgent: hasAgent,
			config: {
				language: config.language,
				currency: config.currency,
				currencyDecimal: config.currencyDecimal,
				timeZone: config.timeZone,
				formatFullDay: config.formatFullDay,
				formatShortDay: config.formatShortDay,
				formatFullHour: config.formatFullHour,
				formatShortHour: config.formatShortHour,
			}
		}

		return {
			respData: data,
			respCode: 200,
			respReturn: true,
		};
	}],
], { permitAgent: true }]);

CompanyRoute.PUT.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,

    `A.verifyInput > reqBody:: company: shortName-, agentId-, status-, ...`,
    `A.refactorOutput(reqBody) > reqBody::
						shortName-,
						customerCode-,
						companyCost-,
						currentStorage-,
						members-,
						feature-,
						featurePackage-,

						config.workingDayWeeks-,
						config._prefix-,
					    config._redis-,
					    config._dcc-,
					    config._dbversion-,
						config.listIps-,
						config.ipAccess-,
						...`,

	`A.findOne(*) > dbCompany: main.company: {"_id" : "@P.company._id"}`,
	// Avoid merge array, coz it merges A1[0] <- A2[0], so delete some array key by refactorOutput above
	`A.mergeFreeObject > dbCompany:: @dbCompany: @reqBody`,

	//`A.printObject`,
	`A.refactorOutput(dbCompany) > dbCompany::
						shortName-,
						customerCode-,
						companyCost-,
						currentStorage-,
						members-,
						feature-,
						featurePackage-,
						...`,

	//`A.printObject(*): @P.body.dbCompany.config`,
    `A.updateOne(*): main.company: {"_id" : "@P.company._id"}: @P.body.dbCompany`,

	`A.findOne(*): main.company: {"_id" : "@P.company._id"}`,
	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

    `A.refactorOutput::
						_id,
						avt,
						name,
						name2,
						shortName,
						descr,
						phone,
						fax,
						email,
						country,
						address,
						config.language,
						config.currency,
						config.currencyDecimal,
						config.timeZone,
						config.formatFullDay,
						config.formatShortDay,
						config.formatFullHour,
						config.formatShortHour`,

]]);

// CompanyRoute.DELETE.push([[""], [
//
// ]]);

CompanyRoute.GET.push([["/lock"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
    `A.updateById(*) > dbCompany: Main.company : {_id: "@P.company._id", agentId: "@P.user.userId"} : ({status:0})`,

	`A.printObject(P)`,
	
	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,
	`A.notifyClearToken: company: @P.company._id, @P.company.shortName`,

	`A.copyKObject(*):: P.company.members.userId, P.body.users`,

    `A.refreshDB: @dbCompany`,
	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $or: [
			{ $in: ["$userId", "@P.body.users"] },
			// { $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],

	`A.printObject(*): P.body.users.emails`,

	
	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Company] Company {{P.company.shortName}} was locked!",
		"view" 		: "companyStatusView",
		"data" 		: {
			"typeAction": "locked",
		}
	}`,

    `A.responseObject: 200: Lock company successfully!`
], { permitAgent: true }]);

CompanyRoute.GET.push([["/unlock"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
    `A.updateById(*) > dbCompany: Main.company : {_id: "@P.company._id", agentId: "@P.user.userId"} : ({status:1})`,
	//`A.printObject`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,
	`A.notifyClearToken: company: @P.company._id, @P.company.shortName`,

	`A.copyKObject(*):: P.company.members.userId, P.body.users`,

    `A.refreshDB: @dbCompany`,
	[`A.aggregateOne(*) > users: user`, [
		{ $match: { $expr: { $or: [
			{ $in: ["$userId", "@P.body.users"] },
			// { $in: ["$_id", "@P.body.users"] },
		]}}},
		{ $projectKeep: ["email"]},
		{ $group: {
			_id: null,
			emails: { $push: "$$ROOT.email"}
		}}
	]],

	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.users.emails",
		"subject" 	: "[Company] Company {{P.company.shortName}} was unlocked!",
		"view" 		: "companyStatusView",
		"data" 		: {
			"typeAction": "unlocked",
		}
	}`,

    `A.responseObject: 200: Unlock company successfully!`
], { permitAgent: true }]);

CompanyRoute.GET.push([["/feature"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.findById(*) > dbCompany: main.company: ({_id: "@P.company._id"})`,

	[`A.jsScript(*):`, (Req, pipeData, ctx) => {
		var UtilFn = pipeData.U.Func;

		var user = Req.user;
		var company = Req.body.dbCompany;

		var feature = UtilFn.featureConfig({
			...(company.feature||{}),
			...(company.featurePackage||{}),
			...(pipeData.K.API.FeatureConfig||{}),
		});

		Req.respCode = 200;
		return { feature };
	}],

    //`A.refactorOutput(dbCompany):: feature`
]]);

CompanyRoute.PUT.push([["/feature"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	// `A.assertObject:: and: (
	// 	feature type object,
	// 	feature not-type empty
	// ): {
	// 	respReturn: true,
	// 	respCode: 503,
	// 	respData: "You must send feature data!"
	// }`,
	// `A.allKeyObject(*) > P.allKeys: @P.body`,
    // `A.verifyInput > P.reqData:: company: feature`,
	// //`A.printObject(*): P.body: P.reqData: P.allKeys`,
	//
	// //`A.printObject(*): P.body: P.reqData`,
	// `A.keepKObject(*): @P.reqData.feature: @P.allKeys`,
	// //`A.printObject(*): P.reqData: P.body`,
	//
	// `A.copyObject(P) > P.featureData: @reqData.feature: @allKeys`,
	//
	// //`A.printObject(P): featureData: body.feature: allKeys`,
	// `A.trimObject(*): @P.featureData`,
	//
	// `A.printObject(P): featureData`,
	// `A.assertObject(P):: and: (
	// 	featureData type object,
	// 	featureDate not-type empty
	// ): {
	// 	respReturn: true,
	// 	respCode: 503,
	// 	respData: "You must send corected feature data!"
	// }`,

	[`A.jsScript(*):`, (Req, pipeData, ctx) => {
		//var companyFeature = Req.company.feature || {};

		var allKeys = Object.keys(pipeData.M.subKey.feature);

		var rs = {};
		var feature = (Req.body||{}).feature;
		var keys = Object.keys(feature || {});
		for (var i = 0; i < keys.length; i++) {
			var k = keys[i];
			if(allKeys.indexOf(k) >= 0) {
				rs[k] = !!feature[k];
			}
		}

		//console.log("keys: ", keys, allKeys);
		Req.featureData = rs;
		return Req.UNRESULT;
	}],

	//`A.printObject(P): reqData: allKeys: featureData`,
	`A.updateSubItem(*): main.company: @P.company._id: feature: @P.featureData:: false`,

	`A.findOne(*) > P.dbData: main.company: @P.company._id`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,
	`A.notifyClearToken: company: @P.company._id, @P.company.shortName`,

    //`A.refactorOutput(P.dbData):: feature `
	[`A.jsScript(*):`, (Req, pipeData, ctx) => {
		var UtilFn = pipeData.U.Func;

		var user = Req.user;
		var company = Req.dbData;

		var feature = UtilFn.featureConfig({
			...(company.feature||{}),
			...(company.featurePackage||{}),
			...(pipeData.K.API.FeatureConfig||{})
		});

		Req.respCode = 200;
		return { feature };
	}],
]]);

CompanyRoute.POST.push([["/workingholiday"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

	`A.findById(*) > P.company: Main.company: {_id: "@P.company._id"}`,
	`A.copyKObject(*):: P.company, P.body`,

    `A.refactorOutput:: config.moringStartTime,
						config.moringEndTime,
						config.afternoonStartTime,
						config.afternoonEndTime,
						config.nightStartTime,
						config.nightEndTime,
						config.workingDayWeeks,
						config.startWeekday,
						config.noWorkingDayMonth,
						config.yearlyHoliday,
						config.noWorkingHourWeek,
						config.ipAccess,
						config.isWebBrowser,
						config.isIOS,
						config.isAndroid`,

]]);

CompanyRoute.PUT.push([["/workingholiday"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	//`A.printObject`,
    `A.refactorOutput > reqBody:: moringStartTime,
						moringEndTime,
						afternoonStartTime,
						afternoonEndTime,
						nightStartTime,
						nightEndTime,
						workingDayWeeks,
						startWeekday,
						noWorkingDayMonth,
						yearlyHoliday,
						noWorkingHourWeek,
						ipAccess,
						isWebBrowser,
						isIOS,
						isAndroid`,

	//`A.printObject`,
    `A.trimObject > reqBody`,
	//`A.printObject`,

	`A.findOne(*) > xyz: main.company : {_id: "@P.company._id"}`,
    //`A.cloneObject(*) > xyz: @P.company`,

	//`A.printObject`,
    `A.mergeDefinedObject: @xyz: {config: "@reqBody"}`,

	//`A.printObject`,
    `A.verifyInput:: company: config`,

	//`A.printObject`,
    `A.updateOne(*): main.company: {_id: "@P.company._id"}: @P.body`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

    `A.refactorOutput::
						config.moringStartTime,
						config.moringEndTime,
						config.afternoonStartTime,
						config.afternoonEndTime,
						config.nightStartTime,
						config.nightEndTime,
						config.workingDayWeeks,
						config.startWeekday,
						config.noWorkingDayMonth,
						config.yearlyHoliday,
						config.noWorkingHourWeek,
						config.ipAccess,
						config.isWebBrowser,
						config.isIOS,
						config.isAndroid`,
]]);

CompanyRoute.POST.push([["/workingholiday/ipmode"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject:: mode!: company.config.ipAccess.mode`, // true or blank are same
	//`A.printObject`,

	// verifyKObject: object: ...key:modelKeyPath...: // Failed using default value
	// assertKObject: object: ...key:modelKeyPath...:  // failed to exist

	`A.updateSubItem(*) > tmp: main.company : @P.company._id : config.ipAccess.mode: @P.body.mode:: false`,
	//`A.printObject(*): P.body: P.company.config`,
	`A.setKObject(*): @P.company.config.ipAccess: mode: @P.body.mode`,
	//`A.printObject(*): P.body: P.company.config`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

    `A.refactorOutput(P.company.config.ipAccess)`,
]]);

CompanyRoute.POST.push([["/workingholiday/:type:(/(whitelist|blacklist)$/)"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.findOne(*) > companyDB: main.company: {_id: "@P.company._id"}`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var type = { whitelist: "whiteLists", blacklist: "blackLists" }[Req.route.type.toLowerCase()];

        const ipLists = Req.body.companyDB.config.ipAccess[type];
        const ipList = pipeData[type] || pipeData[type.substr(0, type.length-1)];

        if (!ipLists || !ipList) {
            return {"respData": `IP ${type} not exists`, "respReturn": true , "respCode" : 500};
        }

        var index = ipLists.findIndex((listItem) => {
            return listItem.ip === ipList.ip;
        });

        if (index >= 0) {
            return {"respData": "IP exists", "respReturn": true , "respCode" : 500};
        }

        ipLists.push(ipList);
        return pipeData;
    }],

    `A.updateById(companyDB) > tmp: main.company: @P.company._id`,
	`A.setCachedObject: company: @companyDB`,
	//`A.printObject`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var type = { whitelist: "whiteLists", blacklist: "blackLists" }[Req.route.type.toLowerCase()];
		return {
			respCode: 200,
			respData: {
				[type]: Req.body.companyDB.config.ipAccess[type]
			}
		};
	}]
]]);

CompanyRoute.PUT.push([["/workingholiday/:type:(/(whitelist|blacklist)$/)"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,

	`A.findOne(*) > companyDB: main.company: {_id: "@P.company._id"}`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var type = { whitelist: "whiteLists", blacklist: "blackLists" }[Req.route.type.toLowerCase()];

        const ipLists = Req.body.companyDB.config.ipAccess[type];
        const ipList = pipeData[type] || pipeData[type.substr(0, type.length-1)];

        if (!ipLists || !ipList) {
            return {"respData": `${type} not exists`, "respReturn": true , "respCode" : 500};
        }

        var index = ipLists.findIndex((listItem) => {
            return listItem.ip === ipList.ip;
        })

        if (index < 0) {
            return {"respData": "IP not exists", "respReturn": true , "respCode" : 500};
        }

        ipLists.splice(index, 1);
        return pipeData;
    }],

    `A.updateById(companyDB) > tmp: main.company: @P.company._id`,
	`A.setCachedObject: company: @companyDB`,
	//`A.printObject`,
	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var type = { whitelist: "whiteLists", blacklist: "blackLists" }[Req.route.type.toLowerCase()];
		return {
			respCode: 200,
			respData: {
				[type]: Req.body.companyDB.config.ipAccess[type]
			}
		};
	}]

    //`A.refactorOutput:: config.ipAccess.whiteLists`,
]]);


// --------------------------------- Member Section ---------------------------------
CompanyRoute.POST.push([["/member/undepartment"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var name = pipeData.name || pipeData.search || "";
		Req.body = { name: Req.func.getASCIISearch(name, "gmi") };

		return Req.UNRESULT;
	}],

	[`A.aggregate > dept::`, [
		{ $lookup: {
			from: "department",
			pipeline: [
				{ $project: {
					members: 1,
				}}
			],
			as: "department"
		}},

		{ $flatArray: {
			user: "$department.members",
		}},

		{ $lookup: {
			from: "user",
			let: { avoidUsers: "$user" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $regexMatch: { input : "$name", regex: "@name" }},
					{ $not: [{ $in: ["$hasDeleted", [true]] }] },
					{ $not: [{ $in: ["$_id", "$$avoidUsers"] }] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					email: 1,
					avt: 1,
					userId: 1,
				}},
			],
			as: "user"
		}},

		{ $project: {
			user: 1
		}},
		{ $unwind: {
			path: "$user",
			preserveNullAndEmptyArrays: false
		}},
		{ $replaceRoot: {
			newRoot: "$user"
		}}
	]],
]]);

CompanyRoute.POST.push([["/member/full"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var name = body.name || body.search || body.text;

		var userFilter = {};
		if(name) {
			name = Req.func.getASCIISearch(name, "gmi");
			userFilter["$or"] = [
				{ name: name },
				{ email: name },
			];
		}

        Req.body.userFilter = userFilter;
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
	`A.pipeRoute: adjustListMember`,

	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: 'seniority',
			pipeline: [
				{ $project: { _id: 1, title: 1 } },
				{ $sort: { title$: -1 } }
			],
			as: "seniority"
		}},

		{ $lookup: {
			from: 'department',
			pipeline: [
				{ $project: { _id: 1, name: 1, name2: 1, } },
				{ $sort: { name$: -1 } }
			],
			as: "department"
		}},

		{ $lookup: {
			from: 'rolecompany',
			pipeline: [
				{ $project: { _id: 1, name: 1, name2: 1, } },
				{ $sort: { name$: -1 } }
			],
			as: "role"
		}},

		{ $lookup: {
			from: 'user',
			pipeline: [
				{ $match: "@userFilter" },

				{ $sort: {
					name$: 1,
				}},

				{ $getTotalLength: ["@page", "totalLength"]},

				{ $populate: ["hrcontract", "_id", "userId", "hrcontract", true]},

				// { $lookup: {
				// 	from: "department",
				// 	localField: "hrcontract.overview.departmentId",
				// 	foreignField: "_id",
				// 	as: "departmentId"
				// } },
				// { $unwind: {
				// 	path: "$departmentId",
				// 	preserveNullAndEmptyArrays: true
				// } },

				{ $populate: ["department", "_id", "members", "departmentId", true]},
				{ $populate: ["seniority", "hrcontract.overview.seniorityId", "_id", "seniorityId", true]},

				{ $addFields: {
					staffCode: "$hrcontract.overview.staffCode",
					monthlySalary: "$hrcontract.overview.monthlySalary",
					hourlySalary: "$hrcontract.overview.hourlySalary",
					birthday: "$hrcontract.overview.birthday",
					entranceAt: "$hrcontract.overview.entranceAt",
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					email: 1,
					informEmail: 1,
					type: 1,
					hasAgent: 1,
					hasAdmin: 1,
					hasSupport: 1,
					status: 1,
					userId: 1,

					hasDeleted: 1,
					totalLength: 1,

					staffCode: 1,
					monthlySalary: 1,
					hourlySalary: 1,
					birthday: 1,
					entranceAt: 1,

					"seniorityId._id": 1,
					"seniorityId.title": 1,
					"seniorityId.title2": 1,

					"departmentId._id": 1,
					"departmentId.name": 1,
					"departmentId.name2": 1,
				}},

				{ $groupTotalLength: ["@page", "totalLength", "users"]}
			],
			as: "userList"
		}},
		{ $unwind: {
			path: "$userList",
			preserveNullAndEmptyArrays: true
		}},
		{ $addFields: {
			page: "$userList.page",
			user: "$userList.users",
		}},
		{ $project: {
			_id: 0,
			userList: 0,
		}}
	]],

	`A.matchObject(*): @P.body.dbData.user: @P.company.members: userId: userId: <<: roleId`,
	//`A.lookupObject: @dbData.user: rolecompany, roleId, _id, roleId, true, _id, name`,
	`A.matchObject(*): @P.body.dbData.user: @P.body.dbData.role: roleId: _id: roleId: _id, name`,
	`A.refactorOutput: @dbData: department, role, seniority, user, page`,
	`A.refactorOutput::`,
], { useZip: true }]);

CompanyRoute.GET.push([["/member/:_id"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`, // User can view his profile
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAdmin || user.hasAgent;

		var _id = Req.route._id;
		if(hasAdmin || (_id.toString() == user._id.toString())) {
			return Req.UNRESULT;
		}

		var A = pipeData.A;
		var rs = await A.checkRole(Req, pipeData, "Main.company", Req.company._id, "rolecompany", "setting.view");
		if(rs) {
			return Req.UNRESULT;
		}

		return {
			respCode: 503,
			respData: "E-02",
			respReturn: true,
		};
	}],

	`A.findById(*) > dbHR: hrcontract: { userId: "@P.route._id" }: {
		userId: "@P.route._id",
		status: 1,
		overview: {},
		timelines: [],
		missions: [],
		careerPath: [],
		comments: [],
		renews: []
	 }`,

	[`A.aggregateOne(*): user`, [
		{ $match: {
			_id: "@P.route._id"
		}},
		{ $addFields: {
			roleId: "@roleId"
		}},

		//{ $populate: ["rolecompany", "roleId", "_id", "roleId", true]},
		{ $populate: ["hrcontract", "_id", "userId", "hrcontract", true]},
		// { $lookup: {
		// 	from: "hrcontract",
		// 	localField: "_id",
		// 	foreignField: "userId",
		// 	as: "hrcontract"
		// }},
		// { $unwind: {
		// 	path: "$hrcontract",
		// 	preserveNullAndEmptyArrays: true
		// }},

		// { $lookup: {
		// 	from: "department",
		// 	localField: "hrcontract.overview.departmentId",
		// 	foreignField: "_id",
		// 	as: "departmentId"
		// }},
		// { $unwind: {
		// 	path: "$departmentId",
		// 	preserveNullAndEmptyArrays: true
		// }},

		{ $populate: ["department", "_id", "members", "departmentId", true]},
		// { $lookup: {
		// 	from: "department",
		// 	localField: "_id",
		// 	foreignField: "members",
		// 	as: "departmentId"
		// }},
		// { $unwind: {
		// 	path: "$departmentId",
		// 	preserveNullAndEmptyArrays: true
		// }},

		{ $populate: ["seniority", "hrcontract.overview.seniorityId", "_id", "seniorityId", true]},
		// { $lookup: {
		// 	from: "seniority",
		// 	localField: "hrcontract.overview.seniorityId",
		// 	foreignField: "_id",
		// 	as: "seniorityId"
		// }},
		// { $unwind: {
		// 	path: "$seniorityId",
		// 	preserveNullAndEmptyArrays: true
		// }},

		{ $addFields: {
			staffCode: "$hrcontract.overview.staffCode",
			tempAddress: "$hrcontract.overview.tempAddress",
		    homeAddress: "$hrcontract.overview.homeAddress",
			monthlySalary: "$hrcontract.overview.monthlySalary",
			hourlySalary: "$hrcontract.overview.hourlySalary",
			birthday: "$hrcontract.overview.birthday",
			entranceAt: "$hrcontract.overview.entranceAt",
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			avt: 1,
			email: 1,
			informEmail: 1,
			type: 1,
			hasAgent: 1,
			hasAdmin: 1,
			hasSupport: 1,
			status: 1,
			userId: 1,

			staffCode: 1,
			tempAddress: 1,
			homeAddress: 1,
			hourlySalary: 1,
			monthlySalary: 1,
			birthday: 1,
			entranceAt: 1,

			"seniorityId._id": 1,
			"seniorityId.title": 1,
			"seniorityId.title2": 1,

			"departmentId._id": 1,
			"departmentId.name": 1,
			"departmentId.name2": 1,

			// "roleId._id": 1,
			// "roleId.name": 1,
			// "roleId.name2": 1,
		}},
	]],
	//`A.responseObject: 200: @dbData`

	`A.matchObject(*): @([P.body]): @P.company.members: userId: userId: <<: roleId`,
	`A.lookupObject(*): @P.body: rolecompany, roleId, _id, roleId, true, _id, name`,
	`A.lookupObject(*): @P.body: Main.usercompany, userId, _id, loginEmail, 0, <-, email`,

	`A.refactorOutput::`
], { permitAgent: true }]);

CompanyRoute.PUT.push([["/member/update"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	//`A.verifyKObject(P.route):: _id!: verify.idType`,
	//`A.printObject`,
	`A.keepKObject::
		_id,
		name,
		name2,
		staffCode,
		avt,
		email,
		informEmail,
		type,

		staffCode,
		seniorityId,
		departmentId,
		roleId,

		monthlySalary,
		hourlySalary,
		birthday,
		entranceAt
	`,
	//`A.printObject`,

	`A.verifyKObject::
		_id!: user.userId:
		name: user.name:
		name2: user.name2:
		avt: user.avt:
		email: user.email:
		informEmail: user.informEmail:
		type: user.type:

		staffCode: hrcontract.overview.staffCode:
		departmentId: hrcontract.overview.seniorityId:
		seniorityId: hrcontract.overview.seniorityId:
		roleId: hrcontract.overview.seniorityId:

		monthlySalary: hrcontract.overview.monthlySalary:
		hourlySalary: hrcontract.overview.hourlySalary:
		birthday: hrcontract.overview.birthday:
		entranceAt: hrcontract.overview.entranceAt
	`,

	`A.findById(*) > oldUserDb: user: {_id: "@P.body._id"}`,
	`A.assertKeyExisted: @oldUserDb: _id: Invalid request!`,

	// Only agent has permit to edit salary
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var user = Req.user;
		if(!user.hasAgent) {
			delete body.monthlySalary;
			delete body.hourlySalary;
		}
		return Req.UNRESULT;
	}],

	`A.cloneObject > reqUser`,
	`A.cloneObject(reqUser) > reqHR`,

	//`A.copyKObject:: reqUser.staffCode: reqHR.hrcontract.overview.staffCode`,
	//`A.printObject`,

	`A.refactorOutput(reqUser) > reqUser::name, name2, email, informEmail, userId, avt, type, status`,
	`A.updateById > dbUser: user: {_id: "@_id"}: @reqUser`,

	//`A.printObject`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};

		var dbUser = body.dbUser;
		var email = body.email;

		var userId = dbUser.userId;
		var companyId = Req.company._id;

		body.reqHR = {
			staffCode: body.staffCode,
			seniorityId: body.seniorityId,
			monthlySalary: body.monthlySalary,
			hourlySalary: body.hourlySalary,
			birthday: body.birthday,
			entranceAt: body.entranceAt,
		};

		if(body.roleId) {
			await A.updateSubItem(Req, pipeData, "Main.company", {_id: companyId}, "members", {userId, roleId:body.roleId}, "userId");
		}

		// Update master data, incase this company is create this user
		var updateUserData = {};
		if(body.name) {
			updateUserData.name = body.name;
		}

		if(email && (email != body.oldUserDb.email)) {
			updateUserData.email = email;
		}

		if(Object.keys(updateUserData).length > 0) {
			const filterObj = {
				_id: userId,
			};

			if(Req.user._id.toString() != dbUser._id.toString()) {
				filterObj.creatorId = companyId;
			}

			// Update master db and not failed it not exist
			// Param, pipeData, colName, idKey, updatedData, shouldCreated=false, updateMany=false, ignoredNotFound=false
			await A.updateById(Req, pipeData, "Main.usercompany", filterObj, updateUserData, false, false, true);
		}

		if(body.departmentId) {
			// Update remove from all old Departments
			const cf = Req.config;
			Req.config = { IgnoreSanitized: true };
			await A.removeSubItem(Req, pipeData, "department", {}, "members", dbUser._id, undefined, true);
			Req.config = Req.config;

			// Insert User into new Department
			await A.insertSubItem(Req, pipeData, "department", body.departmentId, "members", dbUser._id);
		}

		return Req.UNRESULT;
	}],

	// `A.mixObject > reqHR:: {
	// 	staffCode: "@staffCode",
	// 	seniorityId: "@seniorityId",
	// 	monthlySalary: "@monthlySalary",
	// 	hourlySalary: "@hourlySalary",
	// }`,

	// Find one adn update if not exist
	`A.findById > dbHR: hrcontract: { userId: "@dbUser._id" }: {
		userId: "@dbUser._id",
		status: 1,
		overview: {},
		timelines: [],
		missions: [],
		careerPath: [],
		comments: [],
		renews: []
	 }`,
	`A.updateSubItem > dbHRtmp: hrcontract: {userId: "@dbUser._id"}: overview: @reqHR:: false`,

	//`A.printObject`,
	`A.responseObject: 200: Update successfully!`
], { otpMode: "data", F1: {IgnoreSanitized: true} }]);

// New meber from Company Setting -> click on email -> (added: Active User /login/actuser) -> /login/forget/submit -> input OTP -> login/modpass
CompanyRoute.POST.push([["member/new"], [
	`A.pipeRoute: decodeOTPResource`,

	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	//`A.printObject`,
	//`A.verifyInput:: user: name!, email!, status-, hasAdmin-, hasAgent-, ...`,
	`A.trimObject`,
	`A.keepKObject::
		name,
		name2,
		staffCode,
		avt,
		email,
		informEmail,
		type,
		status,

		staffCode,
		seniorityId,
		departmentId,
		roleId,

		monthlySalary,
		hourlySalary,
		birthday,
		entranceAt,

		message,
	`,
	//`A.printObject`,

	`A.verifyKObject::
		name!: user.name:
		name2: user.name2:
		avt: user.avt:
		email!: user.email:
		informEmail: user.informEmail:
		type!: user.type:
		status: user.status:

		staffCode: hrcontract.overview.staffCode:
		seniorityId: hrcontract.overview.seniorityId:
		departmentId: hrcontract.overview.seniorityId:
		roleId: hrcontract.overview.seniorityId:

		monthlySalary: hrcontract.overview.monthlySalary:
		hourlySalary: hrcontract.overview.hourlySalary:
		birthday: hrcontract.overview.birthday:
		entranceAt: hrcontract.overview.entranceAt:

		message: hrcontract.overview.message
	`,

	//`A.printObject`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};

		// who has create in setting can create user
		if(!Req.user /* || !Req.user.hasAgent */) {
			return {
				respCode: 500,
				respData: "Invalid request!",
				respReturn: true,
			};
		}

		var rs1 = await pipeData.A.findById(Req, pipeData, "user", { email: body.email });
		if(rs1 && rs1.email) {
			return {
				respCode: 500,
				respData: "Email existed!",
				respReturn: true,
			};
		}

		var rs2 = await pipeData.A.findById(Req, pipeData, "Main.user", { email: body.email });
		if(rs2 && rs2.email) {
			return {
				respCode: 500,
				respData: "Email existed, please invite instead of create!",
				respReturn: true,
			};
		}

		Req.message = body.message || "";
		return Req.UNRESULT;
	}],
	//`A.printObject`,

	// Find and upsert to create item, onluy email key
    `A.findOne(*) > userCompany: Main.usercompany: ({
        email: "@P.body.email"
    }) : {
        email : "@P.body.email",
		creatorId: "@P.company._id",
		hasActived: false,
		status: 0
	}`,
	//`A.printObject`,

	// Find and upsert to create item, only email key
    `<F1>A.findOne > userDB: user: ({
        "$or": [{"email": "@email"}, {"userId": "@userCompany._id"}]

    }): {
		userId      : "@userCompany._id",
		avt			: "@avt",
        email       : "@email",
        name        : "@name",
		name2       : "@name2",
        informEmail : "@informEmail",
        type        : "@type",
		status		: 0
	}`,
    //`A.printObject:`,

    `A.findOne > hrDB: hrcontract: {
		userId: "@userDB._id"

	}: {
        userId : "@userDB._id",
        overview: {
			staffCode: "@staffCode",
            seniorityId: "@seniorityId",
			monthlySalary: "@monthlySalary",
			hourlySalary: "@hourlySalary",
			birthday: "@birthday",
			entranceAt: "@entranceAt",
        }
    }`,
    //`A.printObject`,

	// Currently accept constant role id
    `A.insertSubItem(*) > memberDB: main.company: @P.company._id: members: {userId : "@P.body.userCompany._id", roleId: "@P.body.roleId", hasActived: false}`,

	// Insert User into Department
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		//`A.insertSubItem > tmp: department: @departmentId: members: @departmentId`
		var A = pipeData.A;
		var body = Req.body || {};
		Req.body = body;

		var departmentId = body.departmentId;
		if(departmentId) {
			await A.insertSubItem(Req, pipeData, "department", {_id: departmentId}, "members", body.userDB._id);
		}

		body.rsData = {
			...body.userDB,
			staffCode: body.hrDB.overview.staffCode,
			departmentId: departmentId,
			seniorityId: body.hrDB.overview.seniorityId,
			monthlySalary: body.hrDB.overview.monthlySalary,
			hourlySalary: body.hrDB.overview.hourlySalary,
			birthday: body.hrDB.overview.birthday,
			entranceAt: body.hrDB.overview.entranceAt,
		};

		return Req.UNRESULT;
	}],


	// `A.mixObject > rsData:: {
	// 	"<-": "@userDB",
	// 	staffCode: "@hrDB.overview.staffCode",
	// 	departmentId: "@departmentId",
	// 	seniorityId: "@hrDB.overview.seniorityId",
	// 	monthlySalary: "@hrDB.overview.monthlySalary",
	// 	hourlySalary: "@hrDB.overview.hourlySalary"
	// }`,

	`A.lookupObject: @rsData:
		department, departmentId, _id, departmentId, true, _id, name, name2:
		seniority, seniorityId, _id, seniorityId, true, _id, title, title2`,

	`A.pipeRoute: sendActivateEmail`,
	/*
	// Call Forget Password
	`A.hashOTP > P.code`,
    `A.formatString(*) > P.otpCode: 'otp_^_{{P.body.email}}_^_{{P.code}}'`,
	`A.setKValue(*): @P.otpCode: @P.body.userCompany._id: 86400: true`, // Code exists 1 day

	// Call Activated New User
	`A.hashOTP > P.token`,
	`A.generateUniqueID(*) > P.token: 24: @P.token`,
	`A.formatString(*) > P.atxToken: 'otp_^_{{P.body.email}}_^_{{P.token}}'`,
	`A.setKValue(*): @P.atxToken: @P.body.userCompany._id: 86400: true`, // Code exists 1 day

	/*
	// Delete on temporary => then Insert new Data, this it no login api so hide this
	`A.deleteById(*) > tmp1: freeobject: {type: "addnew-member", key: "@P.body.rsData.userId"}: true: true`,
	`A.insertById(*) > tmp2: freeobject: {type: "addnew-member", key: "@P.body.rsData.userId", data: {
		"<-": "@P.body.rsData",
		"atxToken": "@P.atxToken",
		"token": "@P.token",
	}`,
	* /

    `A.sendMail(*) > tmpMail: {
        "to" 		: ["@P.body.rsData.email", "@P.body.rsData.informEmail"],
		"subject" 	: "[GitGam] Your account has been created!",
		"view" 		: "welcomeMember",
        "data" 		: "@P.body.rsData"
    }`,
	*/

	//`A.printObject`,
	`A.responseObject: 200: { user: "@rsData" }`
], { otpMode: "data", F1: { IgnoreSanitized : true } }]);

CompanyRoute.POST.push([["member/resend/activate/:_id"], [
	`A.verifyKObject(P.route):: _id!: user.userId`,

	`A.findById(*) > userDb: user: {_id: "@P.route._id"}`,
	`A.assertKeyExisted: @userDb: _id: Invalid request!`,

	`A.findById(*) > userCompany: Main.usercompany: {_id: "@P.body.userDb.userId"}`,
	`A.assertKeyExisted: @userCompany: _id: Invalid request!`,

	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var user = body.userDb;
		var userCompany = body.userCompany;

		//console.log("LOG: ", userCompany, user);
		if(userCompany.hasActived) {
			return {
				respReturn: true,
				respCode: 500,
				respData: "User has been activated!",
			};
		}

		Req.body = {
			rsData		: user,
			userCompany	: userCompany,
			email		: userCompany.email || user.email, // Có thể đổi email rồi mà bên trong không đổi.
		};

		return Req.UNRESULT;
	}],

	`A.pipeRoute: sendActivateEmail`,
	`A.responseObject: 200: Resend activate member successfully!`,
]]);

CompanyRoute.PIPE.push([["sendActivateEmail"], [
	// Call Forget Password
	`A.hashOTP > P.code`,
	`A.formatString(*) > P.otpCode: 'otp_^_{{P.body.email}}_^_{{P.code}}'`,
	`A.setKValue(*): @P.otpCode: @P.body.userCompany._id: 86400: true`, // Code exists 1 day

	// Call Activated New User
	`A.hashOTP > P.token`,
	`A.generateUniqueID(*) > P.token: 24: @P.token`,
	`A.formatString(*) > P.atxToken: 'otp_^_{{P.body.email}}_^_{{P.token}}'`,
	`A.setKValue(*): @P.atxToken: @P.body.userCompany._id: 86400: true`, // Code exists 1 day

	/*
	// Delete on temporary => then Insert new Data, this is not login API so hide this action
	`A.deleteById(*) > tmp1: freeobject: {type: "addnew-member", key: "@P.body.rsData.userId"}: true: true`,
	`A.insertById(*) > tmp2: freeobject: {type: "addnew-member", key: "@P.body.rsData.userId", data: {
		"<-": "@P.body.rsData",
		"atxToken": "@P.atxToken",
		"token": "@P.token",
	}}`,
	*/

	`A.sendMail(*) > tmpMail: {
		"to" 		: ["@P.body.rsData.email", "@P.body.rsData.informEmail"],
		"subject" 	: "[GitGam] Your account has been created!",
		"view" 		: "welcomeMember",
		"data" 		: "@P.body.rsData"
	}`,
], { name: "sendActivateEmail" }]);

// company/member/invite -> login/confirmjoin
CompanyRoute.POST.push([["member/invite"], [
	`A.pipeRoute: decodeOTPResource`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,

	`A.verifyKObject::
		userId!: user.userId:
		roleId!: user.userId`,

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		// if(!Req.user.hasAgent) {
        //     return {
		// 		respData: "E-02",
		// 		respReturn: true,
		// 		respCode: 500
		// 	};
		// };

		var body = Req.body || {};
		var A = pipeData.A;

		var user = await A.findById(Req, pipeData, "Main.usercompany", {_id: body.userId});

		var company = Req.company;
		body = {
			userId: user._id,
			roleId: body.roleId,
			companyId: company._id,
		};

		var token = Req.func.generateUniqueID(72, company._id);
		await A.setKValue(Req, pipeData, token, body, 3600*24, true); // 3600 * 24 // Vaid in 24 hours

		Req.body = { ...body, token, email: user.email, company: {
			name: company.name,
			_id: company._id,
			invite: `[GitGam] You were invited to ${company.name}`,
		}};

		return Req.UNRESULT;
	}],

	/*
	// Delete on temporary -> the Insert new data, not login api, so hide this
	`A.deleteById(*) > tmp1: freeobject: {type: "invite-member", key: "@P.body.userId"}: true: true`,
	`A.insertById(*) > tmp2: freeobject: {type: "invite-member", key: "@P.body.userId", data: "@P.body"}`,
	*/

	`A.sendMail(*) > tmpMail: {
        "to" 		: ["@P.body.email"],
		"subject" 	: "@P.body.company.invite",
		"view" 		: "inviteMember",
        "data" 		: "@P.body"
    }`,

	`A.responseObject: 200: Inviting member sent!`
], { otpMode: "data" }]);

// Search member in global to add into company -> Search to invite member into company
CompanyRoute.POST.push([["member/search"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var search = body.search || body.name || body.text;
		// if(!Req.user.hasAgent || (search === undefined || search === null)) {
        //     return {
		// 		respData: "E-02",
		// 		respReturn: true,
		// 		respCode: 500
		// 	};
		// };

		// For empty case, do not return data, avoid spam to search all email.
		if(!search) {
			return {
				respData: [],
				respReturn: true,
				respCode: 200
			};
		}

		var A = pipeData.A;
		var company = Req.company || {};
		var companyUserIds = A.getKObject(Req, pipeData, company, "members.userId");
		companyUserIds = A.unifyObject(Req, pipeData, companyUserIds);

		search = Req.func.getASCIISearch(search, 'gmi');
		var filter = {
			$or: [
				{ name: search },
				{ email: search },
				{ informEmail: search },
			],
			_id: { $nin: [ ...companyUserIds, company.agentId ] }
		};

		//console.log("Filter: ", filter);
		Req.filter = filter;
		return Req.UNRESULT;
	}],

	//`A.printObject`,
	//`<F1>A.findMany(*) > users: Main.usercompany: @P.filter`,
	[`A.aggregate(*): Main.usercompany`, [
		{ $match: "@P.filter" },
		{ $limit: 10 },
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			email: 1,
			avt: 1,
			userId: "$_id",
		}}
	]],

], { otpMode: "data" }]);

CompanyRoute.POST.push([["member/can/approve/:role:(/^(overtime|leaving|dailyreport|announcement)$/)"], [
	//`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,

	`A.verifyKObject:: projectId: verify.idType`,

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var search = body.search || body.name || body.text || "";
		search = Req.func.getASCIISearch(search, 'gmi');

		var ops = {
			[`permit.${Req.route.role}.approve`]: true,
		};

		var roleModel = "rolecompany";
		if(body.projectId) {
			roleModel = "roleproject";
			ops.projectId = body.projectId;

			var project = await A.findById(Req, pipeData, "project", {_id: body.projectId});
			if(!project) {
				return {
					respCode: 500,
					respData: "Project may not found!",
					respReturn: true,
				};
			}
			body.allMembers = (project.members||[]).map(i => { return {user: i.user, role: i.role}; }) || [];

		} else {
			body.allMembers = ((Req.company||{}).members||[]).map(i => { return {user: i.userId, role: i.roleId}; }) || [];
		}

		body.ops = ops;
		body.search = search;
		body.roleModel = roleModel;

		//console.log("Filter: ", body);
		return Req.UNRESULT;
	}],

	//`A.printObject`,
	//`<F1>A.findMany(*) > users: Main.usercompany: @P.filter`,
	[`A.aggregate(*)::`, [
		{ $lookup: {
			from: "@P.body.roleModel",
			pipeline: [
				{ $match: "@P.body.ops" },
				{ $project: {
					_id: 1,
				}}
			],
			as: "roleModels",
		}},

		{ $lookup: {
			from: "user",
			pipeline: [
				{ $match: { $or: [
					{ hasAgent: true },
					{ hasAdmin: true },
				]}},
				{ $addFields: {
					user: "$_id",
					role: "$_id",
				}},
				{ $project: {
					_id: 0,
				}},
				{ $addFields: {
					hasAdmin: true,
				}},
				{ $project: {
					user: 1,
					role: 1,
					hasAgent: 1,
					hasAdmin: 1,
				}},
			],
			as: "aaUsers",
		}},

		{ $addFields: {
			roleIds: { $ifNull: ["$roleModels._id", []] },
			allMembers: { $concatArrays: [{$ifNull: ["$aaUsers", []]}, "@P.body.allMembers"]}
		}},

		{ $addFields: {
			members: { $filter: {
				input: "$allMembers",
				as: "member",
				cond: { $or: [
					{ $eq: ["$$member.hasAgent", true] },
					{ $eq: ["$$member.hasAdmin", true] },

					{ $in: ["$$member.role", "$roleIds"] },
					{ $in: ["$$member.roleId", "$roleIds"] },
				]}
			}}
		}},

		{ $unwind: {
			path: "$members",
			preserveNullAndEmptyArrays: false,
		}},

		{ $replaceRoot: {
			newRoot: "$members",
		}},

		{ $addFields: {
			user: { $ifNull: ["$user", "$userId"] },
		}},

		{ $populateFilter: ["user", [
			{ $let: {
				userId: "$user"
			}},
			{ $match: { $expr: { $or: [
				{ $eq: ["$_id", "$$userId"] },
				{ $eq: ["$userId", "$$userId"] }
			]}}},
		], "user", false, 1, "_id", "name", "name2", "avt", "userId"]},

		{ $replaceRoot: {
			newRoot: "$user",
		}},

		{ $match: {
			name: "@P.body.search"
		}},

		{ $group: {
			_id: "$_id",
			avt: { $first: "$avt" },
			name: { $first: "$name" },
			name2: { $first: "$name2" },
			userId: { $first: "$userId" },
		}},

		{ $addFields: {
			name2: { $ifNull: ["$name2", ""] },
		}},

		{ $sort: {
			name$: 1
		}},

	]],
]]);


CompanyRoute.DELETE.push([["member/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.delete",
    `A.pipeRoute: checkadmin`,

	`A.findById > P.updatedUser: user: _id`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var K = pipeData.K;
		var query = Req.query || {};

		var loginUser = Req.user || {};
		var user = Req.updatedUser;

		if(user) {
			if(!loginUser.hasAgent && !loginUser.hasAdmin) {
				if(user.hasAgent || user.hasAdmin) {
					user = false;
				}
			}
		}

		if(!user || user.hasAgent) {
			return {
				respCode: 500,
				respData: "Invalid action!",
				respReturn: true,
			};
		}

		var userFilter = { _id: user._id };
		if(query.restore || query.hasRestore) {
			// Restort hasDeleted on Company
			await A.updateSubItem(Req, pipeData, "Main.company", { _id: Req.company._id }, "members", {userId:user.userId, hasDeleted: false}, "userId");

			await A.dbCall(Req, pipeData, "user", "updateOne", userFilter, { $set: {status:1, hasDeleted:false}});
			return {
				respCode: 200,
				respReturn: true,
				respData: "Account restore successfully!"
			};
		}

		var hardDelete = (query.hardDelete || query.hardDeleted) || (query.hasDeleted || false);
		if(hardDelete) {
			if(!user.userId || !user.hasDeleted) {
				return {
					respCode: 503,
					respReturn: true,
					respData: "Incorrect request!"
				};
			}

			await A.deleteById(Req, pipeData, "user", userFilter); // default is hard delete
			await A.removeSubItem(Req, pipeData, "Main.company", { _id: Req.company._id }, "members", { userId: user.userId });
			// Remove HR Contract
			await A.deleteById(Req, pipeData, "hrcontract", {userId: user.userId});

			// for On Premise mode, delete this user also
			let hasPremium = false;
			const apc = CompanyRoute.AppConfig;
			if(apc.runModeStandalone) {
				hasPremium = true;
				if(apc.yetSrvCreateCompany === 'false') {
					hasPremium = false;
				}
			}

			//if(K.App.Env == "OP") {
			if(hasPremium) {
				await A.deleteById(Req, pipeData, "Main.usercompany", {_id: user.userId});

			} else {
				// Release creatorId in Main.userCompany, ignored not found user (due to not created by this company)
				await A.updateById(Req, pipeData, "Main.usercompany", {_id: user.userId, creatorId: Req.company._id}, {creatorId: null}, false, false, true);
			}

			/*
			// Check user in master DB, created by this company, delete it also
			var rs1 = await A.findById(Req, pipeData, "Main.usercompany", { _id: userCompanyId, creatorId: Req.company._id });
			if(rs1 && rs1._id) {
				// Delete if user and has no company!
				// { agentId: "@userCompany._id" },
				// { "members.userId": "@userCompany._id" }
				var rs2 = await A.dbRaw(Req, pipeData, "Main.company", "findOne", {$or: [{agentId: userCompanyId}, {"members.userId": userCompanyId}]});

				if(!rs2 || !rs2._id) {
					//console.log("Delete Case --------------------", rs2);
					await A.deleteById(Req, pipeData, "Main.usercompany", { _id: userCompanyId }, true);
				}
			}
			*/

			// Next time check the Company own domain to decide more case.

			await A.pipeRoute(Req, pipeData, "deleteUser", false, "Company");

			return {
				respCode: 200,
				respReturn: true,
				respData: "Hard delete account successfully!"
			};
		}

		return Req.UNRESULT;
	}],

	`A.updateSubItem(*): Main.company: { _id: "@P.company._id" }: members: {userId: "@P.updatedUser.userId", hasDeleted: true}: userId`,
	`A.updateById(*) > tmp: user: {_id: "@P.updatedUser._id"}: {status: 0, hasDeleted: true}`,
	`A.deleteById(*): user: {_id: "@P.updatedUser._id"}: false`, // soft delete

	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Delete successfully!`
]]);

// ---------------------------- Lock/Unlock ----------------------------
CompanyRoute.PUT.push([["member/:_id/status/:status:(/(lock|unlock)$/)"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    `A.pipeRoute: checkadmin`,
    `A.updateOne(*) > P.updatedUser: user: {_id: "@P.route._id"}: {"status": "@(P.route.status==='unlock'?1:2)"}`,
	`A.updateSubItem(*): Main.company: { _id: "@P.company._id" }: members: {userId:"@P.updatedUser.userId", hasLocked: "@(P.route.status==='unlock'?false:true)"}: userId`,

	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Update member status successfully!`
]]);

// ---------------------------- Admin ----------------------------
CompanyRoute.PUT.push([["member/:_id/admin"], [
	`A.verifyAdmin: true: User was not permitted!`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    `A.pipeRoute: checkadmin`,
    `A.updateOne(*): user: {_id: "@P.route._id"}: {"hasAdmin" : true}`,
	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Update admin for the account successfully!`
]]);

CompanyRoute.DELETE.push([["/member/:_id/admin"], [
	`A.verifyAdmin: true: User was not permitted!`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    `A.pipeRoute: checkadmin`,
    `A.updateOne(*): user: {_id: "@P.route._id"}: {"hasAdmin" : false}`,
	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Revoke admin successfully!`
]]);

// ---------------------------- Support ----------------------------
CompanyRoute.PUT.push([["member/:_id/supporter"], [
	`A.verifyAdmin: true: User was not permitted!`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    `A.pipeRoute: checkadmin`,
    `A.updateOne(*): user: {_id: "@P.route._id"}: {"hasSupport" : true}`,
	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Update supporter for the account successfully!`
]]);

CompanyRoute.DELETE.push([["/member/:_id/supporter"], [
	`A.verifyAdmin: true: User was not permitted!`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    // "A.checkPermission(*): rolecompany: @P.user.roleId: user.edit",
    `A.pipeRoute: checkadmin`,
    `A.updateOne(*): user: {_id: "@P.route._id"}: {"hasSupport" : false}`,
	`A.notifyClearCached(*): user: @P.route._id`,
    `A.responseObject: 200: Revoke supporter successfully!`
]]);


// ------------------------------- Label Setting ----------------------------
CompanyRoute.POST.push([["/label/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	[`A.jsScript:`, async (Req, pipeData, ctx) => {
		var nameOps = { hasGlobal: true };

		var body = Req.body;
		var name = body.name || body.search || body.text;

		if(name) {
			name = Req.func.getASCIISearch(name, "gmi");
			nameOps["$or"] = [ { name }, { descr: name }, { color: name } ];
		}

		body.nameOps = nameOps;
		return Req.UNRESULT;
	}],

	[`A.aggregate: label:`, [
		{ $match: "@nameOps" },

		{ $populate: ["project", "projectId", "_id", "projectId", true] },

		{ $sort: {
			"projectId.name$": 1,
			name$: 1,
		}},

		{ $project: {
			name: 1,
			name2: 1,
	        descr: 1,
	        descrHTML: 1,

	        type: 1,
			color: 1,
	        hasGlobal: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.shortName": 1
		}},
	]],
]]);

CompanyRoute.POST.push([["label"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput:: label: name!, type! ...`,
	`A.checkLimitItem: label: { $expr: { $and: [
		{ $eq: ["$name", "@name"] },
		{ $or: [
			{ $eq: ["@type", "all"] },
			{ $in: ["$type", ["@type", "all"]] }
		]},
	]}}: 0: true: Label existed!`,

	// [`A.aggregateOne > rs: label`, [
	// 	{ $match: {
	// 		name: "@name",
	// 		type: { $in: ["@type", "all"] },
	// 		//hasGlobal: true,
	// 	}}
	// ]],

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		// var rs = body.rs;
		//
		// if(rs && rs._id) {
		// 	return {
		// 		respData: "Label existed!",
		// 		respCode: 500,
		// 		respReturn: true,
		// 	};
		// }

		body.hasGlobal = true;
		return Req.UNRESULT;
	}],

    `A.insertOne: label`,
    `A.refactorOutput:: _id, name, name2, color, type, hasGlobal`
]]);

CompanyRoute.GET.push([["label/:_id"], [
	`A.checkRole(*): project: @P.project._id: rolecompany: setting.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

    `A.findOne: label: { _id: "@P.route._id" }`,
    `A.refactorOutput`,
]]);

CompanyRoute.PUT.push([["label/:_id"], [
	`A.checkRole(*): project: @P.project._id: rolecompany: setting.view, setting.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: label: projectId-, creatorId-, createdAt-, ...`,

	`A.checkLimitItem: label: { $expr: { $and: [
		{ $eq: ["$name", "@name"] },
		{ $or: [
			{ $eq: ["@type", "all"] },
			{ $in: ["$type", ["@type", "all"]] }
		]},
	]}}: 0: true: Label existed!`,

    `A.updateById(*): label: { _id: "@P.route._id" }: @P.body`,
    `A.refactorOutput:: _id, name, name2, color, type, hasGlobal`
]]);

CompanyRoute.DELETE.push([["label/:_id"], [
	`A.checkRole(*): project: @P.project._id: rolecompany: setting.view, setting.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.deleteById(*): label: {_id: "@P.route._id"}`,
    `A.responseObject: 200: Delete label successfully!`
]]);


CompanyRoute.PUT.push([["shortName"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
    // "A.checkPermission(*): rolecompany: @P.user.roleId: project.edit",
    //"A.verifyInput > projectBody:: project: shortName!",
	`A.verifyKObject:: shortName!: company.shortName`,

	//`A.findOne > dbData: main.company: {shortName: "@shortName"}`,\\\
	[`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		pipeData.D.IgnoreSanitized = true;
		var company = await pipeData.A.findOne(Req, pipeData, "Main.company", {
			shortName: { $regex : new RegExp(`^${body.shortName}$`, "i") }
		});

		if(company) {
			return {
				respData: "There are company owning your ShortName!",
				respReturn: true,
				respCode: 500
			};
		}

        return Req.UNRESULT;
    }],

	// `A.assertObject:: or: (
	// 	dbData not-type object,
	// 	dbData type empty,
	// 	dbData type undefined,
	// 	dbData type null
	// ) : {
	// 	respData: "ShortName was existed!",
	// 	respCode: 503,
	// 	respReturn: true
	// }`,

    `A.updateById(*) > xyz: main.company: {_id: "@P.company._id"}: {shortName: "@P.body.shortName"}`,

	`A.notifyClearCached(*): company: @P.company._id, @P.company.shortName`,
	`A.notifyClearToken: company: @P.company._id, @P.company.shortName`,

    `A.responseObject: 200: Update successfully!`
], {}]);

CompanyRoute.POST.push([["/check/:userId"], [
	// Check user in project or not
	// `A.printObject:`,
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,

	// `A.printObject:`,
	`A.verifyKObject(P.route):: userId!: verify.idType `,
	// `A.printObject:`, 

	[`A.aggregateOne(*)::`, [
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					shortName: 1,
					avt:1
				}},
			],
			as: "projects"
		}},

		{ $lookup: {
			from: "source",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
					// { $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					shortName: 1,
					projectId: 1,
				}},
				{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "name2", "avt"]},
			],
			as: "sources"
		}},
		{ $lookup: {
			from: "source",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
					// { $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					shortName: 1,
					projectId: 1,
				}},
				{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "name2", "avt"]},
			],
			as: "sources"
		}},
		{ $lookup: {
			from: "team",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members"] },
					// { $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					projectId: 1,
				}},
				{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "name2", "avt"]},
			],
			as: "teams"
		}},

		{ $lookup: {
			from: "postserver",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", "$members.user"] },
					// { $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					number: 1,
					name2: 1,
					projectId: 1,
				}},
				{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "name2", "avt"]},
			],
			as: "postServers"
		}},

		{ $lookup: {
			from: "mockserver",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", {$ifNull : ["$members.user", []]} ]},
					// { $eq : ["@P.route._id", "$projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					number: 1,
					name2: 1,
					projectId: 1,
				}},
				{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "_id", "name", "name2", "avt"]},
			],
			as: "mockServers"
		}},

		{ $lookup: {
			from: "department",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["@P.route.userId", {$ifNull : ["$members", []]} ]},
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
				}},
			],
			as: "department"
		}},
	]],
]]);

module.exports = CompanyRoute;
