const MockGroupRoute = {
	route	: "/mock/:serverId/group",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

MockGroupRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.verifyInput:: mockgroup: projectId!, serverId!, number-, ...`,
	`A.insertOne: mockgroup`,

	`A.pipeRoute: mockgroup: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockGroupRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.findOne(P.route): mockgroup: {_id: "@_id", serverId: "@serverId"}`,
	`A.verifyInput:: mockgroup: _id-, number-, ...`,

	`A.insertById > P.mockgroup: mockgroup`,
	`A.cloneById(*) > P.lookUp: mockapi:: {groupId: "@P.route._id"}: {groupId: "@P.mockgroup._id"}: 500:: _id-, number-`,

	/*
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;

		var A = pipeData.A;
		var group = await A.insertOne(Req, pipeData, "mockgroup", body);

		//console.log("Group: ", group, Req.route._id);
		var apis = await A.findMany(Req, pipeData, "mockapi", {serverId: group.serverId, groupId: Req.route._id});
		for (var i = 0; i < apis.length; i++) {
			var api = apis[i];
			api.groupId = group._id;

			delete api._id;
			delete api.number;
		}

		//console.log("Insert: ", apis);
		var napis = await A.insertMany(Req, pipeData, "mockapi", apis, 200);
		return Req.UNRESULT;
	}],
	*/

	`A.pipeRoute: mockgroup: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockGroupRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessMockServer: {role: ""}`,

	`<F1>A.findOne(P.route): mockgroup: {serverId: "@serverId", $or: [{_id: "@_id"}, {number: "@_id"}]}`,
], {F1: {IgnoreSanitized: true}} ]);

MockGroupRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mockgroup: number-, projectId-, serverId-, ...`,

	`A.updateById(*): mockgroup: { _id: "@P.route._id", serverId: "@P.route.serverId", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: mockgroup: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockGroupRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessMockServer: {role: "delete"}`,

	`A.deleteById(*): mockgroup: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,
	`A.deleteById(*): mockapi: { groupId: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: true: true`,

	`A.pipeRoute: mockgroup: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = MockGroupRoute;
