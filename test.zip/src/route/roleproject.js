
const RoleProjectRoute = {
    route	: "role-project",
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		roleUserIdKey	: "userId"
    }
}

RoleProjectRoute.POST.push([["s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
    `A.findMany: roleproject`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-, permit-`
]]);

RoleProjectRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    `A.findOne: roleproject`,

	// [`A.jsScript::`,(Req, pipeData, ctx) => {
	// 	var body = Req.body || {};
	// 	var permit = body.permit;
	//
	// // 	var ks = Object.keys(permit);
	// // 	for (var i = 0; i < ks.length; i++) {
	// // 		var k = ks[i];
	// // 		var o = permit[k] || {};
	// // 		permit[k] = {
	// // 			...o,
	// // 			modify: (o.modify)
	// // 		}
	// // 	}
	// //
	// 	permit.issuelog = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		...(permit.issuelog||{}),
	// 	};
	//
	// 	permit.feature = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		//approve: false,
	// 		...(permit.feature||{})
	// 	};
	//
	// 	permit.sprint = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		//approve: false,
	// 		...(permit.sprint||{}),
	// 	};
	//
	// 	permit.cicd = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		//approve: false,
	// 		...(permit.cicd||{}),
	// 	};
	//
	// 	permit.vmmachine = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		//approve: false,
	// 		...(permit.vmmachine||{}),
	// 	};
	//
	// 	permit.automation = {
	// 		view: false,
	// 		modify: false,
	// 		delete: false,
	// 		//approve: false,
	// 		...(permit.automation||{}),
	// 	};
	//
	// 	return Req.UNRESULT;
	// }],

	`U.Func.unifyRoleProject(*): @P.body.permit`,

	//`A.refactorOutput:: permit.milestone.view-, permit.label.view-`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RoleProjectRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
    `A.verifyInput:: roleproject: name!, ...`,
    `A.insertOne: roleproject`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RoleProjectRoute.POST.push([["clone/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
    //`A.verifyInput:: roleproject: name!, ...`,

    `A.findById: roleproject`,
    `A.refactorOutput:: _id-, number-, createdAt-, modifiedAt-, creatorId-, modifierId-`,

	`A.formatString > name: "{{name}} - copied"`,
	`A.insertById: roleproject`,
    `A.refactorOutput:: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RoleProjectRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqData:: roleproject: projectId-, ...`,
	`A.findOne > dbData: roleproject`,

    // < merge defined, but + is free merge.
	`A.modifyObject::
		dbData = <+reqData,
		respData = dbData
    `,

	//`A.printObject: @respData: @dbData`,
    `A.updateById(dbData) > resData: roleproject`,
    `A.refactorOutput(respData):: createdAt-, modifiedAt-, creatorId-, modifierId-`
]]);

RoleProjectRoute.DELETE.push([[`:_id`], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.deleteById: roleproject`,
]]);

module.exports = RoleProjectRoute;
