const GanttRoute = {
    route	: true,
    ctrl	: false,
    model	: false,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.gantt",
        checkMIFs		: ["project", "gantt"],
		imProject		: true,
    }
};

GanttRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: gantt.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
    [`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var matchOps = {};
        var sprintMatchOps = {};

		var name = (body.name || body.search) || (body.text || "");
		name = Req.func.getASCIISearch(name, "gmi");

		var userIds = (body.user || body.users) ||
					  (body.userId || body.userIds) ||
					  (body.member || body.members);

		var fromDate = body.fromDate || body.startDate;
		var toDate = body.toDate || body.endDate;

		const projectId = Req.project._id || Req.query.projectId || body.projectId;
		var milestoneIds = (body.milestone || body.milestones) ||
						   (body.milestoneId || body.milestoneIds);

        var sprintIds = (body.sprint || body.sprints) ||
                        (body.sprintId || body.sprintIds);

		var featureIds = (body.feature || body.features) ||
						 (body.featureId || body.featureIds);

	    var groupIds = (body.groupId || body.groupIds) ||
					  (body.group || body.groups);

		var labelIds = (body.labelId || body.labelIds) ||
					   (body.label || body.labels);

		const taskMatchOps = {};
		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				taskMatchOps.labelIds = { $elemMatch: { $in: labelIds } };
			}
		}

		var numberTask = (body.numberTask || 5) - 0;
		var skipTask = (body.skipTask || 0) - 0;
		var scale = (body.scale || 1.0) - 0;

		if(projectId) {
        	matchOps.projectId = projectId;
		}

		if(groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
				taskMatchOps["$or"] = [
					{ assigneeIds: { $elemMatch: { $in: userIds }}},
					{ testerIds: { $elemMatch: { $in: userIds }}},
					{ reviewerIds: { $elemMatch: { $in: userIds }}},
				];
			}
		}

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				matchOps._id = { $in: milestoneIds };
                sprintMatchOps.milestoneId = { $in: milestoneIds };
			}
		}

        if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}

			if(sprintIds.length > 0) {
				sprintMatchOps._id = { $in: sprintIds };
			}
		}

		if(featureIds) {
			if(!Array.isArray(featureIds)) {
				featureIds = [featureIds];
			}

			// if(featureIds.length > 0) {
			// 	sprintMatchOps._id = { $in: featureIds };
			// }
		}

        if(fromDate && toDate) {
			fromDate = new Date(fromDate);
			toDate = new Date(toDate);

			// For case full, or greater than 50 years, no care date
			if(toDate.getFullYear() - fromDate.getFullYear() < 50) {
	            matchOps.startDate = {"$lte" : toDate };
				matchOps.endDate = { "$gte" : fromDate };

                // Milestone and Sprint not filtered by Date
                // sprintMatchOps.startDate = {"$lte" : toDate };
				// sprintMatchOps.dueDate = { "$gte" : fromDate };

			} else {
				fromDate = null;
				toDate = null;
			}
        }

		body.startDate = fromDate;
		body.endDate = toDate;

		body.hasFilter = ((userIds && userIds.length > 0) ||
						 (labelIds && labelIds.length > 0)) ||
						 ((groupIds && groupIds.length > 0) ||
						 (milestoneIds && milestoneIds.length > 0));

		body.scale = scale || 1.0;
		body.paddingWeek = body.scale > 1 ? 14 : 4;

		body.skipTask = skipTask;
		body.numberTask = numberTask;

		body.name = name;
		body.groupIds = groupIds || [];
		body.milestoneIds = milestoneIds || [];
        body.sprintIds = sprintIds || [];
		body.featureIds = featureIds || [];
		body.projectId = projectId;

        body.matchOps = matchOps;
		body.sprintMatchOps = sprintMatchOps;
        body.taskMatchOps = taskMatchOps;

        body.enableSprint = (((Req.company||{}).feature||{}).sprint && ((Req.project||{}).feature||{}).sprint);

		//console.log("body: ", matchOps, sprintMatchOps);
        return body;
    }],

	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "milestone",
			pipeline: [
				{ $match: "@matchOps" },
				{ $sort: {
					number: -1,
					startDate: -1,
					endDate: -1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,

					number: 1,
					posIndex: 1,

					color: 1,
					status: 1,

					startDate: 1,
					endDate: 1,
					duration: 1,

					//remainingDay: 1,
					//passedDay: 1,
				}}
			],
			as: "milestones"
		}},

		{ $addFields: {
			milestoneIds: "$milestones._id",
            "milestones.itemType": "milestone",
		}},

        // Get Sprints
        { $lookup: {
			from: "sprint",
			pipeline: [
				{ $match: "@sprintMatchOps" },
				{ $sort: {
					number: -1,
					startDate: -1,
					dueDate: -1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,

					number: 1,
					colIndex: 1,
                    milestoneId: 1,

					color: 1,
					status: 1,

					startDate: 1,
					dueDate: 1,
					duration: 1,
				}}
			],
			as: "sprints"
		}},

		{ $addFields: {
			sprintIds: "$sprints._id",
            "sprints.itemType": "sprint",
		}},

		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $or: [
							{ $in: ["$_id", "@groupIds"] },
							{ $in: ["$shortName", "@groupIds"] },
							{ $in: ["@groupIds", [[], undefined, false, null]] }
						]},
						{ $or: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupIds: "$groups._id"
		}},

		{ $lookup: {
			from: 'task',
			let: {
				milestoneIds: "$milestoneIds",
                sprintIds: "$sprintIds",
				groupIds: "$groupIds",
				groups: "$groups"
			},
			pipeline: [
				{ $match: {
					$expr: {
						$and: [
							// For the case date is null
							{ $or: [
								{ $eq: ["@endDate", null]},
								{ $lte: ["$startDate", "@endDate"]},
							]},
							// For the case date is null
							{ $or: [
								{ $eq: ["@startDate", null]},
								{ $gte: ["$dueDate", "@startDate"]},
							]},

							{ $eq: ["$projectId", "@projectId"] },
							{ $or: [
								{ $in: ["$milestoneId", "$$milestoneIds"] },
								{ $in: ["@milestoneIds", [[], undefined, false, null]] }
							]},
                            { $or: [
								{ $in: ["$sprintId", "$$sprintIds"] },
								{ $in: ["@sprintIds", [[], undefined, false, null]] }
							]},
							{ $or: [
								{ $in: ["$featureId", "@featureIds"] },
								{ $in: ["@featureIds", [[], undefined, false, null]] }
							]},
							{ $or: [
								{ $in: ["$groupId", "$$groupIds"] },
								{ $in: ["@groupIds", [[], undefined, false, null]] }
							]},
							{ $or: [
								{ $regexMatch: { input: "$name", regex: "@name" }},
								{ $regexMatch: { input: "$name2", regex: "@name" }},
							]},
							//{ $eq: ["$isSubTask", false] }, // Use one loop only
						],
					},
				}},
				// { $match: {
				// 	$or: [
				// 		{ isSubTask: undefined },
				// 		{ parentId: { $exists: false }},
				// 		{ parentId: null },
				// 		{ parentId: "" },
				// 		{ parentId: undefined },
				// 	],
				// }},
				{ $match: "@taskMatchOps" },
				//{ $populate: ["group", "groupId", "_id", "group", true] },
				{ $addFields: {
					statusObj: { $arrayElemAt: [
						"$$groups",
						{ $indexOfArray: ["$$groupIds", "$groupId"] },
					]},
				}},

				{ $addFields: {
					//countMember: { $sum: [{$size: "$assigneeIds"}, {$size: "$testerIds"}, {$size: "$reviewerIds"}] },
					//duration: {$ceil: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000] }},
					//remainingDay: {$ceil: { $divide: [{$subtract: ["$dueDate", "$$NOW"]}, 86400000] }},
					//passedDay: {$ceil: { $divide: [{$subtract: ["$$NOW", "$startDate"]}, 86400000] }},
					//countTodo: "$totalTodo", //{ $size: "$todos"},
					//countDoneTodo: "$doneTodo",
					// {
					// 	$size: {
					// 		$filter: {
					// 			input: "$todos",
					// 			as: "todos",
					// 			cond: { "$eq": ["$$todos.done", true] }
					// 		}
					// 	}
					// },

					complete: { $cond: [
						{ $or: [
							{ $eq:["$statusObj.shortName", "done"] },
							{ $gte:[{ $ifNull: ["$doneTodo", 0]}, 100] }
						]},
						100,
						{ $multiply: [{$divide: [{$ifNull: ["$doneTodo", 0]}, {$max: ["$totalTodo", 1]}]}, 100]},
					]},
					users: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] },
					status: { $ifNull: ["$statusObj.value", 0] },
					hasTaskDone: { "$cond": [{$eq:["$statusObj.shortName", "done"]}, 1, 0] },

					//userCosts: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] }
				}},

				/*
				// Calculate Estimated cost
				{ $populate: ["hrcontract", "userCosts", "userId", "userCosts"] },
				{ $addFields: {
					estHour: { $multiply: [ { $size: "$userCosts" }, "$duration", 8] },
					estAmount: { $multiply: [{ $sum: "$userCosts.overview.hourlySalary" }, "$duration", 8] }
				}},

				// Calculate Loged cost
				{ $lookup: {
					from: "logtime",
					let: { taskId: "$_id" },
					pipeline: [
						{ $match: {
							$expr: {
								$and: [
									{ $eq: [ "$taskId", "$$taskId"] },
									//{ $eq: [ "$status", 2] } // Approve only
								]
							}
						}},

						// Find Salary
						{ $populate: ["hrcontract", "creatorId", "userId", "hrcontract", false] },
						{ $addFields: {
							hourlySalary: "$hrcontract.overview.hourlySalary",
							//monthlySalary: "$hrcontract.overview.monthlySalary",

							// when approve logtime, calculate this logtime to amount
							amount: { $multiply: ["$hour", "$hrcontract.overview.hourlySalary"]},
						}},

						{ $project: {
							creatorId: 1,
							amount: 1,
							hour: 1,
						}},

					],
					as: "logtimes"
				}},
				*/


				//{ $populate: ["user", "assigneeIds", "_id", "assigneeIds"]},
				//{ $populate: ["user", "testerIds", "_id", "testerIds"]},
				//{ $populate: ["user", "reviewerIds", "_id", "reviewerIds"]},

				// { $addFields: {
				// 	"reviewerIds.type": "reviewer",
				// 	"testerIds.type": "tester",
				// 	"assigneeIds.type": "assignee"
				// }},

				// { $addFields: {
				// 	//users: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] },
				// 	countMember: { $size: "$users" },
				// 	//logAmount: { $sum: "$logtimes.amount" },
				// 	//logHour: { $sum: "$logtimes.hour" },
				// 	//isSubTask: false,
				// }},
				//{ $populate: ["user", "users", "_id", "users"]}, // Do later in js code


				// Sub Task --------------------------------------------
				// {
				// 	$lookup: {
				// 		from: 'task',
				// 		let: { taskId: "$_id", milestoneId: "$milestoneId" },
				// 		pipeline: [
				// 			{ $match: {
				// 				$expr: {
				// 					$and: [
				// 						{ $eq: ["$isSubTask", true] },
				// 						//{ $eq: ["$milestoneId", "$$milestoneId"] }, // No need to check here
				// 						{ $eq: ["$parentId", "$$taskId"] }
				// 					]
				// 				}
				// 			}},
				// 			{ $match: "@taskMatchOps" },
				// 			//{ $populate: ["group", "groupId", "_id", "group", true] },
				//
				// 			{ $addFields: {
				// 				parentId: "$$taskId",
				// 				countMember: { $sum: [{$size: "$assigneeIds"}, {$size: "$testerIds"}, {$size: "$reviewerIds"}] },
				// 				//duration: {$ceil: { $divide: [{$subtract: ["$dueDate", "$startDate"]}, 86400000] }},
				// 				//remainingDay: {$ceil: { $divide: [{$subtract: ["$dueDate", "$$NOW"]}, 86400000] }},
				// 				//passedDay: {$ceil: { $divide: [{$subtract: ["$$NOW", "$startDate"]}, 86400000] }},
				// 				//countTodo: "$totalTodo", //{ $size: "$todos"},
				// 				//countDoneTodo: "$doneTodo",
				// 				// {
				// 				// 	$size: {
				// 				// 		$filter: {
				// 				// 			input: "$todos",
				// 				// 			as: "todos",
				// 				// 			cond: { "$eq": ["$$todos.done", true] }
				// 				// 		}
				// 				// 	}
				// 				// },
				//
				// 				status: "$group.value",
				// 				hasTaskDone: { "$cond": [{$eq:["$status", 6]}, 1, 0] },
				// 				//userCosts: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] }
				// 			}},
				//
				// 			/*
				// 			// Calculate Estimated cost
				// 			{ $populate: ["hrcontract", "userCosts", "userId", "userCosts"] },
				// 			{ $addFields: {
				// 				estHour: { $multiply: [ { $size: "$userCosts" }, "$duration", 8] },
				// 				estAmount: { $multiply: [{ $sum: "$userCosts.overview.hourlySalary" }, "$duration", 8] }
				// 			}},
				//
				// 			// Calculate Loged cost
				// 			{ $lookup: {
				// 				from: "logtime",
				// 				let: { taskId: "$_id" },
				// 				pipeline: [
				// 					{ $match: {
				// 						$expr: {
				// 							$and: [
				// 								{ $eq: [ "$taskId", "$$taskId"] },
				// 								//{ $eq: [ "$status", 2] } // Approve only
				// 							]
				// 						}
				// 					}},
				//
				// 					// Find Salary
				// 					{ $populate: ["hrcontract", "creatorId", "userId", "hrcontract", false] },
				//
				// 					{ $addFields: {
				// 						hourlySalary: "$hrcontract.overview.hourlySalary",
				// 						//monthlySalary: "$hrcontract.overview.monthlySalary",
				//
				// 						// when approve logtime, calculate this logtime to amount
				// 						amount: { $multiply: ["$hour", "$hrcontract.overview.hourlySalary"]},
				// 					}},
				//
				// 					{ $project: {
				// 						creatorId: 1,
				// 						amount: 1,
				// 						hour: 1,
				// 					}},
				//
				// 				],
				// 				as: "logtimes"
				// 			}},
				// 			*/
				//
				// 			// Get populate user types
				// 			//{ $populate: ["user", "assigneeIds", "_id", "assigneeIds"]},
				// 			//{ $populate: ["user", "testerIds", "_id", "testerIds"]},
				// 			//{ $populate: ["user", "reviewerIds", "_id", "reviewerIds"]},
				//
				// 			// { $addFields: {
				// 			// 	"reviewerIds.type": "reviewer",
				// 			// 	"testerIds.type": "tester",
				// 			// 	"assigneeIds.type": "assignee"
				// 			// }},
				//
				// 			{ $addFields: {
				// 				users: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] },
				// 				//logAmount: { $sum: "$logtimes.amount" },
				// 				//logHour: { $sum: "$logtimes.hour" },
				// 				isSubTask: true,
				// 			}},
				//
				// 			{ $populate: ["user", "users", "_id", "users"]},
				//
				// 			{ $sort: {
				// 				colIndex: 1,
				// 				createdAt : -1
				// 			}},
				//
				// 			{ $convertDate: ["startDate -> startDateLocal", "dueDate -> dueDateLocal"]},
				// 			{ $project: {
				// 				// For SubTask of Task
				// 				_id: 1,
				// 				name: 1,
				// 				name2: 1,
				// 				number: 1,
				// 				type: 1,
				// 				status: 1,
				// 				priority: 1,
				// 				startDate: 1,
				// 				startDateLocal: 1,
				// 				dueDate: 1,
				// 				dueDateLocal: 1,
				// 				//duration: 1,
				// 				//remainingDay: 1,
				// 				//passedDay: 1,
				//
				// 				countMember: 1,
				//
				// 				//estHour: 1,
				// 				//logHour: 1,
				//
				// 				//estAmount: 1,
				// 				//logAmount: 1,
				//
				// 				"users._id" : 1,
				// 				"users.type" : 1,
				// 				"users.name" : 1,
				// 				"users.avt" : 1,
				// 				"users.userId" : 1,
				//
				// 				// "assigneeIds._id" : 1,
				// 				// "assigneeIds.name" : 1,
				// 				// "assigneeIds.avt" : 1,
				// 				// "assigneeIds.auserId" : 1,
				// 				//
				// 				// "testerIds._id" : 1,
				// 				// "testerIds.name" : 1,
				// 				// "testerIds.avt" : 1,
				// 				// "testerIds.userId" : 1,
				// 				//
				// 				// "reviewerIds._id" : 1,
				// 				// "reviewerIds.name" : 1,
				// 				// "reviewerIds.avt" : 1,
				// 				// "reviewerIds.userId" : 1,
				//
				// 				// "todos._id": 1,
				// 				// "todos.done": 1,
				//
				// 				//countTodo: 1,
				// 				//countDoneTodo: 1,
				// 				hasTaskDone: 1,
				// 				isSubTask: 1,
				// 				isLock: 1,
				// 				parentId: 1,
				// 			}}
				// 		],
				// 		as: "subTasks"
				// 	}
				// },
				// Edn Sub Task --------------------------------------------

				{ $sort: {
					colIndex: 1,
					createdAt : -1
				}},

				//{ $convertDate: ["startDate -> startDateLocal", "dueDate -> dueDateLocal"]},

				{ $project: {
					// For Task
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					type: 1,
					status: 1,
					priority: 1,

					duration: 1,
					startDate: 1,
					//startDateLocal: 1,
					dueDate: 1,
					//dueDateLocal: 1,

					remainingDay: 1,
					passedDay: 1,

					countMember: 1,

					estHour: 1,
					logHour: 1,

					estAmount: 1,
					logAmount: 1,

					complete: 1,
					users: 1,
					// "users._id" : 1,
					// "users.type" : 1,
					// "users.name" : 1,
					// "users.avt" : 1,
					// "users.userId" : 1,

					// "assigneeIds._id" : 1,
					// "assigneeIds.name" : 1,
					// "assigneeIds.avt" : 1,
					// "assigneeIds.userId" : 1,
					//
					// "testerIds._id" : 1,
					// "testerIds.name" : 1,
					// "testerIds.avt" : 1,
					// "testerIds.userId" : 1,
					//
					// "reviewerIds._id" : 1,
					// "reviewerIds.name" : 1,
					// "reviewerIds.avt" : 1,
					// "reviewerIds.userId" : 1,
					//
					// "todos._id": 1,
					// "todos.done": 1,

					//countTodo: 1,
					//countDoneTodo: 1,

					isSubTask: 1,
					parentId: 1,
					milestoneId: 1,
                    sprintId: 1,

					//subTasks: 1,
					hasTaskDone: 1,
					isLock: 1,
				}},
				// { $addFields: {
				// 	//countTask: { $add: [{$size: "$subTasks"}, 1] },
				// 	//countTaskDone: { $add: [{ $sum: "$subTasks.hasTaskDone" }, "$hasTaskDone"] }
				// }}
			],
			as: "tasks"
		}},

        { $addFields: {
            "tasks.itemType": "task",
        }},

		// { $addFields: {
		// 	//duration: {$ceil: { $divide: [{$subtract: ["$endDate", "$startDate"]}, 86400000] }},
		// 	//remainingDay: {$ceil: { $divide: [{$subtract: ["$endDate", "$$NOW"]}, 86400000] }},
		// 	//passedDay: {$ceil: { $divide: [{$subtract: ["$$NOW", "$startDate"]}, 86400000] }},
		//
		// 	//countTask: { $sum: "$tasks.countTask" },
		// 	//countTaskDone: { $sum: "$tasks.countTaskDone" },
		//
		// 	//countTodo: { $sum: "$tasks.countTodo" },
		// 	//countDoneTodo: { $sum: "$tasks.countDoneTodo" },
		// 	//tasks: { $slice: ["$tasks", "@skipTask", "@numberTask"] } // Currently for all task
		// }},

		// Add user
		{ $flatArray: {
			userIds: "$tasks.users",
		}},
		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "_id", "name", "avt", "userId"]},

		{ $project: {
			milestones: 1,
            sprints: 1,
			tasks: 1,
			users: 1,
			//userIds: 1,
		}}
	]],
	//`A.printObject:`,

	// arrs, weekBoundary=false, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false, keyPaths
	`A.dateMinMax > dbDate: @dbData.tasks: true:: true: true: @paddingWeek: startDate, dueDate`, // old save in dbDate1
	//`A.printObject: dbDate1`,
	//`A.dateMinMax > dbDate2: @dbData.tasks.subTasks: true:: true: true: @paddingWeek: startDate, dueDate`, // not need this step
	//`A.printObject: dbDate2`,
	//`A.dateMinMax > dbDate: ["@dbDate1", "@dbDate2"]: true:: true: true: @paddingWeek: minDate, maxDate`, // not need this step
	//`A.printObject:dbDate`,

	// Copy object to array
    `A.copyKObject:: dbData.milestones, dbDataMilestones`,
    `A.copyKObject:: dbData.sprints, dbDataSprints`,
	`A.copyKObject:: dbData.tasks, dbDataTasks`,
	//`A.copyKObject:: dbDataTasks.subTasks, dbDataSubTasks`, // not need this step
	//`A.printObject`,

	//`A.convertToLocalTime > P.body.dbDate.minDateLocal: @dbDate.minDate`,

	// arrs, startDate, scale=1.0, adjust=0.0, toLocalTime=false, ...keyPaths
    `A.dateFillDayIndex: @dbDataMilestones: @dbDate.minDate: @scale:: true: startDate, startIndex, endDate, endIndex`,
    `A.dateFillDayIndex: @dbDataSprints: @dbDate.minDate: @scale:: true: startDate, startIndex, dueDate, endIndex`,
	`A.dateFillDayIndex: @dbDataTasks: @dbDate.minDate: @scale:: true: startDate, startIndex, dueDate, endIndex`,
	//`A.dateFillDayIndex: @dbDataSubTasks: @dbDate.minDateLocal::: startDateLocal, startIndex, dueDateLocal, endIndex`, // not need this step

	//`A.printObject:`,
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var DateUtil = pipeData.U.Date;

		var body = Req.body || {};
		var date = body.dbDate || {};
		var dbData = body.dbData || {};

        var enableSprint = body.enableSprint;
		var hasFilter = body.hasFilter || false;

		var scale = body.scale || 1.0;

		var userObj = {};
		var users = dbData.users || [];
		users.map(u => {
			userObj[u._id.toString()] = u;
		});

		// Refactor task
		var taskObj = {};
		var tasks = dbData.tasks || [];

        var sprintObj = {};
        var sprintMsObj = {};
        var sprints = dbData.sprints || [];
        if(enableSprint) {
            for (var i = 0; i < sprints.length; i++) {
                var sp = sprints[i];
                var msId = sp.milestoneId || "";
                var arrs = sprintMsObj[msId];
                if(!arrs) {
                    arrs = [];
                    sprintMsObj[msId] = arrs;
                }

                // Sprint should use the ket like Task
                sp.subTasks = sp.subTasks || sp.tasks || [];
                arrs.push(sp);
                sprintObj[(sp._id||"").toString()] = sp;
            }
            //console.log("Arrs Sprint: ", sprintMsObj, sprints);
        }

		//var countTask = tasks.length || 0;
		//var countTaskDone = 0;

		var subTaskObj = {};
		var milestoneObj = {};
		for (var i = 0; i < tasks.length; i++) {
			var task = tasks[i];
			//countTaskDone += (task.hasTaskDone || 0);

			//console.log("task: ", task);
			if(task.isSubTask && task.parentId) {
				var id = task.parentId.toString();
				var arrs = subTaskObj[id];
				if(!arrs) {
					arrs = [];
					subTaskObj[id] = arrs;
				}

				// should update subtask

				// push subTask
				arrs.push(task);

				// remove this subtask of of the list
				tasks.splice(i--, 1);
				task.parentId = task.parentId;

			} /* else { */

				// Assign subTasks ref
				var id = task._id.toString();
				var arrs = subTaskObj[id];
				if(!arrs) {
					arrs = [];
					subTaskObj[id] = arrs;
				}
				task.subTasks = arrs;

				// Assign into Milestone + Sprint
				if(!task.isSubTask && !task.parentId) {
					var milestoneId = task.milestoneId || "";
					//if(milestoneId) { // Accepted unassigned milestone
						var msId = milestoneId.toString();
						var arrMs = milestoneObj[msId];
						if(!arrMs) {
							arrMs = [];
							milestoneObj[msId] = arrMs;
						}

						arrMs.push(task);
					//}

                    // Also Assign into Sprint
                    if(enableSprint) {
                        var sprintId = task.sprintId || "";
    					//if(sprintId) { // Accepted unassigned sprint
    						var spId = sprintId.toString();
    						var spObj = sprintObj[spId];
    						if(spObj) {
                                if((spObj.milestoneId||"").toString() == (task.milestoneId||"").toString()) {
                                    spObj.subTasks = spObj.subTasks || [];
                                    spObj.subTasks.push(task); // Use same key as Task
                                }
    						}
    					//}
                    }
				}
			/* } */

			//delete task.parentId;
			//delete task.milestoneId;
            //delete task.sprintId;

			// assign user
			var users = task.users || [];
			task.users = users;
			for (var j = 0; j < users.length; j++) {
				var u = users[j];
				u = userObj[u];
				if(u) {
					users.splice(j, 1, u);
				} else {
					users.splice(j--, 1);
				}
			}
		}

		//console.log("TET ==========: ", sprintObj, sprintMsObj);

		// refactor milestones;
		var milestones = dbData.milestones || [];

		var emptyList = milestoneObj[""] || [];
		if(emptyList && (emptyList.length > 0)) {
			milestones.push({
				_id: 0,
				name: "",
			});
		}

        var countFn = (obj, rsObj, type="task") => {
            var arrs = (obj.tasks || obj.subTasks) || (obj.sprints || []);
            if(arrs.length > 0) {
                for (var k = 0; k < arrs.length; k++) {
                    var sobj = arrs[k];
                    countFn(sobj, rsObj, type);
                }
            }

            if(obj.itemType === type) {
                rsObj.countTaskDone += (obj.hasTaskDone ? 1 : 0) + (obj.countTaskDone||0);
                rsObj.countTask += (obj.countTask|| (type == "task" ? 1: 0));
            }
        };

        /*
        // Calculate for Milestone (taskDone, toatlTask, complete)
		for (var j = 0; j < milestones.length; j++) {
			var ms = milestones[j] || {};

            var msId = (ms._id||"").toString();
			ms.tasks = milestoneObj[msId] || [];
            if(enableSprint) {
                ms.sprints = sprintMsObj[msId] || [];
            }

			var msCountTask = ms.tasks.length || 0;
			var msCountTaskDone = 0;

			ms.tasks.map(t => {

				msCountTask += ((t.subTasks||[]).length || 0);
				msCountTaskDone += t.hasTaskDone;

				(t.subTasks||[]).map(tt => {
					msCountTaskDone += tt.hasTaskDone;
				});
			});

			ms.countTask = msCountTask;
			ms.countTaskDone = msCountTaskDone;
			ms.complete = ((msCountTaskDone||0) / (msCountTask||1) * 100).toFixed(0)-0;
		}
        */

        for (var j = 0; j < milestones.length; j++) {
            var ms = milestones[j] || {};

            ms.tasks = sprintMsObj[ms?._id?.toString() || ""];

            ms.countTaskDone = 0;
            ms.countTask = 0;
            ms.complete = 0;
            countFn(ms, ms);
            ms.complete = ((ms.countTaskDone||0) / (ms.countTask||1) * 100).toFixed(0)-0;
        }


        // Calculate for Sprint (taskDone, totalTask, complete)
        if(enableSprint) {
            for (var j = 0; j < sprints.length; j++) {
                var sp = sprints[j] || {};

                sp.countTaskDone = 0;
                sp.countTask = 0;
                sp.complete = 0;
                countFn(sp, sp);
                sp.complete = ((sp.countTaskDone||0) / (sp.countTask||1) * 100).toFixed(0)-0;
            }
        }


		//console.log("Task: ", users, dbData.userIds);


		// Calculate -------------------------------------------
		var width = body.width || 1024;
		var totalDay = date.totalDay || 0;

		var minDate = date.minDate || new Date();
		var maxDate = date.maxDate || new Date();

		if(!date.minDate) {
			minDate = new Date(minDate.getTime() - minDate.getDay()*86400000);
		}

		var maxWeek = date.maxWeek;
		if(!maxWeek && maxWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, 1, true);
			maxWeek = rw.week || 0;
		}

		var minWeek = date.minWeek;
		if(!minWeek && minWeek !== 0) {
			// date, sunDayIsFirstDay=true, toBeginDay=true, toLocalTime=false
			var rw = await A.weekRangeFromDate(Req, pipeData, new Date(), true, true, true);
			minWeek = rw.week || 0;
		}

		var week = Math.ceil(width / (body.itemWidth||336));
		var nWeek = week - (maxWeek - minWeek);
		if (nWeek > 0) {
			nWeek = Math.max(nWeek, 1);
			totalDay += (nWeek * 7);

			maxWeek += (nWeek);
			//minWeek += (-1);

			maxDate = new Date(maxDate.getTime() + (nWeek)*7*86400000);
			//minDate = new Date(minDate.getTime() + (-1)*7*86400000);
		}

		date.maxWeek = maxWeek;
		date.minWeek = minWeek;

		date.maxDate = maxDate;
		date.minDate = minDate;

		//console.log("Max: ", maxDate, maxDate.getDay(), body.dbDate1);
		//var localStart = /*date.minDate ||*/ await A.convertToLocalTime(Req, pipeData, minDate);
		//var localEnd = await A.convertToLocalTime(Req, pipeData, new Date());
		date.totalDay = Math.ceil(totalDay / scale);
		DateUtil.getUpdateTodayMonthList(Req, pipeData, date, scale);

		var summary = {
			budget: 0,

			//countTodo: 0,
			//countDoneTodo: 0,

			//countTask,
			//countTaskDone,
			//complete: ((countTaskDone||0) / (countTask||1) * 100.0).toFixed(0)-0,
			duration: 0,
		};

		//console.log("Summary ", summary);
        var tz = DateUtil.getCompanyTimeZone(Req);
		var objComponent = DateUtil.companyTimePoint(Req, pipeData);

        var durationFn = async (task) => {
            var rs1 = task.estHour || task.duration;
            if(!rs1) {
                // Req, pipeData, startDate, endDate, listPolicyDays, isHour, rangeStartDate, rangeEndDate, isLocalTime, objComponent, tz
                rs1 = await DateUtil.calendarWorkingDay(Req, task, task.startDate, task.dueDate||task.endDate, [], true, false, false, false, objComponent, tz);
            }

            var subTasks = task.subTasks || task.tasks || [];
            if(subTasks?.length > 0) {
                for (var k = 0; k < subTasks.length; k++) {
                    var obj = subTasks[k];
                    await durationFn(obj);
                }
            }

            task.duration = ((rs1||0) / 8.0).toFixed(1)-0;
            //ms.duration += rs1;
            task.complete = (task.complete||0.0).toFixed(1)-0;
        };

		for (var i = 0; i < milestones.length; i++) {
			var ms = milestones[i];
			ms._id = ms._id || '1000000000000000000000';
            ms.itemType = 'milestone';

		//}
		//await milestones.map(async (ms) => {
			// remove unused data
			ms.duration = (ms.duration || 0);

			var tasks = ms.tasks || [];

			// Remove empty milestone when has filter and no task inside
			if(hasFilter) {
				if(!tasks || (tasks.length <= 0)) {
					milestones.splice(i--, 1);
					continue;
				}
			}

            await durationFn(ms);

            /*
			for (var j = 0; j < tasks.length; j++) {
				var task = tasks[j];

                /*
			//}
			//await (ms.tasks||[]).map(async (task) => {
				var rs1 = task.estHour || task.duration;
				if(!rs1) {
					// Req, pipeData, startDate, endDate, listPolicyDays, isHour, rangeStartDate, rangeEndDate, isLocalTime, objComponent, tz
					rs1 = await DateUtil.calendarWorkingDay(Req, task, task.startDate, task.dueDate, [], true, false, false, false, objComponent, tz);
				}
				task.duration = (rs1 / 8.0).toFixed(1)-0;

				//ms.duration += rs1;
				task.complete = (task.complete||0.0).toFixed(1)-0;

				//delete task.startDateLocal;
				//delete task.dueDateLocal;

				var subTasks = task.subTasks || [];
				for (var k = 0; k < subTasks.length; k++) {
					var subTask = subTasks[k];
				//}
				//await (task.subTasks||[]).map(async (subTask) => {
					var rs2 = subTask.estHour || subTask.duration;
					if(!rs2) {
						rs2 = await DateUtil.calendarWorkingDay(Req, subTask, subTask.startDate, subTask.dueDate, [], true, false, false, false, objComponent, tz);
					}
					subTask.duration = (rs2 / 8.0).toFixed(1)-0;

					ms.duration += rs2;
					subTask.complete = (subTask.complete||0.0).toFixed(1)-0;

					//delete subTask.startDateLocal;
					//delete subTask.dueDateLocal;
				}
			}
            */

			//summary.budget += ms.budget;

			//summary.countTask += (ms.countTask||0);
			//summary.countTaskDone += (ms.countTaskDone||0);

			// /summary.countTodo += ms.countTodo;
			//summary.countDoneTodo += ms.countDoneTodo;

            summary.countTask = 0;
            summary.countTaskDone = 0;
            countFn({tasks: milestones}, summary, 'milestone');
            summary.complete = ((summary.countTaskDone||0) / (summary.countTask||1) * 100.0).toFixed(0)-0,

			summary.duration += ms.duration;
			//summary.passedDay += ms.passedDay;
			//summary.remainingDay += ms.remainingDay;

            /*
            // Remove Tasks because it is sprints
            if(enableSprint) {
                //delete ms.tasks;
                ms.tasks = ms.sprints;
                delete ms.sprints;
            }
            */
		}

		// Format number of digit
		summary.duration = summary.duration.toFixed(1)-0;

		return { gantts: milestones, date, summary };
	}],

	//`A.responseObject: 200: {"gantts": "@dbData", "date": "@dbDate"}`
], { useZip: true }]);

module.exports = GanttRoute;
