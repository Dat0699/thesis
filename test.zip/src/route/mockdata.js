const MockDataRoute = {
	route	: "/mock/:serverId/data",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

MockDataRoute.POST.push([[""], [
	//`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.verifyInput:: mockdata: projectId!, serverId, number-, ...`,
	`A.insertOne: mockdata`,

	`A.pipeRoute: mockdata: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockDataRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.findOne(P.route): mockdata: {_id: "@_id"}`,
	`A.verifyInput:: mockdata: _id-, number-, ...`,

	`A.insertById > P.mockdata: mockdata`,
	`A.cloneById(*) > P.lookUp: mockapi:: {groupId: "@P.route._id"}: {groupId: "@P.mockdata._id"}: 500:: _id-, number-`,

	`A.pipeRoute: mockdata: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockDataRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessMockServer: {role: ""}`,

	`<F1>A.findOne(P.route): mockdata: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
], {F1: {IgnoreSanitized: true}} ]);

MockDataRoute.POST.push([["/s"], [
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var matchOps = {};

		var content = (pipeData.content || pipeData.title) || (pipeData.search || pipeData.text);
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var serverIds = pipeData.serverId || pipeData.serverIds;

        if(content) {
			var searchName = Req.func.getASCIISearch(content, "gmi");
            matchOps["$or"] = {
				name: searchName,
				shortName: searchName,
				//number: searchName,
			};
        }

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				matchOps.projectId = { $in: projectIds };
			}
		}

		if(serverIds) {
			if(!Array.isArray(serverIds)) {
				serverIds = [serverIds];
			}
			if(serverIds.length > 0) {
				matchOps.serverId = { $in: serverIds };
			}
		}

        pipeData.matchOps = matchOps;
		//console.log("pipeData: ", pipeData);
        return Req.UNRESULT;
    }],

	[`A.aggregate: mockdata`, [
		{ $match: "@matchOps" },

		{ $sort: {
			date: -1,
		}},

		{ $project: {
			_id: 1,
			number: 1,
			name: 1,
			name2: 1,
			shortName: 1,
			content: 1,
			serverId: 1,
			colIndex: 1,
		}},
	]],
]]);

MockDataRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessMockServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: mockdata: number-, projectId-, serverId-, ...`,

	`A.updateById(*): mockdata: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: mockdata: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

MockDataRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessMockServer: {role: "delete"}`,

	`A.deleteById(*): mockdata: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.deleteById(*): mockapi: { groupId: "@P.route._id", projectId: "@P.project._id" }: true: true`,

	`A.pipeRoute: mockdata: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = MockDataRoute;
