const DailyreportRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["dailyreport"],
		roleUserIdKey	: "userId"
	}
};


DailyreportRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
	`A.verifyInput:: dailyreport: projectId, type, content!, problem, reportDate!, reportToIds!, number-, point-, hasResolved-, approvedId-,  approverIds, ...`,
	`A.insertOne : dailyreport`,
	
	`A.populate: project, projectId, _id, project, +, name:
				 user, reportToIds, _id, reportToIds, +, name, name2, userId, avt, email`,
	
	// `A.refactorOutput > P.senderContent:: reportToIds.email, content, type, date, project, number, status`,
	// `A.printObject`,

	// [`A.jsScript::`, async (Req, pipeData, ctx) => {
	// 	let rs = [];
	// 	let listEmail = Req.senderContent.reportToIds || [];
	// 	for (let i=0; i < listEmail.length ; i++) {
	// 		rs.push(listEmail[i]['email']);
	// 	}
	// 	Req.messageSender = Req.user;
	// 	Req.listEmail = rs || [];
	// 	var senderContent = Req.senderContent;

	// 	// A.sendMail(*) > tmpMail: {
	// 	// 	"to" 		: ["@P.listEmail"],
	// 	// 	"subject" 	: "{{P.messageSender.name}} just reported to you at {{P.senderContent.type}}",
	// 	// 	"view" 		: "dailyReport",
	// 	// 	"data" 		: "@P.body"
	// 	// },

	// 	if(!(Req.senderContent.status == 1)) {
	// 		await A.sendMail(Req, pipeData, {
	// 			"to" 		: rs,
	// 			"subject" 	: `${Req.messageSender.name} just reported to you at ${senderContent.type}`,
	// 			"view" 		: "dailyReport",
	// 			"data" 		: ""
	// 		});
	// 	}

	// 	return Req.UNRESULT;
	// }],
	
	
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		pipeData.reportToIds = [];
		return pipeData;
	}],

 	`A.refactorOutput:: createdAt-, modifiedAt-, modifierId-, ...`

]]);

// DailyreportRoute.POST.push([[":_id/reportto"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput:: dailyreport: reportToIds!`,
//
// 	`A.pipeRoute: checkUpdateDailyReport`,
//
// 	`A.insertSubItem(*) > reportToIds: dailyreport: @P.route._id: reportToIds: @P.body.reportToIds`,
// 	`A.populate: user, reportToIds, _id, reportToIds, +, name, name2, userId, avt`,
// 	[`A.jsScript::`, (Req, pipeData, ctx) => {
// 		return pipeData.reportToIds;
// 	}]
// ]]);
//
// DailyreportRoute.PUT.push([[":_id/reportto"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput:: dailyreport: reportToIds!`,
//
// 	`A.pipeRoute: checkUpdateDailyReport`,
//
// 	`A.removeSubItem(*): dailyreport: @P.route._id: reportToIds: @P.body.reportToIds[0]`,
// 	`A.responseObject: 200: Remove reportds successfully!`
// ]]);

DailyreportRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	//`A.pipeRoute: checkUpdateDailyReport`,

	`<F1>A.findOne(P.route): dailyreport: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var body = Req.body;

		if(body) {
			if(user.hasAgent || user.hasAdmin) {
				body.giveScore = true;

			} else {
				var arrs = body.reportToIds || [];
				for (var i = 0; i < arrs.length; i++) {
					var u = arrs[i];
					if((u._id||u).toString() === user._id.toString()) {
						body.giveScore = true;
					}
				}
			}
		}

		return Req.UNRESULT;
	}],

	// `A.populate: project, projectId, _id, project, +, name, name2,
	// 		   : user, creatorId, _id, creatorId, +, name, name2, userId, avt,
	// 		   : user, approverId, _id, approvedBy, +, name, name2, userId, avt,
	// 		   : user, approverIds, _id, approvers, +, name, name2, userId, avt,
	// 		   : user, reportToIds, _id, reportToIds, +, name, name2, userId, avt`,
	`A.refactorOutput:: createdAt-, modifierId-, ...`
], {F1: {IgnoreSanitized: true}} ]);

DailyreportRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	
	`A.verifyInput:: dailyreport: projectId, type, content, problem, reportDate, approverIds, point, reportToIds, ...`,

	`A.pipeRoute: checkUpdateDailyReport`,

	`A.findOne > dailyreportDb : dailyreport`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		if(pipeData.dailyreportDb && pipeData.dailyreportDb.status == 2 ) {
			return {"respData": "E-02", "respReturn": true , "respCode" : 500};
		}
		return pipeData;
	}],

	`A.populate: project, projectId, _id, project, +, name:
				user, reportToIds, _id, reportToIds, +, name, name2, userId, avt, email`,

	// `A.printObject`,
	// `A.refactorOutput > P.senderContent:: reportToIds.email, content, type, date, project`,
	// `A.printObject`,


	// [`A.jsScript::`, (Req, pipeData, ctx) => {
	// 	let rs = [];
	// 	let listEmail = Req.senderContent.reportToIds || [];
	// 	for (let i=0; i < listEmail.length ; i++) {
	// 		rs.push(listEmail[i]['email']);
	// 	}
	// 	Req.messageSender = Req.user;
	// 	Req.listEmail = rs || [];
	// 	return Req.UNRESULT;
	// }],
	
	// `A.sendMail(*) > tmpMail: {
	// 	"to" 		: ["@P.listEmail"],
	// 	"subject" 	: "{{P.messageSender.name}} just updated the report to you at {{P.senderContent.type}}",
	// 	"view" 		: "dailyReport",
	// 	"data" 		: "@P.body"
	// }`,

	//`A.updateById: dailyreport`,
	`A.updateById(*): dailyreport: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject: 200: Update successfully!`
]]);

// Appove DailyReport the Give a Point
DailyreportRoute.PUT.push([[":_id/report"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: dailyreport: hasResolved, point`,

	`A.pipeRoute: checkUpdateDailyReport`,
	`A.findOne > dailyreportDb : dailyreport`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		const dailyreportDb = pipeData.dailyreportDb;

		var user = Req.user || {};
		var index = (user.hasAdmin || user.hasAgent) ? 1 : -1;

		if(index < 0) {
			if (dailyreportDb && dailyreportDb.reportToIds.length > 0) {
				index = pipeData.dailyreportDb.reportToIds.findIndex((item) => {
					 return item.toString() === Req.user._id.toString();
				})
			}
		}

		if(index < 0) {
			var reqData = Req.body || {};
			if((reqData.hasResolved !== undefined) && (reqData.point === undefined)) {
				if(dailyreportDb.creatorId.toString() === user._id.toString()) {
					index = 1;
				}
			}
		}

		//if (index >= 0 && dailyreportDb.status == 2) {
		if (index >= 0) {
			return pipeData;
		}

		return {"respData": "E-02", "respReturn": true , "respCode" : 500};
	}],
	// /`A.updateById: dailyreport`,
	`A.updateById(*): dailyreport: {_id: "@P.route._id"}: @P.body`,
	`A.responseObject: 200: Update successfully!`
]]);

// DailyreportRoute.PUT.push([[":_id/status"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput:: dailyreport: status!`,
//
// 	`A.findOne > dailyreportDb : dailyreport`,
// 	[`A.jsScript::`, (Req, pipeData, ctx) => {
// 		var index = -1;
//
// 		const {dailyreportDb, status} = pipeData;
// 		if (dailyreportDb && dailyreportDb.reportToIds.length > 0) {
// 			index = pipeData.dailyreportDb.reportToIds.findIndex((item) => {
// 				 return item.toString() === Req.user._id.toString();
// 			})
// 		}
//
// 		if (status == 2) {
// 			pipeData.approvedId = Req.user._id
// 		}
//
// 		if (index >= 0) {
// 			return pipeData;
// 		}
// 		return {"respData": "E-02", "respReturn": true , "respCode" : 500};
// 	}],
// 	`A.updateById: dailyreport`,
// 	`A.responseObject: 200: Update successfully!`
// ]]);

DailyreportRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view, dailyreport.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	//`A.findOne > dailyreportDb : dailyreport`,
	[`A.aggregateOne(*) > dailyreportDb: dailyreport`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.dailyreport.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(dailyreportDb):: _id!: verify.idType`,

	`A.deleteOne: dailyreport`,
	`A.responseObject: 200: Delete successfully!`,
]]);

DailyreportRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: dailyreport.view`,
	`A.pipeRoute: getAllDailyReport`,

	`A.printObject:`,
	`A.responseObject(*): 200: @P.body.dbData`,
]]);

DailyreportRoute.PIPE.push([["/s"], [
	`A.trimObject`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		const content = (body.content || body.problem) || (body.text || body.search);
		const fromTime = body.fromDate || body.startDate;
		const toTime = body.toDate || body.endDate;
		var userIds = (body.creator || body.creatorId || body.creatorIds) ||
					  (body.user || body.userId || body.userIds) ||
					  (body.member || body.members || body.memberIds);

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAdmin;

		var rolecompany = (Req.rolecompany||{}).permit;
		// if(!hasAdmin && (!rolecompany || !rolecompany.dailyreport.approve)) {
		// 	userIds = [user._id];
		// }

		var ops = [];
		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}

			if(userIds.length > 0) {
            	ops.push({ $or: [
					{ creatorId: { $in: userIds } },
					//{ reportToIds: { $elemMatch: { $in: userIds }}}
				]});
			}
		}

		if(!hasAdmin && (!rolecompany || !rolecompany.dailyreport.approve)) {
			ops.push({ $or: [
				{ creatorId: { $in: [user._id] } },
				//{ reportToIds: { $elemMatch: { $in: [user._id] }}}
			]});
		}

        if (content) {
            var contentRegex = Req.func.getASCIISearch(content, "gmi");
            ops.push({ $or: [
				{ number: (content||0) -1 },
				{ content: contentRegex },
				{ problem: contentRegex }
            ]});
        }

		var status = body.status || body.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.push({ status: { $in: status } });
			}
		}

		var types = body.type || body.types;
		if(types) {
			if(!Array.isArray(types)) {
				types = [types];
			}

			if(types.length > 0) {
				ops.push({ type: { $in: types } });
			}
		}

        if(fromTime) {
			ops.push({ reportDate: {"$gte" : new Date(fromTime) }});
		}

		if(toTime) {
			ops.push({ reportDate: {"$lte" : new Date(toTime) }});
		}

		var projectIds = (body.project || body.projects) || (body.projectId || body.projectIds);
		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}

			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds } });
			}
		}

		if(ops && ops.length > 0) {
			body.ops = { $and: ops };

		} else {
			body.ops = { };
		}

		body.isAdmin = hasAdmin;
		body.userId = user._id;

        return Req.UNRESULT;
	}],

	`A.getPaginate > page`,

	[`A.aggregateOne(*) > dbData: dailyreport`, [
		{ $match: "@P.body.ops" },

		// Filter user is in this list
		{ $match: { $expr: { $or: [
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },
			{ $and: [
				{ $in: ["@P.user._id", { $ifNull: ["$informToIds", []] } ] },
				{ $in: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},
			{ $and: [
				{ $eq: ["@P.rolecompany.permit.dailyreport.approve", true] },
				{ $in: ["@P.user._id", "$reportToIds" ] },
				//{ $in: ["@P.user._id", { $ifNull: ["$reportToIds", [] ]} ]},
				{ $in: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},
			// { $eq: ["@P.user._id", "$creatorId"] },
			// { $eq: ["$sendToAll", true] },
			// { $eq: ["@P.user.hasAgent", true] },
			// { $eq: ["@P.user.hasAdmin", true] },
			// { $in: ["@P.user._id", "$listMembers"] },
		]}}},

		{ $sort: {
			reportDate: -1,
			//createdAt: -1
		}},

		{ $populate: ["user", "creatorId", "_id", "creatorId", false]}, // Remove deleted user
		{ $getTotalLength: "@P.body.page" },

		{ $populate: ["user", "reportToIds", "_id", "reportToIds"]},
		{ $populate: ["user", "approverId", "_id", "approvedBy", true]},
		{ $populate: ["user", "approverIds", "_id", "approvers"]},
		{ $populate: ["project", "projectId", "_id", "projectId", true]},

		{ $addFields: {
			duration: { $divide: [{ $subtract: ["$endDate", "$startDate"] }, 3600000] },
			giveScore: { $cond: [{$or: [{$eq: ["@P.body.isAdmin", true]}, {$in: ["@P.body.userId", "$reportToIds._id"]}]}, true, false] },
		}},

		{ $project: {
			_id: 1,
			type: 1,
			content: 1,
			point: 1,
			resolution: 1,
			problem: 1,
			hasResolved: 1,

			number: 1,
			reportDate: 1,
			modifiedAt: 1,

			giveScore: 1,
			rejectedMessage: 1,
			status: 1,

			totalLength: 1,

			"project._id": 1,
			"project.name": 1,
			"project.name2": 1,
			"project.shortName": 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,

			"reportToIds._id": 1,
			"reportToIds.name": 1,
			"reportToIds.name2": 1,
			"reportToIds.avt": 1,
			"reportToIds.userId": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,

			"approvers._id": 1,
			"approvers.name": 1,
			"approvers.name2": 1,
			"approvers.avt": 1,
			"approvers.userId": 1,
		}},

		{ $convertDate: "reportDate -> reportDateLocal"},
		{ $group: {
			_id: {
                week: { $week: "$reportDateLocal" },
                //day: { $dayOfMonth: "$reportDate" },
                year: { $year: "$reportDateLocal" }
            },
			date: { $min: "$reportDate" },
			dailyreports: { $push: "$$ROOT"},
			totalLength : { "$first" : "$totalLength" }
		}},
		{ $sort: {
			date: -1
		}},

		{ $project: {
			"dailyreports.totalLength": 0,
		}},

		{ $groupTotalLength: ["@P.body.page", "totalLength", "dailyreports"]}
	]],
], { name: "getAllDailyReport" }]);

DailyreportRoute.POST.push([["export"], [
	`A.pipeRoute: getAllDailyReport`,
	`C.exportDailyReport(*)`,
]]);

DailyreportRoute.POST.push([["addData"],[
	`C.addData(*)`,
]])

DailyreportRoute.PIPE.push([["checkUpdateDailyReport"], [
	[`A.aggregateOne(*) > dailyreportDb: dailyreport`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.dailyreport.modify", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(dailyreportDb):: _id!: verify.idType`,
], {name: "checkUpdateDailyReport"}]);

module.exports = DailyreportRoute;
