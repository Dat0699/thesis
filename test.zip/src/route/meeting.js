const MeetingRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["calendar", "meeting"],
		roleUserIdKey	: "userId"
	}
};

/* TODO: body truyen lên làm cách nào để verify ids đó */
MeetingRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.modify`,
	//"A.verifyInput:: meeting: title!, title2, type!, startDate!, endDate!, venueId!, attends-, disattends-, ...",

	// `A.printObject`,
	`A.fillingDateWorking:`,
	// `A.printObject`,
	
	`A.verifyInput:: meeting: number-, title!, title2, attends-, disattends-, ...`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;

		if(!body.members) {
			body.members = [Req.user._id];
		}

		return Req.UNRESULT;
	}],

	// `A.printObject`,
	`U.Date.calculateMeetingDuration`,
	// `A.printObject`,
	`A.insertOne: meeting`,
	// `A.printObject`,
	`A.pipeRoute: addMeetingReminder`,
]]);

MeetingRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.modify`,
	//`A.trimObject`,
	`A.verifyInput:: meeting: number-, attends-, disattends-, ...`,
	`A.assertObject::: (
		startDate < endDate
	):({
		"respCode": 400, "respData": "To Time invalid", "respReturn": true
	})`,

	[`A.aggregateOne(*) > meetingDb: meeting`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.meeting.modify", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(meetingDb):: _id!: verify.idType`,

	`U.Date.calculateMeetingDuration`,
	"A.updateById > updateDB: meeting",

	[`A.aggregateOne > db2: meeting`, [
		{ $match: {
			_id: "@updateDB._id"
		}},

		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

		{ $flatArray: {
			listMemberTeams: "$teams.members",
			listMemberProjects: "$projects.members.user"
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$members", "$listMemberTeams", "$listMemberProjects"] },
			attends: { $cond: [{$in: ["$attends", [undefined, null, ""]]}, [], "$attends"] },
			disattends: { $cond: [{$in: ["$disattends", [undefined, null, ""]]}, [], "$disattends"] },
		}},

		{ $addFields: {
			attends: { $filter: {
				input: "$attends",
				as: "user",
				cond: { "$in": ["$$user", "$listMembers"] }
			}},
			disattends: { $filter: {
				input: "$disattends",
				as: "user",
				cond: { "$in": ["$$user", "$listMembers"] }
			}}
		}},

		{ $populateFilter: ["user", "listMembers$:_id", "members", undefined, 1, "email"]},

		{ $addFields: {
			members: "$members.email",
		}},

		{ $project: {
			_id: 1,
			attends: 1,
			disattends: 1,
			// listMembers: 1,
			members: 1,
			number: 1,
		}}
	]],

	`A.updateById(db2) > respData: meeting: {_id: "@_id"}: {attends: "@attends", disattends: "@disattends" }`,
	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.db2.members",
		"subject" 	: "[Meeting] You were being on a meeting #{{P.body.db2.number}}",
		"view" 		: "meetingView",
		"data" 		: "@P.body.db2"
	}`,
	`A.pipeRoute: addMeetingReminder`,
]]);

MeetingRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view, meeting.delete`,

	[`A.aggregateOne(*) > meetingDb: meeting`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.meeting.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(meetingDb):: _id!: verify.idType`,

	`A.deleteOne(*): meeting: {_id: "@P.route._id"}`,
	`A.pipeRoute: deleteMeeting`,
	`A.pipeRoute: addMeetingReminder`,
	`A.responseObject: 200: Delete Meeting successfully!`
]]);

MeetingRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): meeting`, [
		{ $match: { $or: [
			{ _id: "@P.route._id" },
			{ number: "@P.route._id" },
		]}},

		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

		{ $flatArray: {
			listMemberTeams: "$teams.members",
			listMemberProjects: "$projects.members.user"
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$members", "$listMemberTeams", "$listMemberProjects" ]},
		}},

		// Filter user is in this list
		{ $match: { $expr: { $or: [
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["$sendToAll", true] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },
			{ $in: ["@P.user._id", "$listMembers"] },
		]}}},

		{ $addFields: {
			disattendCount: { $size: "$disattends" },
			attendCount: { $size: "$attends" },
			totalCount: { $size: "$listMembers" },
			//duration: { $divide: [{ $subtract: ["$endDate", "$startDate"] }, 3600000]},

			isAttend: { $cond: [{$in: ["@P.user._id", "$attends"]}, true, false]},
			isDisattend: { $cond: [{$in: ["@P.user._id", "$disattends"]}, true, false]},
			isInvited: { $cond: [{$in: ["@P.user._id", "$listMembers"]}, true, false]},
		}},

		{ $populate: ["venue", "venueId", "_id", "venueId", true]},
		{ $populate: ["user", "members", "_id", "members"]},
		{ $populateFilter: ["user", "attends$:_id", "attends", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $project: {
			_id: 1,
			type: 1,
			number: 1,
			title: 1,
			title2: 1,
			content: 1,
			conclusion: 1,
			startDate: 1,
			endDate: 1,
			remindBefore: 1,
			duration: 1,

			attends: 1,
			//disattends: 1,

			isAttend: 1,
			isDisattend: 1,
			isInvited: 1,

			disattendCount: 1,
			attendCount: 1,
			totalCount: 1,

			listMembers: 1,
			//listMemberTeams: 1,
			//listMemberProjects: 1,

			"members._id": 1,
			"members.name": 1,
			"members.name2": 1,
			"members.avt": 1,
			"members.userId": 1,

			"venueId._id": 1,
			"venueId.name": 1,
			"venueId.name2": 1,
			"venueId.color": 1,

			"projects._id": 1,
			"projects.name": 1,
			"projects.name2": 1,
			"projects.shortName": 1,
			"projects.avt": 1,
			//"projects.members": 1,

			"teams._id": 1,
			"teams.name": 1,
			"teams.name2": 1,
			"teams.avt": 1,
			//"teams.members": 1,

			// "attachs._id": 1,
			// "attachs.name": 1,
			// "attachs.name2": 1,
			// "attachs.path": 1,
		}},
	]],
]]);

MeetingRoute.POST.push([["s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,
	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {

		const name = pipeData.name || (pipeData.search || pipeData.text);
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;
		var userIds = pipeData.userIds || pipeData.userId;

		var type = pipeData.type || pipeData.types;
		var venue = (pipeData.venue || pipeData.venues) || (pipeData.venueId || pipeData.venueIds);

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAdmin;
		if(!hasAdmin) {
			userIds = [user._id];
		}

        var matchOps = [];

        if(name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            matchOps.push({ $or: [
				{ title: { $regex: nameReg }},
				{ title2: { $regex: nameReg }},
				{ number: (name-0) || -1 }
			]});
        }

		if(type) {
			if(!Array.isArray(type)) {
				type = [type];
			}
			if(type.length > 0) {
				matchOps.push({type: { $in: type }});
			}
		}

		if(venue) {
			if(!Array.isArray(venue)) {
				venue = [venue];
			}
			if(venue.length > 0) {
				matchOps.push({venueId: { $in: venue }});
			}
		}

		if(fromDate && toDate) {
			matchOps.push({ startDate: { $lte: toDate }});
			matchOps.push({ endDate: { $gte: fromDate }});
        }

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds > 0) {
				matchOps.push({ members: { $elemMatch: {"$in": userIds }} });
			}
		}

		pipeData.matchOps = {};
		if(matchOps.length > 0) {
			pipeData.matchOps = { $and: matchOps };
		}

		//console.log("pipeData: ", pipeData);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne(*): meeting`, [
		{ $match: "@P.body.matchOps" },
		{ $sort: {
			startDate: -1,
			createdAt: -1
		}},

		{ $populate: ["venue", "venueId", "_id", "venueId", true]},
		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members.user"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

		{ $flatArray: {
			listMemberTeams: "$teams.members",
			listMemberProjects: "$projects.members.user"
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$members", "$listMemberTeams", "$listMemberProjects" ]},
		}},

		// Filter user is in this list
		{ $match: { $expr: { $or: [
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["$sendToAll", true] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },
			{ $in: ["@P.user._id", "$listMembers"] },
		]}}},

		{ $getTotalLength: "@P.body.page" },

		{ $addFields: {
			disattendCount: { $size: "$disattends" },
			attendCount: { $size: "$attends" },
			totalCount: { $size: "$listMembers" },
			//duration: { $divide: [{ $subtract: ["$endDate", "$startDate"] }, 3600000] }
		}},

		{ $project: {
			_id: 1,
			type: 1,
			number: 1,
			title: 1,
			title2: 1,
			content: 1,
			conclusion: 1,
			startDate: 1,
			endDate: 1,
			remindBefore: 1,
			duration: 1,

			disattendCount: 1,
			attendCount: 1,
			totalCount: 1,

			members: 1,
			teams: 1,
			projects: 1,

			totalLength: 1,

			"projectId._id": 1,
			"projectId.name": 1,
			"projectId.name2": 1,
			"projectId.shortName": 1,
			"projectId.avt": 1,

			"venueId._id": 1,
			"venueId.name": 1,
			"venueId.name2": 1,
			"venueId.color": 1,
		}},

		{ $group: {
			_id: {
                month: { $month: "$startDate" },
                //day: { $dayOfMonth: "$startDate" },
                year: { $year: "$startDate" }
            },
			date: { $first: "$startDate" },

			duration: { $sum: "$duration" },
			meetings: { $push: "$$ROOT"},
			totalLength : { "$first" : "$totalLength" }
		}},

		{ $sort: {
			date: -1
		}},

		{ $project: {
			"meetings.totalLength": 0,
		}},

		{ $groupTotalLength: ["@P.body.page", "totalLength", "meetings"]},
	]],

	//`A.printObject:`,
	//`A.responseObject: 200: {"meetings": "@dbData"}`
]]);

MeetingRoute.GET.push([["/:_id/attend"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	//`A.findById(*) > dbBody: meeting: {"members": "@P.user._id", "_id": "@P.route._id"}`,

	[`A.aggregateOne(*) > dbBody: meeting`, [
		{ $match: { $or: [
			{ _id: "@P.route._id" },
			{ number: "@P.route._id" },
		]}},

		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members.user"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

		{ $flatArray: {
			listMemberTeams: "$teams.members",
			listMemberProjects: "$projects.members.user"
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$members", "$listMemberTeams", "$listMemberProjects" ]},
		}},

		{ $match: { $expr: { $and: [
			{ $in: ["@P.user._id", "$listMembers"]}
		]}}},
	]],

	`A.assertObject:: and: (
		dbBody type object,
		dbBody.members type array
	) : {
		respReturn: true,
		respCode: 500,
		respData: "You were not permit to reply this meeting!"
	}`,
    `A.modifyObject(*):: (
		P.body.dbBody.attends = +P.user._id,
		P.body.dbBody.disattends = -P.user._id,
		P.body.dbBody.attends = ?unify,
		P.body.dbBody.disattends = ?unify,
	)`,
    `A.updateById(dbBody) > tmpBody: meeting`,
	`A.responseObject: 200: Thank you for your confirmation attend!`,
]]);

MeetingRoute.GET.push([["/:_id/disattend"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	//`A.findById(*) > dbBody: meeting: {"members": "@P.user._id", "_id": "@P.route._id"}`,

	[`A.aggregateOne(*) > dbBody: meeting`, [
		{ $match: { $or: [
			{ _id: "@P.route._id" },
			{ number: "@P.route._id" },
		]}},

		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "members.user"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "members"]},

		{ $flatArray: {
			listMemberTeams: "$teams.members",
			listMemberProjects: "$projects.members.user"
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$members", "$listMemberTeams", "$listMemberProjects" ]},
		}},

		{ $match: { $expr: { $and: [
			{ $in: ["@P.user._id", "$listMembers"]}
		]}}},
	]],

	`A.assertObject:: and: (
		dbBody type object,
		dbBody.listMembers type array
	) : {
		respReturn: true,
		respCode: 500,
		respData: "You were not permit to reply this meeting"
	}`,
    `A.modifyObject(*):: (
		P.body.dbBody.attends = -P.user._id,
		P.body.dbBody.disattends = +P.user._id,
		P.body.dbBody.attends = ?unify,
		P.body.dbBody.disattends = ?unify,
	)`,
    `A.updateById(dbBody) > tmpBody: meeting`,
	`A.responseObject: 200: Thank you for your confirmation disattend!`,
]]);

MeetingRoute.POST.push([["check/valid/date"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: meeting.view`,
	`A.verifyKObject:: startDate!: verify.dateType:
					   endDate!: verify.dateType:
					   venueId!: verify.idType:
					   meetingId!: verify.idType`,

	[`A.aggregate: meeting`, [
		{ $match: { $expr: { $and: [
			{ $lte: ["$startDate", "@endDate"] },
			{ $gte: ["$endDate", "@startDate"] },
			{ $eq: ["$venueId", "@venueId"] },
			{ $ne: ["$_id", "@meetingId"] }
		]}}},

		{ $project: {
			_id: 0
		}},
		{ $project: {
			startDate: 1,
			endDate: 1
		}},
	]]
]]);

module.exports = MeetingRoute;
