const WorkingholidayRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		roleUserIdKey	: "userId"
	}
};

WorkingholidayRoute.GET.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.findOne: workingholiday`
]]);

WorkingholidayRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view`,
	`A.verifyInput > reqData:: workingholiday: ...`,
	// colName, key, groupBy, groupAsIntoKey, dateKey="createdAt", searchTextKey="title"
	`A.findMany: workingholiday: {}::: date: title`
]]);

WorkingholidayRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyInput:: workingholiday: title!, date!, type!`,
	//"A.printObject",
	`A.insertOne: workingholiday`
]]);

WorkingholidayRoute.PUT.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: workingholiday: ...`,
	`A.updateOne: workingholiday`
]]);

WorkingholidayRoute.DELETE.push([["/:_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: setting.view, setting.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne: workingholiday`

]]);

module.exports = WorkingholidayRoute;
