const PostAPIRoute = {
	route	: "post/:serverId/api",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

PostAPIRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.verifyInput:: postapi: groupId, projectId!, serverId!, number-, ...`,
	`A.insertOne: postapi`,

	`A.pipeRoute: postapi: { type: "create" }`,
	`A.pipeRoute: featureUpdateRelatedItem`,

	`A.responseObject(*): 200: @P.body`
]]);

PostAPIRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.findOne(P.route): postapi: {_id: "@_id", serverId: "@serverId"}`,
	`A.verifyInput:: postapi: _id-, method!, ...`,

	`A.insertOne: postapi`,

	`A.pipeRoute: postapi: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostAPIRoute.POST.push([["/select"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqBody:: postapi: projectId`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		if(Req.route.serverId !== 'any') {
			return Req.onResponse(500, 'Wrong request!');
		}

		return Req.UNRESULT;
	}],

	[`A.aggregate(*): postapi`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@P.project._id"] },
			// { $or: [
			// 	{ $in: ["$featureId", ['', undefined, null, 0, [], false]] },
			// 	{ $not: [{ $in: ["$featureId", ["@P.body.reqBody.featureId"]] }] },
			// ]}
		]}}},
		{ $project: {
			_id: 1,
			number: 1,
			name: 1,
			name2: 1,
		}}
	]],

	// `A.findMany: postapi: @reqBody`,
	// `A.refactorOutput:: _id, number, title, title2`,
]]);

PostAPIRoute.POST.push([["/group/s"], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var projectId = Req.project._id;

		var name = (pipeData.name || pipeData.search) || (pipeData.title || pipeData.text);
		pipeData.apiSearchText = Req.func.getASCIISearch(name||"", "gmi");
		pipeData.apiSearchNumber = (name - 0) || -1;

		pipeData.searchExistFilter = {};
		if(name) {
			// use to filter empty list
			pipeData.searchExistFilter = {anyKey: "__anyValue__"};
		}

		pipeData.hasTrim = !!name;
		pipeData.serverId = Req.route.serverId;
		pipeData.projectId = projectId;

		//console.log(JSON.stringify(pipeData));
        return pipeData;
    }],

    // [`A.aggregateOon > respData: postgroup:`, [
	// 	{ $match: {
	// 		projectId: "@projectId",
	// 		serverId: "@serverId",
	// 		$or: [
	// 			{ "parentId": {$eq: null} },
	// 			{ "parentId": {$exists: false} }
	// 		]
	// 	}},
	// 	{ $lookup: {
	// 		from: "postgroup",
	// 		let: { groupId: "$_id" },
	// 		pipeline: [
	// 			{ $match: {
	// 				$expr: {
	// 					$and: [
	// 						{ $eq: ["$projectId", "@projectId"] },
	// 						{ $eq: ["$parentId", "$$groupId"] },
	// 					]
	// 				}
	// 			}},
	// 			{ $lookup: {
	// 				from: "postapi",
	// 				let: { groupId : "$_id" },
	// 				pipeline: [
	// 					{ $match: {
	// 						$expr: {
	// 							$and: [
	// 								{ "$eq": [ "$groupId", "$$groupId" ] },
	// 								{ $eq: ["$projectId", "@projectId"] },
	// 								{ $or: [
	// 									{ $regexMatch: { input: "$name", regex: "@apiSearchText"} },
	// 									{ $eq: ["$number", "@apiSearchNumber"] }
	// 								]}
	// 							]
	// 						}
	// 					}},
	// 					{ $addFields: {
	// 						type: "api"
	// 					}},
	// 					{ $sort: {
	// 						colIndex: 1,
	// 					}},
	// 					{ $project: {
	// 						_id: 1,
	// 						type: 1,
	// 						name: 1,
	// 						name2: 1,
	// 						method: 1,
	// 						url: 1,
	// 						number: 1,
	// 						colIndex: 1,
	// 					} },
	// 				],
	// 				//as: "apis"
	// 				as: "children"
	// 			}},
	//
	// 			{ $project: {
	// 	   			 _id: 1,
	// 	   			 name: 1,
	// 				 name2: 1,
	// 	   			 //apis: "$children",
	// 				 children: 1,
	// 	   		 }},
	//
	// 			 { $addFields: {
	// 				 type: "folder",
	// 	   			 numberAPI: { "$size": "$children" },
	// 	   		 }},
	//
	// 			 { $match: {
	// 				 $expr: {
	// 				 	$or: [
	// 				 		{ $gt: ["$numberAPI", 0] },
	// 						"@searchExistFilter"
	// 					]
	// 				}
	// 			}}
	//
	// 		],
	// 		//as: "subs"
	// 		as: "childrenFolders"
	// 	}},
	// 	{ $addFields: {
	// 		subs: "$childrenFolders"
	// 	}},
	//
	// 	{ $lookup: {
	// 		 from: "postapi",
	// 		 let: { groupId : "$_id"},
	// 		 pipeline: [
	// 			{ $match: {
	// 				$expr: {
	// 					$and: [
	// 						{ "$eq": [ "$groupId", "$$groupId" ] },
	// 						{ $eq: ["$projectId", "@projectId"] },
	// 						{ $regexMatch: { input : "$name", regex: "@apiSearchText"} }
	// 					]
	// 				}
	// 			}},
	// 			{ $addFields: {
	// 				type: "api"
	// 			}},
	// 			{ $sort: {
	// 				colIndex: 1,
	// 			}},
 	// 			{ $project: {
 	// 				_id: 1,
	// 				type: 1,
	// 				name: 1,
	// 				name2: 1,
	// 				method: 1,
	// 				url: 1,
	// 				number: 1,
	// 				colIndex: 1,
 	// 			}},
	// 		 ],
	// 		 //as: "apis"
	// 		 as: "childrenApis"
	// 	}},
	// 	{ $addFields: {
	// 		type: "folder",
	// 		//apis: "$childrenApis"
	// 	}},
	// 	{ $sort: {
	// 		colIndex: 1,
	// 	}},
	// 	{ $project: {
	// 		 _id: 1,
	// 		 name: 1,
	// 		 name2: 1,
	// 		 type: 1,
	// 		 //apis: 1,
	// 		 //subs: 1,
	// 		 colIndex: 1,
	// 		 childrenApis: 1,
	// 		 childrenFolders: 1,
	// 	}},
	// 	{ $addFields: {
	// 		 numberAPI: { "$size": "$childrenApis" },
	// 		 numberSub: { "$sum": "$childrenFolders.numberAPI" },
	// 	}},
	// 	{ $match: { $or: [
	// 		{ numberAPI: { $gt: 0 } },
	// 		{ numberSub: { $gt: 0 } },
	// 		"@searchExistFilter"
	// 	]}},
	// 	{ $addFields: {
	// 		children: { $concatArrays: ["$childrenFolders", "$childrenApis"]}
	// 	}},
	// 	{ $project: {
	// 		childrenApis: 0,
	// 		childrenFolders: 0,
	// 	}}
	// ]]

	[`A.aggregate > data::`, [
		{ $lookup: {
			from: "postgroup",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $eq: ["$serverId", "@serverId"] },
				]}}},
				// { $sort: {
				// 	colIndex: 1,
				// 	name$: 1,
				// 	name2$: 1,
				// }},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					type: "folder",
					colIndex: 1,
					parentId: 1,
				}},
			],
			as: "groups",
		}},
		{ $lookup: {
			from: "postapi",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$projectId", "@projectId"] },
					{ $eq: ["$serverId", "@serverId"] },
					{ $or: [
						{ $regexMatch: { input: "$name", regex: "@apiSearchText"} },
						{ $regexMatch: { input: "$name2", regex: "@apiSearchText"} },
						{ $eq: ["$number", "@apiSearchNumber"] }
					]},
				]}}},
				// { $sort: {
				// 	colIndex: 1,
				// 	name$: 1,
				// 	name2$: 1,
				// }},
				{ $project: {
					_id: 1,
					type: 1,
					name: 1,
					name2: 1,
					method: 1,
					url: 1,
					number: 1,
					type: "api",
					colIndex: 1,
					parentId: "$groupId",
				}},
			],
			as: "apis",
		}},

		{ $addFields: {
			lists: { $concatArrays: [{$ifNull: ["$groups", []]}, {$ifNull: ["$apis", []]}]}
		}},
		{ $project: {
			lists: 1,
		}},
		{ $project: {
			_id: 0,
		}},
		{ $unwind: {
			path: "$lists"
		}},
		{ $replaceRoot: {
			newRoot: "$lists"
		}},
		{ $sort: {
			colIndex: 1,
			name$: 1,
			name2$: 1,
		}},
	]],

	`A.parentGroupObject > data: @data: parentId: children: colIndex`, //: type`,
	`A.trimObjectDeeply: @hasTrim: @data: children: type: folder`,
], { useZip: true }]);


//
// PostAPIRoute.POST.push([["/s"], [
// 	`A.aggregate: postapi: {
// 		$group: {
// 			_id : "$groupId",
// 			lists: {
// 				$push : "$$ROOT"
// 			}
// 		}
// 	}: {
// 		$lookup: {
// 			from: "postapifolder",
// 			localField: "_id",
// 			foreignField: "_id",
// 			as: "folder"
// 		}
// 	}: {
// 		$unwind: {
// 			path: "$folder"
// 		}
// 	}: {
// 		$addFields: {
// 			name: "$folder.name"
// 		}
// 	} : {
// 		$project: {
// 			"folder": 0
// 		}
// 	}`,
//
// 	//`A.populate: postapifolder, _id, _id, +, name`,
// 	//`A.moveKObject(*):: P.body.folder.name, P.body.name`,
// 	`A.refactorOutput:: _id-, ...`
//
// ]]);

PostAPIRoute.GET.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): postapi`, [
		{ $match: { $expr: { $and: [
			{ $eq: ["$projectId", "@P.project._id"] },
			{ $eq: ["$serverId", "@P.route.serverId"] },
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				{ $eq: ["$number", "@P.route._id"] },
			]},
		]}}},
	]],

	//`<F1>A.findOne(*): postapi: {serverId: "@P.route.serverId", projectId: "@P.project._id", $or: [{_id: "@P.route._id"}, {number: "@P.route._id"}]}`,
], {F1: {IgnoreSanitized: true}} ]);

PostAPIRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: postapi: colIndex, groupId, projectId!`,

	`A.updateById(*) > postapiDb : postapi: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update postapi successfully!`
]]);

PostAPIRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: postapi: projectId-, number-, serverId-, ...`,

	`A.updateById(*): postapi: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: @P.body`,

	`A.pipeRoute: postapi: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostAPIRoute.DELETE.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessPostServer: {role: "delete"}`,

	`A.deleteById(*): postapi: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,

	`A.pipeRoute: postapi: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = PostAPIRoute;
