const FeatureRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.feature",
        checkMIFs		: ["project", "feature"],
		imProject		: true,
    }
};

FeatureRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    //`A.printObject`,
	`A.fillingDateWorking:: startDate: dueDate: 40`, // 40h => 5 days
    `A.verifyInput:: feature: projectId!, name!, name2, descr, hasLocked, color, icon, parentId, featurePoint, startDate, dueDate, members`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;

		body.startDate = new Date(body.startDate || new Date());
		body.dueDate = new Date(body.dueDate || ((new Date()).getTime() + 86400000));

		// For year maximum
		var y = body.startDate.getFullYear();
		if(body.dueDate.getFullYear() - y > 2) {
			body.dueDate.setFullYear(y + 1);
		}

		if((body.dueDate - body.startDate) / 86400000 > 720) {
			return {
				respData: "Feature duration should be around 720 days",
				respReturn: true,
				respCode: 500
			};
		}

		return Req.UNRESULT;
	}],

    `A.insertOne: feature`,

	`A.pipeRoute: feature: { type: "create" }`,
    `A.refactorOutput:: _id, name, name2, descr, number, hasLocked, color, descr, status, startDate, dueDate`
]]);

FeatureRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    //`A.verifyInput > reqBody:: feature: projectId!`,

    //`A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

        var ops = {};

		var projectId = Req.project._id;
        ops.projectId = projectId;
		body.projectId = projectId;

		var name = (body.name || body.search) || (body.text || "");
		body.name = name;
		if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops["$or"] = [
				{ name: nameReg },
				{ name2: nameReg },
				{ number: (name-0) || -1 }
			];
        }

		var milestoneIds = (body.milestone || body.milestones) || (body.milestoneId || body.milestoneIds);
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				ops.milestoneId = { $in: milestoneIds };
			}
		}

		var sprintIds = (body.sprint || body.sprints) || (body.sprintId || body.sprintIds);
		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}

			if(sprintIds.length > 0) {
				ops.sprintId = { $in: sprintIds };
			}
		}

        body.ops = ops;
        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	[`A.aggregate > dbData: feature:`, [
		{ $match: "@ops" },
		{ $limit: 5000 },

		{ $sort: {
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			color: 1,
			number: 1,
			colIndex: 1,
			parentId: 1,
			//startDate: 1,
			//dueDate: 1,
			colIndex: 1,
			status: 1,
			hasCompleted: 1,
			hasLocked: 1,
			sprintId: 1,
			milestoneId: 1,
		}},

		{ $addFields: {
			expanded: true,
		}},

		{ $sort: {
			colIndex: 1,
			name$: 1
		}},
	]],

	//`A.moveKeyNameDeeply::name, name2, title`,

	// `A.printObject:`,
    `A.parentGroupObject > groupData: @dbData: parentId: children::name, name2: @name`,
	//`A.printObject:`,
	`A.flatGroupObject: @groupData: parentId: children: totalSprint: accTotalSprint: indentLevel: index`,
	//`A.printObject:`,
	
	//`A.flatGroupObject:: milestones, "parentId", "sprints", "totalSprint", "accTotalSprint", "indentLevel", "index")`,

	// Test script flat object
	// flatGroupObject = function(Param, pipeData, lists, parentKey, groupKey, totalKey, accTotalKey, levelKey, func)
	// [`A.flatGroupObject > abc2:: parentId: children: totalFeature: accTotalFeature: level`, (Req, pipeData, parent, lists) => {
	// 	console.log("parent: ", parent);
	// }],

	//`A.printObject:`,
]]);

FeatureRoute.POST.push([["full/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	//`A.copyKObject(*):: P.project._id, P.body.projectId`,
    //`A.verifyInput > reqBody:: feature: projectId!`,

    //`A.trimObject`,
    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

        var ops = {};

		var projectId = Req.project._id;
        ops.projectId = projectId;
		body.projectId = projectId;

		var name = (body.name || body.search) || (body.text || "");
		body.name = name;
		// if (name) {
        //     ops["$or"] = [
		// 		{ name: Req.func.getASCIISearch(name, "gmi") },
		// 		{ number: (name-0) || -1 }
		// 	];
        // }

		// 1 for Poking, 2 for Approved, 3 for Rejected, 4 for Submitted/Approved point, 6: for Completed, 7 for Polking
		var status = body.statusIds || body.statuses || body.status;
		if(status) {
			if(!Array.isArray(status)) {
				status = [status];
			}

			if(status.length > 0) {
				ops.status = { $in: status };
			}
		}

		var sprintIds = (body.sprint || body.sprints) || (body.sprintId || body.sprintIds);
		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}

			if(sprintIds.length > 0) {
				ops.sprintId = { $in: sprintIds };
			}
		}

		var milestoneIds = (body.milestone || body.milestones) || (body.milestoneId || body.milestoneIds);
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(sprintIds.length > 0) {
				ops.milestoneIds = { $in: milestoneIds };
			}
		}

        body.ops = ops;
        return Req.UNRESULT;
    }],

	//`A.printObject:`,
	[`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $eq: ["$shortName", "done"] },
						{ $or: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $sort: {
					colIndex: 1,
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
					colIndex: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupDone: { $arrayElemAt: [ "$groups", 0 ] },
			// 	 { $filter: {
			// 		 input: "$groups",
			// 		 as: "group",
			// 		 cond: { "$in": ["$$group.shortName", "done"] }
			// 	 }},
			// 	 0
			// ]}
		}},


		{ $lookup: {
			from: "task",
			let: { groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: {
					featureId: { $nin: [null, undefined, "", 0, false]}
				}},
				// { $addFields: {
				// 	hasTaskDone: { "$cond": [{$eq:["$groupId", "$$groupDoneId"]}, 1, 0] },
				// }},
				{ $sort: {
					colIndex: 1,
				}},
				{ $project: {
					_id: 1,
					//featureId: 1,
					groupId: 1,
					totalTodo: 1,
					doneTodo: 1,
					status: 1,
					colIndex: 1,
					//hasTaskDone: 1,
				}}
			],
			as: "tasks"
		}},

		{ $addFields: {
			tasks: { $ifNull: ["$tasks", []] }
		}},

		// { $addFields: {
		// 	totalTask: { $size: "$tasks" }
		// }},

		{ $lookup: {
			from: "feature",
			let: { tasks: "$tasks", /*totalTask: "$totalTask",*/ groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: "@ops" },
				{ $limit: 5000 },

				{ $addFields: {
					groupDoneId: "$$groupDoneId",
					taskLists:  { $cond: [
						{ $ne: ["$status", 6] },
						[],
						{ $filter: {
							input: "$$tasks",
							as: "task",
							cond: { $eq: ["$$task.featureId", "$_id"]},
						}}
					]},
				}},

				{ $addFields: {
					taskDones: { $cond: [
						{ $ne: ["$status", 6] },
						[],
						{ $filter: {
							input: "$taskLists",
							as: "task",
							cond: { $eq: ["$$task.groupId", "$groupDoneId"]},
						}}
					]},
				}},

				{ $addFields: {
					complete: { $cond: [
						{ $eq: ["$status", 6] },
						100,

						{ $multiply: [
							{ $divide: [
								{ $max: [{ $size: "$taskDones" }, 0] },
								{ $max: [{ $size: "$taskLists" }, 1] }
							]},
							100]
						},
					]},
					hasCompleted: { $cond: [ { $eq: ["$status", 6] }, true, false] },
				}},

				/*
				{ $addFields: {
					idx: { $indexOfArray: ["$$tasks._id", "$_id"] },
				}},

				{ $addFields: {
					idx: { $cond: [
						{ $lt: ["$idx", 0] },
						{ $add: ["$$totalTask", 20] },
						"$idx"
					]}
				}},
				{ $addFields: {
					task: { $arrayElemAt: ["$$tasks", "$idx"] },
				}},

				{ $addFields: {
					complete: { $cond: [
						{ $eq: ["$task.groupId", "$$groupDoneId"] },
						100,
						{ $multiply: [{ $divide: [{$max: ["$task.doneTodo", 0]}, {$max: ["$task.totalTodo", 1]} ]}, 100] },
					]}
				}},
				*/

				{ $sort: {
					colIndex: 1,
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
					icon: 1,
					number: 1,
					colIndex: 1,
					parentId: 1,
					//startDate: 1,
					//dueDate: 1,
					colIndex: 1,
					status: 1,
					complete: 1,
					hasCompleted: 1,
					hasLocked: 1,
				}},

				{ $addFields: {
					expanded: true,
				}},

				{ $sort: {
					colIndex: 1,
					name$: 1
				}},
			],
			as: "features"
		}},

		{ $project: {
			features: 1,
		}}
	]],

	//`A.moveKeyNameDeeply::name, name2, title`,

	//`A.printObject:`,
    `A.parentGroupObject: @dbData.features: parentId: children::name, name2: @name`,

	// Test script flat object
	// flatGroupObject = function(Param, pipeData, lists, parentKey, groupKey, totalKey, accTotalKey, levelKey, func)
	// [`A.flatGroupObject > abc2:: parentId: children: totalFeature: accTotalFeature: level`, (Req, pipeData, parent, lists) => {
	// 	console.log("parent: ", parent);
	// }],

	//`A.printObject:`,

]]);

FeatureRoute.GET.push([[":_id/testflow/:testflowId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								testflowId!: verify.idNumberType`,

	[`A.aggregateOne(*): testflow`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route.testflowId"] },
				{ $eq: ["$number", "@P.route.testflowId"] },
			]},
			{ $eq: ["$featureId", "@P.route._id"] },
			{ $eq: ["$projectId", "@P.project._id"] },
		]}}},

		// For Test case
		{ $loopArrayItem: ["testcases", false, "testcases", [
			{ $populateFilter: ["testcase", "testcase:_id", "testcase", false, 1, "_id", "number", "title", "title2", "modifierId", "modifiedAt"] },
			{ $populateFilter: ["user", "updatedBy:_id", "tester", true, 1, "_id", "name", "name2", "userId", "avt"] },
			{ $addFields: {
				testDate: { $ifNull: ["$updatedAt", "$testcase.modifiedAt"]},
			}},
			{ $project: {
				"testcase.modifierId": 0,
				"testcase.modifiedAt": 0,
			}},
		]]},

		{ $sort: {
			colIndex: 1,
		}},

		{ $project: {
			_id: 1,
			title: 1,
			title2: 1,
			number: 1,
			colIndex: 1,

			status: 1,
			testDate: 1,

			testcases: 1,
		}}
	]],
]]);

FeatureRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	// Get all sub feature
	// colName, idKey, parentKey, onlyId, levelDeep=10, ...keepKeys
	// `A.findAllChildById(*) > allChildFeatureIds: feature: { $and: [
	// 	{ $eq: ["$$item.projectId", "@P.project._id"]},
	// 	{ $or: [
	// 		{ $eq: ["$$item._id", "@P.route._id"] },
	// 		{ $eq: ["$$item.number", "@P.route._id"] }
	// 	]}
	// ]}: parentId: true: false: 10`,
	//`A.printObject:`,

    [`A.aggregateOne(*): feature`, [
		// $getAllChildren: colName, idKey, parentKey, saveAs, keepOpsKeys=true, onlyId=false, getThisItem=true, levelDeep=10, ...keepKeys
		{ $getAllChildren: ["feature", { $and: [
			{ $eq: ["$$item.projectId", "@P.project._id"]},
			{ $or: [
				{ $eq: ["$$item._id", "@P.route._id"] },
				{ $eq: ["$$item.number", "@P.route._id"] }
			]}
		]}, "parentId", "allChildFeatureIds", false, true, false, 10]},

		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
				{ $eq: ["$number", "@P.route._id"] },
			]},
			{ $eq: ["$projectId", "@P.project._id"] },
		]}}},

		{ $addFields: {
			taskIds: { $ifNull: ["$taskIds", []]},
			bugIds: { $ifNull: ["$bugIds", []]},
			wikiIds: { $ifNull: ["$wikiIds", []]},
			postapiIds: { $ifNull: ["$postapiIds", []]},
			testcaseIds: { $ifNull: ["$testcaseIds", []]},
			testflowIds: { $ifNull: ["$testflowIds", []]},
		}},

		// Get Group Task done
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $and: [
						{ $eq: ["$shortName", "done"] },
						{ $or: [
							{ $eq: ["$projectId", "@projectId"] },
							{ $eq: ["$hasGlobal", true] },
						]}
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
					value: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupDone: { $arrayElemAt: [ "$groups", 0 ] },
			// 	 { $filter: {
			// 		 input: "$groups",
			// 		 as: "group",
			// 		 cond: { "$in": ["$$group.shortName", "done"] }
			// 	 }},
			// 	 0
			// ]}
		}},

		// Add Linked Sprint
		{ $lookup: {
			from: "sprint",
			let: { sprintId: "$sprintId", groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$sprintId"] },
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},

				// Gat all feature and task to calculate completion %
				//{ $populateFilter: ["feature", "_id:sprintId", "features", true, 1, "_id", "name1", "name2", "status"] },
				{ $lookup: {
					from: "feature",
					let: { sprintId: "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$_id", "$$sprintId"] },
							{ $eq: ["$projectId", "@P.project._id"] },
						]}}},
						{ $project: {
							_id: 1,
						}}
					],
					as: "features",
				}},
				{ $addFields: {
					featureIds: { $ifNull: ["$features._id", []] }
				}},

				// get all task
				{ $lookup: {
					from: "task",
					let: { featureIds: "$featureIds", groupDoneId: "$$groupDoneId" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $in: ["$featureId", "$$featureIds"] },
							{ $eq: ["$projectId", "@P.project._id"] },
						]}}},
						{ $addFields: {
							hasTaskDone: { $cond: [
								{ $eq: ["$groupId", "$$groupDoneId"] },
								1,
								0,
							]}
						}},
						{ $project: {
							_id: 0
						}},
						{ $project: {
							hasTaskDone: 1
						}}
					],
					as: "tasks",
				}},

				{ $addFields: {
					totalTask: { $size: "$tasks" },
					totalTaskDone: { $sum: "$tasks.hasTaskDone" },
				}},
				{ $addFields: {
					totalTaskOps: { $max: ["$totalTask", 1] },
				}},

				{ $addFields: {
					complete_op$: "($totalTaskDone / $totalTaskOps) * 100.0"
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					colIndex: 1,
					status: 1,
					complete: 1,
					milestoneId: 1,
					dueDate: 1,
				}}
			],
			as: "linkedSprint"
		}},
		{ $unwind: {
			path: "$linkedSprint",
			preserveNullAndEmptyArrays: true,
		}},


		// Add Linked Tasks (Task + Bug)
		{ $lookup: {
			from: "task",
			let: { featureId: "$_id", taskIds: "$taskIds", bugIds: "$bugIds", groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$featureId", "$$featureId"] },
						{ $in: ["$_id", "$$taskIds"] },
						{ $in: ["$_id", "$$bugIds"] },
					]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $addFields: {
					hasTaskDone: { $cond: [{ $eq: ["$groupId", "$$groupDoneId"] }, 1, 0] },
					complete: { $cond: [
						{ $eq: ["$groupId", "$$groupDoneId"] },
						100,
						{ $multiply: [{ $divide: [{$max: ["$doneTodo", 0]}, {$max: ["$totalTodo", 1]} ]}, 100] },
					]}
				}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					type: 1,
					priority: 1,
					number: 1,
					colIndex: 1,
					status: 1,
					complete: 1,
					hasTaskDone: 1,
					groupId: 1,
				}},
			],
			as: "allTaskBugs"
		}},
		// { $unwind: {
		// 	path: "$linkedTasks",
		// 	preserveNullAndEmptyArrays: true,
		// }},

		// Isolate Task and Bug
		{ $addFields: {
			totalTask: { $size: "$allTaskBugs" },
			linkedTasks: { $filter: {
				input: "$allTaskBugs",
				as: "task",
				cond: { $eq: ["$$task.type", 1] }
			}},
			linkedBugs: { $filter: {
				input: "$allTaskBugs",
				as: "task",
				cond: { $ne: ["$$task.type", 1] }
			}},

			// get last test flow item
			//testflowTC: { $arrayElemAt: [{ $ifNull: ["$testflows", []] }, -1 }, // get last item
		}},

		// Feature Complete by Task Linked
		{ $addFields: {
			complete: { $cond: [
				{ $eq: ["$status", 6] },
				100,
				{ $multiply: [{$divide: [{$max: [{$sum: "$allTaskBugs.hasTaskDone"}, 0]}, {$max: ["$totalTask", 1]} ]}, 100]},
			]},
			hasCompleted: { $cond: [ { $eq: ["$status", 6] }, true, false] },

			// get last test flow item
			//testflowTC: { $ifNull: ["$testflows", []] },
			//testcaseIds: { $ifNull: ["$testcases.testcase", []] },

			userIds: { $concatArrays: [
						{ $ifNull: ["$testcases.updatedBy", []] },

						{ $ifNull: ["$poking.doing.user", []] },
						{ $ifNull: ["$poking.testing.user", []] },
						{ $ifNull: ["$poking.reviewing.user", []] },
					]},
		}},

		{ $addFields: {
			// get last test flow item
			//testcaseIds: { $setUnion: ["$testcaseIds", "$testflowTC"]},
			testcaseIds: { $ifNull: ["$testcaseIds", []] },
			testflowIds: { $ifNull: ["$testflowIds", []] },

			userIds: { $setUnion: { $ifNull: ["$userIds", []] }},
			milestoneId: { $ifNull: ["$milestoneId", "$linkedSprint.milestoneId"]},
		}},

		// Add Linked Milestone
		{ $lookup: {
			from: "milestone",
			let: { milestoneId: "$milestoneId" }, //milestoneId2: "$linkedSprint.milestoneId" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$milestoneId"] },
					//{ $eq: ["$_id", "$$milestoneId2"] },
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},

				// Get all feature related to milestone
				{ $lookup: {
					from: "feature",
					let: { milestoneId: "$_id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $eq: ["$milestoneId", "$$milestoneId"] },
							{ $eq: ["$projectId", "@P.project._id"] },
						]}}},
						{ $project: {
							_id: 1
						}}
					],
					as: "features"
				}},
				{ $addFields: {
					featureIds: { $ifNull: ["$features._id", []] }
				}},

				// Get all Task related to this milestone
				{ $lookup: {
					from: "task",
					let: { milestoneId: "$_id", featureIds: "$featureIds", groupDoneId: "$groupDone._id" },
					pipeline: [
						{ $match: { $expr: { $and: [
							{ $or: [
								{ $eq: ["$milestoneId", "$$milestoneId"] },
								{ $in: ["$featureId", "$$featureIds"] },
							]},
							{ $eq: ["$projectId", "@P.project._id"] },
						]}}},
						{ $addFields: {
							hasTaskDone: { $cond: [
								{ $eq: ["$groupId", "$$groupDoneId"] },
								1,
								0,
							]}
						}},
						{ $project: {
							_id: 0,
						}},
						{ $project: {
							hasTaskDone: 1,
						}},
					],
					as: "tasks"
				}},
				{ $addFields: {
					totalTask: { $size: "$tasks" },
					totalTaskDone: { $sum: "$tasks.hasTaskDone" },
				}},
				{ $addFields: {
					totalTaskOps: { $max: ["$totalTask", 1] },
				}},

				// Percent by task, because feature not store complete
				{ $addFields: {
					complete_op$: "($totalTaskDone / $totalTaskOps) * 100.0"
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
					status: 1,
					number: 1,
					complete: 1,
					endDate: 1,
				}},
			],
			as: "linkedMilestone"
		}},
		{ $unwind: {
			path: "$linkedMilestone",
			preserveNullAndEmptyArrays: true,
		}},

		{ $addFields: {
			//allChildFeatureIds: { $ifNull: ["@P.body.allChildFeatureIds", []]}
			allChildFeatureIds: { $ifNull: ["$allChildFeatureIds", []]}
		}},

		// Add Related Tasked
		{ $lookup: {
			from: "task",
			let: { allChildFeatureIds: "$allChildFeatureIds", groupDoneId: "$groupDone._id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$featureId", "$$allChildFeatureIds"] },
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $addFields: {
					complete: { $cond: [
						{ $eq: ["$groupId", "$$groupDoneId"] },
						//{ $in: ["$status", [6]] },
						100,
						{ $multiply: [{ $divide: ["$doneTodo", {$max: ["$totalTodo", 1]}] }, 100]},
					]}
				}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					type: 1,
					priority: 1,
					number: 1,
					status: 1,
					complete: 1,
					groupId: 1,
				}},
			],
			as: "relatedTasks"
		}},

		// Add Test case
		{ $lookup: {
			from: "testcase",
			let: { testcaseIds: "$testcaseIds", featureId: "$featureId" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$featureId", "$$featureId"] },
						{ $in: ["$_id", "$$testcaseIds"] },
					]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $project: {
					_id: 1,
					//name: 1,
					//name2: 1,
					number: 1,
					title: 1,
					title2: 1,
					//content: 1,
					status: 1,
				}},
			],
			as: "linkedTestCases"
		}},

		// Add Test Flow
		{ $lookup: {
			from: "testflow",
			let: { testflowIds: "$testflowIds" , featureId: "$_id"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$featureId", "$$featureId"]},
						{ $in: ["$_id", "$$testflowIds"] },
					]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $project: {
					_id: 1,
					//name: 1,
					//name2: 1,
					number: 1,
					title: 1,
					title2: 1,
					//content: 1,
					status: 1,
				}},
			],
			as: "linkedTestFlows"
		}},

		// copy from test flow detail in feature API
		{ $lookup: {
			from: "testflow",
			let: { currentTestFlowId: "$currentTestFlowId", featureId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$currentTestFlowId"] },
					// { $or: [
					// 	{ $eq: ["$_id", "@P.route.testflowId"] },
					// 	{ $eq: ["$number", "@P.route.testflowId"] },
					// ]},
					{ $eq: ["$projectId", "@P.project._id"] },
					{ $eq: ["$featureId", "$$featureId"] },
				]}}},

				// For Test case
				{ $loopArrayItem: ["testcases", false, "testcases", [
					{ $populateFilter: ["testcase", "testcase:_id", "testcase", false, 1, "_id", "number", "title", "title2", "modifierId", "modifiedAt"] },
					{ $populateFilter: ["user", "updatedBy:_id", "tester", true, 1, "_id", "name", "name2", "userId", "avt"] },
					{ $addFields: {
						testDate: "$testcase.modifiedAt"
					}},
					{ $project: {
						"testcase.modifierId": 0,
						"testcase.modifiedAt": 0,
					}},
				]]},

				{ $project: {
					_id: 1,
					title: 1,
					title2: 1,
					number: 1,

					status: 1,
					testDate: 1,

					testcases: 1,
				}}
			],
			as: "currentTestFlow",
		}},
		{ $unwind: {
			path: "$currentTestFlow",
			preserveNullAndEmptyArrays: true,
		}},

		// --------------
		// Add Post API
		{ $addFields: {
			postflowIds: {$ifNull: ["$postflowIds", []]}, // for empty old data
			postapiIds: {$ifNull: ["$postapiIds", []]}, // for empty old data
		}},
		{ $lookup: {
			from: "postapi",
			let: { postapiIds: "$postapiIds", featureId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$featureId", "$$featureId"] },
						{ $in: ["$_id", "$$postapiIds"] },
					]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				//{ $populateFilter: ["group", "groupId:_id", "group", true, 1, "_id", "name", "name2", "number"]},
				{ $populateFilter: ["postserver", "serverId:_id", "server", true, 1, "_id", "name", "name2", "number"]},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					featureId: 1,
					group: 1,

			        url: 1,
			        method: 1,
					serverId: 1,
					server: 1,

					// reqDoc: 1,
			        // reqHeader: 1,
			        // reqQuery: 1,
			        // reqBody: 1,
					// //reqPreScript: 1,
					//
			        // //resHeader: 1,
			        // resBody: 1,
					// //resPostScript: 1,
					//
			        // resStatus: 1,
			        // resTime: 1,
			        // resSize: 1,
					//
					// status: 1,
				}},
			],
			as: "linkedPostApis"
		}},

		// Add Post Flow
		{ $lookup: {
			from: "postflow",
			let: { postflowIds: "$postflowIds" /*, featureId: "$_id" */},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$_id", "$$postflowIds"] },
					//{ $eq: ["$featureId", "$$featureId"]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,
					testDate: 1,
					testMode: 1,
					status: 1,
				}},
			],
			as: "linkedPostFlows"
		}},

		// copy from test flow detail in feature API
		{ $lookup: {
			from: "postflow",
			let: { currentPostFlowId: "$currentPostFlowId", featureId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$currentPostFlowId"] },
					// { $or: [
					// 	{ $eq: ["$_id", "@P.route.postflowId"] },
					// 	{ $eq: ["$number", "@P.route.postflowId"] },
					// ]},
					{ $eq: ["$projectId", "@P.project._id"] },
					{ $eq: ["$featureId", "$$featureId"] },
				]}}},

				// For Test case
				{ $loopArrayItem: ["postapi", false, "postapis", [
					{ $populateFilter: ["postapi", "postapi:_id", "postapi", false, 1, "_id", "number", "name", "name2", "modifierId", "modifiedAt"] },
					{ $populateFilter: ["user", "updatedBy:_id", "tester", true, 1, "_id", "name", "name2", "userId", "avt"] },
					{ $addFields: {
						testDate: "$postapi.modifiedAt"
					}},
					{ $project: {
						"postapi.modifierId": 0,
						"postapi.modifiedAt": 0,
					}},
				]]},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					number: 1,

					status: 1,
					testDate: 1,
					testMode: 1,

					testcases: 1,
				}}
			],
			as: "currentPostFlow",
		}},
		{ $unwind: {
			path: "$currentPostFlow",
			preserveNullAndEmptyArrays: true,
		}},


		// Add Linked Automation Test case
		{ $lookup: {
			from: "automation",
			let: { featureId: "$_id" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$featureId", "$$featureId"] },
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					type: 1,
					script: 1,
					status: 1,
				}},
			],
			as: "linkedAutomations"
		}},

		// Add Linked Wiki
		{ $lookup: {
			from: "wiki",
			let: { featureId: "$_id", wikiIds: "$wikiIds" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $or: [
						{ $eq: ["$featureId", "$$featureId"] },
						{ $in: ["$_id", "$$wikiIds"] },
					]},
					{ $eq: ["$projectId", "@P.project._id"] },
				]}}},
				{ $populateFilter: ["group", "groupId:_id", "group", true, 1, "_id", "name", "name2"]},
				{ $project: {
					_id: 1,
					title: 1,
					title2: 1,
					number: 1,
					groupId: 1,
					group: 1,
				}},
			],
			as: "linkedWikis"
		}},


		// Add User updated Test case
		{ $lookup: {
			from: "user",
			let: { userIds: "$userIds" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$_id", "$$userIds"] }
				]}}},
				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					avt: 1,
					email: 1,
					userId: 1,
				}},
			],
			as: "users",
		}},

		{ $addFields: {
			linkedTasksDone: { $sum: {$ifNull: ["$linkedTasks.hasTaskDone", []]}},
			linkedTasksTotal: { $size: {$ifNull: ["$linkedTasks", []]}},

			linkedBugsDone: { $sum: {$ifNull: ["$linkedBugs.hasTaskDone", []]}},
			linkedBugsTotal: { $size: {$ifNull: ["$linkedBugs", []]}},

			linkedRelatedTasksDone: { $sum: {$ifNull: ["$linkedRelatedTasks.hasTaskDone", []]}},
			linkedRelatedTasksTotal: { $size: {$ifNull: ["$linkedRelatedTasks", []]}},
		}},

		{ $addFields: {
			compeleteItem: {
				task_op$: "($linkedTasksDone / ($linkedTasksTotal ?max 1)) * 100.0",
				bug_op$: "($linkedBugsDone / ($linkedBugsTotal ?max 1)) * 100.0",
				relatedTask_op$: "($linkedRelatedTasksDone / ($linkedRelatedTasksTotal ?max 1)) * 100.0",

				milestone: { $ifNull: ["$linkedMilestone.complete", 0] },
				sprint: { $ifNull: ["$linkedSprint.complete", 0] },
			}
		}},

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			descr: 1,
			color: 1,
			icon: 1,
			status: 1,
			number: 1,
			colIndex: 1,

			startDate: 1,
			dueDate: 1,

			poking: 1,
			featurePoint: 1,

			linkedTasks: 1,
			linkedBugs: 1,
			linkedMilestone: 1,
			linkedSprint: 1,
			linkedTestCases: 1,
			linkedTestFlows: 1,
			linkedAutomations: 1,
			linkedWikis: 1,
			relatedTasks: 1,

			currentTestFlow: 1,
			//currentTestFlowId: 1,

			linkedPostApis: 1,
			linkedPostFlows: 1,
			currentPostFlow: 1,
			//currentPostFlowId: 1,

			//testcases: 1,
			//allTestcases: 1,

			complete: 1,
			hasCompleted: 1,
			compeleteItem: 1,
			hasLocked: 1,
			users: 1,
			//userIds: 1,
		}}
	]],
	//`A.printObject:`,

	//`A.printObject: @userIds`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var stat = {};

		body.stat = stat;

		var poking = body.poking || {};

        var userObj = {};
		(body.users||[]).map(user => {
			userObj[user._id] = user;
		});

        var funcCount = function(arrs=[]) {
            var min = 10000;
            var max = -10000;
            var sum = 0;
            var count = 0;

            for(var l=0; l<arrs.length; l++) {
                var userUbj = arrs[l];
                var p = (userUbj.point||0)-0;

                if(!p || (p <= 0)) {
                    arrs.splice(l--, 1);
                    continue;
                }

                count++;
                if(max < p) max = p;
                if(min > p) min = p;
                sum += p;

                // For Poking populate ---------------------------------------
                userUbj.user = userObj[userUbj.user];
            }

            return {
                min: (min < 0) || (min >= 10000) ? 0 : min,
                max: (max < 0) ||(max >= 10000) ? 0 : max,
                avg: (sum / (count||1)).toFixed(1) - 0
            };
        };

		// Doing ---------------------------------------
		stat.doing = funcCount(poking.doing);

		// Testing ---------------------------------------
        stat.testing = funcCount(poking.testing);

		// Reviewing ---------------------------------------
		stat.reviewing = funcCount(poking.reviewing);


		// Process testcase ---------------------------------------
		var tcObj = {};
		(body.allTestcases||[]).map(tc => {
			tcObj[tc._id] = tc;
		});

		// var lastTestflow = body.testflows || [];
		// lastTestflow = testflow[lastTestflow.length-1] || {};
		// (lastTestflow.testcases||[]).map(tc => {
		// 	tc.testcase = tcObj[tc.testcase];
		// 	tc.updatedBy = userObj[tc.updatedBy];
		// });
		// body.lastTestflow = testflow;
		//
		// (body.testcases||[]).map(tc => {
		// 	tc.testcase = tcObj[tc.testcase];
		// 	tc.updatedBy = userObj[tc.updatedBy];
		// });

		//body.linkedTestcases = body.testcases || [];;

		//delete body.testcases;
		//delete body.allTestcases;
		delete body.users;

		// (body.testflows||[]).map(k => {
		// 	delete k.testcases;
		// })

		return body;
	}],
]]);

FeatureRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: feature: colIndex-, number-, name, name2, color, icon, hasLocked, descr, startDate, dueDate, parentId, sprintId, milestoneId, featurePoint, status, currentTestFlowId`,

    `A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var U = pipeData.U;
		var body = Req.body || {};
		var reqBody = body.reqBody || {};

		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const featureDb = body.featureDb;
        //console.log(pipeData);

		//var permit = featureDb && (hasAdmin || (featureDb.creatorId.equals(user._id) && featureDb.status != 2));
        if(!featureDb || (!hasAdmin && [2, 4].indexOf(featureDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

		U.Func.syncTask(Req, pipeData, reqBody, featureDb);

		if((body.colIndex != undefined) && (body.colIndex != null)) {
			reqBody.colIndex = body.colIndex / 1.0;
		}

		if(reqBody.startDate && reqBody.dueDate) {
			if((reqBody.dueDate - reqBody.startDate) / 86400000 > 720) {
				return {
					respData: "Feature duration should be around 720 days",
					respReturn: true,
					respCode: 500
				};
			}
		}

		var featurePoint = reqBody.featurePoint || featureDb.featurePoint || {};
		if(featurePoint) {
			featurePoint.total = (featurePoint.doing||0) + (featurePoint.testing||0) + (featurePoint.reviewing||0);
			reqBody.featurePoint = featurePoint;
		}

		//console.log("reqBody: ", reqBody);
        return Req.UNRESULT;
    }],

    `A.updateById(reqBody) > temp: feature`,

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var reqBody = body.reqBody || {};
		var A = pipeData.A;
		var annUsers = [];
		var request = Req.user;
		var action = '';
		console.log('asdasda', body.temp)

		if(reqBody?.hasLocked != undefined) {
			if(reqBody?.hasLocked) {
				action = 'Locked';
			} else {
				action = 'Unlocked'
			}
		}  

		if (reqBody.hasCompleted != undefined || reqBody.status) {
			if(reqBody.status == 6) {
				action = 'Completed';
			} else if (reqBody.status == 1) {
				action = 'Reopen';
			}
		}

		annUsers = await A.aggregateOne(Req, pipeData, "", [
			{ $lookup: {
				from: "roleproject",
				pipeline: [
					{ $match: {
						[`permit.feature.view`]: true
					}},
	
					{ $project: {
						_id: 1
					}},
				],
				as: "listRoles"
			}},

			{$addFields: {
				listRoleIds : '$listRoles._id',
			}},

			{ $lookup: {
				from: "project",
				pipeline: [
					{ $match: { $expr: { $and: [
						{ $eq: [ "$_id", Req.body.projectId ] },
						{ $or: [
							{ $in: [ Req.user._id , "$members.user"] },
							{ $eq: [Req.user.hasAgent, true]},
							{ $eq: [Req.user.hasAdmin, true]}
						]}
					]}}},
	
					{ $project: {
						_id: 1,
						members: 1,
						name: 1,
						name2: 1,
						shortName: 1,
					}},
				],
				as: "project"
			}},

			{ $unwind: {
				path: "$project",
				preserveNullAndEmptyArrays: false
			}},

			{ $addFields: {
				listUsers: { $filter: {
					input: "$project.members",
					as: "item",
					cond: { $and: [
						{ $in: ["$$item.role", "$listRoleIds"] }]},
				}}
			}},

			{ $addFields: {
				listUserIds: "$listUsers.user"
			}},

			{ $project: {
				listUserIds: 1,
				project: 1
			}},

			{ $lookup: {
				from: "user",
				pipeline: [
					{ $match: { $expr: { $or: [
						{ $eq: [ "$in", "$listUserIds"] },
					]}}},
	
					{ $project: {
						email: 1
					}},
				],
				as: "userEmails"
			}},
			{ $project: {
				userEmails: 1,
			}},
		]);

		const data = {
			project: Req?.project || {},
			number: body?.temp?.number || 0,
			request,
			action
		};

		await A.sendMail(Req, pipeData, {
			"to" 		: annUsers?.userEmails.map(x => x.email),
			"subject" 	: `[Feature] ${request?.name} just ${action} in item #${body?.temp?.number} `,
			"view" 		: 'featureView',
			"data" 		: data
		});
        return Req.UNRESULT;
    }],

	`A.pipeRoute: feature: { type: "update" }`,
    `A.responseObject: 200: Update successfully!`
]]);

FeatureRoute.PUT.push([[":_id/move/position"], [
    `A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: feature: colIndex, milestoneId, sprintId, projectId!`,

	`A.updateById(*) > featureDb : feature: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update feature successfully!`
]]);

//FeatureRoute.PUT.push([["/poking/:_id/:type:(/^(doing|testing|reviewing|all)$/gmi)"], [
FeatureRoute.PUT.push([["/poking/:_id/point"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    //`A.verifyInput > reqBody:: feature:name, name2, color, startDate, dueDate, parentId, colIndex, featurePoint, status`,

    `A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const featureDb = pipeData.featureDb;
        //console.log(pipeData);

		//var permit = featureDb && (hasAdmin || (featureDb.creatorId.equals(user._id) && featureDb.status != 2));
        if(!featureDb || (!hasAdmin && [2, 4].indexOf(featureDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

		var body = Req.body || {};
		//body = body.reqBody || body;

		// var type = Req.route.type;

        var userId = user._id.toString();
        var poking = featureDb.poking || {};
        featureDb.poking = poking;

        if(body.doing > 0) {
            poking.doing = (poking.doing || []).filter(item => item.user.toString() != userId);
            poking.doing.push({point: body.doing, user: user._id});
        }

        if(body.testing > 0) {
            poking.testing = (poking.testing || []).filter(item => item.user.toString() != userId);
            poking.testing.push({point: body.testing, user: user._id});
        }

        if(body.reviewing > 0) {
            poking.reviewing = (poking.reviewing || []).filter(item => item.user.toString() != userId);
            poking.reviewing.push({point: body.reviewing, user: user._id});
        }


		// body.keyPath = `poking.${type}`;
		// body.point = (body[type]||0) - 0;

        return { poking };
    }],

	//`A.printObject:`,
	// `A.removeSubItem(*) > tmp1: feature: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.keyPath: @P.user._id: user`,
	// `A.insertSubItem(*) > tmp2: feature: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.keyPath: [{user: "@P.user._id", point: "@P.body.point"}]`,

    `A.updateById(*) > tmp: feature: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	//`A.pipeRoute: feature: { type: "update" }`,
    `A.responseObject: 200: Poking successfully!`
]]);

FeatureRoute.PUT.push([["approve/:_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: feature: featurePoint, status`,

    `A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const featureDb = pipeData.featureDb;
        //console.log(pipeData);

		//var permit = featureDb && (hasAdmin || (featureDb.creatorId.equals(user._id) && featureDb.status != 2));
        if(!featureDb || (!hasAdmin && [2, 4].indexOf(featureDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500
			};
        }

		var body = (Req.body||{}).reqBody || {};

		if(!body.featurePoint) {
			body.featurePoint = {};
		}

		if(!featureDb.poking) {
			featureDb.poking = {};
		}

		// Doing
		if([undefined, null, ''].indexOf(body.featurePoint.doing) >= 0) {
			var total = 0;
			var arrs = featureDb.poking.doing || [];
			arrs.map(user => {
				total += (user.point||0);
			});
			body.featurePoint.doing = total / (arrs.length||1);
		}

		// Testing
		if([undefined, null, ''].indexOf(body.featurePoint.testing) >= 0) {
			var total = 0;
			var arrs = featureDb.poking.testing || [];
			arrs.map(user => {
				total += (user.point||0);
			});
			body.featurePoint.testing = total / (arrs.length||1);
		}

		// Reviewing
		if([undefined, null, ''].indexOf(body.featurePoint.reviewing) >= 0) {
			var total = 0;
			var arrs = featureDb.poking.reviewing || [];
			arrs.map(user => {
				total += (user.point||0);
			});
			body.featurePoint.reviewing = total / (arrs.length||1);
		}

		body.status = body.status || 6;
		Req.body = body;

        return body;
    }],

	`A.updateById: feature`,

	`A.pipeRoute: feature: { type: "approve" }`,
    `A.responseObject: 200: Approve successfully!`
]]);

// FeatureRoute.POST.push([[":_id/create/sprint"], [
// 	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
// 	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,
//
// 	[`A.jsScript:`, async (Req, pipeData, ctx) => {
// 		var body = Req.body || {};
// 		var featureDb = body.featureDb || {};
//
//
//		body.projectId = Req.project._id;
// 		body.featureId = featureDb._id || body.featureId;
// 		body.name = body.name || featureDb.name || "";
// 		body.name2 = body.name2 || featureDb.name2 || "";
//
// 		body.newSprint = {
// 			projectId: body.projectId,
// 			name: body.name,
// 			name2: body.name2,
// 			featureId: body.featureId,
// 			startDate: body.startDate,
// 			dueDate: body.dueDate,
// 			parentId: body.parentId,
// 		};
//
// 		return Req.UNRESULT;
// 	}],
//
// 	`A.insertById > sprintDb: sprint: @newSprint`,
//
// 	`A.updateById: feature: {_id: "@featureDb._id"}: {taskId: "@sprintDb._id"}: false: false: true`,
// 	`A.responseObject: 200: Create sprint successfully!`,
// ]]);

FeatureRoute.POST.push([[":_id/create/task"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var U = pipeData.U;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		U.Func.syncTask(Req, pipeData, body, featureDb);

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				U.Func.syncTask(Req, pipeData, body, sprint);
			}
		}

		body.featureId = featureDb._id || body.featureId;
		body.name = body.name || "";
		body.name2 = body.name2 || "";

		if(!body.groupId) {
			var group = await A.findById(Req, pipeData, "group", {shortName: "backlog", hasGlobal: true});
			body.groupId = group._id;
		}

		body.newTask = {
			projectId: Req.project._id,
			groupId: body.groupId,
			name: body.name,
			name2: body.name2,
			type: body.type || 1,
			featureId: body.featureId,
			sprintId: body.sprintId,
			milestoneId: body.milestoneId,
			startDate: body.startDate,
			dueDate: body.dueDate,
			parentId: body.parentId,
			isSubTask: body.parentId ? true : false,
		};

		/*
		var taskDb = await A.insertById(Req, pipeData, "task", body.newTask);
		var taskIds = body.feature.taskIds || [];
		taskIds.push(taskDb._id);
		*/

		Req.route.typeKeys = (body.newTask.type == 1) ? "taskIds" : "bugIds";
		return Req.UNRESULT;
	}],

	`A.insertById > taskDb: task: @newTask`,

	//`A.updateById: feature: {_id: "@featureDb._id"}: {taskIds: "@taskIds"}: false: false: true`,
	`A.insertSubItem(*) > tmp: feature: {_id: "@P.route._id", projectId: "@P.project._id"}: @P.route.typeKeys: @P.body.taskDb._id`,

	`A.responseObject: 200: Create task successfully!`,
]]);

// ------------------------ For Related Item ------------------------
FeatureRoute.POST.push([[":_id/add/:type:(/^(wiki|postapi|task|bug|testcase)$/)/:itemId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								itemId!: verify.idType`,

	`A.verifyKObject:: testflowId: verify.idType`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		const route = Req.route;
		//const body = Req.body;

		var type = route.type;
		route.type = (type == 'bug') ? 'task' : type;
		route.typeKeys = type + 'Ids';
		route.msg = "Add " + type + " successfully!";

		var testflowId = Req.body.testflowId;
		if(testflowId) {
			var testcaseId = route.itemId;
			await pipeData.A.insertSubItem(Req, pipeData, "testflow", {_id: testflowId}, "testcases", {
				testcase	: testcaseId,
				result		: "new",
				updatedBy	: Req.user._id,
				updatedAt	: new Date(),
			});
		}

		return Req.UNRESULT;
	}],

	`A.insertSubItem(*) > tmp: feature: {_id: "@P.route._id", projectId: "@P.project._id"}: @P.route.typeKeys: @P.route.itemId`,
	//`A.updateById(*): @P.route.type: {_id: "@P.route.itemId", projectId: "@P.project._id"}: {featureId: "@P.route._id"}`, // Add/Insert not need to set in item model
	`A.responseObject(*): 200: @P.route.msg`,
]]);

FeatureRoute.POST.push([[":_id/remove/:type:(/^(wiki|postapi|task|bug|testcase)$/)/:itemId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								itemId!: verify.idType`,

	`A.verifyKObject:: testflowId: verify.idType`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		const route = Req.route;
		//const body = Req.body;

		var type = route.type;
		route.type = (type == 'bug') ? 'task' : type;
		route.typeKeys = type + 'Ids';
		route.msg = "Remove " + type + " successfully!";

		var testflowId = Req.body.testflowId;
		if(testflowId) {
			var testcaseId = route.itemId;
			await pipeData.A.removeSubItem(Req, pipeData, "testflow", {_id: testflowId}, "testcases", testcaseId, "testcase");
		}

		return Req.UNRESULT;
	}],

	`A.removeSubItem(*) > tmp: feature: {_id: "@P.route._id", projectId: "@P.project._id"}: @P.route.typeKeys: @P.route.itemId`,
	`A.updateById(*): @P.route.type: {_id: "@P.route.itemId", projectId: "@P.project._id"}: {featureId: ""}`,
	`A.responseObject(*): 200: @P.route.msg`,
]]);


// ------------------------ For Post API ------------------------
FeatureRoute.POST.push([[":_id/create/postapi"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				body.sprintId = sprint._id || sprintId;
				//body.milestoneId = sprint.milestoneId || (featureDb.milestoneId || body.milestoneId);
			}
		}

		body.projectId = Req.project._id;
		//body.featureId = featureDb._id || body.featureId;
		body.name = body.name || "";
		body.name2 = body.name2 || "";
		body.url = body.url || "";
		body.method = body.method || "";

		return Req.UNRESULT;
	}],

	`A.insertById > postapiDb: postapi: {
		projectId: "@projectId",
		name: "@name",
		name2: "@name2",
		method: "@method",
		url: "@url",
		sprintId: "@sprintId",
	}`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var postflowId = body.postflowId;
		if(postflowId) {
			var postapi = body.postapiDb;
			await A.insertSubItem(Req, pipeData, "postflow", {_id: postflowId}, "postapis", {
				postapi		: postapi._id,
				result		: "new",
				updatedBy	: Req.user._id,
				updatedAt	: new Date(),
			});
		}

		return Req.UNRESULT;
	}],

	// Must always added into feature
	`A.insertSubItem(*) > tmp: feature: {_id: "@P.body.featureDb._id"}: postapiIds: @P.body.postapiDb._id`,
	`A.responseObject: 200: Create postapi successfully!`,
]]);

// FeatureRoute.POST.push([[":_id/add/postapi/:postapiId"], [
// 	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType:
// 								postapiId: verify.idType`,
//
// 	`A.insertSubItem(*) > tmp: feature: {_id: "@P.route._id"}: postapiIds: @P.route.postapiId`,
// 	`A.responseObject: 200: Add postapi successfully!`,
// ]]);
//
// FeatureRoute.POST.push([[":_id/remove/postapi/:postapiId"], [
// 	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType:
// 								postapiId: verify.idType`,
//
// 	`A.removeSubItem(*) > tmp: feature: {_id: "@P.route._id"}: postapiIds: @P.route.postapiId`,
// 	`A.responseObject: 200: Remove postapi successfully!`,
// ]]);

// FeatureRoute.PUT.push([[":_id/update/postapi/:postapiId"], [
// 	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
// 	`A.verifyInput:: postapi: _id-, number-, projectId-, featureId-, milestoneId-, ...`,
// 	`A.updateById: postapi`,
// 	`A.responseObject: 200: Update postapi successfully!`,
// ]]);

FeatureRoute.PUT.push([[":_id/update/postflow/:postflowId/postapi/:postapiId/status/:status:(/^(new|testing|passed|failed)$/)"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								postflowId!: verify.idType:
								postapiId!: verify.idType`,

	`A.updateSubItem(*) > tmp: postapi:
		{_id: "@P.route.postflowId", projectId: "@P.project._id", featureId: "@P.route._id"}:
		postapis:
		{postapi: "@P.route.postapiId", result: "@P.route.status"}: postapi`,

	`A.responseObject: 200: Update postapi successfully!`,
]]);

// ---------------------- For Post Flow -----------------------
FeatureRoute.POST.push([[":_id/create/postflow"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				body.sprintId = sprint._id || sprintId;
				body.milestoneId = sprint.milestoneId || (featureDb.milestoneId || body.milestoneId);
			}
		}

		body.projectId = Req.project._id;
		body.featureId = featureDb._id || body.featureId;
		body.name = body.name || "";
		body.name2 = body.name2 ||"";

		return Req.UNRESULT;
	}],

	`A.insertById > postflowDb: postflow: {
		projectId: "@projectId",
		name: "@name",
		name2: "@name2",
		testDate: "@testDate",
		testMode: "@testMode",
		featureId: "@featureId",
		sprintId: "@sprintId",
		milestoneId: "@milestoneId",
	}`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};
		var featureDb = body.featureDb || {};
		var testflowDb = body.postflowDb || {};

		var updatedData = {postflowIds: [...(featureDb.postflowIds||[]), postflowDb._id]};
		if(!featureDb.currentPostFlowId) {
			updatedData.currentPostFlowId = postflowDb._id;
		}

		await A.updateById(Req, pipeData, "feature", {_id: featureDb._id}, updatedData);
		return Req.UNRESULT;
	}],

	//`A.insertSubItem(*) > tmp: feature: {_id: "@P.route.postflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: postflowIds: @P.body.postflowDb._id`,
	`A.responseObject: 200: Create post flow successfully!`,
]]);

FeatureRoute.PUT.push([[":_id/update/postflow/:postflowId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								postflowId!: verify.idType`,

	`A.verifyInput:: postflow: title!, title2, descr`,
	`A.updateById(*): postflow: {_id: "@P.route.postflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: @P.body`,
	`A.responseObject: 200: Update post flow successfully!`,
]]);

FeatureRoute.POST.push([[":_id/clone/postflow/:postflowId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								postflowId!: verify.idType`,

	`A.findById(*) > postflowDb: postflow: {_id: "@P.route.postflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: @P.body`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var db = body.postflowDb;

		var date = new Date();
		var userId = Req.user._id;

		(db.postapis||[]).map(item => {
			item.status = 'new';
			item.updatedAt = date;
			item.updatedBy = userId;
		});

		return Req.UNRESULT;
	}],

	`A.keepKObject(postflowDb):: title, title2, postapis, color, featureId, projectId, status, testDate`,
	`A.insertById(*) > newItem: postflow: @P.body.postflowDb`,

	`A.insertSubItem(*) > tmp: feature:
		{_id: "@P.route._id", projectId: "@P.project._id"}:
		postflowIds:
		@P.body.newItem._id`,

	`A.responseObject: 200: Clone post flow successfully!`,
]]);

// ------------------------ For Test Case ------------------------
FeatureRoute.POST.push([[":_id/create/testcase"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				body.sprintId = sprint._id || sprintId;
				body.milestoneId = sprint.milestoneId || (featureDb.milestoneId || body.milestoneId);
			}
		}

		body.projectId = Req.project._id;
		body.featureId = featureDb._id || body.featureId;
		body.title = body.title || "";
		body.title2 = body.title2 || "";

		return Req.UNRESULT;
	}],

	`A.insertById > testcaseDb: testcase: {
		projectId: "@projectId",
		title: "@title",
		title2: "@title2",
		content: "@content",
		condition: "@condition",
		featureId: "@featureId",
		sprintId: "@sprintId",
		milestoneId: "@milestoneId",
	}`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body;

		var testflowId = body.testflowId;
		if(testflowId) {
			var testcase = body.testcaseDb;
			await A.insertSubItem(Req, pipeData, "testflow", {_id: testflowId}, "testcases", {
				testcase	: testcase._id,
				result		: "new",
				updatedBy	: Req.user._id,
				updatedAt	: new Date(),
			});
		}

		return Req.UNRESULT;
	}],

	// Must always added into feature
	`A.insertSubItem(*) > tmp: feature: {_id: "@P.body.featureDb._id"}: testcaseIds: @P.body.testcaseDb._id`,
	`A.responseObject: 200: Create test case successfully!`,
]]);

FeatureRoute.PUT.push([[":_id/update/testcase/:testcaseId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyInput:: testcase: _id-, number-, projectId-, featureId-, milestoneId-, ...`,
	`A.updateById: testcase`,
	`A.responseObject: 200: Update test case successfully!`,
]]);

FeatureRoute.PUT.push([[":_id/update/testflow/:testflowId/testcase/:testcaseId/status/:status:(/^(new|testing|passed|failed)$/)"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								testflowId!: verify.idType:
								testcaseId!: verify.idType`,

	`A.updateSubItem(*) > tmp: testflow:
		{_id: "@P.route.testflowId", projectId: "@P.project._id", featureId: "@P.route._id"}:
		testcases:
		{testcase: "@P.route.testcaseId", result: "@P.route.status"}: testcase`,

	`A.responseObject: 200: Update test case successfully!`,
]]);

// ------------------------ For Test Flow ------------------------
FeatureRoute.POST.push([[":_id/create/testflow"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				body.sprintId = sprint._id || sprintId;
				body.milestoneId = sprint.milestoneId || (featureDb.milestoneId || body.milestoneId);
			}
		}

		body.projectId = Req.project._id;
		body.featureId = featureDb._id || body.featureId;
		body.title = body.title || "";
		body.title2 = body.title2 ||"";

		return Req.UNRESULT;
	}],

	`A.insertById > testflowDb: testflow: {
		projectId: "@projectId",
		title: "@title",
		title2: "@title2",
		content: "@content",
		condition: "@condition",
		featureId: "@featureId",
		sprintId: "@sprintId",
		milestoneId: "@milestoneId",
	}`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var body = Req.body || {};
		var featureDb = body.featureDb || {};
		var testflowDb = body.testflowDb || {};

		var updatedData = {testflowIds: [...(featureDb.testflowIds||[]), testflowDb._id]};
		if(!featureDb.currentTestFlowId) {
			updatedData.currentTestFlowId = testflowDb._id;
		}

		await A.updateById(Req, pipeData, "feature", {_id: featureDb._id}, updatedData);
		return Req.UNRESULT;
	}],

	// JSFunction did it insertSubItem
	//`A.insertSubItem(*) > tmp: feature: {_id: "@P.route.testflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: testflowIds: @P.body.testflowDb._id`,

	`A.responseObject: 200: Create test flow successfully!`,
]]);

FeatureRoute.PUT.push([[":_id/update/testflow/:testflowId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								testflowId!: verify.idType`,

	`A.verifyInput:: testflow: title!, title2, descr`,
	`A.updateById(*): testflow: {_id: "@P.route.testflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: @P.body`,
	`A.responseObject: 200: Update test flow successfully!`,
]]);

FeatureRoute.POST.push([[":_id/clone/testflow/:testflowId"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType:
								testflowId!: verify.idType`,

	`A.findById(*) > testflowDb: testflow: {_id: "@P.route.testflowId", featureId: "@P.route._id", projectId: "@P.project._id"}: @P.body`,
	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var db = body.testflowDb;

		var date = new Date();
		var userId = Req.user._id;

		(db.testcases||[]).map(item => {
			item.status = 'new';
			item.updatedAt = date;
			item.updatedBy = userId;
		});

		return Req.UNRESULT;
	}],

	`A.keepKObject(testflowDb):: title, title2, testcases, color, featureId, projectId, status, testDate`,
	`A.insertById(*) > newItem: testflow: @P.body.testflowDb`,

	`A.insertSubItem(*) > tmp: feature:
		{_id: "@P.route._id", projectId: "@P.project._id"}:
		testflowIds:
		@P.body.newItem._id`,

	`A.responseObject: 200: Clone test flow successfully!`,
]]);


// -------------------- For Milestone -------------------
FeatureRoute.POST.push([[":_id/create/milestone"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript:`, (Req, pipeData, ctx) => {
		var body = Req.body;
		var featureDb = body.featureDb || {};

		body.startDate = new Date(body.startDate || new Date());
		body.endDate = new Date(body.endDate || ((new Date()).getTime() + 86400000));

		// For year maximum
		var y = body.startDate.getFullYear();
		if(body.endDate.getFullYear() - y > 2) {
			body.endDate.setFullYear(y + 1);
		}

		if((body.endDate - body.startDate) / 86400000 > 720) {
			return {
				respData: "Milestone duration should be around 720 days",
				respReturn: true,
				respCode: 500
			};
		}

		body.projectId = Req.project._id;
		body.featureId = featureDb._id || body.featureId;
		body.name = body.name || "";
		body.name2 = body.name2 || "";

		return Req.UNRESULT;
	}],

	`A.insertById > milestoneDb: milestone: {
		projectId: "@projectId",
		name: "@name",
		name2: "@name2",
		type: "@type",
		startDate: "@startDate",
		endDate: "@endDate",
	}`,

	`A.updateById: feature: {_id: "@featureDb._id"}: {milestoneId: "@milestoneDb._id"}: false: false: true`,
	`A.responseObject: 200: Create milestone successfully!`,
]]);

FeatureRoute.POST.push([[":_id/create/automation"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var featureDb = body.featureDb || {};

		var sprintId = body.sprintId || featureDb.sprintId;
		if(sprintId) {
			var sprint = await A.findById(Req, pipeData, "sprint", {_id: sprintId});
			if(sprint) {
				if(sprint.startDate) {
					body.startDate = sprint.startDate;
				}

				if(sprint.dueDate) {
					body.dueDate = sprint.dueDate;
				}

				body.sprintId = sprint._id || sprintId;
				body.milestoneId = sprint.milestoneId || (featureDb.milestoneId || body.milestoneId);
			}
		}

		body.featureId = featureDb._id || body.featureId;
		body.name = body.name || "";
		body.name2 = body.name2 || "";

		body.newAutomation = {
			projectId: Req.project._id,
			name: body.name,
			name2: body.name2,
			type: body.type || 'js',
			featureId: body.featureId,
			sprintId: body.sprintId,
			milestoneId: body.milestoneId,
			startDate: body.startDate,
			dueDate: body.dueDate,
		};

		/*
		var taskDb = await A.insertById(Req, pipeData, "task", body.newAutomation);
		var taskIds = body.feature.taskIds || [];
		taskIds.push(taskDb._id);
		*/

		return Req.UNRESULT;
	}],

	`A.insertById > taskDb: automation: @newAutomation`,

	//`A.updateById: feature: {_id: "@featureDb._id"}: {taskIds: "@taskIds"}: false: false: true`,
	`A.responseObject: 200: Create automation successfully!`,
]]);


FeatureRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: feature.view, feature.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.findOne(*) > featureDb: feature: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.findOne(*) > childFeatureDb: feature: { parentId: "@P.route._id", projectId: "@P.project._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		var user = Req.user;
		var hasAdmin = user.hasAgent || user.hasAdmin;

        const featureDb = body.featureDb;
        //console.log(body);

		//var permit = featureDb && (hasAdmin || (featureDb.creatorId.equals(user._id) && featureDb.status != 2));
        if(!featureDb || (!hasAdmin && [4].indexOf(featureDb.status) >= 0)) {
	    	return {
				respData: "E-02",
				respReturn: true,
				respCode: 500,
			};
        }

		const childFeatureDb = body.childFeatureDb;
		if(childFeatureDb && childFeatureDb._id) {
			return {
				respData: "Can not delete parent feature!",
				respReturn: true,
				respCode: 500,
			};
		}

        return Req.UNRESULT;
    }],

	// Common.findAllChildById = async function(Param, pipeData, colName, idKey, parentKey, onlyId, getThisItem=true, levelDeep=10, ...keepKeys) {
	//`A.findAllChildById(*) > allIds: feature: @P.route._id: parentId: true: true: 10`,
	//`A.printObject:`,

	// colName, idKey, hardDelete=true, deleteMany=false)
	//`<A>A.deleteById: feature: {_id: {$in : "@allIds" }}: true: true`,
	`<A>A.deleteById(*): feature: {_id: "@P.route._id"}: true: false`,

	`A.pipeRoute: feature: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
], { A: { IgnoreSanitized: true } }]);

module.exports = FeatureRoute;
