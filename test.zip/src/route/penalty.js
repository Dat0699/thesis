const PenaltyRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.performance",
		checkMIFs		: ["project", "performance"],// "penalty"],
		imProject		: true,
	}
};

PenaltyRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyInput:: penalty: projectId!, members, point, date, reason!, number-, ...`,

	`A.insertOne: penalty`,

	`A.pipeRoute: penalty: { type: "create" }`,
	`A.refactorOutput:: members, point, date, reason, taskId, projectId, status, number, creatorId`,
]]);

// PenaltyRoute.POST.push([["/s"], [
// 	`A.findMany: penalty`,
// 	`A.refactorOutput:: members, point, date, reason, taskId, projectId, status, creatorId`,
// ]]);

PenaltyRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): penalty`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		{ $populateFilter: ["user", "creatorId:_id", "creator", true, 1, "_id", "name", "userId", "avt"]},

		{ $project: {
			_id: 1,
			members: 1,
			point: 1,
			date: 1,
			reason: 1,
			taskId: 1,
			projectId: 1,
			status: 1,
			number: 1,
			creatorId: 1,
			creator: 1,
			modifiedAt: 1,
			rejectedMessage: 1,
		}}
	]],
]]);

PenaltyRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: penalty: members, point, date, reason, taskId, number-, status-`,

	`A.updateById(*): penalty: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: penalty: { type: "update" }`,
	`A.refactorOutput:: members, point, date, reason, taskId, projectId, status, number, creatorId`,
]]);

PenaltyRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view, performance.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.deleteOne(*): penalty: { _id: "@P.route._id", projectId: "@P.project._id" }`,

	`A.pipeRoute: penalty: { type: "delete" }`,
	`A.responseObject: 200: Delete Penalty successfully!`,
]]);

PenaltyRoute.POST.push([["/full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: performance.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		const projectId = pipeData.projectId;
		var taskId = pipeData.taskId;

		var userIds = (pipeData.user || pipeData.users) ||
					  (pipeData.userId || pipeData.userIds) ||
					  (pipeData.member || pipeData.members);

        var matchOps = {};
		if(projectId) {
        	matchOps.projectId = projectId;
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				matchOps.status = { $in: status };
			}
		}

        if(fromDate && toDate) {
			matchOps["$and"] = [
				{ date: { "$gte" : new Date(fromDate) }},
				{ date: { "$lte" : new Date(toDate) }}
			];
        }

		if(taskId) {
			if(!Array.isArray(taskId)) {
				taskId = [taskId];
			}
			if(taskId.length > 0) {
				matchOps.taskId = { $in: taskId };
			}
		}

		if(userIds) {
			if(!Array.isArray(userIds)) {
				userIds = [userIds];
			}
			if(userIds.length > 0) {
				matchOps.members = {$elemMatch: { $in: userIds }};
			}
		}

		pipeData.userIds = userIds || [];
        pipeData.matchOps = matchOps;
		//console.log("pipeData: ", matchOps.$and);

        return pipeData;
    }],

	`A.getPaginate > page`,

	//`A.printObject`,
	[`A.aggregateOne: penalty`, [
		{ $match: "@matchOps" },

		{ $sort: {
			date: -1,
			createdAt: -1,
		}},
		//
		// { $addFields: {
		// 	members: { $filter: {
		// 		input: "$members",
		// 		as: "member",
		// 		cond: { $not: { $in: ["$$member", "@userIds" ]}}
		// 	}}
		// }},
		//
		// { $addFields: {
		// 	members: { $setUnion: ["@userIds", "$members"]}
		// }},

		// for taskId
		{ $populate: ["task", "taskId", "_id", "taskId", true] },

		// for userId
		{ $populate: ["user", "members", "_id", "members"] },

		// for creatorId
		{ $populate: ["user", "creatorId", "_id", "creatorId", true] },

		// Filter data, keep valuable keys
		{ $project: {
			_id: 1,
			point: 1,
			reason: 1,
			reason2: 1,
			date: 1,
			status: 1,
			number: 1,
			modifiedAt: 1,
			rejectedMessage: 1,

			//totalLength: 1,

			"taskId._id": 1,
			"taskId.name": 1,
			"taskId.name2": 1,
			"taskId.number": 1,
			"taskId.type": 1,
			"taskId.status": 1,
			"taskId.priority": 1,

			"members._id": 1,
			"members.name": 1,
			"members.name2": 1,
			"members.avt": 1,
			"members.userId": 1,

			"creatorId._id": 1,
			"creatorId.name": 1,
			"creatorId.name2": 1,
			"creatorId.avt": 1,
			"creatorId.userId": 1,
		}},

		{ $getTotalLength: "@page" },
		{ $groupTotalLength: ["@page", "totalLength", "penalties", false, {
			totalPoint: { $sum: "$point" }
		}]},
	]],
]]);

module.exports = PenaltyRoute;
