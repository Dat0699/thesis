const DashboardRoute = {
	route	: true,
	ctrl	: false,
	model	: false,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.dashboard",
		checkMIFs		: ["project", "dashboard"],
		imProject		: true,
		keepRole		: true,
	}
};

DashboardRoute.POST.push([["full"], [
	`A.checkRole(*): project: @P.project._id: roleproject: dashboard.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.trimObject`,
	`U.Date.calendarWorkingDay(*) > cldWorkingDay: @P.body.startDate: @P.body.endDate::: @P.project.startDate: @P.project.dueDate`,

	//`A.printObject`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var matchTaskOps = [{ $in: ["$groupId", "$$groupIds"] }];
		var matchTaskDateOps = [];

		var matchSprint = [];
		var matchLogtimeOps = [];
		var matchMissionOps = [];
		var matchCheckinOps = [
			{ $eq: ["$creatorId", "$$userId"] },
			//{ $gt: ["$checkinHour", 0] }, // only valid check in
			{ $gt: ["$checkin", 0] }, // Only checkin count it count
		];
		var matchRiskOps = [{ $not: [{ $in: ["$status", [2]] }] }];

		//console.log("CHECK: ", Req.project.feature, Req.company.feature, Req);
		var fromDate = pipeData.fromDate || pipeData.startDate;
		var toDate = pipeData.toDate || pipeData.endDate;
		var projectIds = Req.project._id; //pipeData.projectId || pipeData.projectIds;
		var showRisk = pipeData.risk;// || pipeData.viewRisk || pipeData.showRisk;
		var milestoneIds = pipeData.milestoneId || pipeData.milestoneIds;
		var sprintIds = pipeData.sprintId || pipeData.sprintIds;

		var user = Req.user || {};
		var hasAdmin = user.hasAgent || user.hasAgent;

		if(!hasAdmin) {
			// Hide risk
			// Req.roleproject == true when admin
			var enableRisk = ((Req.company||{}).feature||{}).risk &&
							 ((Req.project||{}).feature||{}).risk &&
							 (((Req.roleproject||{}).permit||{}).risk||{}).view;
			if((showRisk == false) || !enableRisk) {
				matchRiskOps.push({ $eq: ["$anyKey", "anyValue"] });
			}
		}

		if(!fromDate) {
			var date = new Date();
			var d1 = date.getDate();
			var d2 = date.getDay();

			fromDate = new Date(date.getFullYear(), date.getMonth(), d1-d2, 0, 0, 0);
			endDate = new Date(date.getFullYear(), date.getMonth(), d1-d2+6, 23, 59, 59);
		}

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				matchTaskOps.push({ $in: ["$projectId", projectIds] });
				matchMissionOps.push({ $in: ["$projectId", projectIds] });
				matchLogtimeOps.push({ $in: ["$projectId", projectIds] });
				matchRiskOps.push({ $in: ["$projectId", projectIds] });
				matchSprint.push({ $in: ["$projectId", projectIds] });
			}
		}

        if(fromDate) {
			fromDate = new Date(fromDate);

			matchTaskDateOps.push({ $or: [
				{ startDate: { $gte: fromDate }},
				{ startDate: { $in: [null, undefined, 0, false, ""] }},
			]});

			matchMissionOps.push({ $gte: ["$startDate", fromDate] });

			matchRiskOps.push({ $gte: ["$dueDate", fromDate] });
			matchLogtimeOps.push({ $gte: ["$fromTime", fromDate] });
			matchCheckinOps.push({ $gte: ["$date", fromDate] });
			matchSprint.push({ $gte: ["$dueDate", fromDate] });
        }

		if(toDate) {
			toDate = new Date(toDate);
			matchTaskDateOps.push({ $or: [
				{ dueDate: { $lte: toDate }},
				{ dueDate: { $in: [null, undefined, 0, false, ""] }},
			]});

			matchMissionOps.push({ $lte: ["$endDate", toDate] });
			//matchMissionOps.endDate = { "$lte": new Date(toDate.getTime() + 7*86400000)};
			//pipeData.missionCheckDate = new Date(toDate.getTime() + 6*86400000);

			matchRiskOps.push({ $lte: ["$dueDate", toDate] });
			matchLogtimeOps.push({ $lte: ["$fromTime", toDate] });
			matchCheckinOps.push({ $lte: ["$date", toDate] });
			matchSprint.push({ $lte: ["$startDate", toDate] });
        }

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}

			if(milestoneIds.length > 0) {
				matchSprint.push({ $in: ["$milestoneId", milestoneIds] });
				matchTaskOps.push({ $in: ["$milestoneId", milestoneIds] });
				matchRiskOps.push({ $in: ["$milestoneId", milestoneIds] });
				matchLogtimeOps.push({ $in: ["$taskId", "$$taskIds"] });
			}
		}

		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}

			if(sprintIds.length > 0) {
				// matchSprint.push({ $in: ["$milestoneId", milestoneIds] });
				matchSprint.push({ $in: ["$_id", sprintIds] });

				//matchTaskOps.push({ $in: ["$milestoneId", milestoneIds] });
				//matchRiskOps.push({ $in: ["$milestoneId", milestoneIds] });
				//matchLogtimeOps.push({ $in: ["$taskId", "$$taskIds"] });
			}
		}

		pipeData.matchTaskOps = { $expr: { $and: matchTaskOps }};
		if(matchTaskDateOps.length > 0) {
			pipeData.matchTaskOps = { $and: [
				{ $and: matchTaskDateOps },
				pipeData.matchTaskOps
			]};
		}

		pipeData.matchLogtimeOps = { $expr: { $and: matchLogtimeOps }};
		pipeData.matchMissionOps = { $expr: { $and: matchMissionOps }};
		pipeData.matchRiskOps = { $expr: { $and: matchRiskOps }};
		pipeData.matchCheckinOps = { $expr: { $and: matchCheckinOps }};

		pipeData.projectIds = projectIds;
		pipeData.milestoneIds = milestoneIds || [];
		pipeData.sprintIds = sprintIds || [];

		pipeData.matchSprint = matchSprint;

		pipeData.startDate = fromDate || new Date();
		pipeData.endDate = toDate;

		//console.log("pipeData: ", pipeData.matchLogtimeOps.$expr.$and[0]);
        return Req.UNRESULT;
    }],
	//`A.printObject: @matchTaskOps: @matchLogtimeOps.$and: @matchLogtimeOps.$expr.$and: @matchMissionOps: @matchCheckinOps.$and: @matchCheckinOps.$expr.$and: @matchRiskOps.$or[0]`,

	[`A.aggregate > dbData::`, [
		// Task
		// User Task
		// Log time
		// KPI
		// Mission
		// Activity

		// Get log time need filter by milestone (from task)

		// Get Group
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match : {
					type: "task",
					$expr: { $or: [
						{ $eq: ["$projectId", "@projectId"] },
						{ $eq: ["$hasGlobal", true] },
					]}
		        }},
				{ $addFields: {
					shortName: { $toLower: "$shortName" }
				}},
				{ $project: {
					_id: 1,
					shortName: 1,
				}},
			],
			as: "groups"
		}},
		{ $addFields: {
			groupIds: "$groups._id"
		}},


		// Task
		{ $lookup: {
			from: "task",
			let: { groupIds: "$groupIds", groups: "$groups" },
			pipeline: [
				{ $match: "@matchTaskOps" },
				{ $addFields: {
					members: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] },
					taskType: { $arrayElemAt: [
						"$$groups",
						{ $indexOfArray: ["$$groupIds", "$groupId"] },
					]}
				}},

				{ $addFields: {
					taskType: { $ifNull: ["$taskType.shortName", "backlog"]}
				}},

				//{ $populate: ["user", "members", "_id", "members"]},

				{ $addFields: {
					//countTodo: "$totalTodo", // { $size: "$todos" },
					//countDoneTodo: "$doneTodo",
					// {
					// 	$size: {
					// 		$filter: {
					// 			input: "$todos",
					// 			as: "todos",
					// 			cond: { "$eq": ["$$todos.done", true] }
					// 		}
					// 	}
					// },
					hasTaskDone: { "$cond": [{$eq:["$taskType", "done"]}, 1, 0] },
					hasTaskDoing: { "$cond": [{$eq:["$taskType", "indoing"]}, 1, 0] },
					hasTaskTesting: { "$cond": [{$eq:["$taskType", "testing"]}, 1, 0] },
					hasTaskReviewing: { "$cond": [{$eq:["$taskType", "inreviewing"]}, 1, 0] },
					hasTaskOther: { "$cond": [{$in:["$taskType", ["backlog", "assigned"]]}, 1, 0] },
					// 1: Open, 2.Assigned, 3 Doing, 4: Test, 5: Review, 6: Done
				}},

				{ $project: {
					_id: 1,
					type: 1,
					//status: 1,
					hasTaskDone: 1,
					hasTaskDoing: 1,
					hasTaskTesting: 1,
					hasTaskReviewing: 1,
					hasTaskOther: 1,

					//todos: 1,
					//countTodo: 1,
					//countDoneTodo: 1,

					members: 1,
					// "members._id": 1,
					// "members.name": 1,
					// "members.name2": 1,
					// "members.type": 1,
					// "members.avt": 1,
					// "members.userId": 1,
				}}
			],
			as: "tasks"
		}},

		// Summary for task, Logime, KPI section
		{ $addFields: {
			//taskIds: "$tasks._id",
			//countTodo: { $sum: "$tasks.countTodo"},
			//countDoneTodo: { $sum: "$tasks.countDoneTodo"},

			allTaskIds: "$tasks._id",
			task: {
				count: { $size: "$tasks" },
				done: { $sum: "$tasks.hasTaskDone" },
				doing: { $sum: "$tasks.hasTaskDoing" },
				testing: { $sum: "$tasks.hasTaskTesting" },
				reviewing: { $sum: "$tasks.hasTaskReviewing" },
				other: { $sum: "$tasks.hasTaskOther" },
			},
			// taskCount: { $size: "$tasks" },
			// taskDone: { $sum: "$tasks.hasTaskDone" },
			// taskDoing: { $sum: "$tasks.hasTaskDoing" },
			// taskTesting: { $sum: "$tasks.hasTaskTesting" },
			// taskReviewing: { $sum: "$tasks.hasTaskReviewing" },
			// taskOther: { $sum: "$tasks.hasTaskOther" },

			//taskCountPercent: { $divide: [{ $size: "$tasks" }, 100.0] },

			//logtimeCount: { $sum: "$tasks.logtimeCount" },
			//logtimeHour: { $sum: "$tasks.logtimeHour" },
			//logtimeApprovedHour: { $sum: "$tasks.logtimeApprovedHour" },
		//}},

		// { $addFields: {
		// 	taskCountPercent: { $cond: [{$gt: ["$taskCountPercent", 0]}, "$taskCountPercent", 1]}
		// }},

		// task Type Statistic
		//{ $addFields: {
			taskTypes: [
				// "A.isEnum(1,2,3,4,5) < 1", // 1: Task/Issues, 2: Bug, 3: Q&A, 4: Inform, 5: Request
				// 'task': '#367BF5', 'bug': '#DD462D', 'qa': '#F2994A', 'inform': '#2FA84F', 'rq': '#9B51E0'
				{
					name: "task",
					color: "#367BF5",
					value : { $size: { $filter: {
						input: "$tasks",
						as: "task",
						cond: { "$eq": ["$$task.type", 1] }
					}}}
				},
				{
					name: "bug",
					color: "#DD462D",
					value: { $size: { $filter: {
						input: "$tasks",
						as: "task",
						cond: { "$eq": ["$$task.type", 2] }
					}}}
				},
				{
					name: "QA",
					color: "#F2994A",
					value: { $size: { $filter: {
						input: "$tasks",
						as: "task",
						cond: { "$eq": ["$$task.type", 3] }
					}}}
				},
				{
					name: "inform",
					color: "#2FA84F",
					value: { $size: { $filter: {
						input: "$tasks",
						as: "task",
						cond: { "$eq": ["$$task.type", 4] }
					}}}
				},
				{
					name: "request",
					color: "#9B51E0",
					value: { $size: { $filter: {
						input: "$tasks",
						as: "task",
						cond: { "$eq": ["$$task.type", 5] }
					}}}
				}
			]
		}},

		/*
		// Calculate Logtime type
		// #$loopArrayItem: arrayKeyPath, keepEmpty, saveAsKey, pipelines
		{ $loopArrayItem: ["tasks", false, "logtimes", [
			{ $let: { tasks: "$tasks", logtimeHour: "$logtimeHour" }},

			{ $project: {
				logtimes: 1
			}},

			{ $unwind: {
				path: "$logtimes",
				preserveNullAndEmptyArrays: false
			}},

			{ $replaceRoot: {
				newRoot: "$logtimes"
			}},

			{ $group: {
				_id: "$type",
				type: { $first: "$type" },
				total: { $sum: "$hour" },
			}},
			// { $addFields: {
			// 	percent: { $multiply: [{$divide: ["$total", "$$logtimeHour"]}, 100] }
			// }}
		]]},
		*/

		// New calculate logtime
		// Logtime shour count isolation
		{ $lookup: {
			from: "logtime",
			let: { taskIds: "$allTaskIds" },
			pipeline: [
				{ $match: "@matchLogtimeOps" },
				{ $addFields: {
					approvedHour: { $cond: [{$in: ["$status", [2]]}, "$hour", 0] }
				}},
				// { $project: {
				// 	_id: 1,
				// 	hour: 1,
				// 	approvedHour: 1,
				// 	type: 1,
				// 	//fromTime: 1,
				// 	creatorId: 1,
				// }}
				{ $group: {
					_id: "$type",
					type: { $first: "$type" },
					total: { $sum: "$hour" },
					count: { $sum: 1 },
					approved: { $sum: "$approvedHour" }
				}}
			],
			as: "logtimes"
		}},


		/*
		{ $lookup: {
			from: "__zcounting",

			pipeline: [
				{ $limit: 1 },
				{ $project: { _id: 1 }},
				{ $project: { _id: 0 }},
				{ $addFields: { tasks: "$$tasks" }},

				{ $unwind: {
					path: "$tasks",
					preserveNullAndEmptyArrays: false
				}},

				{ $replaceRoot: {
					newRoot: "$tasks"
				}},

				{ $project: {
					logtimes: 1
				}},

				{ $unwind: {
					path: "$logtimes",
					preserveNullAndEmptyArrays: false
				}},

				{ $replaceRoot: {
					newRoot: "$logtimes"
				}},

				{ $group: {
					_id: "$type",
					type: { $first: "$type" },
					total: { $sum: "$hour" },
				}},
				{ $addFields: {
					percent: { $multiply: [{$divide: ["$total", "$$logtimeHour"]}, 100] }
				}}
			],
			as: "logtimes"
		}},
		*/

		// For Risk
		{ $lookup: {
			from: "risk",
			pipeline: [
				{ $match: "@matchRiskOps" },
				{ $populate: ["label", "labelId", "_id", "label", true]},
				{ $sort: {
					priority: -1
				}},
				{ $project: {
					_id: 1,
					index: 1,
					content: 1,
					content2: 1,
			        priority: 1,
					status: 1,
					weight: 1,
					number: 1,

					"label._id": 1,
					"label.name": 1,
					"label.name2": 1,
					"label.color": 1,
				}}
			],
			as: "risks"
		}},

		// Them Logtime, estimate Task vao Dashboard cho moi user
		// Calculate Task User
		{ $lookup: {
			from: "__zcounting",
			let: { tasks: "$tasks" },
			pipeline: [
				{ $limit: 1 },
				{ $project: { _id: 1 }},
				{ $project: { _id: 0 }},
				{ $addFields: { tasks: "$$tasks" }},

				{ $unwind: {
					path: "$tasks",
					preserveNullAndEmptyArrays: true
				}},

				{ $unwind: {
					path: "$tasks.members",
					preserveNullAndEmptyArrays: true
				}},

				{ $addFields: {
					_id: "$tasks.members",
					// name: "$tasks.members.name",
					// type: "$tasks.members.type",
					// avt: "$tasks.members.avt",
					// userId: "$tasks.members.userId",

					taskId: "$tasks._id",

					// hasTaskDone: "$tasks.hasTaskDone",
					// hasTaskDoing: "$tasks.hasTaskDoing",
					// hasTaskTesting: "$tasks.hasTaskTesting",
					// hasTaskReviewing: "$tasks.hasTaskReviewing",
					// hasTaskOther: "$tasks.hasTaskOther",
					//countTodo: "$tasks.countTodo",
					//countDoneTodo: "$tasks.countDoneTodo",
				}},
				//{ $project: { tasks: 0 }},

				{ $group: {
					_id: "$_id",
					//name: { "$first": "$name" },
					//type: { "$first": "$type" },
					//avt: { "$first": "$avt" },
					//userId: { "$first": "$userId" },

					//countTodo : { $sum: "$tasks.countTodo" },
					//countDoneTodo : { $sum: "$tasks.countDoneTodo" },

					tasks: { $push : "$$ROOT" },
				}},


				{ $populateFilter: ["user", "_id:_id", "user", true, 1, "_id", "name", "userId", "avt", "type"]},

				// Group deleted user owning task
				{ $group: {
					_id: "$user._id",

					name: { $first: "$user.name" },
					name2: { $first: "$user.name2" },
					type: { $first: "$user.type" },
					avt: { $first: "$user.avt" },
					userId: { $first: "$user.userId" },
					tasks: { $push: "$tasks" }
				}},

				{ $addFields: {
					tasks: { $reduce: {
						input: "$tasks",
						initialValue: [],
						in: { $concatArrays : ["$$value", "$$this"] }
					}}
				}},

				{ $sort: {
					name$: 1,
					type: 1,
					//countDoneTodo: 1,
				}},

				/*
				// Curently hide this section
				// Lookup for Estimated Checkin, hour for member
				{ $lookup: {
					from: "checkin",
					//localField: "_id",
					//foreignField: "userId",
					let: { userId: "$_id"},
					pipeline: [
						{ $match: "@matchCheckinOps" },
					],
					as: "checkins",
				}},
				*/

				{ $addFields: {
					task: {
						count: { $size: "$tasks" },
						done : { $sum: "$tasks.tasks.hasTaskDone" },
						doing : { $sum: "$tasks.tasks.hasTaskDoing" },
						testing : { $sum: "$tasks.tasks.hasTaskTesting" },
						reviewing : { $sum: "$tasks.tasks.hasTaskReviewing" },
						other : { $sum: "$tasks.tasks.hasTaskOther" },
					},
					// taskCount: { $size: "$tasks" },
					// taskDone : { $sum: "$tasks.tasks.hasTaskDone" },
					// taskDoing : { $sum: "$tasks.tasks.hasTaskDoing" },
					// taskTesting : { $sum: "$tasks.tasks.hasTaskTesting" },
					// taskReviewing : { $sum: "$tasks.tasks.hasTaskReviewing" },
					// taskOther : { $sum: "$tasks.tasks.hasTaskOther" },

					//workingCount: { $size: "$checkins" },
					//workingHour: { $sum: "$checkins.checkinHour" },
					//workingDay: { $divide: [{$sum: "$checkins.checkinHour"}, 8] },
					//scheduleDay: { "$cond": [{$in:["$type", [1]]}, "@cldWorkingDay", {"$size": "$checkins"}] },

					/* // Hide logtime + estimate
					estimatedCount: { "$cond": [
										{ $in: ["$type", [1]] },
										"@cldWorkingDay",
										{ $size: "$checkins.registerHour" }
								    ]},

					estimatedHour: { "$cond": [
										{ $in:["$type", [1]] },
										{ $multiply: ["@cldWorkingDay", 8]},
										{ $sum: "$checkins.registerHour" }
									]},

					logtimes: {
						$filter: {
							input: {
								$reduce: {
									input: "$tasks.tasks.logtimes",
									initialValue: [],
									in: { $concatArrays : ["$$value", "$$this"] }
								}
							},
							as: "logtime",
							cond: { "$eq": ["$$logtime.creatorId", "$_id"] },
						}
					}
					*/
				}},
				{ $addFields: {
					/* // Hide logtime + estimate
					logtimeCount: { $size: "$logtimes" },
					logtimeHour: { $sum: "$logtimes.hour" },
					*/
					complete: { $multiply: [{$divide: ["$task.done", {$cond:[{$eq: ["$task.count", 0]}, 1, "$task.count"]}]}, 100]},
				}},

				{ $project: {
					tasks: 0,
					logtimes: 0,
					//checkins: 0,
				}},

				{ $sort: {
					complete: -1,
					"task.done": -1,
				}}
			],
			as: "members"
		}},

		// Calculate Sprint
		{ $lookup: {
			from: "feature",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$projectId", "@projectIds"] },
					{ $or: [
						{ $in: ["@milestoneIds", [null, undefined, "", false, []]] },
						{ $in: ["$milestoneId", "@milestoneIds"] },
					]},
					{ $or: [
						{ $in: ["@sprintIds", [null, undefined, "", false, []]] },
						{ $in: ["$sprintId", "@sprintIds"] },
					]},
				]}}},
				{ $addFields: {
					hasComplete: { $cond: [{$eq: ["$status", 6]}, 1, 0] }
				}},
				{ $project: {
					hasComplete: 1,
				}},
				{ $project: {
					_id: 0,
				}},
			],
			as: "features"
		}},

		// Calculate Sprint
		{ $lookup: {
			from: "sprint",
			pipeline: [
				{ $match: { $expr: { $and: "@matchSprint" }}},
				{ $addFields: {
					hasComplete: { $cond: [{$eq: ["$status", 6]}, 1, 0] }
				}},
				{ $project: {
					hasComplete: 1,
				}},
				{ $project: {
					_id: 0,
				}},
			],
			as: "sprints"
		}},

		{ $addFields: {
			feature: {
				total: { $size: "$features.hasComplete" },
				complete: { $sum: "$features.hasComplete" }
			},
			sprint: {
				total: { $size: "$sprints.hasComplete" },
				complete: { $sum: "$sprints.hasComplete" }
			},
		}},

		{ $addFields: {
			/* // hide logtime + estimate
			estimatedHour: { $sum: "$members.estimatedHour" },
			estimatedCount: { $sum: "$members.estimatedCount" },
			*/

			//workingHour: { $sum: "$members.workingHour" },
			//workingCount: { $sum: "$members.workingCount" },

			complete: { $multiply: [{$divide: ["$task.done", {$cond:[{$eq: ["$task.count", 0]}, 1, "$task.count"]}]}, 100]},

			logtime: {
				count: { $sum: "$logtimes.count" },
				hour: { $sum: "$logtimes.total" },
				approvedHour: { $sum: "$logtimes.approved" },
			}
		}},

		{ $project: {
			groups: 0,
			groupIds: 0,

			features: 0,
			sprints: 0,

			taskIds: 0,
			allTaskIds: 0,

			tasks: 0,
			taskCountPercent: 0,
			//taskIds: 0,
			//todos: 0,

			//"logtimes.total": 0,
			"logtimes.count": 0,
			"logtimes.approved": 0,

			/*
			"countTodo": 88,
			"countDoneTodo": 47,
			"taskCount": 36,
			"taskDone": 6,
			"logtimeCount": 2,
			"logtimeHour": 2,
			"estimatedHour": 400,
			"estimatedCount": 50,
			"workingHour": 30,
			"workingCount": 5,
			"complete": 53.40909090909091
			*/
		}},
	]],

	//`U.Date.calendarWorkingDay > totalCalendarWorkingDay:`,
	//`U.Date.calendarWorkingDay > totalWorkedDay: @startDate: @(new Date())`,

	/* // Hide logtime + estimate
	[`A.aggregateOne > allTaskCount: task`, [
		{ $match: {
			projectId: "@projectId"
		}},
		{ $addFields: {
			hasTaskDone: { "$cond": [{$eq:["$status", 6]}, 1, 0] },
			hasTaskDoing: { "$cond": [{$eq:["$status", 3]}, 1, 0] },
			hasTaskTesting: { "$cond": [{$eq:["$status", 4]}, 1, 0] },
			hasTaskReviewing: { "$cond": [{$eq:["$status", 5]}, 1, 0] },
			hasTaskReviewing: { "$cond": [{$in:["$status", [0,1,2]]}, 1, 0] },
		}},
		{ $group: {
			_id: null,
			totalTaskDone: { $sum: "$hasTaskDone" },
			totalTaskDoing: { $sum: "$hasTaskDoing" },
			totalTaskTesting: { $sum: "$hasTaskTesting" },
			totalTaskReviewing: { $sum: "$hasTaskReviewing" },
			totalTaskOther: { $sum: "$hasTaskOther" },
			totalTask: { $sum: 1 }
		}},
		{ $lookup: {
			from: "project",
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "@projectId"] }
				]}}},
				{ $project: {
					_id: 1,
					startDate: 1,
					dueDate: 1,
				}}
			],
			as: "project"
		}},
		{ $unwind: {
			path: "$project",
			preserveNullAndEmptyArrays: true
		}},

		{ $project: {
			_id: 0
		}}
	]],
	*/

	//`A.printObject:`,
	`U.Date.calendarWorkingDay(P.project) > totalCalendarWorkingDay: @startDate: @dueDate`,
	`U.Date.calendarWorkingDay(P.project) > totalWorkedDay: @startDate: @(new Date())`,
	//`A.printObject:`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var dbData = body.dbData || {};
		dbData = dbData[0] || dbData;

		var message = "";
		var color = "#367bf5";
		var statusMode = "blue";

		var allTaskCount = dbData.task.count || 0;

		var workedDay = body.totalWorkedDay || 0;
		var calendarDay = body.totalCalendarWorkingDay || 0;

		var completeDay = workedDay / (calendarDay||1);
		//var complete = dbData.complete; // Task complete

		var totalTask = dbData.task.count || 0;
		var totalTaskDone = dbData.task.done;
		// var totalTaskDoing = dbData.taskDoing;
		// var totalTaskTesting = dbData.taskTesting;
		// var totalTaskReviewing = dbData.taskReviewing;
		// var totalTaskOther = dbData.taskOther;

		var complete = totalTaskDone / (totalTask || 1);
		var delta = completeDay - complete;

		//console.log("dbData: ", {...dbData, risks:undefined, logtimes:undefined, members:undefined});
		dbData.summary = {
			// totalTask,
			// totalTaskDone,
			// totalTaskDoing,
			// totalTaskTesting,
			// totalTaskReviewing,
			// totalTaskOther,
			complete,
			completeDay,
			delta,
			totalWorkedDay: workedDay,
			totalCalendarWorkingDay: calendarDay,
		};

		//dbData.totalWorkedDay = workedDay;
		//dbData.totalCalendarWorkingDay = calendarDay;
		//dbData.completeDay = completeDay;
		//dbData.delta = delta;

		var project = Req.project || {};
		if((workedDay <= 0) || (calendarDay <= 0)) {
			// Not start project so dont has status
			message = "Will start soon!";
			color = "#0e69de";
			statusMode = "";

		} else if(project.hasCompleted || (complete > 0.975)) {
			message = "Yes, Trying to Target!";
			color = "#01ac58"; // green 27ae66
			statusMode = "blue";

		} else {
			if(delta > 0.35) {
				color = "#495b7c"; // black
				message = "Uhm, Fastest ASAP!";
				statusMode = "black";

			} else if(delta > 0.20) {
				// So late, lost control
				color = "#db4b36"; // orange
				message = "Oh, Keep Faster!";
				statusMode = "red";

			} else if(delta > 0.10) {
				// Late but in control
				color = "#e25d18"; // orange
				message = "Yah, Let's Trying More!";
				statusMode = "orange";

			} else if(delta > 0.05) {
				// Late but seem to be ok
				color = "#0e69de"; // blue // 3678f5
				message = "On Progress!";
				statusMode = "blue";

			} else if(delta > 0.02) {
				// OK status
				color = "#01ac58"; // // green 27ae66
				message = "On Good!";
				statusMode = "blue";

			} else {
				// So Excelent
				color = "#27ae66"; // Green
				message = "So Excellent!";
				statusMode = "green";
			}

			/*
			{ $eq: ["$hasCompleted", true] },
			"#27ae66", // green

			{ $cond: [
				{$gte: ["$delta", -5]},
				"#01ac58", // // green 27ae66
				{ $cond: [
					{$gte: ["$delta", -10]},
					"#0e69de", // blue // 3678f5
					{ $cond: [
						{$gte: ["$delta", -20]},
						"#e25d18", // orange
						{ $cond: [
							{$gte: ["$delta", -35]},
							"#db4b36", // orange
							"#495b7c", // black
						]}
					]}
				]}
			]}


			// var logtime = dbData.logtimeHour / 8;
			// var estimate = dbData.estimatedHour / 8;
			// var working = dbData.workingHour / 8;
			//
			//
			// var logDayRate = logtime / (workedDay||1); // -> user log / user time of calendar working
			// var logWorkRate = logtime / (working||1); // user log / user working hour
			// var workingRate = working / (workedDay||1); // user attitude of working time
			//
			// var workDayRate = workDayRate / (calendarDay||1);
			// var completeDiffRate = complete / (workDayRate||1);

			if(logDayRate <= 0 || logWorkRate <= 0 || workingRate <= 0) {
				// message += "First Starting, Let's Try!";
				message += "Let's Try!";
				color = "#66A606";

				dbData.statusMessage = message.trim();
				dbData.statusColor = color.trim();

				return dbData;
			}

			if(completeDiffRate > 0.2) {
				message += " Slow Progress!";
				color = "#ff0101";
			} else {
				message += " On Progress!";
				color = "#367bf5";
			}

			if(logDayRate < 0.8 || logWorkRate < 0.8 || workingRate < 0.8) {
				message += " Cut Spare Time!";
				color = "#b93ae8";

			} else {
				message += " Try More!";
			}

			*/
		}

		//console.log("Param: ", body);
		dbData.statusMessage = message.trim();
		dbData.statusColor = color.trim();
		dbData.statusMode = statusMode.trim();

		// Color for logtime
		(dbData.logtimes||[]).map(logtime => {
			//logtime.percent = Math.floor(logtime.percent);
			logtime.color = {
				"working"		: "#27ae60",
				"implementing"	: "#32a852",
				"correcting"	: "#bb6bd9",
				"reviewing"		: "#7b32a8",
				"designing"		: "#367bf5",
				"training"		: "#ed8936",
				"meeting"		: "#79d2de",
				"optimizing"	: "#6fcf97",
				"testing"		: "#fc6e56",
				"coding"		: "#046898",
				"planning"		: "#538ce0",
				"other"			: "#123456",
			}[logtime.type || "Other"];
		});

		// for Task Type
		// (dbData.taskTypes||[]).map(type => {
		// 	type.value = Math.floor(type.value);
		// });

		// Add test Data
		//dbData.sprint = { total: 139, complete: 35};
		//dbData.feature = { total: 125, complete: 68};

		return dbData;
	}],

	`A.responseObject(*): 200: @P.body`
], { useZip: true } ]);

module.exports = DashboardRoute;
