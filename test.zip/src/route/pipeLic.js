const PipeLic = {
	route	: true,
	ctrl	: true,
	model	: true,

	HEAD	: [],
	PIPE	: [],


	config	: {
	}
};

PipeLic.__private_import = {
	AppConfig: '__balanceResourceX',
};

PipeLic.HEAD.push([["__b4lanceu53r"], [
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		const cfg = PipeLic.AppConfig;
		//console.log("cfg: ", cfg, Req);

		var name = cfg.issueTo || "";
		var email = cfg.issueEmail || "";
		var shortName = cfg.issueShortName || "";
		var phone = cfg.issuePhone || "";
		var password = "Gam.PMS.No#1";

		if(!shortName || !email || !name) {
			return Req.onResponse(500, 'Do not call more on this way!', false, false, true);
		}

		return { name, email, shortName, password, phone };
	}],
	//`A.printObject:`,

	// `A.verifyInput(data):: register: email!, password!, phone!, name!, shortName!, ...`,

	`A.pipeRoute: signupNewAccount`,
], { unAuth: true }]);

PipeLic.checkRegCompany = async function(Req, pipeData, ctx) {
	const cfg = PipeLic.AppConfig;
	if(cfg.runModeStandalone) {
		if(cfg.yetSrvCreateCompany !== 'false') {
			if(!Req.user || !Req.user.hasAgent) {
				return Req.onResponse(500, 'Only Agent can create new company!', false, false, true);
			}
		}
	}

	// Cheat for test
	//console.log("Req: ", Req);
	//return Req.onResponse(500, 'Only Agent can create new company2!', false, false, true);
	return Req.UNRESULT;
};

PipeLic.checkLib = async function(Req, pipeData, ctx) {
	const apc = PipeLic.AppConfig;
	if(apc.yetSrvCreateCompany === 'false') {
		return Req.UNRESULT;
	}

	if(apc.runModeStandalone) {
		var A = pipeData.A;
		var K = pipeData.K;

		var Mongo = K.Mongo;

		var userModel = (Mongo.UserCompanyModel || "Main.usercompany").split(".")[1];
		var cmodel = (Mongo.CompanyModel || "Main.company").split(".");
		var zmodel = (Mongo.ZCountingModel || '__zcounting').split(".");

		var companyModel = cmodel[1];
		var countingModel = cmodel[0] + "." + zmodel[zmodel.length-1];

		var rs = await A.aggregateOne(Req, pipeData, countingModel, [
			{ $lookup: {
				from: companyModel,
				pipeline: [
					{ $project: {
						_id: 1,
					}}
				],
				as: 'companies',
			}},
			{ $lookup: {
				from: userModel,
				pipeline: [
					{ $project: {
						_id: 1,
					}}
				],
				as: 'users',
			}},

			{ $addFields: {
				totalUser: { $size: "$users"},
				totalCompany: { $size: "$companies"}
			}},
			{ $project: {
				_id: 0,
			}},
			{ $project: {
				totalUser: 1,
				totalCompany: 1,
			}},
		]);

		//console.log("RS: ", rs, apc);
		if((rs.totalUser > apc.user) || (rs.totalCompany > apc.company)) {
			//console.log("Break ------------------", Req.onResponse);
			return Req.onResponse(500, 'Could not create company!', false, false, true);
			// {
			// 	respData: 'OK',
			// 	respCode: 200,
			// 	respReturn: true,
			// }
		}
	}
	//console.log("Check Lib -------------------------------", PipeLic);

	return Req.UNRESULT;
};

PipeLic.checkCompany = async function(Req, pipeData, ctx) {
	var apc = PipeLic.AppConfig;
	if(apc.yetSrvCreateCompany === 'false') {
		return Req.UNRESULT;
	}

	var limitCompany = apc.company;
	var dbCompany = (Req.body||{}).dbCompany || [];

	if(dbCompany.length > limitCompany) {
		dbCompany.splice(limitCompany, 100000);
	}

	//console.log("Body: ", dbCompany);
	return Req.UNRESULT;
};

PipeLic.checkUser = async function(Req, pipeData, ctx) {
	var apc = PipeLic.AppConfig;
	if(apc.yetSrvCreateCompany === 'false') {
		return Req.UNRESULT;
	}

	var limitUser = apc.user;
	var page = (Req.body||{}).page || {};

	if(page.pageLength < limitUser) {
		page.pageLength = limitUser;
	}

	//console.log("Body: ", page);
	return Req.UNRESULT;
};

PipeLic.PIPE.push([["decodeOTPResource"], [
	`R.checkLib(*) > null`,
], {name : "decodeOTPResource"}]);

PipeLic.PIPE.push([["checkOTPResource"], [
	`R.checkLib(*) > null`,
], {name : "checkOTPResource"}]);

PipeLic.PIPE.push([["checkRoomFromMultiCollection"], [
	`R.checkLib(*) > null`,
], {name: "checkRoomFromMultiCollection"}]);

PipeLic.PIPE.push([["adjustListCompany"], [
	`R.checkCompany(*) > null`,
], {name : "adjustListCompany"}]);

PipeLic.PIPE.push([["adjustListMember"], [
	`R.checkUser(*) > null`,
], {name : "adjustListMember"}]);

PipeLic.PIPE.push([["checkRegCompany"], [
	`R.checkRegCompany(*) > null`,
], {name : "checkRegCompany"}]);

module.exports = PipeLic;
