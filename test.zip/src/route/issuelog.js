const IssueLogRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],

    config	: {
		checkKeyFeature	: "project.feature.issuelog",
        checkMIFs		: ["project", "issuelog"],
		imProject		: true,
    }
};

IssueLogRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: issuelog.view, issuelog.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	//`A.printObject:`,
    `A.verifyInput:: issuelog: projectId!, name!, ...`,

    `A.insertOne: issuelog`,
    `A.populate: label, labelIds, _id, label, +, name, name2, color
               : milestone, milestoneId, _id, milestone, +, name`,

	`A.pipeRoute: issuelog: { type: "create" }`,
    `A.refactorOutput:: modifiedAt-, modifierId-, creatorId-, ...`
]]);

IssueLogRoute.POST.push([["/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: issuelog.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
        const name = (pipeData.name || pipeData.search) || (pipeData.text || pipeData.content);

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		var memberIds = pipeData.memberId || pipeData.memberIds;
		var projectIds = pipeData.projectId || pipeData.projectIds;
		var milestoneIds = pipeData.milestoneId || pipeData.milestoneIds;
		var sprintIds = pipeData.sprintId || pipeData.sprintIds;
		var featureIds = pipeData.featureId || pipeData.featureIds;
		var labelIds = pipeData.labelId || pipeData.labelIds;

		var ops = {};
		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}
			if(projectIds.length > 0) {
				ops.projectId = { $in: projectIds };
			}
		}

		if(featureIds) {
			if(!Array.isArray(featureIds)) {
				featureIds = [featureIds];
			}
			if(featureIds.length > 0) {
				ops.featureId = { $in: featureIds };
			}
		}

		if(sprintIds) {
			if(!Array.isArray(sprintIds)) {
				sprintIds = [sprintIds];
			}
			if(sprintIds.length > 0) {
				ops.sprintId = { $in: sprintIds };
			}
		}
		
		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
			if(milestoneIds.length > 0) {
				ops.milestoneId = { $in: milestoneIds };
			}
		}

		if(memberIds) {
			if(!Array.isArray(memberIds)) {
				memberIds = [memberIds];
			}
			if(memberIds.length > 0) {
				ops.memberIds = { $elemMatch: { $in: memberIds } };
			}
		}

		if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}
			if(labelIds.length > 0) {
				ops.labelIds = { $elemMatch: { $in: labelIds } };
			}
		}

        if (name) {
            var nameRegex = Req.func.getASCIISearch(name, "gmi");
            ops["$or"] = [
				{ name : nameRegex },
				{ number: (name-0) || -1 },
			];
        }

        if(fromDate && toDate) {
            ops["$and"] = [
				{ date: { "$gte" : new Date(fromDate) }},
				{ date: { "$lte" : new Date(toDate) }},
			];
        }

        pipeData.ops = ops;
        return pipeData;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: issuelog`, [
		{ $match: "@ops"},
		{ $sort: {
			date: -1,
			createdAt: -1,
		}},

		{ $getTotalLength: "@page" },

		{ $populateFilter: ["label", "labelIds$:_id", "labels", undefined, 1, "_id", "name", "name2", "color"]},
		{ $populateFilter: ["user", "memberIds$:_id", "members", undefined, 1, "_id", "name", "avt", "userId"]},
		//{ $populateFilter: ["milestone", "milestoneId:_id", "milestone", true, 1, "_id", "number", "name", "name2", "color"]},

		{ $project: {
			_id: 1,
			number: 1,

			name: 1,
			name2: 1,
	        descr: 1,
			priority: 1,

			date: 1,
			labelIds: 1,
			labels: 1,

	        memberIds: 1,
			members: 1,
			//milestone: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "issuelogs"]},
	]]
], { useZip: true }]);

IssueLogRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: issuelog.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

	[`A.aggregateOne(*): issuelog`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}},

		{ $populateFilter: ["label", "labelIds$:_id", "labels", undefined, 1, "_id", "name", "name2", "color"]},
		{ $populateFilter: ["user", "memberIds$:_id", "members", undefined, 1, "_id", "name", "avt", "userId"]},
		{ $populateFilter: ["milestone", "milestoneId:_id", "milestone", true, 1, "_id", "number", "name", "name2", "color"]},
		{ $populateFilter: ["sprint", "sprintId:_id", "sprint", true, 1, "_id", "number", "name", "name2", "color"]},
		{ $populateFilter: ["feature", "featureId:_id", "feature", true, 1, "_id", "number", "name", "name2", "color"]},

		{ $project: {
			modifierId: 0,
			creatorId: 0,
		}}
	]],

    // `<F1>A.findOne(P.route): issuelog: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
    // `A.populate: label, labelIds, _id, label, +, name, name2, color
    //            : milestone, milestoneId, _id, milestone, +, name`,
    // "A.refactorOutput:: modifierId-, creatorId-, ...",
]]);

IssueLogRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: issuelog.view, issuelog.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: issuelog: status-, projectId-, number-, ...`,
    `A.refactorOutput:: number-, ...`,

    //`A.findOne(*) > issuelogDb: issuelog: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	[`A.aggregateOne(*) > issuelogDb: issuelog:`, [
		{ $match: {
			_id: "@P.route._id",
			projectId: "@P.project._id"
		}},
		
		{ $populateFilter: ["user", "memberIds$:_id", "members", undefined, 1, "email"] },
		{ $populateFilter: ["user", "creatorId:_id", "creators", undefined, 1, "email", "name", "name2"] },
		{ $populateFilter: ["project", "projectId:_id", "project", true, 1, "name", "name2", "shortName"] },
		{ $addFields: {
			//members: "$members.email",
			//creator: "$creator.email"
			userEmails: { $setUnion: [ {$ifNull: ["$members.email", []]}, {$ifNull: ["$creators.email", []]} ] },
			creator: { $ifNull: [{$first: "$creators"}, {}]}
		}},
		{ $project: {
			_id: 1,
			userEmails: 1,
			creator: 1,
			project: 1,
			number: 1,
		}}
	]],

	`A.assertKeyExisted(issuelogDb):: _id: Invalid request!`,

    `A.updateById(*) > temp: issuelog: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

    // `A.populate: label, labelIds, _id, label, +, name, name2, color
    //            : milestone, milestoneId, _id, milestone, +, name`,

	// `A.pipeRoute: issuelog: { type: "update" }`,
	// "A.findMany > listEmail: user: @P.body.memberIds",
	//`A.populate > P.tmp1: user, creatorId, _id, creator, +, _id, name, name2, userId, avt`,
	

	`A.sendMail(*) > tmpMail: {
		"to" 		: "@P.body.issuelogDb.userEmails",
		"subject" 	: "[IssueLog] Your were mention in IssueLog",
		"view" 		: "issueLogView",
		"data" 		: "@P.body.issuelogDb"
	}`,

    // `A.refactorOutput:: modifierId-, creatorId-, ...`,
	`A.responseObject: 200: Update successfully!`
]]);

IssueLogRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: issuelog.view, issuelog.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.findOne(*) > issuelogDb: issuelog: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	`A.assertKeyExisted(issuelogDb):: _id: Invalid request!`,

    `A.deleteById(*): issuelog: {_id: "@P.route._id", projectId: "@P.project._id"}`,

	`A.pipeRoute: issuelog: { type: "delete" }`,
    `A.responseObject: 200: Delete successfully!`
]]);

module.exports = IssueLogRoute;
