const AnnouncementRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkMIFs		: ["announcement"],
		roleUserIdKey	: "userId"
	}
};


AnnouncementRoute.POST.push([[""], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	"A.verifyInput:: announcement: title!, title2, fromId, content, announcedDate, viewerIds-, number-, ...",
	"A.insertOne: announcement",
	`A.populate: department, fromId, _id, from, +, name, name2, descr
			   : user, creatorId,_id, creator, +, name, name2, userId, avt`,
	`A.trimObject`,
	`A.refactorOutput:: modifiedAt-, modifierId-,...`
]]);

// AnnouncementRoute.POST.push([[":_id/attach"], [
// 	`A.insertSubItem(*) > attachId: announcement: @P.route._id: attachIds: @P.body.attachIds`,
// 	`A.populate: attach, attachId, _id, attach, +, name, name2, mimeType, length `,
//     `A.responseObject: 200: @attach`
// ]]);

// AnnouncementRoute.PUT.push([[":_id/attach"], [
//     `A.removeSubItem(*): announcement: @P.route._id: attachIds: @P.body.attachIds[0]`,
//     `A.responseObject: 200: Remove attach successfully!`
// ]]);

AnnouncementRoute.POST.push([[":_id/user"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

	`A.insertSubItem(*) > userId: announcement: @P.route._id: userIds: @P.body.userIds`,
	`A.populate: user, userId, _id, user, +, name, name2, avt, userId `,
    `A.responseObject: 200: @user`
]]);

AnnouncementRoute.PUT.push([[":_id/user"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.removeSubItem(*): announcement: @P.route._id: userIds: @P.body.userIds[0]`,
    `A.responseObject: 200: Remove user successfully!`
]]);

AnnouncementRoute.POST.push([[":_id/department"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

	`A.insertSubItem(*) > userId: announcement: @P.route._id: departmentIds: @P.body.departmentIds`,
	`A.populate: department, departmentIds, _id, department, +, name, name2, descr`,
    `A.responseObject: 200: @department`
]]);

AnnouncementRoute.PUT.push([[":_id/department"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.removeSubItem(*): announcement: @P.route._id: departmentIds: @P.body.departmentIds[0]`,
    `A.responseObject: 200: Remove department successfully!`
]]);

AnnouncementRoute.POST.push([[":_id/project"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

	`A.insertSubItem(*) > projectId: announcement: @P.route._id: projectIds: @P.body.projectIds`,
	`A.populate: project, projectId, _id, project, +, name`,
    `A.responseObject: 200: @project`
]]);

AnnouncementRoute.PUT.push([[":_id/project"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.removeSubItem(*): announcement: @P.route._id: projectIds: @P.body.projectIds[0]`,
    `A.responseObject: 200: Remove project successfully!`
]]);

AnnouncementRoute.POST.push([[":_id/team"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.insertSubItem(*) > teamId: announcement: @P.route._id: teamIds: @P.body.teamIds`,
	`A.populate: team, teamId, _id, team, +, name`,
	`A.responseObject: 200: @team`
]]);

AnnouncementRoute.PUT.push([[":_id/team"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.removeSubItem(*): announcement: @P.route._id: teamIds: @P.body.teamIds[0]`,
    `A.responseObject: 200: Remove team successfully!`
]]);

AnnouncementRoute.POST.push([[":_id/seniority"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.insertSubItem(*) > seniorityId: announcement: @P.route._id: seniorityIds: @P.body.seniorityIds`,
	`A.populate: seniority, seniorityId, _id, seniority, +, title`,
	`A.responseObject: 200: @seniority`
]]);

AnnouncementRoute.PUT.push([[":_id/seniority"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	`A.pipeRoute: checkUpdateAnnouncement`,

    `A.removeSubItem(*): announcement: @P.route._id: seniorityIds: @P.body.seniorityIds[0]`,
    `A.responseObject: 200: Remove seniority successfully!`
]]);

AnnouncementRoute.GET.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view`,
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	[`A.aggregateOne(*): announcement`, [
		{ $match: { $or: [
			{ _id: "@P.route._id" },
			{ number: "@P.route._id" },
		]}},

		{ $populateFilter: ["department", "departmentIds$:_id", "departments", undefined, 1, "_id", "name", "name2", "avt",  "members"] },
		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "_id", "name", "name2", "avt", "members"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "_id", "name", "name2", "avt", "members"]},
		{ $populateFilter: ["seniority", "seniorityIds$:_id", "seniority", undefined, 1, "_id", "name", "name2", "title"]},

		{ $populateFilter: ["hrcontract", "seniorityIds$:overview.seniorityId", "hrcontract", undefined, 1, "userId"]},

		{ $lookup: {
			from: "user",
			let: { sendToAll: "$sendToAll" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$$sendToAll", true] },
				]}}},
				{ $match: {
					hasDeleted: { $nin: [true] }
				}},
				{ $project: {
					_id: 1
				}}
			],
			as: "allUsers"
		}},

		{ $flatArray: {
			listMemberDepartments: "$departments.members",
			listMemberProjects: "$projects.members.user",
			listMemberTeams: "$teams.members",
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$allUsers", "$userIds", "$hrcontract.userId", "$listMemberDepartments", "$listMemberProjects", "$listMemberTeams" ]},
		}},

		// Filter user is in this list
		{ $match: { $expr: { $or: [
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },
			{ $and: [
				{ $or: [
					{ $eq: ["$sendToAll", true] },
					{ $in: ["@P.user._id", { $ifNull: ["$listMembers", []] } ] },
				]},
				{ $in: ["$status", [2]] },
			]},
			{ $and: [
				{ $eq: ["@P.rolecompany.permit.announcement.approve", true] },
				{ $in: ["@P.user._id", { $ifNull: ["$approverIds", [] ]} ]},
				{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},
		]}}},

		{ $addFields: {
			userCount: { $size: "$listMembers" },
			viewCount: { $size: "$viewerIds" },
			showView: { $cond:[{
				$and: [
					{ $or: [
						{ $eq: ["$sendToAll", true] },
						{ $in: ["@P.user._id", "$listMembers"] },
					]},
					{ $not: [{$in: ["@P.user._id", "$viewerIds"]}] },
					{ $in: ["$status", [2] ] }
				]
			}, true, false]},
		}},

		{ $populateFilter: ["user", "userIds$:_id", "users", undefined, 1, "_id", "name", "userId", "avt"] },
		{ $populateFilter: ["department", "fromId:_id", "from", true, 1, "_id", "name", "avt"] },
		{ $populateFilter: ["user", "approverId:_id", "approvedBy", undefined, 1, "_id", "name", "userId","avt"]},
		{ $populateFilter: ["user", "viewerIds$:_id", "viewers", undefined, 1, "_id", "name", "userId","avt"]},

		{ $project: {
			createdAt: 0,
			//modifiedAt: 0,
			listMembers: 0,
			allUsers: 0,
			hrcontract: 0,
			"departments.members": 0,
			"projects.members": 0,
			"teams.members": 0,
		}}
	]],

	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;
		if(body && body._id) {
			return body;
		}

		return {
			respCode: 500,
			respData: "Item Not Found!",
			respReturn: true,
		};
	}],

	//`<F1>A.findOne(P.route): announcement: {$or: [{_id: "@_id"}, {number: "@_id"}]}`,
	// `A.populate: user, userIds, _id, users, +, name, name2, avt, userId
	// 		   : department, departmentIds, _id, departments, +, name, name2, descr
	// 		   : department, fromId, _id, from, +, name, name2, descr
	// 		   : project, projectIds, _id, projects, +, name, name2, avt, userId
	// 		   : team, teamIds, _id, team, +, name
	// 		   : seniority, seniorityIds, _id, seniority, +, title, descr
	// 		   : user, approverId, _id, approvedBy, +, name, name2, avt, userId,
	// 		   : user, approverIds, _id, approvers, +, name, name2, avt, userId,
	// 		   : user, viewerIds, _id, viewers, +, name, name2, avt, userId`,
	// 		   // attach, attachIds, _id, attachs, +, name, name2, mimeType, length
	//
	// `A.refactorOutput:: createdAt-, modifiedAt-, ...`
	//  {F1: { IgnoreSanitized: true }}
]]);

AnnouncementRoute.PUT.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput > reqBody:: announcement: title, content, fromId, sendToAll, number-, status-, ...`,
	`A.pipeRoute: checkUpdateAnnouncement`,
	// `A.findOne > announcementDb: announcement`,
	`A.updateOne(reqBody): announcement`,
	`A.responseObject: 200: Update announcement successfully!`

	// `A.sendMail(*) > tmpMail: {
	// 	"to" 		: "@P.body.db2.members",
	// 	"subject" 	: "[Meeting] You were being on a meeting #{{P.body.db2.number}}",
	// 	"view" 		: "meetingView",
	// 	"data" 		: "@P.body.db2"
	// }`,
]]);

// It handled by api approved
// AnnouncementRoute.PUT.push([[":_id/status"], [
// 	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.modify`,
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
// 	`A.verifyInput > reqBody:: announcement: status!`,
// 	[`A.jsScript::`, (Req, pipeData, ctx) => {
// 		if(pipeData.status == 2) {
// 			pipeData.approvedId = Req.user._id;
// 		}
// 		return pipeData;
// 	}],
// 	`A.updateOne: announcement`,
// 	`A.responseObject: 200: Update status successfully!`
// ]]);

AnnouncementRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view, announcement.delete`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

	//`A.findOne > announcementDb: announcement`,
	[`A.aggregateOne(*) > announcementDb: announcement`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.announcement.delete", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(announcementDb):: _id!: verify.idType`,

	[`A.jsScript::`,(Req, pipeData, ctx) => {
		if(pipeData.announcementDb && pipeData.announcementDb.status == 2) {
			return {"respData": "E-02", "respReturn": true , "respCode" : 500};
		}
		return pipeData;
	}],

	`A.deleteOne: announcement`,
	`A.pipeRoute: deleteAnnouncement`,
	`A.responseObject: 200: Delete Announcement successfully!`
]]);

AnnouncementRoute.POST.push([["/s"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var ops = {};

		const fromDate = pipeData.fromDate || pipeData.startDate;
		const toDate = pipeData.toDate || pipeData.endDate;

		if(fromDate && toDate) {
			ops["$and"]= [
				{ announcedDate: {"$gte" : new Date(fromDate)} },
				{ announcedDate: {"$lte" : new Date(toDate)} }
			];
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.status = { $in: status };
			}
		}

		const title = pipeData.title || pipeData.search;
		if(title) {
			var nameReg = Req.func.getASCIISearch(title, "gmi");
			ops["$or"] = [
				{ title: nameReg },
				{ title2: nameReg },
				{ content: nameReg },
				{ number: (title-0) || -1 }
			];
		}

		pipeData.ops = ops;
		return pipeData;
	}],

	`A.getPaginate > page`,

	[`A.aggregateOne(*): announcement`, [
		{ $match: "@P.body.ops" },
		{ $sort: {
			announcedDate: -1,
			createdAt: -1,
		}},

		{ $populateFilter: ["department", "departmentIds$:_id", "departments", undefined, 1, "_id", "name", "avt",  "members"] },
		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "_id", "name", "avt", "members"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "_id", "name", "avt", "members"]},
		{ $populateFilter: ["seniority", "seniorityIds$:_id", "seniority", undefined, 1, "_id", "name", "title"]},

		{ $populateFilter: ["hrcontract", "seniorityIds$:overview.seniorityId", "hrcontract", undefined, 1, "userId"]},

		{ $lookup: {
			from: "user",
			let: { sendToAll: "$sendToAll" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$$sendToAll", true] },
				]}}},
				{ $match: {
					hasDeleted: { $nin: [true] }
				}},
				{ $project: {
					_id: 1
				}}
			],
			as: "allUsers"
		}},

		{ $flatArray: {
			listMemberDepartments: "$departments.members",
			listMemberProjects: "$projects.members.user",
			listMemberTeams: "$teams.members",
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$allUsers", "$userIds", "$hrcontract.userId", "$listMemberDepartments", "$listMemberProjects", "$listMemberTeams" ]},
		}},

		// Filter user is in this list
		{ $match: { $expr: { $or: [
			{ $eq: ["@P.user._id", "$creatorId"] },
			{ $eq: ["@P.user.hasAgent", true] },
			{ $eq: ["@P.user.hasAdmin", true] },
			{ $and: [
				{ $or: [
					{ $eq: ["$sendToAll", true] },
					{ $in: ["@P.user._id", { $ifNull: ["$listMembers", []] } ] },
				]},
				{ $in: ["$status", [2]] },
			]},
			{ $and: [
				{ $eq: ["@P.rolecompany.permit.announcement.approve", true] },
				{ $in: ["@P.user._id", { $ifNull: ["$approverIds", [] ]} ]},
				{ $eq: ["$status", [2, 3, 4]] }, // approved, rejected, submitted
			]},
			// { $eq: ["@P.user._id", "$creatorId"] },
			// { $eq: ["$sendToAll", true] },
			// { $eq: ["@P.user.hasAgent", true] },
			// { $eq: ["@P.user.hasAdmin", true] },
			// { $in: ["@P.user._id", "$listMembers"] },
		]}}},

		{ $addFields: {
			userCount: { $size: "$listMembers" },
			viewCount: { $size: "$viewerIds" },
		}},

		// Modifier
		{ $populate: ["user", "approverId", "_id", "approvedBy", true] },
		{ $populate: ["department", "fromId", "_id", "from", true] },

		{ $project: {
			_id: 1,
			number: 1,

	        title: 1,
			title2: 1,
	        content: 1,

			sendToAll: 1,
	        announcedDate: 1,
			modifiedAt: 1,
			creatorId: 1,
			approverIds: 1,

			rejectedMessage: 1,
	        status: 1,

			viewCount: 1,
			userCount: 1,

			totalLength: 1,

			"from._id": 1,
			"from.name": 1,
			"from.name2": 1,
			"from.avt": 1,
			"from.descr": 1,

			"approvedBy._id": 1,
			"approvedBy.name": 1,
			"approvedBy.name2": 1,
			"approvedBy.avt": 1,
			"approvedBy.userId": 1,
		}},

		{ $getTotalLength: ["@P.body.page", "totalLength"]},
		{ $groupTotalLength: ["@P.body.page", "totalLength", "announcements"]},
	]]
	// `A.findMany: announcement: @ops`,
	// `A.populate: attach, attachIds, _id, attachs, +, name, name2, mimeType, length
	// 		   : user, userIds, _id, users, +, name, name2, avt, userId
	// 		   : user, creatorId, _id, creator, +, name, name2, avt, userId
	// 		   : user, modifierId, _id, modifier, +, name, name2, avt, userId
	// 		   : department, departmentIds, _id, departments, +, name, name2, descr
	// 		   : department, fromId, _id, from, +, name, name2, descr
	// 		   : project, projectIds, _id, projects, +, name, name2, avt, userId
	// 		   : team, teamIds, _id, team, +, name
	// 		   : seniority, seniorityIds, _id, seniority, +, title, descr
	// 		   : user, approvedId, _id, approved, +, name, name2, avt, userId`,
	// `A.refactorOutput:: createdAt-, modifiedAt-, ...`
], {useZip: true}]);

AnnouncementRoute.POST.push([[":_id/confirm/view"], [
	`A.checkRole(*): Main.company: @P.company._id: rolecompany: announcement.view`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	[`A.aggregateOne(*) > dbBody: announcement`, [
		{ $match: {
			_id: "@P.route._id"
		}},

		{ $populateFilter: ["department", "departmentIds$:_id", "departments", undefined, 1, "_id", "name", "avt",  "members"] },
		{ $populateFilter: ["project", "projectIds$:_id", "projects", undefined, 1, "_id", "name", "avt", "members"]},
		{ $populateFilter: ["team", "teamIds$:_id", "teams", undefined, 1, "_id", "name", "avt", "members"]},
		{ $populateFilter: ["seniority", "seniorityIds$:_id", "seniority", undefined, 1, "_id", "name", "title"]},
		{ $populateFilter: ["hrcontract", "seniorityIds$:overview.seniorityId", "hrcontract", undefined, 1, "userId"]},

		{ $lookup: {
			from: "user",
			let: { sendToAll: "$sendToAll" },
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$$sendToAll", true] },
				]}}},
				{ $match: {
					hasDeleted: { $nin: [true] }
				}},
				{ $project: {
					_id: 1
				}}
			],
			as: "allUsers"
		}},

		{ $flatArray: {
			listMemberDepartments: "$departments.members",
			listMemberProjects: "$projects.members.user",
			listMemberTeams: "$teams.members",
		}},

		{ $addFields: {
			listMembers: { $setUnion: ["$allUsers", "$userIds", "$hrcontract.userId", "$listMemberDepartments", "$listMemberProjects", "$listMemberTeams" ]},
		}},

		{ $match: { $expr: { $or: [
			{ $eq: ["$sendToAll", true] },
			{ $in: ["@P.user._id", "$listMembers"]}
		]}}},

		{ $project: {
			_id: 1,
			viewerIds: 1,
		}}
	]],

	`A.assertObject:: and: (
		dbBody type object,
		dbBody.viewerIds type array
	) : {
		respReturn: true,
		respCode: 500,
		respData: "You were not permit to reply this meeting"
	}`,

	//`A.findById > dbBody: announcement`,
	`A.modifyObject(*):: (
		P.body.dbBody.viewerIds = +P.user._id,
		P.body.dbBody.viewerIds = ?unify,
	)`,

    `A.updateById(dbBody) > tmpBody: announcement`,
	`A.responseObject: 200: Thank you, you confirmed viewing this announcement!`,
]]);

AnnouncementRoute.PIPE.push([["checkUpdateAnnouncement"], [
	[`A.aggregateOne(*) > announcementDb: announcement`, [
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$_id", "@P.route._id"] },
			]},
			{ $or: [
				{ $or: [
					{ $eq: ["@P.user.hasAgent", true] },
					{ $eq: ["@P.user.hasAdmin", true] },
				]},
				{ $or: [
					{ $ne: ["$status", 2]}, // not approved
					{ $eq: ["@P.user._id", "$creatorId"] },
					{ $eq: ["@P.rolecompany.permit.announcement.modify", true] },
				]}
			]},
		]}}},
	]],
	`A.verifyKObject(announcementDb):: _id!: verify.idType`,
], {name: "checkUpdateAnnouncement"}]);

module.exports = AnnouncementRoute;
