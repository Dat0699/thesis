const TutorialRoute = {
    route	: true,
    ctrl	: false,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
	PIPE	: [],

    config	: {
        //checkMIFs	: ["project"],
		//imCompany: true,
    }
};

TutorialRoute.POST.push([[""], [
	`A.pipeRoute: isGitGamWebSite`,

    `A.verifyInput:: Public.tutorial: type!, name!, parentId, content, language`,
    `A.insertOne: Public.tutorial`,
]]);

TutorialRoute.POST.push([["/s"], [
	`A.pipeRoute: tutorialList`,
	`A.responseObject(*): 200: @P.body`,
], {
	useZip: true,
	imCompany: false,
	unAuth: true,
}]);

TutorialRoute.POST.push([["/edit/s"], [
	`A.pipeRoute: tutorialList`,
	`A.responseObject(*): 200: @P.body`,
], {
	useZip: true,
}]);

TutorialRoute.PIPE.push([["tutorialList"], [
	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var user = Req.user || {};

		var search = (body.search || body.text) || (body.name || "");

		body.search = Req.func.getASCIISearch(search, "gmi");
		body.isGitGam = ((Req.company||{}).shortName||"").toLowerCase() == "gitgam";
		body.hasAdmin = user.hasAdmin || user.hasAgent;
		body.hasGitGamAdmin = body.isGitGam && body.hasAdmin;
		body.hasTrim = !!search;

		return Req.UNRESULT;
	}],

    [`A.aggregate > data: Public.tutorial`, [
		{ $addFields: {
			parentId: { $ifNull: ["$parentId", null] }
		}},
		{ $match: { $expr: { $and: [
			{ $or: [
				{ $eq: ["$isPublic", true] },
				{ $eq: ["@hasGitGamAdmin", true]},
				//{ language: "@language" },
			]},
			//{ $in: ["$parentId", [undefined, null, "", 0]] },
			{ $or: [
				{ $eq: ["$type", "folder"]},
				{ $regexMatch: { input: "$name", regex: "@search" }},
				{ $regexMatch: { input: "$content", regex: "@search" }},
			]}
		]}}},

		// Get Level 2
		// { $lookup: {
		// 	from: "tutorial",
		// 	let: { parentId1: "$_id" },
		// 	pipeline: [
		// 		{ $match: { $expr: { $and: [
		// 			{ $or: [
		// 				{ $eq: ["$isPublic", true] },
		// 				{ $eq: ["@hasGitGamAdmin", true]},
		// 				//{ language: "@language" },
		// 			]},
		// 			{ $eq: ["$parentId", "$$parentId1"]},
		// 		]}}},
		//
		// 		// Get Level 3
		// 		{ $lookup: {
		// 			from: "tutorial",
		// 			let: { parentId2: "$_id" },
		// 			pipeline: [
		// 				{ $match: { $expr: { $and: [
		// 					{ $or: [
		// 						{ $eq: ["$isPublic", true] },
		// 						{ $eq: ["@hasGitGamAdmin", true]},
		// 						//{ language: "@language" },
		// 					]},
		// 					{ $eq: ["$parentId", "$$parentId2"]},
		// 				]}}},
		// 				{ $match: { $or: [
		// 					{ name: "@search" },
		// 					{ content: "@search" }
		// 				]}},
		//
		// 				{ $project: {
		// 					_id: 1,
		// 					parentId: 1,
		// 					name: 1,
		// 					name2: 1,
		// 					number: 1,
		// 					//content: 1,
		// 					//date: 1,
		// 					type: 1,
		// 					isPublic: 1,
		// 				}},
		// 				{ $sort: {
		// 					colIndex: 1,
		// 					name$: 1
		// 				}}
		// 			],
		// 			as: "listItem"
		// 		}},
		//
		// 		// Filter empty ----------------
		// 		{ $addFields: {
		// 			totalItem: { $size: "$listItem" }
		// 		}},
		// 		{ $match: { $or: [
		// 			{ totalItem: { $gt: 0 } },
		// 			{ name: "@search" },
		// 			{ content: "@search" }
		// 		]}},
		//
		// 		{ $addFields: {
		// 			listItem: { $cond: [{$eq: ["$type", "item"]}, undefined, "$listItem"]},
		// 		}},
		//
		// 		{ $project: {
		// 			_id: 1,
		// 			parentId: 1,
		// 			name: 1,
		// 			name2: 1,
		// 			number: 1,
		// 			colIndex: 1,
		//
		// 			//content: 1,
		// 			//date: 1,
		// 			type: 1,
		// 			listItem: 1,
		// 			isPublic: 1,
		// 		}},
		// 		{ $sort: {
		// 			colIndex: 1,
		// 			name$: 1
		// 		}}
		// 	],
		// 	as: "listItem"
		// }},

		// Filter empty ----------------
		// { $addFields: {
		// 	totalItem: { $size: "$listItem" }
		// }},
		// { $match: { $or: [
		// 	{ totalItem: { $gt: 0 } },
		// 	{ name: "@search" },
		// 	{ content: "@search" }
		// ]}},
		//
		// { $addFields: {
		// 	listItem: { $cond: [{$eq: ["$type", "item"]}, undefined, "$listItem"]},
		// }},

		{ $sort: {
			colIndex: 1,
			name$: 1,
			name2$: 1,
		}},
		{ $project: {
			_id: 1,
			parentId: 1,
			name: 1,
			name2: 1,
			number: 1,
			colIndex: 1,
			//content: 1,
			//date: 1,
			type: 1,
			//listItem: 1,
			isPublic: 1,
		}},
		{ $sort: {
			colIndex: 1,
			name$: 1
		}}
	]],

	`A.parentGroupObject > data: @data: parentId: listItem: type`,
	`A.trimObjectDeeply: @hasTrim: @data: listItem: type: folder`,

], { name: "tutorialList" }]);


TutorialRoute.GET.push([["/:_id"], [
	`A.pipeRoute: tutorialDetail`,
	`A.responseObject(*): 200: @P.body`,
], {
	imCompany: false,
	unAuth: true,
}]);

TutorialRoute.GET.push([["/edit/:_id"], [
	`A.pipeRoute: tutorialDetail`,
	`A.responseObject(*): 200: @P.body`,
], {
	useZip: true,
}]);

TutorialRoute.PIPE.push([["tutorialDetail"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	[`A.jsScript(*)`, (Req, pipeData, ctx) => {
		var body = Req.body || {};
		var user = Req.user || {};

		body.isGitGam = ((Req.company||{}).shortName||"").toLowerCase() == "gitgam";
		body.hasAdmin = user.hasAdmin || user.hasAgent;
		body.hasGitGamAdmin = body.isGitGam && body.hasAdmin;

		var _id = Req.route._id;
		body.ops = [{ $or: [
			{ $eq: ["$_id", _id ] },
			{ $eq: ["$number", _id - 0 ] },
		] }];

		if(!body.hasGitGamAdmin) {
			body.ops.push({
				$eq: ["$isPublic", true]
			});
		}

		return body;
	}],

    [`A.aggregateOne: Public.tutorial`, [
		{ $match: { $expr: { $and: "@ops" }}},
		{ $addFields: {
			creator: {
				_id: "$creatorId",
				userId: "$userRef",
				name: "$userName",
				avt: { $ifNull: ["$userAvt", 100] }
			}
		}},
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			date: 1,
			number: 1,
			content: 1,
			type: 1,
			userName: 1,
			parentId: 1,
			createdAt: 1,
			creator: 1,
			isPublic: 1,
		}}
	]]
], { name: "tutorialDetail" }]);

TutorialRoute.PUT.push([[":_id/move/position"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: Public.tutorial: colIndex, parentId!`,

	`A.updateById(*) > tutorialDb : Public.tutorial: { _id: "@P.route._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update tutorial successfully!`
]]);

TutorialRoute.PUT.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: Public.tutorial: number-, ...`,
	//`A.printObject:`,
    `A.updateById(*): Public.tutorial: {_id: "@P.route._id"}: @P.body`,
    `A.responseObject: 200: Update successfully!`,
]]);

TutorialRoute.DELETE.push([[":_id"], [
	`A.pipeRoute: isGitGamWebSite`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `<F1>A.deleteById(*): Public.tutorial: {$or: [{_id: "@P.route._id"}, {parentId: "@P.route._id"}]}`,
], {F1: {IgnoreSanitized: true}}]);

module.exports = TutorialRoute;
