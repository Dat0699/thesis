const HrcontractRoute = {
	route	: true,
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
	}
};

HrcontractRoute.POST.push([["/s"], [
	`A.findMany: hrcontract`,
	`A.populate: user, userId, _id, user, +, name, name2, userId, avt`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		for (let i=0; pipeData.length > i; i++) {
			pipeData[i].missionLength = pipeData[i].missions.length;
			pipeData[i].missionDone = 0;
			for(let j= 0; j < pipeData[i].missions.length; j++) {
				if(pipeData[i].missions[j].done) {
					pipeData[i].missionDone++
				}
			}
			pipeData[i].missionPercent = (pipeData[i].missionDone / pipeData[i].missionLength) * 100;
		}
		return pipeData;
	}],
	`A.moveKObject(*):: P.body.overview.memberType, P.body.memberType
					 : P.body.overview.entranceAt, P.body.entranceAt
					 : P.body.overview.reviewAt, P.body.reviewAt
					 : P.body.overview.phoneNumber, P.body.phoneNumber
					 : P.body.overview.homeNumber, P.body.homeNumber
					 : P.body.overview.tempAddress, P.body.tempAddress,
					 : P.body.overview.homeAddress, P.body.homeAddress,
					 : P.body.overview.monthlySalary, P.body.monthlySalary,
					 : P.body.overview.hourlySalary, P.body.hourlySalary`,

	`A.refactorOutput:: _id, number, memberType, entranceAt, reviewAt, createdAt, missionLength, missionDone, missionPercent, phoneNumber, homeNumber, tempAddress, homeAddress, monthlySalary, hourlySalary`
]]);

HrcontractRoute.POST.push([["/:_id/mission"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	[`A.aggregate(*): hrcontract:`, [
		{ $match: {
			_id : "@P.route._id"
		}},
		{ $unwind: "$missions" },
		{ $match: {
			"missions.type": "@P.body.type"
		}},
		{ $group: {
			_id : "$missions.creatorId",
			missions: {
				$push: {
					_id       : "$missions._id",
					name      : "$missions.name",
					done      : "$missions.done",
					createdAt : "$missions.createdAt",
				}
			}
		}},
		{ $lookup: {
			from          : "user",
			localField    : "_id",
			foreignField  : "_id",
			as            : "creator"
		}},
		{ $unwind: "$creator" }
	]],
	`A.refactorOutput:: creator._id, creator.avt, creator.userId, creator.name, missions`
]]);

HrcontractRoute.GET.push([["/:_id/overview"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,
	`A.findOne: hrcontract`,
	`A.populate: attach, overview.attachIds, _id, overview.attachs, +, name, name2, mimeType, length`,
	`A.refactorOutput:: overview`
]]);

HrcontractRoute.PUT.push([["/:_id/overview"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput > reqBody:: hrcontract: overview!`,
	`A.updateOne(reqBody): hrcontract`,
	`A.populate: attach, overview.attachIds, _id, overview.attachs, +, name, name2, mimeType, length`,
	`A.refactorOutput:: overview`

]]);

// HrcontractRoute.POST.push([["/:_id/overview/attach"], [
// 	`A.insertSubItem(*) > attachId: hrcontract: @P.route._id: overview.attachIds: @P.body.attachIds[0]`,
// 	`A.populate: attach, attachId, _id, attach, +, name, name2, mimeType, length`,
// 	`A.refactorOutput:: attach`
//
// ]]);
//
// HrcontractRoute.PUT.push([["/:_id/overview/attach"], [
//     `A.removeSubItem(*): hrcontract: @P.route._id: overview.attachIds: @P.body.attachIds[0]`,
// ]]);

HrcontractRoute.POST.push([["/:_id/timeline"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: hrcontract: timelines!`,
	`A.insertSubItem(*): hrcontract: @P.route._id: timelines: @P.body.timelines`,
]]);

HrcontractRoute.GET.push([["/:_id/timeline"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findOne: hrcontract`,
	`A.refactorOutput:: timelines`,
	`A.populate: user, timelines.creatorId, _id, timelines.creator, +, name, name2, userId, avt`
]]);

HrcontractRoute.DELETE.push([["/:_id/timeline/:timelineId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.removeSubItem(*): hrcontract: @P.route._id: timelines: @P.route.timelineId: _id`,
]]);

HrcontractRoute.PUT.push([["/:_id/timeline"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.updateSubItem(*): hrcontract: _id: timelines: @P.body.timeline: _id`,
]]);

HrcontractRoute.POST.push([["/:_id/comment"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: hrcontract: comments!`,
	`A.insertSubItem(*): hrcontract: @P.route._id: comments: @P.body.comments`

]]);

HrcontractRoute.DELETE.push([["/:_id/comment/:commentId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.removeSubItem(*): hrcontract: @P.route._id: comments: @P.route.commentId: _id`,
]]);

HrcontractRoute.PUT.push([["/:_id/comment"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.updateSubItem(*): hrcontract: _id: comments: @P.body.comments: _id`,
]]);

HrcontractRoute.GET.push([["/:_id/comment"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findOne: hrcontract`,
	`A.populate: user, comments.creatorId, _id, comments.creator, +, name, name2, userId, avt`,
	`A.refactorOutput:: comments`
]]);

HrcontractRoute.POST.push([["/:_id/renew"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: hrcontract: renews!`,
	`A.insertSubItem(*): hrcontract: @P.route._id: renews: @P.body.renews`
]]);

HrcontractRoute.DELETE.push([["/:_id/renew/:renewId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.removeSubItem(*): hrcontract: @P.route._id: renews: @P.route.renewId: _id`,
]]);

HrcontractRoute.PUT.push([["/:_id/renew"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.updateSubItem(*): hrcontract: _id: renews: @P.body.renews: _id`,

]]);

HrcontractRoute.GET.push([["/:_id/renew"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.findOne: hrcontract`,
	`A.refactorOutput:: renews`,
	`A.populate: user, renews.creatorId, _id, renews.creator, +, name, name2, userId, avt`
]]);

// HrcontractRoute.PUT.push([["/:_id/renew/approved"], [
// 	`A.updateSubItem(*): hrcontract: _id: renews: @P.body.renews: _id`,
// ]]);

HrcontractRoute.POST.push([["/:_id/mission"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: hrcontract: missions!`,
	`A.insertSubItem(*): hrcontract: @P.route._id: missions: @P.body.missions`
]]);

HrcontractRoute.PUT.push([["/:_id/mission"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.updateSubItem(*): hrcontract: _id: missions: @P.body.missions: _id`,

]]);

HrcontractRoute.DELETE.push([["/:_id/mission/:missionId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.removeSubItem(*): hrcontract: @P.route._id: missions: @P.route.missionId: _id`,
]]);

module.exports = HrcontractRoute;
