
const TaskRoute = {
    route	: true,
    ctrl	: true,
    model	: true,

    POST	: [],
    GET		: [],
    PUT		: [],
    DELETE	: [],
    PIPE    : [],

    config	: {
        // will check, Req.company.feature.project, and also will check:
        // Req.project(:projectId).feature.wiki,
        // Req.project(:projectId).feature.budget,
        // userId in Req.project(:projectId).members.
        // Those get project(:projectId), assign the o bject -> Req/Param, then check, all done automatically.
        // checkMIFs		: ["task", "project: projectId->task,MIF"],
        // uploadToFile	: false,
		checkKeyFeature	: "project.feature.task",
		checkMIFs		: ["project", "task"],
		imProject		: true,
    }
};

TaskRoute.POST.push([['/next-prev'], [
    ['A.jsScript', (Req, pipeData, ctx) => {

        if (!pipeData.searchGroup || !pipeData.colIndex) {
			return {"respData": {}, "respReturn": true , "respCode" : 500};
        }

        var assigneeIds = pipeData.assigneeIds;
        var reviewerIds = pipeData.reviewerIds;
        var testerIds = pipeData.testerIds ;

        const name = pipeData.name || '';
        const milestoneIds = pipeData.milestoneId || pipeData.milestoneIds;
        const labelIds = pipeData.labelIds;
        const projectId = pipeData.projectId;

        var searchGroup  = pipeData.searchGroup;

        var colIndex = pipeData.colIndex;
        var mode = pipeData.mode;
        var groupId = Object.keys(searchGroup)[0];

        const reopen = (pipeData.reopen || pipeData.reOpen) || 0;
        const status = pipeData.status || pipeData.statuses;
        const priority = pipeData.priority || pipeData.prioritys || pipeData.priorities;

        const nameReg = Req.func.getASCIISearch(name || '', 'gmi');
        const taskNumber = (name - 0 || -1);
        const operator = (mode == 'next') ? '$gte' : '$lte';

        const taskMatchAnd = {
            $and: [
                { groupId },
                { colIndex: { [operator]: colIndex } },
                { $or: [
                    { projectId: projectId },
                    { shortName: projectId },
                ]}
            ]
        };

        if ((status != undefined) && (status != null) && (status != '')) {
            if (!Array.isArray(status)) {
                status = [status];
            }
            taskMatchAnd.$and.push({
                status: { $in: status }
            });
        }
        if ((priority != undefined) && (priority != null) && (priority != '')) {
            if (!Array.isArray(priority)) {
                priority = [priority];
            }
            taskMatchAnd.$and.push = {
                priority: { $in: priority }
            };
        }

        if (reopen > 0) {
            taskMatchAnd.$and.push({
                reopen: { $gt: 0 }
            });
        }

        if (name) {
            taskMatchAnd.$and.push({
                $or: [
                    { name: nameReg },
					{ name2: nameReg },
                    { number: taskNumber },
            	]
			});
        }

        if(assigneeIds) {
			if(!Array.isArray(assigneeIds)) {
				assigneeIds = [assigneeIds];
			}
		}

		if((testerIds == undefined) || (testerIds == null)) {
			testerIds = assigneeIds;

		} else {
			if(!Array.isArray(testerIds)) {
				testerIds = [testerIds];
			}
		}

		if((reviewerIds == undefined) || (reviewerIds == null)) {
			reviewerIds = assigneeIds;

		} else {
			if(!Array.isArray(reviewerIds)) {
				reviewerIds = [reviewerIds];
			}
		}

		const or = [];

        if (assigneeIds && (assigneeIds.length > 0)) {
            or.push({ assigneeIds: { $in: assigneeIds } });
        }

        if (testerIds && (testerIds.length > 0)) {
            or.push({ testerIds: { $in: testerIds }  });
        }

        if (reviewerIds && (reviewerIds.length > 0)) {
            or.push({ reviewerIds: { $in: reviewerIds } });
        }

        if (or && (or.length > 0)) {
            taskMatchAnd.$and.push({ $or: or });
        }

        if (labelIds) {
            if (!Array.isArray(labelIds)) {
                labelIds = [labelIds];
            }

            if (labelIds.length > 0) {
                taskMatchAnd.$and.push({
                    labelIds: {
                        $in: labelIds
                    }
                });
            }
        }

        if (milestoneIds) {
            if (!Array.isArray(milestoneIds)) {
                milestoneIds = [milestoneIds];
            }

            if (labelIds.length > 0) {
                taskMatchAnd.$and.push({
                    milestoneId: {
                        $in: milestoneIds
                    }
                });
            }
        }
        var searchNameTextGroup = { };
        var taskNameTextInGroup = searchGroup[groupId];
        if ((taskNameTextInGroup != '') && (taskNameTextInGroup != null)) {
			var groupNameReg = Req.func.getASCIISearch(taskNameTextInGroup || '', 'gmi');
            searchNameTextGroup.$or = [
                { name: groupNameReg },
				{ name2: groupNameReg },
                { number: +taskNameTextInGroup },
            ];
        }

        pipeData.taskMatchAnd = taskMatchAnd;
        pipeData.searchNameTextGroup = searchNameTextGroup;
        pipeData.sort = mode == 'next' ? 1 : -1;

        return Req.UNRESULT;
    }],

    [`A.aggregate > tasks: task`, [
        { $match: "@taskMatchAnd" },
        { $match: "@searchNameTextGroup" },
        { $sort: {
			colIndex: "@sort",
			createdAt : -1
		}},
		{ $limit: 2 },
		{ $project: {
			_id: 1,
			number: 1,
			// name: 1,
			// name2: 1,
		}}
    ]],

	//`A.printObject`,
	['A.jsScript', (Req, pipeData, ctx) => {
		var body = Req.body;
		var tasks = body.tasks || [];
		var task = false;

		if(body.taskId) {
			if(tasks.length == 2) {
				var obj = tasks[0];
				if(obj && (obj._id.toString() == body.taskId.toString())) {
					task = tasks[1];
				}
			}
		} else {
			task = tasks[1];
		}

		if(task && task._id) {
			return {
				respData: { _id: task._id, number: task.number },
				respReturn: true,
				respCode: 200,
			};
		}

		return { respData: {}, respReturn: true , respCode: 200 };
	}],
]]);

TaskRoute.POST.push([[""], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.fillingDateWorking:: startDate: dueDate: 120`, // 12h => 5 days
    `A.verifyInput:: task: projectId!, name!, name2, groupId, parentId, milestoneId, ...`,

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;
		var U = pipeData.U;

		var body = Req.body || {};

		// If create sub task
		var parentId = body.parentId;
		if(parentId) {
			body.isSubTask = true;

			if(!body.featureId) {
				// Case 1: Get Feature of Task parentId
				var task = await A.findById(Req, pipeData, "task", {_id: parentId});
				if(task) {
					U.Func.syncTask(Req, pipeData, body, task);
				}
			}
		}

		var milestoneId = body.milestoneId;
		if(milestoneId) {
			if(!body.featureId) {
				// Case 2: Get Feature of milestoneId, if not get from parent task
				var feature = await A.findById(Req, pipeData, "feature", { milestoneId });
				if(feature) {
					U.Func.syncTask(Req, pipeData, body, feature);
				}
			}
		}

		// creator as reviewer
		if(!body.reviewerIds || !Array.isArray(body.reviewerIds) || (body.reviewerIds.length < 0)) {
			body.reviewerIds = [Req.user._id];
		}


		if(!body.groupId) {
			var filter = {};
			var groupId = body.groupId;
			if(!groupId) {
				filter.shortName = "backlog";
				filter.hasGlobal = true;

			} else {
				filter._id = groupId;
			}

			var groupObj = await pipeData.A.findById(Req, pipeData, "group", {
				type: "task",
				...filter,
			});

			if(!groupObj || !groupObj._id) {
				return {
					respCode: 500,
					respData: "Create task must specific a group!",
					respReturn: true,
				};
			}

			body.groupId = groupObj._id;
			if(!body.status) {
				body.status = groupObj.value || 1;

				// {
				// 	1: 1, // Backlog
				// 	2: 2, // Assign
				// 	3: 3, // Doing
				// 	4: 4, // Test
				// 	5: 5, // Review
				// 	6: 6 // Done
				// }[rs.value||0] || 0;

				// 1: Open, 2.Assigned, 3 Doing, 4: Test, 5: Review, 6: Done
				/*
					"01": "Backlog",
					"02": "Assigned",
					"33": "Start Doing",
					"44": "Finish Doing",
					"54": "Start Testing",
					"55": "Finish Testing",
					"65": "Start Reviewing",
					"66": "Finish Reviewing"
				*/
			}
		}

		var d = (new Date()).getTime();
		if(!body.startDate) {
			body.startDate = new Date(d + (1 * 86400000));
		}

		if(!body.dueDate) {
			body.dueDate = new Date(d + (5 * 86400000));
		}

		//console.log("Data: ", Req.body);
		return Req.UNRESULT;
	}],

	//`A.printObject`,
    `A.insertOne(*) > taskDb: task: @P.body`,
	`A.pipeRoute: task: { type: "create", task: "@taskDb" }`,
	`A.pipeRoute: featureUpdateRelatedItem`,

	//`A.logActivity:: task: create: @taskDb._id: @taskDb.number`,

	// type, subType, refId, refNum, content, oldContent, userId, projectId
    //`A.insertOne > taskcommentdb: taskcomment: ( {"referenceId" : "@taskDb._id"})`,
    `A.responseObject(taskDb): 200: { _id: "@_id",
                                      groupId: "@groupId",
									  name: "@name",
									  number: "@number",
									  name2: "@name2",
                                      milestoneId: "@milestoneId",
                                      createdAt: "@createdAt",
                                      dueDate: "@dueDate",
									  startDate: "@startDate",
                                      parentId: "@parentId",
                                      doneTodo: "@doneTodo",
                                      totalTodo: "@totalTodo",
									  status: "@status",
									  colIndex: "@colIndex",
									  reopen: "@reopen",
                                    }`

    // `A.refactorOutput(taskDb):: _id, groupId, milestoneId, createdAt, dueDate, parentId, doneTodo, totalTodo`
]]);

TaskRoute.GET.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idNumberType`,

    // "A.checkRole: project: projectId: roleproject: task.view",
	[`A.aggregateOne(*): task`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},

		// for Label
		{ $lookup: {
			from: "label",
			let: { labelIds: "$labelIds"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $in: ["$_id", "$$labelIds"] }
				]}}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					type: 1,
					descr: 1,
					color: 1,
				}}
			],
			as: "labels"
		}},

		// for Group
		{ $lookup: {
			from: "group",
			let: { groupId: "$groupId"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$groupId"] }
				]}}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					shortName: 1,
					value: 1,
					color: 1,
				}}
			],
			as: "group"
		}},
		{ $unwind: {
			path: "$group",
			preserveNullAndEmptyArrays: true
		}},

		// for Milestone
		{ $lookup: {
			from: "milestone",
			let: { milestoneId: "$milestoneId"},
			pipeline: [
				{ $match: { $expr: { $and: [
					{ $eq: ["$_id", "$$milestoneId"] }
				]}}},

				{ $addFields: {
					color: { $ifNull: ["$color", "#70CD5F"]}
				}},

				{ $project: {
					_id: 1,
					name: 1,
					name2: 1,
					color: 1,
                    number: 1,
				}}
			],
			as: "milestone"
		}},
		{ $unwind: {
			path: "$milestone",
			preserveNullAndEmptyArrays: true
		}},

		// Add Fields
		{ $addFields: {
			isFollow: { $cond: [{$in: ["@P.user._id", "$watcherIds"]}, true, false]},
			isAssignee: { $cond: [{$in: ["@P.user._id", "$assigneeIds"]}, true, false]},
			isTester: { $cond: [{$in: ["@P.user._id", "$testerIds"]}, true, false]},
			isReviewer: { $cond: [{$in: ["@P.user._id", "$reviewerIds"]}, true, false]},

            hasTaskDone: { $cond: [{ $eq: ["$group.value", 6] }, true, false] },
			value: "$group.value",
		    //groupId: "$group._id",
			/*
		    totalTodo: { $size: "$todos" },
			doneTodo: {
				$size: {
					$filter: {
						input: "$todos",
						as: "todos",
						cond: { "$eq": ["$$todos.done", true] }
					}
				}
			}
			*/
		}},

		// for Sub Task
		{ $populateFilter: ["task", "_id:parentId", "subTasks", undefined, 1, "_id", "name", "name2", "type", "status", "number", "groupId"]},

		// for Related Task
		{ $populateFilter: ["task", [
			{ $let: { relatedTaskIds: "$relatedTaskIds"}},
			{ $match: { $expr: { $and: [
				{ $in: ["$_id", "$$relatedTaskIds"] }
			]}}},
		], "relatedTasks", undefined, 1, "_id", "name", "name2", "type", "status", "number", "groupId"]},


		// for Assignee
		{ $populateFilter: ["user", "assigneeIds$:_id", "assignees", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Tester
		{ $populateFilter: ["user", "testerIds$:_id", "testers", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Tester
		{ $populateFilter: ["user", "reviewerIds$:_id", "reviewers", undefined, 1, "_id", "name", "userId", "avt"]},

		// for Watcher
		{ $populateFilter: ["user", "watcherIds$:_id", "watchers", undefined, 1, "_id", "name", "userId", "avt"]},

		{ $populateFilter: ["user", "creatorId:_id", "creator", true, 1, "_id", "name", "userId", "avt"]},

		{ $populateFilter: ["task", "parentId:_id", "parentTask", true, 1, "_id", "name", "name2", "number", "type"]},

		// For Related Feature
		{ $populateFilter: ["feature", "featureId:_id", "relatedFeature", true, 1, "_id", "name", "name2", "color", "number", "earningPoints", "featurePoint", "sprintId"]},

		// For Linked Feature
		{ $populateFilter: ["feature", "_id:taskId", "linkedFeature", true, 1, "_id", "name", "name2", "color", "number", "earningPoints", "featurePoint", "sprintId"]},

		// For Feature Point
		{ $loopArrayItem: ["linkedFeature.earningPoints", false, "earningPoints", [
			{ $populateFilter: ["user", "user:_id", "user", false, 1, "_id", "name", "userId", "avt"]},
		]]},

		{ $addFields: {
			featurePoint: "$linkedFeature.featurePoint",
		}},

		// For Sprint
		{ $populateFilter: ["sprint", "linkedFeature.sprintId:_id", "sprint", true, 1, "_id", "name", "name2", "color", "number"]},

		// Project
		{ $project: {
			creatorId: 0,
			modifierId: 0,
			modifiedAt: 0,
			labelIds: 0,
			relatedTaskIds: 0,
			//attachIds: 0,
			testerIds: 0,
			reviewerIds: 0,
			watcherIds: 0,
			assigneeIds: 0,
            milestoneId: 0,
            todo: 0,

			"relatedFeature.sprintId": 0,
			"relatedFeature.featurePoint": 0,
			"relatedFeature.earningPoints": 0,

			"linkedFeature.sprintId": 0,
			"linkedFeature.featurePoint": 0,
			"linkedFeature.earningPoints": 0,
		}}
    ]],

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		var DateUtil = pipeData.U.Date;
		var rs = body.estHour || body.duration;
		if(!rs) {
			rs = await DateUtil.calendarWorkingDay(Req, body, body.startDate, body.endDate||body.dueDate, [], true, false, false, false);
		}

		body.duration = rs;
		body.estHour = rs;

		return body;
	}],
]]);

TaskRoute.POST.push([["/group/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    // `A.verifyInput::task: projectId!, ...`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;
			// var { assigneeIds, groupId, name, name2, milestoneIds, labelIds, projectId, searchGroup, pageIndex, pageLength } = body;
        var assigneeIds = body.assigneeIds;
		var reviewerIds = body.reviewerIds;
		var testerIds = body.testerIds;

        var groupId = body.groupId;
        var name = body.name || "";
        var milestoneIds = (body.milestone || body.milestones) || (body.milestoneId || body.milestoneIds);
        var labelIds = body.labelIds;
        var projectId = body.projectId;
        var searchGroup =  body.searchGroup;

		var reopen = (body.reopen || body.reOpen) || 0;
		var status = body.status || body.statuses;
		var type = body.type || body.types;

		var priority = body.priority || body.prioritys || body.priorities;

        var pageIndex = body.pageIndex;
		var pageStart = body.pageStart;
        var pageLength = body.pageLength;

		var show2N = (Req.user||{}).show2N || false;
        var nameReg = Req.func.getASCIISearch(name||"", "gmi");
		var taskNumber = (name-0 || -1);

		if(milestoneIds) {
			if(!Array.isArray(milestoneIds)) {
				milestoneIds = [milestoneIds];
			}
		}

		pageStart = pageStart || 0;
		pageLength = pageLength || 25;

		if(!pageStart) {
			// Pagindex start from 0
			pageStart = (pageIndex||0) * pageLength;
		}

		var columns = body.columns;
		var taskMatchExprAnd = [
			...[(columns && columns.length >= 0) ?
				{ $or: [{$in: ["$$groupValue", columns]},  {$in: ["$$groupId", columns]}] } :
				[]
			],

			{ $or: [
				{ $eq: ["$projectId", projectId] },
				{ $eq: ["$shortName", projectId] }
			]},
			{ $eq: ["$groupId", "$$groupId"] },
		];

        let matchSearchGlobal = {};

        if ((priority != undefined) && (priority != null) && (priority != '')) {
            if (!Array.isArray(priority)) {
              priority = [priority];
            }
            matchSearchGlobal.priority = { $in: priority };
        }

        if (reopen > 0) {
            matchSearchGlobal.reopen =  { $gt: 0 };
        }

        if ((type != undefined) && (type != null) && (type != '')) {
            if (!Array.isArray(type)) {
                type = [type];
            }
            matchSearchGlobal.type = { $in: type };
        }

        if ((status != undefined) && (status != null) && (status != '')) {
            if (!Array.isArray(status)) {
                status = [status];
            }
            matchSearchGlobal.status = { $in: status };
        }

        //console.log(searchGroup);
		if(searchGroup) {
			var searchTaskNameInGroup = [];
			var groupIds = Object.keys(searchGroup);
			var allGroupIds = [];
			for(var i=0; i<groupIds.length; i++) {
				var groupId = groupIds[i];
				var taskNameTextInGroup = searchGroup[groupId];
				if(taskNameTextInGroup) {
					var taskSubNumber = (taskNameTextInGroup-0 || -1);

					var groupNameReg = Req.func.getASCIISearch(taskNameTextInGroup, "gmi")
					searchTaskNameInGroup.push({ $and: [
						{ $eq: [groupId, "$$groupId"] },
						{ $or: [
							{ $regexMatch: { input : "$name", regex: groupNameReg } },
							{ $regexMatch: { input : "$name2", regex: groupNameReg } },
							{ $eq: ["$number", taskSubNumber ]}
						]}
					]});
					allGroupIds.push(groupId);
				}
			}

			if(allGroupIds && allGroupIds.length > 0) {
				searchTaskNameInGroup.push({ $not: { $in: ["$$groupId", allGroupIds] } });
			}

			if(searchTaskNameInGroup && searchTaskNameInGroup.length > 0) {
				// Search sub group ->  task name
				taskMatchExprAnd.push({ $or: searchTaskNameInGroup });
			}
		}

        const pipelineGroup =  [
			{ $match: { $expr: { $and: taskMatchExprAnd } } },
            { $match : matchSearchGlobal },
			{ $sort : {
				 colIndex: 1,
				 createdAt : -1
        	}},

			// calculate total
			{ $group: {
				_id: null,
				tasks: { $push: "$$ROOT" },
				totalTask: { $sum: 1 },
			}},

			{ $addFields: {
				tasks: { $slice: ["$tasks", pageStart, pageLength] }
			}},
			{ $addFields: {
				"tasks.totalTask": "$totalTask"
			}},

			{ $unwind: {
				path: "$tasks",
				preserveNullAndEmptyArrays: false,
			}},
			{ $replaceRoot: {
				newRoot: "$tasks"
			}},

			// { $addFields: {
			// 	_id: "$task._id",
            //     labelIds: "$task.labelIds",
			// 	milestoneIds: "$task.milestoneIds",
            //     assigneeIds: "$task.assigneeIds",
			// 	testerIds: "$task.testerIds",
			// 	reviewerIds: "$task.reviewerIds",
			// 	startDate: "$task.startDate",
			// 	dueDate: "$task.dueDate",
			// 	todos: "$task.todos",
			// }},

			// Paginate
			//{ $skip: pageIndex*pageLength },
			//{ $limit: pageLength },

			// Populate
			//{ $populate: ["label", "labelIds", "_id", "labels"]},
			//{ $populate: ["milestone", "milestoneIds", "_id", "milestones", true]}, // Not used anymore

			//{ $populateFilter: ["user", "assigneeIds$:_id", "assignees", undefined, 1, "_id", "name", "userId", "avt"]},
			//{ $populateFilter: ["user", "testerIds$:_id", "testers", undefined, 1, "_id", "name", "userId", "avt"]},
			//{ $populateFilter: ["user", "reviewerIds$:_id", "reviewers", undefined, 1, "_id", "name", "userId", "avt"]},
			// { $populate: ["user", "assigneeIds", "_id", "assignees"]},
			// { $populate: ["user", "testerIds", "_id", "testers"]},
			// { $populate: ["user", "reviewerIds", "_id", "reviewers"]},

			// { $addFields: {
			// 	"reviewerIds.type": "reviewer",
			// 	"testerIds.type": "tester",
			// 	"assigneeIds.type": "assignee"
			// }},

			// { $addFields: {
			// 	users: { $setUnion: ["$assigneeIds", "$testerIds", "$reviewerIds"] }
			// }},

			{ $addFields: {
				dueDateCal: { $convert: { input: "$dueDate", to: "double", onError: 0, onNull: 0}},
				startDateCal: { $convert: { input: "$startDate", to: "double", onError: 0, onNull: 0}},
				nowDateCal: { $convert: { input: "$$NOW", to: "double", onError: 0, onNull: 0}},
			}},

			{ $addFields: {
				duration: {$ceil: { $divide: [{$subtract: ["$dueDateCal", "$startDateCal"]}, 86400000] }},
				remainingDay: {$ceil: { $divide: [{$subtract: ["$dueDateCal", "$nowDateCal"]}, 86400000] }},
				members: { $concatArrays: ["$assigneeIds", "$testerIds", "$reviewerIds"]},
				labels: { $ifNull: ["$labelIds", [] ]},
				/*
				totalTodo: { $size: "$todos"},
				doneTodo: {
					$size: {
						$filter: {
							input: "$todos",
							as: "todos",
							cond: { "$eq": ["$$todos.done", true] }
						}
					}
				} */
			}},

        	{ $project: {
                _id: 1,

                name: 1,
				name2: 1,
                //attachIds: 1,
				descr: 1,
                //descrHTML: 1,

				number: 1,
                type: 1,
                status: 1,
                priority: 1,
                reopen: 1,
                weight: 1,

				duration: 1,
				remainingDay: 1,
                startDate: 1,
                dueDate: 1,
                hasLimited: 1,
                colIndex: 1,
                isLock: 1,

				totalTodo: 1,
                doneTodo: 1,

				totalTask: 1,

				members: 1,
				assigneeIds: 1,
				testerIds: 1,
				reviewerIds: 1,

				labels: 1,

                // Label
				// "labels._id": 1,
				// "labels.name": 1,
				// "labels.name2": 1,
				// "labels.type": 1,
				// "labels.descr": 1,
				// "labels.color": 1,

                // milestone
				// "milestone._id": 1,
				// "milestone.name": 1,
				// "milestone.name2": 1,
				// "milestone.color": 1,
				// "milestone.descr": 1,
				// "milestone.startDate": 1,
				// "milestone.endDate": 1,

				// "users._id": 1,
				// "users.name": 1,
				// "users.name2": 1,
				// "users.avt": 1,
				// "users.userId": 1,

				// "assignees": 1,
				// "testers": 1,
				// "reviewers": 1,
            }},
		]

		// When client send assignedId to filter
		if(assigneeIds) {
			if(!Array.isArray(assigneeIds)) {
				assigneeIds = [assigneeIds];
			}
		}

		if((testerIds == undefined) || (testerIds == null)) {
			testerIds = assigneeIds;

		} else {
			if(!Array.isArray(testerIds)) {
				testerIds = [testerIds];
			}
		}

		if((reviewerIds == undefined) || (reviewerIds == null)) {
			reviewerIds = assigneeIds;

		} else {
			if(!Array.isArray(reviewerIds)) {
				reviewerIds = [reviewerIds];
			}
		}

		var or = [];
		if(assigneeIds && (assigneeIds.length > 0)) {
			or.push({ assigneeIds: { $elemMatch: { $in: assigneeIds } }});
		}

		if(testerIds && (testerIds.length > 0)) {
			or.push({ testerIds: { $elemMatch: { $in: testerIds } }});
		}

		if(reviewerIds && (reviewerIds.length > 0)) {
			or.push({ reviewerIds: { $elemMatch: { $in: reviewerIds } }});
		}

		if(or && (or.length > 0)) {
			matchSearchGlobal.$or = or;
		}


		// When client send test to search global
        if (name) {
            taskMatchExprAnd.push({ $or: [
                { $regexMatch: { input : "$name", regex: nameReg }},
				{ $regexMatch: { input : "$name2", regex: nameReg }},
				{ $eq: ["$number", taskNumber ]}
            ]})
        }

        // When client send labelIds to filter
        if(labelIds) {
			if(!Array.isArray(labelIds)) {
				labelIds = [labelIds];
			}

			if(labelIds.length > 0) {
				//matchSearchGlobal.labelIds = labelIds;
	            matchSearchGlobal.labelIds = {
	                $elemMatch: {
	                    $in: labelIds
	                }
	            }
			}
        }

		// When client send milestone to filter
        if(milestoneIds) {
			if(milestoneIds.length > 0) {
		        taskMatchExprAnd.push({
		            '$in': [ '$milestoneId', milestoneIds ]
		        });
			}
        }

		var groupMatch = {
	        hasGlobal: true,
	        type: "task"
		};

        if (groupIds) {
			if(!Array.isArray(groupIds)) {
				groupIds = [groupIds];
			}

			if((groupIds.length > 0) && (groupIds.length < 2)) {
            	groupMatch._id = { $in: groupIds };
			}
        }

		body.groupMatch = groupMatch;
        body.pipelineGroup = pipelineGroup;
        return body;
    }],

	//`A.printObject:`,
    [`A.aggregateOne > dbData::`, [
		{ $lookup: {
			from: "group",
			pipeline: [
				{ $match: "@groupMatch" },
				{ $sort : {
					value : 1
				}},
				{ $project: {
			        name: 1,
					name2: 1,
			        color: 1,
			        shortName: 1,
			        value: 1
			    }},
				{ $lookup: {
			        from: "task",
			        let: { groupId: "$_id", groupValue: "$value" },
			        pipeline: "@pipelineGroup",
			        as: "tasks"
				}},

				{ $flatArray: {
					members: "$tasks.members",
					labels: "$tasks.labels"
				}},

				{ $addFields: {
					members: { $setUnion: "$members" },
					labels: { $setUnion: "$labels" },
					totalTask: { $ifNull: [{ $first: "$tasks.totalTask" }, 0] },
					count: { $size : "$tasks" }
				}},
				{ $project: {
					"tasks.totalTask": 0,
					"tasks.members": 0,
					//"tasks.labels": 0,
				}},
			],
			as: "groups",
		}},

		{ $flatArray: {
			members: "$groups.members",
			labels: "$groups.labels"
		}},

		{ $addFields: {
			members: { $setUnion: "$members" },
			labels: { $setUnion: "$labels" },
		}},

		{ $populateFilter: ["user", "members$:_id", "members", undefined, 1, "_id", "name", "avt", "userId"]},
		{ $populateFilter: ["label", "labels$:_id", "labels", undefined, 1, "_id", "name", "name2", "color", "userId"]},

		{ $project: {
			"groups.members": 0,
			"groups.labels": 0,
		}}
	]],

	//`A.printObject:`,
	[`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body || {};

		var dbData = body.dbData;

		var labelObj = {};
		var labels = dbData.labels || [];
		labels.map(label => {
			labelObj[label._id.toString()] = label;
		});

		var memberObj = {};
		var members = dbData.members || [];
		members.map(member => {
			memberObj[member._id.toString()] = member;
		});

		const RID = function(root, rkey, obj, nkey, shouldDelete) {
			var arrs = root[rkey];

			for (var i = 0; i < arrs.length; i++) {
				var k = arrs[i];
				var val = obj[k];
				if(!val || !k) {
					arrs.splice(i--, 1);

				} else {
					arrs.splice(i, 1, val);
				}
			}

			if(nkey) {
				root[nkey] = arrs;
			}

			if(shouldDelete) {
				delete root[rkey];
			}
		};

		var groups = dbData.groups || [];
		groups.map(group => {
			(group.tasks||[]).map(task => {
				// Replace assignedId
				RID(task, "assigneeIds", memberObj, "assignees", true);

				// Replace testerIds
				RID(task, "testerIds", memberObj, "testers", true);

				// Replace reviewerIds
				RID(task, "reviewerIds", memberObj, "reviewers", true);

				// Replace labelIds
				RID(task, "labels", labelObj, "labels", false);

			});
		});

		return groups;
	}],

], { EnableProfiling: true, useZip: true } ]);

// X1
TaskRoute.PUT.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: colIndex-, number-, projectId-, budget-, creatorId-, taskId-, reopen-, createdAt-, ...`,
    //`A.refactorOutput:: colIndex-, number-, ...`,
    // `A.findOne > dbBody: task`,
    // `A.pipeRoute: Checktask`,
	//`A.printObject:`,
	[`A.jsScript(*)::`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var dbBody = Req.body || {};
		var milestoneId = dbBody.milestoneId;

		var projectId = Req.project._id;
		var parentId = Req.route._id;

		var updateSubData = {};
		if(milestoneId) {
			// colName, idKey, updatedData, shouldCreated=false, updateMany=false
			var rs = await A.findById(Req, pipeData, "task", {parentId, projectId});
			if(rs && rs._id) {
				//console.log("------------ 2", milestoneId, parentId, projectId);
				updateSubData = { milestoneId };
			}

		} else if(milestoneId === "") {
			//console.log("------------ 1: ", milestoneId, parentId, projectId);
			updateSubData = { milestoneId };
		}

		var featureId = dbBody.featureId;
		if(featureId) {
			updateSubData.featureId = featureId;
		}

		var groupId = dbBody.groupId;
		if(groupId && !dbBody.status) {
			var groupDb = await A.findById(Req, pipeData, "group", {_id: groupId});
			if(groupDb) {
				dbBody.status = groupDb.value || 1;
			}
		}

		if(Object.keys(updateSubData).length > 0) {
			await A.updateById(Req, pipeData, "task", {parentId, projectId}, updateSubData, false, true);
		}

	 	return Req.UNRESULT;
    }],

    `A.updateById(*) > task: task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body`,

	`A.pipeRoute: task: { type: "update", task: "@task" }`,
    `A.responseObject: 200: Update successfully!`
]]);

TaskRoute.DELETE.push([[":_id"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.delete`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.findOne(*) > dbBody: task: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.pipeRoute: Checktask`,

    `A.populate: group, dbBody.groupId, _id, dbBody.group, +, name, name2, type, shortName, color`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var dbBody = pipeData.dbBody;
        if (!dbBody) {
            return {
				respData: "Task not found!",
				respReturn: true,
				respCode: 503
			};
        }

		var user = Req.user || {};
		var unpermit = !user.hasAdmin && !user.hasAgent;
        if (unpermit && (dbBody.group && dbBody.group.shortName == 'done')) {
			return {
				respData: "Can not delete this task!",
				respReturn: true,
				respCode: 400
			};
        }

		var projectId = (Req.project||{})._id;
		var taskId = dbBody._id;

		Req.filter = { _id:taskId, projectId };
		Req.relatedFilter = { taskId, projectId };
		Req.parentFilter = { parentId: taskId, projectId };

	 	return pipeData;
    }],

	// Delete This task
    `A.deleteById(*) > xyz: task: @P.filter`,

	// Update many task to remove parentId, isSubTask
	// colName, idKey, updatedData, shouldCreated=false, updateMany=false, ignoredNotFound=false
	`A.updateById(*) > xyz: task: @P.parentFilter: {parentId:null, isSubTask: false}: false: true: true`,

	// Delete Logtime
	`A.deleteById(*) > xyz: logtime: @P.relatedFilter: true: true`,

	// Delete Performance
	`A.deleteById(*) > xyz: performance: @P.relatedFilter: true: true`,

	// Delete Penalty
	`A.deleteById(*) > xyz: penalty: @P.relatedFilter: true: true`,

	// Delete Cost
	`A.deleteById(*) > xyz: cost: @P.relatedFilter: true: true`,

	`A.pipeRoute: taskDelete: { task: "@dbBody" }`,
    `A.responseObject: 200: Delete Task successfully!`
]]);

TaskRoute.POST.push([["number"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	//`A.printObject:`,
    `A.verifyInput:: task: projectId!`,
    [`A.aggregateOne: group`, [
		{ $match : {
			type: "task",
			$expr: { $or: [
				{ $eq: ["$projectId", "@projectId"] },
				{ $eq: ["$hasGlobal", true] },
			]}
        }},

		{ $populateFilter: ["task", "_id:groupId", "tasks", undefined, 1, "projectId"]},
		{ $addFields: {
			tasks: {
				$filter: {
		            input: "$tasks",
		            as: "task",
		            cond: { $eq: ["$$task.projectId", "@projectId"] }
				}
			}
		}},

		{ $project: {
			shortName: 1,
			numberTask: { $size: "$tasks" }
		}},

		{ $group: {
			_id: null,
			groups: { $push: "$$ROOT" },
			numberTask: { $sum: "$numberTask" }
		}},

		{ $addFields: {
			numberGroupDone: {
                $filter: {
		            input: "$groups",
		            as: "group",
		            cond: { "$eq": [{$toLower:"$$group.shortName"}, "done"] }
				}
			},
		}},

		{ $addFields: {
			numberDone: { $sum: "$numberGroupDone.numberTask" }
		}},

		{ $addFields: {
			numberTask: { $convert: { input: "$numberTask", to: "double", onError: 0, onNull: 0}},
			numberDone: { $convert: { input: "$numberDone", to: "double", onError: 0, onNull: 0}},
		}},

		{ $addFields: {
			numberRemaining: { $subtract: ["$numberTask", "$numberDone"]}
		}},

		{ $project: {
			_id: 0,
			groups: 0,
			numberGroupDone: 0,
		}},
    ]],
]]);


// TaskRoute.POST.push([["/:_id/todo/s"], [
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
//     [`A.aggregateOne(*): task`, [
//         { $match: {
// 			_id: "@P.route._id"
// 		}},
//         { $project: {
//             _id: 0,
// 			/*
//             totalTodo: {$size: "$todos"},
//             doneTodo: {
//                 $size: {
//                     $filter: {
//                         input: "$todos",
//                         as: "todos",
//                         cond: { "$eq": ["$$todos.done", true] }
//                     }
//                 }
//             }
// 		}},
//     ]],
// 	`A.responseObject(*): 200: @P.body`,
// ]]);
//
// TaskRoute.POST.push([[":_id/todo"], [
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
//     `A.verifyInput:: task: todo!`,
//     `A.insertSubItem(*): task: @P.route._id: todos: @P.body.todo`,
//     `A.responseObject(*): 200: @P.body[0]`,
// ]]);
//
// TaskRoute.PUT.push([["/:_id/todo"], [
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
//     `A.updateSubItem(*) > temp: task: @P.route._id: todos: @P.body.todo: _id`,
//     [`A.aggregate(*): task`,[
// 		{ $match: {
//             _id: "@P.route._id"
//         }},
// 		{ $project : {
//             _id: 0,
//             todo: {
//                 $filter : {
//                     input:"$todos",
//                     as: "item",
//                     cond: {
//                         $and: [
//                             {$eq: ['$$item._id', "@P.body.todo._id"]},
//                         ]
//                     }
//                 }
//             }
//         }},
// 		{ $unwind: {
// 			path: "$todo",
// 			preserveNullAndEmptyArrays: false
// 		}},
// 		{ $replaceRoot: {
// 			newRoot: "$todo"
// 		}}
//     ]],
// 	`A.responseObject(*): 200: @P.body[0]`,
// ]]);
//
// TaskRoute.PUT.push([["/:_id/todo/remove"], [
// 	`A.verifyKObject(P.route):: _id!: verify.idType`,
//     `A.removeSubItem(*): task: @P.route._id: todos: @P.body.todo`,
// 	`A.responseObject: 200: Remove todo successfully!`,
// ]]);


TaskRoute.POST.push([["/:_id/clone"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput:: task: projectId!`,

	[`A.aggregateOne(*) > dbBody: task:`, [
		{ $match: {
			// projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}}
	]],
	`A.pipeRoute: Checktask`,

	// get first task
    [`A.aggregateOne > task: task:`, [
		{ $sort: {
			colIndex: -1
		}},
		{ $limit: 1 }
	]],

    `A.findOne > groupDb: group: {
        shortName : "backlog",
     }`,

    [`A.jsScript(*)::`, (Req, pipeData, ctx) => {
        //console.log(pipeData.task);
		var body = Req.body || {};
		var dbBody = body.dbBody || {};

		//var projectId = (dbBody.projectId+"").split("").reverse().join("");

        dbBody.groupId = body.groupDb._id;
        dbBody.colIndex = body.task.colIndex + 1000;
        dbBody.status = body.groupDb.value || 1;

		//var newGetFileToken = pipeData.A.autoHash(Req, false, 50); // 2nd param must be false to get new hash

		// Adjust link of image
		//var fromStrReg = `\/${Req.company._id}\/task\/${projectId}\/[a-z0-9]{50,60}[.][a-z0-9]{1-10}/gmi`;
		//var toStr = `${Req.company._id}/task/${projectId}/${newGetFileToken}`;
		//task.descr = (task.descr||"").replace(fromStrReg, toStr);

		//console.log("Number: ", dbBody.number);

		// Delete old data
		delete dbBody._id;
		delete dbBody.number;
		delete dbBody.creatorId;
		delete dbBody.modifierId;
		delete dbBody.createdAt;
		delete dbBody.modifiedAt;
		delete dbBody.reopen;

        return Req.UNRESULT;
    }],

    `A.insertById > newTask: task: @dbBody`,
    // [`A.jsScript::`, (Req, pipeData, ctx) => {
	// 	var body = Req.body;
    //     if(body) {
    //         body.doneTodo = 0;
    //         body.totalTodo = body.todos.length;
    //         for (let i=0; i < body.todos.length; i++) {
    //             if(body.todos.done == true ) {
    //                 body.doneTodo = body.doneTodo + 1;
    //             }
    //         }
    //     }
    //     return body;
    // }],

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body;
		var dbBody = body.dbBody;
		var newTask = body.newTask;

		// Adjust link of image
		var fromStrReg = `\/${dbBody.projectId}\/task\/${(dbBody._id+"").split("").reverse().join("")}\/`;
		var toStr = `/${newTask.projectId}/task/${(newTask._id+"").split("").reverse().join("")}/`;

		var descr = (newTask.descr||"").replace(new RegExp(fromStrReg, "gmi"), toStr);
		await A.updateById(Req, pipeData, "task", {_id: newTask._id}, { descr });

		//console.log("DERC: \n", newTask.descr, "\n", descr, "\n", fromStrReg, toStr);

		return Req.UNRESULT;
	}],

	//`A.logActivity:: task: clone: @_id: @number`,
	// type, subType, refId, refNum, content, oldContent, userId, projectId
    `A.pipeRoute(*): task: { type: "clone", task: "@P.body" }`,
	`A.pipeRoute(*): taskMoreAction: {type: "clone", oldProjectId: "@P.body.dbBody.projectId", newProjectId: "@P.body.newTask.projectId", oldTaskId: "@P.route._id", newTaskId: "@P.body.newTask._id" }`,

    // `A.populate(newTask): label, labelIds, _id,labels,+, name, name2, type, descr,
    //            : milestone, milestoneId, _id, milestone, +, name, name2, color,
    //            : user, assigneeIds, _id, assignees,  +, name, name2, userId, avt,
    //            : user, testerIds, _id, testers,  +, name, name2, userId, avt,
    //            : user, watcherIds, _id, watchers,  +, name, name2,  userId, avt,
    //            : user, reviewerIds, _id, reviewers,  +, name, name2, userId, avt`,

    `A.responseObject(newTask): 200: { _id: "@_id", number: "@number", name: "@name" }`,

    // `A.responseObject: 200: Clone task successfully!`
], { F1: { IgnoreSanitized: true } }]);

TaskRoute.POST.push([["/:_id/move"], [
	`A.verifyKObject:: oldProjectId!: verify.idType`,
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.checkRole(*): project: @P.body.oldProjectId: roleproject: task.view, task.delete`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: projectId!`,

	[`A.aggregateOne(*) > dbBody: task:`, [
		{ $match: {
			// projectId: "@P.route.projectIdOld",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}}
	]],

    `<F1>A.findMany > labels: label: { "hasGlobal": true, "_id": { $in: "@dbBody.labelIds" }  }`,
    `A.findOne > groupDb: group:{
        shortName : "backlog" ,
    }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		const dbBody = pipeData.dbBody;
        const labels = pipeData.labels || [];

		const projectId = pipeData.projectId;

		// Failed case, move project in project
		if((dbBody.projectId+"") == projectId) {
			return undefined;
		}

		var task = {};
		task.projectId = projectId;
		task.groupId = pipeData.groupDb._id;
		task.status = pipeData.groupDb.value || 1;
		task.name = dbBody.name || "";
		task.name2 = dbBody.name2 || "";
        task.type = dbBody.type;
		task.startDate = dbBody.startDate;
		task.dueDate = dbBody.dueDate;
        task.labelIds = labels.map(x => x._id);

		if (dbBody.descr) {
			task.descr = dbBody.descr
		}
		task.todos = dbBody.todos || [];
		pipeData.task = task;

		return Req.UNRESULT;
    }],
    `A.insertOne > newTask: task: @task`,
    `A.deleteOne(*) > xyz: task: {"_id": "@P.route._id"}`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body;
		var dbBody = body.dbBody;
		var newTask = body.newTask;

		// Adjust link of image
		var fromStrReg = `\/${dbBody.projectId}\/task\/${(dbBody._id+"").split("").reverse().join("")}\/`;
		var toStr = `/${newTask.projectId}/task/${(newTask._id+"").split("").reverse().join("")}/`;

		var descr = (newTask.descr||"").replace(new RegExp(fromStrReg, "gmi"), toStr);
		await A.updateById(Req, pipeData, "task", {_id: newTask._id}, { descr });

		//console.log("DERC: \n", newTask.descr, "\n", descr, "\n", fromStrReg, toStr);

		return Req.UNRESULT;
	}],

	//`A.logActivity:: task: move: @xyz._id: @xyz.number`,
	// type, subType, refId, refNum, content, oldContent, userId, projectId
	`A.pipeRoute: task: { type: "move", task: "@newTask" }`,
	`A.pipeRoute(*): taskMoreAction: {type: "move", oldProjectId: "@P.body.dbBody.projectId", newProjectId: "@P.body.newTask.projectId", oldTaskId: "@P.route._id", newTaskId: "@P.body.newTask._id" }`,

    //`A.responseObject: 200: @newTask`
	`A.responseObject(newTask): 200: { _id: "@_id", number: "@number", name: "@name" }`,

], { F1: { IgnoreSanitized: true } }]);

TaskRoute.POST.push([["/:_id/copy"], [
	`A.verifyKObject:: oldProjectId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.checkRole(*): project: @P.body.oldProjectId: roleproject: task.view`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: task: projectId!`,

	[`A.aggregateOne(*) > dbBody: task:`, [
		{ $match: {
			// projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" },
			]
		}}
	]],

    `<F1>A.findMany > labels: label: { "hasGlobal": true, "_id": { $in: "@dbBody.labelIds" }  }`,
    `A.findOne > groupDb: group:{
        shortName : "backlog" ,
    }`,

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		const projectId = pipeData.projectId;
		const dbBody = pipeData.dbBody;
        const labels = pipeData.labels || [];

		// Failed case, copy project in project
		if((dbBody.projectId+"") == projectId) {
			return undefined;
		}

		var task = {};
		task.projectId = projectId;
		task.groupId = pipeData.groupDb._id;
		task.status = pipeData.groupDb.value || 1;
		task.name = dbBody.name || "";
		task.name2 = dbBody.name2 || "";
        task.type = dbBody.type;
		task.startDate = dbBody.startDate;
		task.dueDate = dbBody.dueDate;
        task.labelIds = labels.map(x => x._id);

		if (dbBody.descr) {
			task.descr = dbBody.descr
		}
		task.todos = dbBody. todos || [];

		pipeData.task = task;

		return Req.UNRESULT;
    }],

    `A.insertOne > newTask: task: @task`,

	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body;
		var dbBody = body.dbBody;
		var newTask = body.newTask;

		// Adjust link of image
		var fromStrReg = `\/${dbBody.projectId}\/task\/${(dbBody._id+"").split("").reverse().join("")}\/`;
		var toStr = `/${newTask.projectId}/task/${(newTask._id+"").split("").reverse().join("")}/`;

		var descr = (newTask.descr||"").replace(new RegExp(fromStrReg, "gmi"), toStr);
		await A.updateById(Req, pipeData, "task", {_id: newTask._id}, { descr });

		//console.log("DERC: \n", newTask.descr, "\n", descr, "\n", fromStrReg, toStr);

		return Req.UNRESULT;
	}],

	//`A.logActivity:: task: copy: @_id: @number`,
	// type, subType, refId, refNum, content, oldContent, userId, projectId

	`A.pipeRoute(*): task: { type: "copy", task: "@P.body,newTask" }`,
	`A.pipeRoute(*): taskMoreAction: {type: "copy", oldProjectId: "@P.body.dbBody.projectId", newProjectId: "@P.body.newTask.projectId", oldTaskId: "@P.route._id", newTaskId: "@P.body.newTask._id" }`,

    //`A.responseObject: 200: @newTask` // and deafult data is P.body
	`A.responseObject(newTask): 200: { _id: "@_id", number: "@number", name: "@name" }`,
], { F1: { IgnoreSanitized: true } }]);

TaskRoute.POST.push([["/:_id/assignee"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: assigneeIds!, projectId!`,

	`A.insertSubItem(*) > assignees: task: @P.route._id: assigneeIds: @P.body.assigneeIds`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "assignee", subType: "add", task: "@task", memberId: '@assigneeIds' }`,

    `A.populate: user, assignees, _id, assignees, +, userId, name, name2, avt`,
    `A.responseObject: 200: Add assignee successfully!`
]]);

TaskRoute.PUT.push([["/:_id/assignee"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: assigneeIds!, projectId!`,

    `A.removeSubItem(*) > ctx: task: @P.route._id: assigneeIds: @P.body.assigneeIds[0]`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "assignee", subType: "remove", task: "@task", memberId: '@assigneeIds' }`,

    `A.responseObject: 200: Remove assignee successfully!`
]]);

TaskRoute.POST.push([["/:_id/tester"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: testerIds!, projectId!`,

    `A.insertSubItem(*) > testers: task: @P.route._id: testerIds: @P.body.testerIds`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "tester", subType: "add", task: "@task", memberId: '@testerIds' }`,

    `A.populate: user, testers, _id, testers, +, name, name2, userId, avt`,
    `A.responseObject: 200: Add tester successfully!`
]]);

TaskRoute.PUT.push([["/:_id/tester"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,
	"A.verifyInput:: task: testerIds!, projectId!",

    `A.removeSubItem(*) > ctx: task: @P.route._id: testerIds: @P.body.testerIds[0]`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "tester", subType: "remove", task: "@task", memberId: '@testerIds' }`,

    `A.responseObject: 200: Remove tester successfully!`
]]);

TaskRoute.GET.push([["/:_id/follow"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.insertSubItem(*) > watcherIds: task: @P.route._id: watcherIds: @P.user._id`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { type: "follow",task: "@task" }`,

    `A.populate: user, watcherIds, _id, watcher, +, name, name2, userId, avt`,
    `A.responseObject: 200: @watcher[0]`
]]);

TaskRoute.GET.push([["/:_id/unfollow"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.removeSubItem(*): task: @P.route._id: watcherIds: @P.user._id`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { type: "unfollow", task: "@task" }`,

    `A.responseObject: 200: Unfollow task successfully!`
]]);

TaskRoute.POST.push([["/:_id/reviewer"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: reviewerIds!, projectId!`,

    `A.insertSubItem(*) > reviewers: task: @P.route._id: reviewerIds: @P.body.reviewerIds`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "reviewer", subType: "add",  task: "@task", memberId: '@reviewerIds'}`,

    `A.populate: user, reviewers, _id, reviewers, +, userId, name, name2, avt`,
    `A.responseObject: 200: Add reviewer successfully!`
 ]]);

TaskRoute.PUT.push([["/:_id/reviewer"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

	`A.verifyInput:: task: reviewerIds!, projectId!`,

    `A.removeSubItem(*) > ctx: task: @P.route._id: reviewerIds: @P.body.reviewerIds[0]`,

    `A.findOne > task: task`,
	`A.pipeRoute: task: { mode: "member", type: "reviewer", subType: "remove", task: "@task", memberId: '@reviewerIds' }`,

    `A.responseObject: 200: Remove reviewer successfully!`
]]);

TaskRoute.POST.push([["/:_id/label"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.verifyInput:: task: labelIds!, projectId!`,
    `A.insertSubItem(*) > labelIds: task: @P.route._id: labelIds: @P.body.labelIds`,
    `A.populate: label, labelIds, _id, labels, +, name, name2, color`,
    `A.responseObject: 200: @labels`
]]);

TaskRoute.PUT.push([["/:_id/label"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

	"A.verifyInput:: task: labelIds!, projectId! ",
    `A.removeSubItem(*): task: @P.route._id: labelIds: @P.body.labelIds[0]`,
    `A.responseObject: 200: Remove label successfully!`
]]);

// @Toan thiếu update cái parentId của Task => add Subtask
TaskRoute.POST.push([["/:_id/subtask"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyKObject:: subTaskIds!: verify.arrayIdType`,

	`A.findById(*) > P.taskDb: task: {_id: "@P.route._id"}`,
	`A.assertKeyExisted(*): @P.taskDb: _id: Parent task was not found!`,
	`A.pipeRoute: Checktask`,

    `<F1>A.updateOne(*): task:
    	{ _id: { $eq: "@P.body.subTaskIds[0]", $ne: "@P.route._id" }, projectId: "@P.project._id" } :
    	{ parentId: "@P.route._id", "isSubTask": true, milestoneId: "@P.taskDb.milestoneId" }`,
	// `A.findMany(*) > subTasks: task: ({"parentId" : "@P.route._id"})`,

    `A.refactorOutput:: _id, name, name2, status, type, number`


    // `A.verifyInput > reqBody:: task: subTaskIds`,
    // "A.findById > dbBody: task",
    // `A.pipeRoute: Checktask`,
    // `A.modifyObject::
    //     dbBody.subTaskIds = */reqBody.subTaskIds`,
    // "A.updateById(dbBody): task",
    // `A.populate: task, subTaskIds, _id, subTasks, + , name, name2, status, number, type`,
    // `A.jsScript::(
    //     return pipeData.subTasks[pipeData.subTasks.length - 1];
    // )`
], {
    F1: { IgnoreSanitized: true }
}]);

// @Toan thiếu update cái parentId của Task
TaskRoute.PUT.push([["/:_id/subtask"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyKObject:: subTaskIds!: verify.arrayIdType`,

	`A.pipeRoute: checkTaskValidToEdit`,

	// `A.findById > dbBody: task`,
    // `A.pipeRoute: Checktask`,
	`<F1>A.updateOne(*) > dbData: task: {_id: "@P.body.subTaskIds[0]", projectId: "@P.project._id"}: {"parentId": null, "isSubTask": false}`,

	`A.findMany(*) > subTasks: task: ({ parentId : "@P.route._id", projectId: "@P.project._id" })`,
	`A.responseObject: 200: Remove subTask successfully!`,
], { F1: { IgnoreVerify: true } }]);

TaskRoute.POST.push([["/:_id/relatedtask"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyKObject:: relatedTaskIds!: verify.arrayIdType`,

	`A.pipeRoute: checkTaskValidToEdit`,

    `A.insertSubItem(*) > relatedtask: task: { _id: "@P.route._id", projectId: "@P.project._id" }: relatedTaskIds: @P.body.relatedTaskIds`,

    `A.populate : task, relatedtask, _id, relatedtask, +, _id, name, name2, status, type, number`,
    `A.responseObject: 200: @relatedtask`
]]);

TaskRoute.PUT.push([["/:_id/relatedtask"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyKObject:: relatedTaskIds!: verify.arrayIdType`,

	`A.pipeRoute: checkTaskValidToEdit`,

    `A.removeSubItem(*): task: { _id: "@P.route._id", projectId: "@P.project._id" }: relatedTaskIds: @P.body.relatedTaskIds[0]`,

	`A.responseObject: 200: Remove relatedtask successfully!`
]]);

TaskRoute.POST.push([["/:_id/add/limitaccess"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput > reqBody:: task: limitAccessIds!, projectId!`,

    `A.findById(*) > dbBody: task: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.pipeRoute: Checktask`,

	`A.modifyObject::
        dbBody.limitAccessIds = */reqBody.limitAccessIds,
        respData = 200`,

	`A.mixObject(dbBody) > upBody:: ({
		"modifiedAt"        : "@modifiedAt",
		"limitAccessIds"    : "@limitAccessIds"
	})`,

    `A.updateById(*) > tmpBody: task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.upBody`,
]]);

TaskRoute.POST.push([["/:_id/remove/limitaccess"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.verifyInput > reqBody:: task: limitAccessIds!, projectId!`,

    `A.findById(*) > dbBody: task: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.pipeRoute: Checktask`,

    `A.modifyObject::
        dbBody.limitAccessIds = //reqBody.limitAccessIds`,

    `A.updateById(*) > tmpBody: task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.dbBody`,
]]);

/*
TaskRoute.POST.push([["/loadmore"], [
	[`A.aggregate: task`, [
		{ $match: {
			"projectId": "@projectId",
			"groupId": "@groupId"
		}},
		{ $sort: {
			colIndex: 1,
			createdAt: -1
		}},

		{ $skip: "@pageStart" },
		{ $limit: 25 },

		{ $populate: ["label", "labelIds", "_id", "labels"]},

		{ $populate: ["user", "assigneeIds", "_id", "assignees"]},
		{ $populate: ["user", "testerIds", "_id", "testers"]},
		{ $populate: ["user", "reviewerIds", "_id", "reviewers"]},

		{ $project: {
			"_id": 1,
			"name": 1,
			"name2": 1,
			"descr": 1,
			"number": 1,
			"type": 1,
			"status": 1,
			"priority": 1,
			"reopen": 1,
			"weight": 1,
			"duration": 1,
			"remainingDay": 1,
			"startDate": 1,
			"dueDate": 1,
			"hasLimited": 1,
			"colIndex": 1,
			"isLock": 1,

			// Label
			"labels._id": 1,
			"labels.name": 1,
			"labels.name2": 1,
			"labels.type": 1,
			"labels.descr": 1,
			"labels.color": 1,

			// Assignees
			"assignees._id": 1,
			"assignees.name": 1,
			"assignees.name2": 1,
			"assignees.avt": 1,
			"assignees.userId": 1,

			// Testers
			"testers._id": 1,
			"testers.name": 1,
			"testers.name2": 1,
			"testers.avt": 1,
			"testers.userId": 1,

			// Reviewers
			"reviewers._id": 1,
			"reviewers.name": 1,
			"reviewers.name2": 1,
			"reviewers.avt": 1,
			"reviewers.userId": 1,
			totalTodo: { $size: "$todos" },
			doneTodo: {
				$size: {
					$filter: {
						input: "$todos",
						as: "todos",
						cond: { "$eq": ["$$todos.done", true] }
					}
				}
			}
		}}
	]],
], {maxPageLimit: 25}]);
*/

TaskRoute.GET.push([["/:_id/lock"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.updateOne(*): task: { _id: "@P.route._id", projectId: "@P.project._id" }: {"isLock" : true}`,

	`A.pipeRoute(*): task: { type: "lock", task: "@P.body" }`,
	`A.responseObject: 200: Lock successfully!`
]]);

TaskRoute.GET.push([["/:_id/unlock"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.updateOne(*): task: { _id: "@P.route._id", projectId: "@P.project._id" }: {"isLock" : false}`,

	`A.pipeRoute(*): task: { type: "unlock", task: "@P.body" }`,

	`A.responseObject: 200: Unlock successfully!`
]]);

TaskRoute.POST.push([["/subTask/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.verifyKObject:: taskId!: verify.idType`,

    `A.trimObject`,
    [`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		var A = pipeData.A;

		var nameReg = Req.func.getASCIISearch(body.name || "", "gmi");
        body.name = nameReg;

		var taskId = body.taskId;
		body.taskIds = [taskId];

		// (Param, pipeData, colName, idKey, parentKey, onlyId, levelUp=10, ...keepKeys)
		// colName, idKey, parentKey, onlyId, getThisItem=true, levelUp=10, ...keepKeys
		//var rs1 = await A.findAllParentById(Req, pipeData, "task", taskId, "parentId", true, true, 2);
		//var rs2 = await A.findAllChildrenById(Req, pipeData, "task", taskId, "parentId", true, true, 2); // Because it not permit in below condition

		//body.taskIds.push( ...(rs1||[]) /*, ...(rs2||[])*/ );

		//console.log("ARR: ", body.taskIds, rs1);
        return Req.UNRESULT;
    }],

    [`<F1>A.aggregate: task:`, [
		{ $limit: 1 },
		{ $getAllParent: ["task", "@taskId", "parentId", 'saveAsPTask', false, true, true, 10] },
		{ $getAllChildren: ["task", "@taskId", "parentId", 'saveAsCTask', false, true, true, 10] },

		{ $match: {
            _id: { $nin: "@taskIds" },
            parentId: { $ne: "@taskId" },
            isSubTask: { $nin: [true] },
            $or: [
                { parentId: { $exists: false }},
                { parentId: { $in: ["", null, undefined] }}
            ],
            projectId: "@projectId"
        }},

		{ $addFields: {
            numString: { $toString: "$number" }
        }},
		{ $addFields: {
            searchName: { $concat: ['#','$numString', '$name',  ]},
			searchName2: { $concat: ['#','$numString', '$name2',  ]}
        }},
		{ $match: { $or: [
            { "searchName": "@name" },
			{ "searchName2": "@name" }
        ]}},

		{ $limit: 10 },
		{ $project: {
            _id: 1,
            name: 1,
			name2: 1,
            status: 1,
            type: 1,
            number: 1
        }}
	]],
	//`A.printObject:`,

], { F1: { IgnoreSanitized: true }} ]);

TaskRoute.POST.push([["/relatedTask/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,
	`A.verifyKObject:: taskId!: verify.idType`,

    `A.trimObject`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var nameReg = Req.func.getASCIISearch(pipeData.name || "", "gmi");
		pipeData.name = nameReg;
        return pipeData;
    }],

    [`<F1>A.aggregate: task:`, [
		{ $match: {
            _id : { $ne : "@taskId" },
            parentId : { $ne : "@taskId" },
            projectId : "@projectId"
        }},
		{ $addFields: {
            numString: { $toString: "$number" }
        }},
		{ $addFields: {
            searchName: { $concat: ['#','$numString', '$name'] },
			searchName2: { $concat: ['#','$numString', '$name2'] }
        }},

		{ $match: { $or: [
            { "searchName": "@name" },
			{ "searchName2": "@name" },
        ]}},

		{ $limit: 10 },
		{ $project: {
            _id: 1,
            name: 1,
			name2: 1,
            status: 1,
            type: 1,
            number: 1
        }}
	]]
], { F1: { IgnoreSanitized: true }} ]);

TaskRoute.PUT.push([["/:_id/action"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,

    `A.findOne(*) > taskDb: task: { _id: "@P.route._id", projectId: "@P.project._id" }`,
    `A.pipeRoute: Checktask`,

    `A.populate: group, taskDb.groupId, _id, taskDb.group, +, shortName`,
    `A.findOne > groupdb: group: { value: "@value", type: "task", hasGlobal: true}`,

    [`A.aggregateOne > taskMax: task:`, [
		{ $match: {
            groupId: "@groupdb._id"
        }},
		{ $sort: {
            colIndex: -1
        }},
    	//{ $limit:1 }
	]],

    [`A.jsScript::`, (Req, pipeData, ctx) => {
		var body = Req.body;

        // x : status, y: index group // 1: Open, 2.Assigned, 3 Doing, 4: Test, 5: Review, 6: Done
		var GET_TYPE = (x, y) => {
			if (x === 3 && y === 3) {
                return 'Start Doing'
            }
            if (x === 4 && y === 4) {
                return 'Finish Doing'
            }
            if (x === 5 && y === 4) {
                return 'Start Testing'
            }
            if (x === 5 && y === 5) {
                return 'Finish Testing'
            }
            if (x === 6 && y === 5) {
                return 'Start Reviewing'
            }
            if (x === 6 && y === 6) {
                return 'Finish Reviewing'
            }
		}

        const taskDb = body.taskDb;
        const status = body.status;
        const groupdb = body.groupdb;
        const taskMax = body.taskMax;
		const isReopen = body.reOpen || body.reopen;

        if(!taskDb || !taskDb.group) {
            return {"respData": "task or group not exist", "respReturn": true, "respCode" : "500"};
        }

        var index;
        if (taskDb.group.shortName == 'assigned' || taskDb.group.shortName == 'indoing') {
            index = taskDb.assigneeIds.findIndex((item) => {
                return item.toString() === Req.user._id.toString();
            });
        }

        if (taskDb.group.shortName == 'intesting') {
            index = taskDb.testerIds.findIndex((item) => {
                return item.toString() === Req.user._id.toString();
            });
        }

        if (taskDb.group.shortName == 'inreviewing') {
            index = taskDb.reviewerIds.findIndex((item) => {
                return item.toString() === Req.user._id.toString();
            });
        }

        if (index < 0) {
            return {"respData": "E-02", "respReturn": true, "respCode" : "500"};
        }

        var reqBody = {};
        if(taskDb.group._id.toString() != groupdb._id.toString()) {
        	reqBody.colIndex = ((taskMax||{}).colIndex||0) + 1000;
        }

        reqBody.status = status || groupdb.value;
		reqBody.groupId = groupdb._id;

		var taskLogs = taskDb.taskLogs || [];
		reqBody.taskLogs = taskLogs;

		var actionType = "movePosition";
		if(isReopen) {
			actionType = "reopen";
			reqBody.reopen = (taskDb.reopen||0) + 1;
			taskLogs.push({
	            type: "Reopen",
	            at: new Date(),
	            userId: Req.user._id
	        });

		} else {
			var type = GET_TYPE(reqBody.status, groupdb.value);
			if(type) {
				taskLogs.push({
		            type: type,
		            at: new Date(),
		            userId: Req.user._id
		        });
			}
		}

		body.actionType = actionType;
		body.reqBody = reqBody;

        return Req.UNRESULT;
    }],

	// Update Task Point
	//`A.pipeRoute: calculateTaskPoint`, // action/reopen dont have Reopn button -> dont use this code here

    `A.updateOne(*) > taskDb: task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.reqBody`,

    //`A.insertSubItem > xyz: task: { "_id": "@taskDb._id" }: taskLogs: @taskLogs`,

	`A.pipeRoute(*): task: { type: "@P.body.actionType", task: "@P.body.taskDb" }`,
	`A.responseObject: 200: Update successfully!`
]]);

TaskRoute.PUT.push([[":_id/movetask"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    //`A.verifyInput > reqBody:: task: colIndex, groupId!, status!, projectId!, fromDate, toDate, name`,
	[`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body;

		const filter = Req.body || {};
		const projectId = Req.project._id; //filter.projectId;
		const groupId = filter.groupId;

		const fromDate = body.fromDate || body.startDate;
		const toDate = body.toDate || body.endDate;

		const name = filter.name || filter.text || filter.search;
		let searchGroup = filter.searchGroup;
		if(typeof searchGroup == "object") {
			searchGroup = searchGroup[groupId||Object.keys(searchGroup)[0]];
		}

        var ops = [];
		if(projectId) {
        	ops.push({ projectId: projectId });
		}

		if(groupId) {
			ops.push({ groupId: groupId });
		}

		if(fromDate) {
			ops.push({ startDate: { "$gte" : new Date(fromDate) } });
		}

		if(toDate) {
			ops.push({ dueDate:  { "$lte" : new Date(toDate) } });
		}

        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg },
			]});
        }

		if (searchGroup) {
			var nameReg = Req.func.getASCIISearch((searchGroup||"").toString(), "gmi");
            ops.push({ $or: [
				{ name: nameReg },
				{ name2: nameReg },
			]});
        }

        Req.body.ops = { $and: ops };
        return Req.UNRESULT;
    }],

    [`A.aggregate > tasksInGroups: task`, [
		{ $match: "@ops" },
		{ $sort: {
        	colIndex: 1,
        	createdAt : -1
    	}},
		{ $project: {
			_id: 1,
			colIndex: 1,
			createdAt: 1,
			assigneeIds: 1,
			testerIds: 1,
			reviewerIds: 1,
			//taskLogs: 1,
		}}
	]],

    `A.findOne > groupDb: group: {_id: "@groupId"}`,

    [`A.jsScript`, (Req, pipeData, ctx) => {

		/*
        // x : status, y: index group
		var GET_TYPE = (x, y) => {
            if (y === 1) {
                return 'Backlog'
            }
            if (y === 2) {
                return 'Assigned'
            }
            if (y === 1) {
                return 'Start Doing'
            }

			if (x === 3 && y === 3) {
                return 'Start Doing'
            }
            if (x === 4 && y === 4) {
                return 'Finish Doing'
            }
            if (x === 5 && y === 4) {
                return 'Start Testing'
            }
            if (x === 5 && y === 5) {
                return 'Finish Testing'
            }
            if (x === 6 && y === 5) {
                return 'Start Reviewing'
            }
            if (x === 6 && y === 6) {
                return 'Finish Reviewing'
            }
		}
		*/

		var GET_TYPE = (x, y) => {
			return {
				"01": "Backlog",
				"02": "Assigned",
				"33": "Start Doing",
				"44": "Finish Doing",
				"54": "Start Testing",
				"55": "Finish Testing",
				"65": "Start Reviewing",
				"66": "Finish Reviewing"
			}[`${x||0}${y||0}`] // => (x*10) + y
		}

        var body = Req.body || {};
		var tasksInGroups = body.tasksInGroups;
		var colIndex = body.colIndex;

		var taskDb = Req.task || body.taskDb;
        if(!body.groupDb || !taskDb || !taskDb._id) {
            return { respData: "Group or Task was not found!", respReturn: true, respCode: 503 };
        }

		var length = tasksInGroups.length || 0;
		if(length <= 0) {
			// for case group empty
			colIndex = 100;

		} else {
			if (colIndex <= 0) {
				// Move top of group
	            colIndex = tasksInGroups[0].colIndex - 0.5;

	        } else {
				// Move last of group
				if((colIndex >= length) || (length == 1)) {
					// Sure, this is move end of group.
					colIndex = tasksInGroups[length-1].colIndex + 0.5;

				} else {
					// this case, task need inserting between n-1 and n
					// (taskIn[n] - taskIn[n-1]) / 2 + random
					var taskUp = tasksInGroups[colIndex-1].colIndex;
					var taskDown = tasksInGroups[colIndex].colIndex;

					// add random to avoid/limited two tasks own same colIndex
					var delta = (taskDown - taskUp)/2;
					var random = Math.random() - 0.5;
					colIndex = taskUp + delta + (random*delta/2);
					//console.log("Down: ", taskDown, taskUp, delta, colIndex);
				}
			}
		}

		var isReopen = body.isReopen || body.reOpen || body.reopen;
		var reqBody = {
			colIndex,
			status: body.status || body.groupDb.value || 1,
			groupId: body.groupId,
		};

		var taskLogs = taskDb.taskLogs || [];
		reqBody.taskLogs = taskLogs;

		var actionType = "movePosition";
		if(isReopen) {
			actionType = "reopen";
			reqBody.reopen = (taskDb.reopen||0) + 1;
			taskLogs.push({
	            type: "Reopen",
	            at: new Date(),
	            userId: Req.user._id
	        });

		} else {
			var type = GET_TYPE(body.status, body.groupDb.value);
	        if(type) {
	            taskLogs.push({
	                type,
	                at: new Date(),
	                userId: Req.user._id
	            });
	        }
		}

		body.actionType = actionType;
		body.reqBody = reqBody;

        return Req.UNRESULT;
   }],
   // type, subType, refId, refNum, content, oldContent, userId, projectId

    `A.updateOne(*) > taskDb: task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body.reqBody`,

    //`A.insertSubItem(*) > xyz: task: { "_id": "@P.body.taskDb._id" }: taskLogs: @P.taskLogs`,

	// Update Task Point
	`A.pipeRoute: calculateTaskPoint`,

	//`A.logActivity:: task: move: @_id: @number`,
	`A.pipeRoute(*): task: { type: "@P.body.actionType", task: "@P.body.taskDb" }`,
	`A.responseObject(*): 200: @P.body.taskDb`
]]);

TaskRoute.PUT.push([[":_id/move/position"], [
    `A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: task: colIndex, milestoneId, sprintId, projectId!`,

	`A.updateById(*) > taskDb : task: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update task successfully!`
]]);

TaskRoute.PUT.push([["/:_id/reopen"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view, task.modify`,
	`A.verifyKObject(P.route):: _id!: verify.idType`,
	`A.pipeRoute: checkTaskValidToEdit`,

    `A.uniquizedObject(*) > reqData:  { _id: "@P.route._id", projectId: "@P.project._id" }`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
        pipeData.taskLogs = {
            type: "Reopen",
            at: new Date(),
            userId: Req.user._id
        }
        return pipeData;
    }],

    `A.dbRaw > task: task: findOneAndUpdate:
        @reqData:
        { '$inc': { reopen: 1 } }`,

    `A.insertSubItem(*) > xyz: task: { "_id": "@P.body.task._id" }: taskLogs: @taskLogs`,

	`A.pipeRoute(*): task: { type: "reopen",  task: "@P.body.task"}`,
    `A.responseObject: 200: Update reopen successfully!`
]]);

TaskRoute.POST.push([["/members/s"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	//`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.findOne: task: ({
		_id: "@taskId",
		projectId: "@projectId"
    })`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
        const assignees = pipeData.assigneeIds || [];
        const testers = pipeData.testerIds || [];
        const reviewers = pipeData.reviewerIds || [];
        pipeData.members = assignees.concat(testers, reviewers);
        return pipeData;
	}],

    `A.unifyObject > members: @members`,
    `A.populate: user, members, _id, members, +, name, name2, userId, avt, hasDeleted, status`,
	//`A.printObject`,

    [`A.jsScript`, (Req, pipeData, ctx) => {
		var members = pipeData.members || [];
		pipeData.members = members;

        const assigneeIds = pipeData.assigneeIds || [];
		const testerIds = pipeData.testerIds || [];
		const reviewerIds = pipeData.reviewerIds || [];

        for (let i=0; i < members.length; i++) {
			var member = members[i] || {};
			members[i] = member;

			if(member.hasDeleted || member.status != 1) {
				members.splice(i, 1);
				i--;
				continue;
			}

			delete member.hasDeleted;
            member.isAssignees = false;
            member.isTesters = false;
            member.isReviewers = false;

			var memberId = (member._id || member) + "";
            assigneeIds.forEach((item) => {
                if(item && item.toString() === memberId) {
                    member.isAssignees = true;
                }
            });

            testerIds.forEach((item) => {
                if(item && item.toString() === memberId) {
                    member.isTesters = true;
                }
            });

            reviewerIds.forEach((item) => {
                if(item && item.toString() === memberId) {
                    member.isReviewers = true;
                }
            });
        }

        return members;
    }],
]]);

TaskRoute.POST.push([["/select"], [
	`A.checkRole(*): project: @P.project._id: roleproject: task.view`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

    `A.verifyInput > reqData:: task: projectId!, name, type`,
    [`A.jsScript`, (Req, pipeData, ctx) => {
		var body = Req.body.reqData;
        const projectId = pipeData.reqData.projectId;

		var types = (body.type || body.types) || (body.typeId || pipeData.body);
		var name = (body.name || pipeData.body || "") + "";

        var ops = { projectId };

        if (name) {
			var nameReg = Req.func.getASCIISearch(name, "gmi");
            ops["$or"] = [
				{ name: nameReg },
				{ name2: nameReg },
				{ number: (name-0) || 0 }
			];
        }

		if(types) {
			if(!Array.isArray(types)) {
				types = [types];
			}

			ops.type = { $in: types };
		}

        pipeData.ops = ops;
        return pipeData;
    }],

	[`A.aggregate: task`, [
		{ $match: "@ops" },
		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			type: 1,
			sprintId: 1,
			milestoneId: 1,
			featureId: 1,
		}}
	]],
    //`A.findMany: task: @ops`,
    //`A.refactorOutput:: _id, name, name2, type, number`
], { useZip: true }]);

TaskRoute.PIPE.push([["calculateTaskPoint"], [
	// check groupDb is done -> delivery point, else rejected point
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var A = pipeData.A;

		var body = Req.body || {};
		var task = body.taskDb || Req.taskDb;

		var arrs = [];
		if(body.groupDb.shortName == "done") {

			//console.log("Check: ", task);
			if(task) {
				var featureDb = await A.findById(Req, pipeData, "feature", {taskId: task._id});
				if(featureDb) {
					var featurePoint = featureDb.featurePoint || {};
					if(featurePoint.doing) {
						var point = featurePoint.doing / ((task.assigneeIds||[]).length || 1);
						(task.assigneeIds||[]).map(user => {
							arrs.push({
								user,
								point,
								type: "doing",
							});
						});
					}

					if(featurePoint.testing) {
						var point = featurePoint.testing / ((task.testerIds||[]).length || 1);
						(task.testerIds||[]).map(user => {
							arrs.push({
								user,
								point,
								type: "testing",
							});
						});
					}

					if(featurePoint.reviewing) {
						var point = featurePoint.reviewing / ((task.reviewerIds||[]).length || 1);
						(task.reviewerIds||[]).map(user => {
							arrs.push({
								user,
								point,
								type: "reviewing",
							});
						});
					}
				}
			}
		}

		// ignoredNotFound = true;
		await A.updateById(Req, pipeData, "feature", {taskId: task._id}, { earningPoints: arrs }, false, false, true);

		return Req.UNRESULT;
	}]

], { name: "calculateTaskPoint" }]);

module.exports = TaskRoute;
