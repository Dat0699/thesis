const PostFlowRoute = {
	route	: "post/:serverId/flow",
	ctrl	: true,
	model	: true,

	POST	: [],
	GET		: [],
	PUT		: [],
	DELETE	: [],
	PIPE	: [],

	config	: {
		checkKeyFeature	: "project.feature.postapi",
		checkMIFs		: ["project", "postapi"],
		imProject		: true,
	}
};

PostFlowRoute.POST.push([[""], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId`,

	`A.verifyInput:: postflow: projectId!, serverId!, name!, status-, number-, ...`,
	`A.insertOne: postflow`,

	`A.pipeRoute: postflow: { type: "create" }`,
	`A.responseObject(*): 200: @P.body`,
]]);

PostFlowRoute.PUT.push([[":_id/move/position"], [
	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	`A.verifyKObject(P.route):: _id!: verify.idType`,
    `A.verifyInput:: postflow: colIndex, parentId, projectId!`,

	`A.updateById(*) > postflowDb : postflow: { _id: "@P.route._id", projectId: "@P.project._id" }: @P.body: false: false: true`,
	`A.responseObject: 200: Update post flow successfully!`
]]);

PostFlowRoute.PUT.push([["/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.verifyInput:: postflow: projectId-, serverId-, name, name2, testDate, testMode, status`,

	`A.updateOne(*): postflow: { _id: "@P.route._id", projectId: "@P.project._id", serverId: "@P.route.serverId" }: @P.body`,

	`A.pipeRoute: postflow: { type: "update" }`,
	`A.responseObject(*): 200: @P.body`,
]]);

PostFlowRoute.DELETE.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.delete`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.deleteById(*): postflow: { _id: "@P.route._id", projectId: "@P.project._id" }`,
	// colName, idKey, hardDelete=true, deleteMany=false`

	`A.deleteMany(*) > tmp: postresult: { postflowId: "@P.route._id", projectId: "@P.project._id" }: true: true`,

	`A.pipeRoute: postflow: { type: "delete" }`,
	`A.responseObject: 200: Delete successfully!`
]]);


PostFlowRoute.POST.push([["/s"], [
	`A.verifyKObject(P.route):: serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId`,

	[`A.jsScript`, (Req, pipeData, ctx) => {
		var ops = [];

        var projectIds = pipeData.projectId || pipeData.projectIds;
		var startDate = pipeData.fromDate || pipeData.startDate;
		var endDate = pipeData.toDate || pipeData.endDate;
		var title = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);

		var serverId = Req.route.serverId;
		ops.push({ serverId: serverId });

		if(projectIds) {
			if(!Array.isArray(projectIds)) {
				projectIds = [projectIds];
			}

			if(projectIds.length > 0) {
				ops.push({ projectId: { $in: projectIds } });
			}
		}

		var status = pipeData.status || pipeData.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.push({
					status: { $in: status }
				});
			}
		}

		if(startDate && endDate) {
			ops.push({ testDate: { $gte: new Date(startDate) } });
			ops.push({ testDate: { $lte: new Date(endDate) } });
		}

        if(title) {
            ops.push({ $or: [
				{ title : Req.func.getASCIISearch(title, "gmi") },
				{ number: (title-0) || -1 }
			]});
        }

		if(!ops || (ops.length <= 0)) {
			pipeData.ops = {};

		} else {
        	pipeData.ops = { $and: ops };
		}

        //console.log(ops);
        return pipeData;
    }],

	`A.getPaginate > page`,

	[`A.aggregateOne: postflow:`, [
		{ $match: "@ops" },
		{ $sort: { colIndex: 1, number: -1 }},
		{ $getTotalLength: "@page" },

		//{ $populate: ["user", "creatorId", "_id", "creatorId", true]},
		{ $populate: ["postresult", "_id", "postflowId", "postresults", undefined]},

		{ $addFields: {
			testedCount: { $size: {
				$filter: {
					input: "$postresults",
					as: "postresult",
					cond: { "$in": ["$$postresult.status", ["passed", "failed"]] }
				}
			}},
			passedCount: { $size: {
				$filter: {
					input: "$postresults",
					as: "postresult",
					cond: { "$in": ["$$postresult.status", ["passed"]] }
				}
			}},
			//apiCount: { $size: "$postresult" }
			apiCount: { $size: "$postresults" }
		}},

		{ $addFields: {
			failedCount: { $subtract: ["$testedCount", "$passedCount"]}
		}},

		{ $project: {
			name: 1,
			name2: 1,
			number: 1,
			status: 1,
			colIndex: 1,

			testDate: 1,
			testMode: 1,

			apiCount: 1,
			testedCount: 1,
			passedCount: 1,
			failedCount: 1,

			postresults: 1,
			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "postflows"]}
	]],

	//`A.responseObject: 200: @dbData`,
], { useZip: true }]);

PostFlowRoute.GET.push([[":_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	[`A.aggregateOne(*): postflow:`, [
		{ $match: {
			projectId: "@P.project._id",
			$or: [
				{ _id: "@P.route._id" },
				{ number: "@P.route._id" }
			]
		}},
	]]
]]);


PostFlowRoute.POST.push([[":_id/result/full"], [
	`A.verifyKObject(P.route):: _id!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	[`A.jsScript(*)`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		var route = Req.route;
		var project = Req.project;

		var postflowId = route._id;
		if(postflowId && (postflowId-0) > 0) {
			if((postflowId+"").length < 12) {
				var rs = await pipeData.A.findById(Req, pipeData, "postflow", {number: postflowId-0, projectId: project._id, serverId: route.serverId});
				if(rs && rs._id) {
					postflowId = rs._id;
				}
			}
		}

		var ops = [
			{ projectId: project._id },
			{ serverId: route.serverId },
			{ postflowId: postflowId },
		];

		var startDate = body.fromDate || body.startDate;
		var endDate = body.toDate || body.endDate;
		var name = (body.title || body.name) || (body.search || body.text);

		var status = body.status || body.statuses;
		if((status != undefined) && (status != null) && (status != "")) {
			if(!Array.isArray(status)) {
				status = [status];
			}
			if(status.length > 0) {
				ops.push({
					$in: ["$status", status]
				});
			}
		}

		if(startDate && endDate) {
			ops.push({ testDate: { $gte: new Date(startDate) } });
			ops.push({ testDate: { $lte: new Date(endDate) } });
		}

        if(name) {
            ops.push({ $or: [
				{ name : Req.func.getASCIISearch(name, "gmi") },
				{ number: (name-0) || -1 }
			]});
        }

    	body.ops = { $and: ops };
        //console.log(ops);
        return Req.UNRESULT;
    }],

	`A.getPaginate > page`,
	[`A.aggregateOne: postresult:`, [
		{ $match: "@ops" },
		{ $sort: { number: -1, }},
		{ $getTotalLength: "@page" },

		{ $project: {
			_id: 1,
			name: 1,
			name2: 1,
			number: 1,
			status: 1,

			name: 1,
			name2: 1,
			url: 1,
			method: 1,

			testDate: 1,

			//reqHeader: 1,
			//reqBody: 1,
			//reqPreScript: 1,

			//resHeader: 1,
			resBody: 1,
			//resPostScript: 1,

			resStatus: 1,
			resTime: 1,
			resSize: 1,

			totalLength: 1,
		}},

		{ $groupTotalLength: ["@page", "totalLength", "postresults"]}
	]],
]]);

PostFlowRoute.GET.push([[":_id/result/detail/:postresultId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								postresultId!: verify.idNumberType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
	`A.pipeRoute: checkAccessPostServer: {role: ""}`,

	[`A.aggregateOne(*): postresult:`, [
		{ $match: {
			projectId: "@P.project._id",
			serverId: "@P.route.serverId",
			postflowId: "@P.route._id",
			$or: [
				{ _id: "@P.route.postresultId" },
				{ number: "@P.route.postresultId" }
			]
		}},
	]]
]]);

//
// PostFlowRoute.POST.push([[":_id/result/full"], [
// 	`A.verifyKObject(P.route):: _id!: verify.idType:
// 								serverId!: verify.idType`,
//
// 	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view`,
// 	`A.pipeRoute: checkAccessPostServer: {role: ""}`,
//
// 	[`A.jsScript`, (Req, pipeData, ctx) => {
// 		var postapiOps = [{ $in: ["$_id", "$$postapis"] }];
// 		var postresultOps = [{
// 			postflowId	: "$$postflowId",
// 			postapiId	: "$$postapiId",
// 		}];
//
// 		// var startDate = pipeData.fromDate || pipeData.startDate;
// 		// var endDate = pipeData.toDate || pipeData.endDate;
// 		var name = (pipeData.title || pipeData.name) || (pipeData.search || pipeData.text);
//
// 		var status = pipeData.status || pipeData.statuses;
// 		if((status != undefined) && (status != null) && (status != "")) {
// 			if(!Array.isArray(status)) {
// 				status = [status];
// 			}
// 			if(status.length > 0) {
// 				postresultOps.push({
// 					$in: ["$status", status]
// 				});
// 			}
// 		}
//
// 		// if(startDate && endDate) {
// 		// 	ops.push({ testDate: { $gte: new Date(startDate) } });
// 		// 	ops.push({ testDate: { $lte: new Date(endDate) } });
// 		// }
//
//         if(name) {
//             postapiOps.push({ $or: [
// 				{ name : Req.func.getASCIISearch(name, "gmi") },
// 				{ number: (name-0) || -1 }
// 			]});
//         }
//
//     	pipeData.postapiOps = postapiOps;
// 		pipeData.postresultOps = postresultOps;
//
//         //console.log(ops);
//         return Req.UNRESULT;
//     }],
//
//
// 	`A.getPaginate > page`,
// 	//`A.printObject`,
//
// 	[`A.aggregateOne(*): postflow:`, [
// 		{ $match: {
// 			$or: [
// 				{ _id: "@P.route._id" },
// 				{ number: "@P.route._id" },
// 			],
// 			projectId: "@P.project._id"
// 		}},
//
// 		{ $lookup: {
// 			from: "postresult",
// 			let: { postapis: "$postapis", postflowId: "$_id" },
// 			pipeline: [
// 				{ $match: { $expr: { $and: "@P.body.postapiOps" }}},
//
// 				{ $getTotalLength: "@P.body.page" },
//
// 				//{ $skip: "@P.body.page.pageStart" },
// 				//{ $limit: "@P.body.page.pageLength" },
//
// 				// Post Result
// 				{ $lookup: {
// 					from: "postresult",
// 					let: { postflowId: "$$postflowId", postapiId: "$_id" },
// 					pipeline: [
// 						{ $match: "@P.body.postresultOps" },
// 						{ $project: {
// 							_id: 1,
// 							status: 1,
//
// 							url: 1,
// 					        method: 1,
//
// 							reqHeader: 1,
// 					        reqBody: 1,
//
// 							resHeader: 1,
// 					        resBody: 1,
// 							resPostScript: 1,
//
// 					        resStatus: 1,
// 					        resTime: 1,
// 					        resSize: 1,
// 						}}
// 					],
// 					as: "postresult"
// 				}},
// 				{ $unwind: {
// 					path: "$postresult",
// 					preserveNullAndEmptyArrays: true
// 				}},
// 				{ $addFields: {
// 					postresult: { $ifNull: ["$postresult", { status: "new" } ]}
// 				}},
//
// 				// Group Id
// 				{ $lookup: {
// 					from: "postgroup",
// 					localField: "groupId",
// 					foreignField: "_id",
// 					as: "groupId"
// 				}},
// 				{ $unwind: {
// 					path: "$groupId",
// 					preserveNullAndEmptyArrays: true
// 				}},
//
// 				{ $project: {
// 					number: 1,
//
// 			        name: 1,
//					name2: 1,
// 			        url: 1,
// 			        method: 1,
//
// 					postresult: 1,
// 					totalLength: 1,
//
// 					"groupId._id": 1,
// 					"groupId.name": 1,
// 					"groupId.name2": 1,
// 					"groupId.color": 1,
// 				}},
//
// 				{ $groupTotalLength: ["@P.body.page", "totalLength", "postapis"] },
// 			],
// 			as: "postapis"
// 		}},
//
// 		{ $project: {
// 			postapis: 1
// 		}},
//
// 		{ $unwind: {
// 			path: "$postapis",
// 			preserveNullAndEmptyArrays: true
// 		}},
// 		{ $replaceRoot: {
// 			newRoot: "$postapis"
// 		}},
// 	]],
//
// 	//`A.responseObject: 200: @((dbData[0]||{}).postapis)`,
// ]]);

PostFlowRoute.POST.push([["clone/:_id"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.findOne(P.route): postflow: {_id: "@_id", serverId: "@serverId"}`,
	`A.verifyInput:: postflow: _id-, number-, ...`, // Internal function call, but we need remove key

	`A.insertById > P.postflow: postflow`,
	`A.cloneById(*) > P.lookUp: postresult:: {postflowId: "@P.route._id"}: {postflowId: "@P.postflow._id"}: 1000:: _id-, number-`,

	// Need checking sub folder

	/*
	[`A.jsScript(*):`, async (Req, pipeData, ctx) => {
		var body = Req.body;
		body.name = `${body.name} - cloned`;

		var A = pipeData.A;
		var flow = await A.insertOne(Req, pipeData, "postflow", body);

		//console.log("Flow: ", group, Req.route._id);
		var results = await A.findMany(Req, pipeData, "postresult", {serverId: flow.serverId, postflowId: Req.route._id});
		for (var i = 0; i < apis.length; i++) {
			var api = apis[i];
			api.postflowId = flow._id;

			delete api._id;
			delete api.number;
		}

		//console.log("Insert: ", apis);
		var napis = await A.insertMany(Req, pipeData, "postresult", results, 200);
		return Req.UNRESULT;
	}],
	*/

	`A.pipeRoute: postflow: { type: "clone" }`,
	`A.responseObject(*): 200: @P.body`
]]);

PostFlowRoute.POST.push([[":_id/result/new"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId:
						P.route._id, P.body.postflowId`,

	`A.verifyInput > reqData:: postresult: name!, method!, url!, _id-, number-, createdAt-, creatorId-, modifiedAt-, modifierId-, ...`,
	`A.insertById > rsData: postresult: @reqData`,

	`A.responseObject: 200: Create successfully!`
]]);

PostFlowRoute.POST.push([[":_id/result/add"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	// Add list API item into post result, body: postapis: [_id1, _id2, ...]
	`A.verifyKObject:: postapiIds!: verify.arrayIdType`,
	`A.findMany(*) > dbPostApis: postapi: { _id: "@P.body.postapiIds", projectId: "@P.project._id" }`,

	`A.copyKObject(*):: P.project._id, P.body.projectId:
						P.route.serverId, P.body.serverId:
						P.route._id, P.body.postflowId`,

	`A.verifyInput(dbPostApis) > data:: postresult: _id-, number-, createdAt-, creatorId-, modifiedAt-, modifierId-, ...`,
	`A.insertById > rsData: postresult: @dbData`,

	`A.responseObject: 200: Add successfully!`
]]);

PostFlowRoute.PUT.push([[":_id/result/update/:postResultId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType:
								postResultId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "modify"}`,

	`A.verifyInput > reqData:: postresult: _id-, number-, projectId-, serverId-, postflowId-, createdAt-, creatorId-, modifiedAt-, modifierId-, ...`,

	`A.updateById(*) > rsData: postresult: {_id: "@P.route.postResultId", postflowId: "@P.route._id", projectId: "@P.project._id"}: @P.body.reqData`,

	`A.responseObject: 200: Update successfully!`
]]);

PostFlowRoute.DELETE.push([[":_id/result/remove/:postResultId"], [
	`A.verifyKObject(P.route):: _id!: verify.idType:
								serverId!: verify.idType:
								postResultId!: verify.idType`,

	`A.checkRole(*): project: @P.project._id: roleproject: postapi.view, postapi.modify`,
	`A.pipeRoute: checkAccessPostServer: {role: "delete"}`,

	`A.deleteById(*): postresult: { _id: "@P.route.postResultId", projectId: "@P.project._id", serverId: "@P.route.serverId" }`,
	`A.responseObject: 200: Delete successfully!`
]]);

module.exports = PostFlowRoute;
