const Validate = {};

Validate.someKeyEqual = (input, value) => {
    const keyEqual = [];
    if (input instanceof Array) {
        input.forEach((vItem, iItem) => {
            if (vItem === value) {
                keyEqual.push(iItem);
            }
        });
        return keyEqual.length > 0 ? keyEqual : undefined;
    }
    if (input instanceof Object) {
        Object.keys(input).forEach((iKey) => {
            if (input[iKey] === value) {
                keyEqual.push(iKey)
            }
        })
        return keyEqual.length > 0 ? keyEqual : undefined;
    }
}

module.exports = Validate;
