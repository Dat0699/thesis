const FuncUtil = {};

FuncUtil.__private_import = {

};

FuncUtil.__after_import = async function(self, A) {
	//console.log("Server Tiemzone:", FuncUtil.tz);
}

FuncUtil.syncUser = async function(Req, pipeData, A, userCompany, user) {
	// -------------- Begin Syuc Name and Email --------------

	var avt = Math.max((userCompany.avt||0), (user.avt||0));

	var updateUserCompany = {};
	if(!userCompany.name) {
		// Update user -> collection Mainusercompany.name
		updateUserCompany.name = user.name;
		userCompany.name = user.name;
	}
	if(userCompany.avt < avt) {
		userCompany.avt = avt;
		updateUserCompany.avt = avt;
	}

	if(Object.keys(updateUserCompany).length > 0) {
		await A.updateById(Req, pipeData, "Main.usercompany", {_id: userCompany._id}, updateUserCompany);
	}

	var updateUser = {};
	if(userCompany.name && (userCompany.name != user.name)) {
		// Re-update db -> collection user.name
		user.name = userCompany.name;
		updateUser.name = userCompany.name;
	}

	if(userCompany.email && (userCompany.email != user.email)) {
		// Re-update db -> collection user.email
		updateUser.email = userCompany.email;
		user.email = userCompany.email;
	}

	if(user.avt < avt) {
		user.avt = avt;
		updateUser.avt = avt;
	}

	if(Object.keys(updateUser).length > 0) {
		await A.updateById(Req, pipeData, "user", {_id: user._id}, updateUser);
	}
	// -------------- End Syuc Name and Email --------------

	return Req.UNRESULT;
}

FuncUtil.featureConfig = function(obj) {
	var config = (obj||{}).disableList || '';
	config = config.replace(/\s{1,}/gmi, "").split(",");

	for(var i=0; i<config.length; i++) {
		var key = config[i];
		obj[key] = false;
	}

	return obj;
}

FuncUtil.unifyRoleCompany = function(Req, pipeData, permitObj) {
	var K = pipeData.K;

	var xars = (K.API || K.Api).FeatureConfig;
	xars = xars.disableList || xars.disableLists;

	var permit = permitObj || pipeData;
	if(xars && permit) {

		var arrs = ["chat", "working", "drive", "helpdesk", "warehouse", "dailyreport", "announcement", "calendar", "leaving", "meeting", "overtime", "reminder", "setting"];

		for (var i = 0; i < arrs.length; i++) {
			var key = arrs[i];
			if(xars.indexOf(key) < 0) {
				if(permit[key] == undefined) {
					permit[key] = {view: false};
				}
			}
		}
	}

	// //project			: { ...VCUD },
	// chat			: { ...VCUD },
	// working			: { ...VCUD },
	// drive		: { ...VCUD },
	// helpdesk		: { ...VCUD },
	// warehouse		: { ...VCUD },
	//
	// dailyreport		: { ...VCUDA },
	// announcement	: { ...VCUDA },
	//
	// calendar		: { ...V },
	// leaving			: { ...VCUDA },
	// meeting			: { ...VCUD },
	// overtime		: { ...VCUDA },
	// reminder		: { ...VCUD },
	//
	// setting			: { ...VCUD },


	return Req.UNRESULT;
}

FuncUtil.unifyRoleProject = function(Req, pipeData, permitObj) {
	var K = pipeData.K;

	var xars = (K.API || K.Api).FeatureConfig;
	xars = xars.disableList || xars.disableLists;

	var permit = permitObj || pipeData;
	if(xars && permit) {

		var arrs = ["dashboard", "feature", "sprint", "planning", "task", "wiki", "gantt", "milestone", "document", "automation", "sourcecode", "cicd", "vmmachine", "postapi", "testcase", "performance", "changelog", "logtime", "cost", "risk", "issuelog", "setting"];

		for (var i = 0; i < arrs.length; i++) {
			var key = arrs[i];
			if(xars.indexOf(key) < 0) {
				if(permit[key] == undefined) {
					permit[key] = {view: false};
				}
			}
		}
	}

	// dashboard	: {...VCUD},
	// feature		: {...VCUDA},
	// sprint		: {...VCUDA},
	// task        : {...VCUD},
	// wiki        : {...VCUD},
	// gantt       : {...V},
	// milestone   : {...VCUDA},
	// document    : {...VCUD},
	//
	// automation	: {...VCUD},
	//
	// //team        : {...VCUD},
	// //user        : {...VCUD},
	//
	// sourcecode  : {...VCUD},
	// cicd		: {...VCUD},
	// vmmachine	: {...VCUD},
	// postapi     : {...VCUD},
	// testcase    : {...VCUD},
	//
	// performance	: {...VCUDA},
	// changelog   : {...VCUDA},
	// logtime     : {...VCUDA},
	//
	// cost      	: {...VCUDA},
	// risk        : {...VCUD},
	// issuelog    : {...VCUD},
	// //label		: {...VCUD},
	// setting		: {...VCUD},
	//
	// //snippet     : {...subPermit},


	return Req.UNRESULT;
}

FuncUtil.syncTask = function(Req, pipeData, data, obj) {
	if(!data.featureId) {
		data.featureId = obj._id;
	}

	if(!data.milestoneId) {
		data.milestoneId = obj.milestoneId;
	}

	if(!data.startDate) {
		data.startDate = obj.startDate;
	}

	if(!data.dueDate) {
		data.dueDate = obj.dueDate;
	}
};

module.exports = FuncUtil;
