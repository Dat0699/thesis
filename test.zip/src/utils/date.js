const DateUtil = {};

DateUtil.__private_import = {

};

DateUtil.__after_import = async function(self, A) {
	DateUtil.tz = await A.getServerTimeZone();
	DateUtil.convertToLocalTime = A.convertToLocalTime;
	DateUtil.getCompanyTimeZone = A.getCompanyTimeZone;
	DateUtil.getUserTimeZone = A.getUserTimeZone;
	DateUtil.getNumberDayIndex = A.getNumberDayIndex;
	DateUtil.lookupObject = A.lookupObject;
	//console.log("Server Tiemzone:", DateUtil.tz);
}

DateUtil.isLeapYear = function(year) {
    return !(year % 4) && (
        !(year % 400) || (year % 100)
    );
}

DateUtil.totalDayInMonth = (year, month) => {
    const totalDay = ([31, DateUtil.isLeapYear(year)?29:28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ])[month];
    return totalDay;
}

DateUtil.weekDays = [ "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday" ];

DateUtil.companyTimePoint = function(Req, pipeData) {
	var cc = (Req.company||{}).config || {};
	var ms = (cc.moringStartTime || 0) - 0;
	var me = (cc.moringEndTime || 0) - 0;

	var as = (cc.afternoonStartTime || 0) - 0;
	var ae = (cc.afternoonEndTime || 0) - 0;

	var ns = (cc.nightStartTime || 0) - 0;
	var ne = ((cc.nightEndTime || 0) - 0);

	var gap1 = as - me;
	var gap2 = ns - ae;
	var wd = ne - ms - gap1 - gap2;
	return {cc, ms, me, as, ae, ns, ne, gap1, gap2, wd};
}

const getDuration = function(Req, pipeData, startHour, endHour, companyTimePoint) {
	var {cc, ms, me, as, ae, ns, ne} = companyTimePoint || DateUtil.companyTimePoint(Req, pipeData);
	//console.log("ms, me, as, ae, ns, ne", ms, me, as, ae, ns, ne);

	// get inter secn of three secgment
	var seg1 = 0;
	if(startHour < me) {
		seg1 = Math.min(me, endHour) - Math.max(startHour, ms);
		seg1 = Math.max(seg1, 0);
	}

	var seg2 = 0;
	if((startHour < ae) && (endHour > as)) {
		seg2 = Math.min(ae, endHour) - Math.max(startHour, as);
		seg2 = Math.max(seg2, 0);
	}

	var seg3 = 0;
	if((startHour < ne) && (endHour > ns)) {
		seg3 = Math.min(ne, endHour) - Math.max(startHour, ns);
		seg3 = Math.max(seg3, 0);
	}

	//console.log("seg: ", seg1, seg2, seg3);
	return seg1 + seg2 + seg3;
}

DateUtil.calculateDuration = async function(Req, pipeData, ctx, keyStartDate="startDate", keyEndDate="endDate", hasTimeValue=false) {
	var obj = ctx || pipeData;
	var startHour = (typeof keyStartDate == "date") ? keyStartDate : obj[keyStartDate];
	if(startHour == undefined) startHour = obj.startDate;
	var endHour = (typeof keyEndDate == "date") ? keyEndDate : obj[keyEndDate];
	if(endHour == undefined) endHour = obj.endDate;

	if((!startHour && startHour != 0) || (!endHour && endHour != 0)) {
		return 0;
	}

	if(!hasTimeValue) {
		// Convert to local date time here
		//startHour = await DateUtil.convertToLocalTime(Req, pipeData, startHour);
		//endHour = await DateUtil.convertToLocalTime(Req, pipeData, endHour);

		startHour = new Date(startHour);
		endHour = new Date(endHour);

		var companyTzOffset = DateUtil.getCompanyTimeZone(Req) * 3600000;
		startHour.setUTCMilliseconds(companyTzOffset);
		endHour.setUTCMilliseconds(companyTzOffset);

		startHour = startHour.getUTCHours() + (startHour.getUTCMinutes()/60.0);
		endHour = endHour.getUTCHours() + (endHour.getUTCMinutes()/60.0);

	} else {
		startHour = startHour / 3600;
		endHour = endHour / 3600;
	}


	//console.log("startHour: ", startHour, endHour);
	return getDuration(Req, pipeData, startHour, endHour);

	/*
	var {cc, ms, me, as, ae, ns, ne} = DateUtil.companyTimePoint(Req, pipeData);
	//console.log("ms, me, as, ae, ns, ne", ms, me, as, ae, ns, ne);

	// get inter section of three secgment
	var seg1 = 0;
	if(startHour < me) {
		seg1 = Math.min(me, endHour) - Math.max(startHour, ms);
		seg1 = Math.max(seg1, 0);
	}

	var seg2 = 0;
	if((startHour < ae) && (endHour > as)) {
		seg2 = Math.min(ae, endHour) - Math.max(startHour, as);
		seg2 = Math.max(seg2, 0);
	}

	var seg3 = 0;
	if((startHour < ne) && (endHour > ns)) {
		seg3 = Math.min(ne, endHour) - Math.max(startHour, ns);
		seg3 = Math.max(seg3, 0);
	}

	//console.log("seg: ", seg1, seg2, seg3);
	return seg1 + seg2 + seg3;
	*/


	/*
	var totalHour = endHour - startHour;
	//console.log("CTX", startHour, endHour, totalHour);

	// Gap 1
	if((as > me) && (ae > as)) {
		if((startHour < me) && (endHour > as)) {
			totalHour -= (as - me);
		}
	}

	// Gap 2
	if((ns > ae) && (ne > ns)) {
		if((startHour < ae) && (endHour > ns)) {
			totalHour -= (ns - ae);
		}
	}

	// Inside Gap 1
	if((as > me) && (ae > as)) {
		if((startHour > me) && (startHour < as) && (endHour > as)) {
			totalHour -= (as - startHour);
		}
	}

	// Inside Gap 2
	if((ns > ae) && (ne > ns)) {
		if((startHour > ae) && (startHour < ns) && (endHour > ns)) {
			totalHour -= (ns - startHour);
		}
	}

	//console.log("------------------", startHour, endHour, totalHour);
	return totalHour;
	*/
}

DateUtil.calculateRegisterDuration = async function(Req, pipeData, ctx) {
	var data = ctx || pipeData;
	if(!Array.isArray(data)) {
		data = [data];
	}

	await data.map(async (item) => {
		item.registerHour = await DateUtil.calculateDuration(Req, data, item, "registerIn", "registerOut", true);
	});

	return Req.UNRESULT;
}

DateUtil.calculateCheckinDuration = async function(Req, pipeData, ctx) {
	var body = ctx || pipeData;

	if(body.checkout > 0) {
		body.checkinHour = await DateUtil.calculateDuration(Req, pipeData, body, "checkin", "checkout", true);
	}

	var startMorning = -1;
	var backAfternoon = -1;

	// For Normal Staff, type === 1
	if(Req.user.type == 1) {
		var {cc, ms, me, as, ae, ns, ne} = DateUtil.companyTimePoint(Req, pipeData);
		startMorning = ms;
		backAfternoon = ae;

	} else {
		// get Register today
		startMorning = body.registerIn;
		backAfternoon = body.registerOut;
	}

	if((body.checkin > 0) && (startMorning >= 0)) {
		body.comeLateHour = Math.max(body.checkin/3600 - startMorning, 0);
	}

	if((body.checkout > 0) && (backAfternoon >= 0)) {
		body.backEarlyHour = Math.max(backAfternoon - body.checkout/3600, 0);
	}

	return Req.UNRESULT;
}

DateUtil.calculateLeavingDuration = async function(Req, pipeData, ctx, listPolicyDays) {
	var body = ctx || pipeData;
	body.duration = body.estDuration;
	if(!body.duration) {
		body.duration = await DateUtil.calendarWorkingDay(Req, body, false, false, listPolicyDays, true);
	}
	return Req.UNRESULT;
}

DateUtil.calculateMeetingDuration = async function(Req, pipeData, ctx, listPolicyDays) {
	var body = ctx || pipeData;
	body.duration = body.estDuration;
	if(!body.duration) {
		body.duration = await DateUtil.calendarWorkingDay(Req, body, false, false, listPolicyDays, true);
	}

	//body.duration = body.estDuration || ((body.endDate - body.startDate) / 3600000);

	return Req.UNRESULT;
}

DateUtil.calculateOvertimeDuration = async function(Req, pipeData, ctx) {
	var data = ctx || pipeData;
	var totalHour = (data.endDate - data.startDate) / 3600000; //await DateUtil.calculateDuration(Req, pipeData, data);

	// Old data, will be removed soon.
	data.effortRatio = data.effortRatio || 1;
	data.totalHour = data.estDuration || (data.userHour || totalHour) || 0;
	data.totalEffortHour = data.totalHour * (data.effortRatio||0);

	// New Data
	data.duration = data.estDuration || totalHour || 0;
	data.mkDuration = data.mkDuration || 0;

	var memberSalarys = data.memberSalarys || [];
	data.memberSalarys = memberSalarys;

	var userIds = data.userIds || [];
	if(userIds.length > 0) {
		var userObj = {};
		if((data.mkSalaryRatio||0) > 0) {
			var listUsers = userIds.map(_id => { return {user: _id}; });
			await DateUtil.lookupObject(Req, listUsers, ["hrcontract", "user", "userId", "salary", 0, "hourlySalary", "monthlySalary"]);

			(listUsers||[]).map(user => {
				userObj[user.user] = user.salary || {};
			});
		}

		// Curently get the overtime for every member
		for (var i = 0; i < memberSalarys.length; i++) {
			var member = memberSalarys[i];
			member.duration = totalHour || 0;
			member.mkDuration = data.mkDuration || member.mkDuration || 0;
			member.amount = member.duration * (userObj[member.user]||0) * (data.mkSalaryRatio||0);
		}

	} else {
		data.userIds = [];
		data.memberSalaries = [];
	}

	return Req.UNRESULT;
}

DateUtil.getUpdateTodayMonthList = function(Req, pipeData, date, scale=1.0, adjust=0) {
	scale = scale || 1.0;
	adjust = adjust || 0.0;

	var minDate = date.minDate;
	var maxDate = date.maxDate;

	var td = DateUtil.getNumberDayIndex(Req, pipeData, minDate, new Date(), false, true) + adjust;
	if(scale > 1.0) {
		td = Math.floor(td / scale);
	}
	date.todayIndex = td;

	var monthLists = [];
	date.monthLists = monthLists;

	var ndate = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
	//console.log("minDate: ", minDate.toString(), minDate.getHours(), minDate.getDate());

	//console.log("N: ", ndate, minDate, maxDate, (ndate > minDate), (ndate < maxDate));
	while (ndate < maxDate) {
		if(ndate > minDate) {
			var tds = DateUtil.getNumberDayIndex(Req, pipeData, minDate, ndate, false, true) + adjust;
			if(scale > 1.0) {
				tds = Math.floor(tds / scale);
			}
			monthLists.push(tds);
		}

		ndate.setMonth(ndate.getMonth()+1);
	}
}

const dateComponent = function(date) {
	return {
		year: date.getFullYear(),
		month: ("0" + (date.getUTCMonth()+1)).substr(-2),
		day: ("0" + date.getUTCDate()).substr(-2),
		hour: ("0" + date.getUTCHours()).substr(-2),
		minute: ("0" + date.getUTCMinutes()).substr(-2),
		second: ("0" + date.getUTCSeconds()).substr(-2),
		dayInWeek: date.getUTCDay(),
	};
}

DateUtil.isPolicyDay = function(Req, pipeData, policy, date, weekOnly=false) {
	var whd = DateUtil.weekDays[date.dayInWeek||0];
	//console.log("whd: ", whd, date);
	whd = (((Req.company||{}).config||{}).workingDayWeeks||{})[whd];
	if(weekOnly || !policy) {
		return !whd;
	}

	var rs = (policy||{})[`${date.year}-${date.month}-${date.day}`] || !whd;

	//console.log("Return Rs: ", rs, whd);
	return rs;
}

DateUtil.calendarWorkingDay = async function(Req, pipeData, startDate, endDate, listPolicyDays, isHour, rangeStartDate, rangeEndDate, isLocalTime, objComponent, tz) {
	//console.log("A: ", startDate, endDate, " : ", listPolicyDays, " : ", isHour, " : ", rangeStartDate, rangeEndDate);

	startDate = startDate || (pipeData.startDate || pipeData.fromDate);
	endDate = endDate || (pipeData.endDate || pipeData.toDate);

	if(rangeStartDate) {
		startDate = Math.max(new Date(rangeStartDate), new Date(startDate));
	}

	if(rangeEndDate) {
		endDate = Math.min(new Date(rangeEndDate), new Date(endDate));
	}

	startDate = new Date(startDate);
	endDate = new Date(endDate);

	//console.log("Start: ", startDate, endDate);
	objComponent = objComponent || DateUtil.companyTimePoint(Req, pipeData);
	//console.log("objComponent: ", objComponent);

	var policy = {};
	if(listPolicyDays) {
		listPolicyDays.map(async (day) => {
			var localDate = await DateUtil.convertToLocalTime(Req, pipeData, day.date);
			var localComponent = dateComponent(localDate);
			day.localDate = localDate;
			day.localComponent = localComponent;

			policy[`${localComponent.year}-${localComponent.month}-${localComponent.day}`] = true;
		});
	}

	var startLocalDate = new Date(startDate); //await DateUtil.convertToLocalTime(Req, pipeData, startDate);
	var endLocalDate = new Date(endDate); //await DateUtil.convertToLocalTime(Req, pipeData, endDate);

	if(!isLocalTime) {
		//startLocalDate.setUTCMilliseconds(14 * 3600000);
		//endLocalDate.setUTCMilliseconds(14 * 3600000);

		var companyTzOffset = (tz || DateUtil.getCompanyTimeZone(Req)) * 3600000;
		startLocalDate.setUTCMilliseconds(companyTzOffset);
		endLocalDate.setUTCMilliseconds(companyTzOffset);

		//startLocalDate = await DateUtil.convertToLocalTime(Req, pipeData, startDate);
		//endLocalDate = await DateUtil.convertToLocalTime(Req, pipeData, endDate);
	}

	var startComponent = dateComponent(startLocalDate);
	var endComponent = dateComponent(endLocalDate);

	//console.log("startDate: ", startLocalDate.toString(), endLocalDate.toString(), (new Date()).toString());

	if( (startComponent.year == endComponent.year) &&
		(startComponent.month == endComponent.month) &&
		(startComponent.day == endComponent.day) ) {

		// Same day
		return getDuration(Req, pipeData,
			(startComponent.hour-0) + startComponent.minute/60,
			(endComponent.hour-0) + endComponent.minute/60,
			objComponent
		) / (isHour ? 1 : objComponent.wd);

	} else {

		// Start Day Count
		var startCount = 0;
		var edStartDay = new Date(startLocalDate);
		if(!DateUtil.isPolicyDay(Req, pipeData, policy, startComponent)) {
			edStartDay.setUTCHours(23);
			edStartDay.setUTCMinutes(59);
			edStartDay.setUTCSeconds(59);

			var edStartComponent = dateComponent(edStartDay);
			startCount = getDuration(Req, pipeData,
				(startComponent.hour-0) + startComponent.minute/60,
				(edStartComponent.hour-0) + edStartComponent.minute/60,
				objComponent
			);
		}

		// End Day Count
		var endCount = 0;
		var edEndDay = new Date(endLocalDate);
		if(!DateUtil.isPolicyDay(Req, pipeData, policy, endComponent)) {
			edEndDay.setUTCHours(0);
			edEndDay.setUTCMinutes(0);
			edEndDay.setUTCSeconds(0);

			var edEndComponent = dateComponent(edEndDay);
			endCount = getDuration(Req, pipeData,
				(edEndComponent.hour-0) + edEndComponent.minute/60,
				(endComponent.hour-0) + endComponent.minute/60,
				objComponent
			);
		}

		// middle section
		var middleCount = 0;
		edEndDay.setUTCMilliseconds(-1000); // previous day of end
		edStartDay.setUTCMilliseconds(1000); // next Day of start

		while(edStartDay < edEndDay) {
			var date = dateComponent(edStartDay);
			if(!DateUtil.isPolicyDay(Req, pipeData, policy, date)) {
				middleCount += objComponent.wd;
			}

			//console.log("edStartDay: ", edStartDay.toString());
			edStartDay.setUTCMilliseconds(86400000); // increase 1 day
		}

		//console.log("END Section: ", objComponent, startCount, middleCount, endCount, objComponent.wd, isHour, (startCount + middleCount + endCount) / (isHour ? 1 : objComponent.wd));
		var rs = (startCount + middleCount + endCount) / (isHour ? 1 : objComponent.wd);
		//console.log("RS: ", rs, startCount, middleCount, endCount, isHour, edStartDay, edEndDay);
		return rs;
	}


	/*

	if(!startDate) {
		var date = new Date();
		startDate = new Date(date.getFullYear(), date.getUTCMonth(), 1, 0, 0, 1);
	} else {
		startDate = new Date(startDate);
	}

	if(!endDate) {
		var date = new Date();
		var m = date.getUTCMonth();
		var y = date.getUTCFullYear();
		endDate = new Date(y, m, DateUtil.totalDayInMonth(y, m), 23, 59, 59);

	} else {
		endDate = new Date(endDate);
	}

	var dd = DateUtil.companyTimePoint(Req, pipeData);
	dd = (dd.cc||{}).weekWorkDayCount || {};

	var weekWorkDayCount =  (dd.monday || (typeof dd.monday == "undefined") ? 1 : 0) +
							(dd.tuesday || (typeof dd.tuesday == "undefined") ? 1 : 0) +
							(dd.wednesday || (typeof dd.wednesday == "undefined") ? 1 : 0) +
							(dd.thursday || (typeof dd.thursday == "undefined") ? 1 : 0) +
							(dd.friday || (typeof dd.friday == "undefined") ? 1 : 0) +
							(dd.saturday ? 1 : 0) +
							(dd.sunday ? 1 : 0);

	var duration = (endDate - startDate) / 86400000; // by day
	var remaining = Math.ceil(duration % 7); // remaining day.
	var durationWeek = parseInt(duration / 7) * weekWorkDayCount;
	//console.log("durationWeek: ", durationWeek, weekWorkDayCount, duration, startDate, endDate, remaining, dd);

	//console.log(pipeData, startDate, endDate);
	// remaining day in wwek
	var dt = startDate.getTime();
	for(var i=0; i<remaining; i+=1) {
		//console.log("dt+86400000*i ", dt+86400000*i);
		var nextDate = new Date(dt+86400000*i);
		//nextDate.setUTCMilliseconds(dt+86400000*i);

		var dayKey = DateUtil.weekDays[nextDate.getUTCDay()];
		var value = dd[dayKey];
		if(!!value) {
			durationWeek += 1;
		}
	}

	if(listPolicyDays) {
		var countPolicy = 0;
		for(var i=0; i<listPolicyDays.length; i++) {
			var item = listPolicyDays[i];
			var date = item.date;
			if((date > startDate) && (date < endDate)) {
				var type = item.type;

				//if(type == 1) {
					// holiday but this is the off day working of company, so count working day
					var dayKey = DateUtil.weekDays[date.getUTCDay()];
					var value = dd[dayKey];
					if(!value) { // day iff of company so (value is false)
						countPolicy += 1;
					}

				//} else if(type == 2) {
					// Make-up day but in company Day Off, still count working day
					// var dayKey = DateUtil.weekDays[date.getUTCDay()];
					// var value = dd[dayKey];
					// if(!value) { // day iff of company so (value is false)
					// 	countPolicy += 1;
					// }
				//}
			}
		}

		durationWeek += countPolicy;
	}

	return durationWeek;
	*/
}


// DateUtil.calendarWorkingListDays = async function(Req, pipeData, startDate, endDate, listPolicyDays, isHour, rangeStartDate, rangeEndDate) {
// 	//console.log("A: ", startDate, endDate, " : ", listPolicyDays, " : ", isHour, " : ", rangeStartDate, rangeEndDate);
//
// 	startDate = startDate || (pipeData.startDate || pipeData.fromDate);
// 	endDate = endDate || (pipeData.endDate || pipeData.toDate);
//
// 	if(rangeStartDate) {
// 		startDate = Math.max(new Date(rangeStartDate), new Date(startDate));
// 	}
//
// 	if(rangeEndDate) {
// 		endDate = Math.min(new Date(rangeEndDate), new Date(endDate));
// 	}
//
// 	//console.log("Start: ", startDate, endDate);
// 	var objComponent = DateUtil.companyTimePoint(Req, pipeData);
// 	//console.log("objComponent: ", objComponent);
//
// 	var policy = {};
// 	if(listPolicyDays) {
// 		listPolicyDays.map(async (day) => {
// 			var localDate = await DateUtil.convertToLocalTime(Req, pipeData, day.date);
// 			var localComponent = dateComponent(localDate);
// 			day.localDate = localDate;
// 			day.localComponent = localComponent;
//
// 			policy[`${localComponent.year}-${localComponent.month}-${localComponent.day}`] = true;
// 		});
// 	}
// }

module.exports = DateUtil;
