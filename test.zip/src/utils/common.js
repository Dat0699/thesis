const { randomBytes } = require('crypto');

const Common = {};

Common.generateUUID8 = function() {
    return randomBytes(8).toString("hex");
}

Common.randomAlphaB = function() {
    return String.fromCharCode(parseInt((65 + Math.random()*(90-65))));
}

Common.randomSpecialChar = function() {
    let s = "!@#$%^&*";
    return s.substr(Math.floor(s.length*Math.random()), 1);
}

Common.generatePassword = function () {
    return Common.randomAlphaB() + randomBytes(5).toString("hex") + Common.randomSpecialChar();
}

// Common.evalInContext = function(js, ctx) {
// 	try {
// 		// Security scope access
// 		var Common = false
// 		var module = false;
// 		var exports = false;
// 		var global = false;
// 		var process = false;
// 		var fs = false;
// 		var require = function(){return""};
//
// 		with (ctx) {
// 			return eval(js);
// 		};
// 	} catch(e) {}
//
// 	return "";
// }

Common.removeKeys = function (obj, keys) {
    if (!obj) return null;
    let result = {}, objK = Object.keys(obj), key;
    for (let index = 0; index < objK.length; index++) {
        key = objK[index]
        if (keys.indexOf(key) === -1) {
            result[key] = obj[key]
        }
    }
    return result;
}

module.exports = Common;
