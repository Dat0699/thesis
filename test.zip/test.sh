#!/bin/bash

RED='\033[1;31m'
NC='\033[0m' # No Color
GREEN='\033[0;32m'
BLUE='\033[1;34m'

# Black        0;30     Dark Gray     1;30
# Red          0;31     Light Red     1;31
# Green        0;32     Light Green   1;32
# Brown/Orange 0;33     Yellow        1;33
# Blue         0;34     Light Blue    1;34
# Purple       0;35     Light Purple  1;35
# Cyan         0;36     Light Cyan    1;36
# Light Gray   0;37     White         1;37

#Server='https://api-pms.gitgam.com'
Server='http://192.168.1.200:12000'

step1=500
step2=200

function action() {
	echo ""
	echo -e "${BLUE}Count ------------------------------------------------- ${1}*${3} + ${2} ===> ${RED}[$(($1*$3 + $2))]${NC}"
	#curl 'http://192.168.1.200:12000/story/s?projectId=5fb4c48832207d46e7647e99' \
	curl "${Server}/story/s?projectId=5fb4c48832207d46e7647e99" \
	-X 'POST' \
	-H 'content-type: application/json' \
	-H 'user-token: base350b91fa0d3681689f90eba1f45da1170bb967c5187ffb83c9d192f19e4z41yaf15a01N63c9dc90d3ae133b4556478ba1p' \
	--data-raw '{"projectId":"5fb4c48832207d46e7647e99","name":""}' \
	--compressed
	echo ""
}

for ((i=0; i<$step1; i++))
do
	for ((j=1; j<=step2; j++))
	do
		action $i $j $step2
	done
done
