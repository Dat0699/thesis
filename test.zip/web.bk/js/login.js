if (!window.root) {
    throw new Error("Root Not Found")
}

const Root = window.root;
const Login = {
    submit: function (e) {
        return new Promise(cb => {
            e.preventDefault();
            const formData = new FormData(e.target);
            // const objData = Object.fromEntries(formData);
            const oReq = new XMLHttpRequest();

            oReq.open("post", "http://localhost:8080/home/signin");

            oReq.onreadystatechange = function() {
                if (oReq.readyState === XMLHttpRequest.DONE && oReq.status === 200) {
                    const res = JSON.parse(oReq.responseText);
                    const token = (res.data || {}).token;
                    console.log(token);

                    if(token) {
                        localStorage.setItem("token", token);
                        if (!Root.socketState.loading && !Root.socketState.connected) {
                            Root.socketState.loading = true;
							Root.connectSocket();
                        }
                    }
                }

            }

            oReq.send(formData);
        })
    }
};

Login.Node = Root.createNode(
    {
        tagName: "form",
        cls: "login-form",
        parentNode: Root.rootElem,
        innerHTML: `
            Email: <input type="email" name="email"/>
            Password: <input type="password" name="password"/>
            CompanyId: <input type="text" name="companyId"/>`,
        opts: {
            onsubmit: Login.submit
        }
    },
    Root.createNode({
        tagName: "button",
        cls: "button",
        text: "Login",
        opts: {
            type: "submit",
        }
    })
);

startAppSocket();
