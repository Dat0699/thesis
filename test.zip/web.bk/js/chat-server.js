const http = require('http');
const crypto = require('crypto');
const AppConfig = require('../config/app');

var ChatServer = {};

ChatServer.config = {
    imServer: true,
};

const Connection = function (socket, server) {

    const socketId = generateSocketID();
    const handlers = {};
    const connections = server.connections;
    const connection = {
        socketId,
        socket,
        on,
        emit,
        join,
        leave,
        broadcast: {
            emit: (eventName, data) => func.broadcast(eventName, data, connections, socketId),
        }
    };
    const func = server.func;

    if (socket) {
        socket.setTimeout(AppConfig.TimeOut);
    }

    socket.on("data", (rawData) => {
        let buffer = Buffer.alloc(0);
        buffer = Buffer.concat([buffer, rawData], buffer.length + rawData.length);

        let frameBuffer = extractFrame(buffer);

        try {
            const { event, data } = JSON.parse(frameBuffer);
            if (!event || !data) {
                return;
            }

            const handler = handlers[event];
            if (!handler) {
                return;
            }

            if (frameBuffer) {
                handler(data);
                socket.setTimeout(AppConfig.TimeOut);
            };

        } catch {
            return;
        } finally {
            socket.setTimeout(AppConfig.TimeOut);
        }

    });

    socket.on('timeout', () => {
        socket.end();
    });

    socket.on('close', () => {
        func.close(socketId);
    })

    function on(eventName, handler) {
        handlers[eventName] = handler;
    }

    function emit(eventName, data) {
        let _data = { event: eventName, data }

        let messageData = generateMessage(JSON.stringify(_data));
        if (!messageData) {
            return;
        }

        socket.write(messageData);
    }

    function join(roomID) {
        let room = connections[roomID];
        if (!room) {
            room = {};
        }
        room[socketId] = connection;
    }

    function leave(roomID) {
        let room = connections[roomID];
        if (!room) {
            delete room[socketId];
        }
    }

    return connection;
}

const createSocketServer = function (server, opts = {}) {
    const { port } = opts || AppConfig.ServerPort;

    if (!server) {
        server = http.createServer();
        if (!port) {
            throw new Error(`Port is required`);
        }
        server.listen(port)
    }

    const connections = {}, middleware = [], func = { broadcast, to }, handlers = {};
    const socketServer = { server, handlers, middleware, connections, func }

    function on(eventName, cb) {
        socketServer.handlers[eventName] = cb;
    }

    function emit(eventName, data, _connections) {
        for (let [, connection] of Object.entries(_connections)) {
            connection.emit(eventName, data);
        }
    }

    function to(roomID) {
        let room = connections[roomID];
        return {
            emit: (eventName, data) => emit(eventName, data, room),
        }
    }

    function broadcast(eventName, data, _connections, socketId) {
        for (let [, connection] of Object.entries(_connections)) {
            if (connection.socketId !== socketId) {
                connection.emit(eventName, data);
            }
        }
    }

    function use(handlers) {
        let _handlers = handlers instanceof Array ? handlers : [handlers];
        let handler;
        for (let i = 0; i < _handlers.length; i++) {
            handler = _handlers[i];
            if (typeof handler !== 'function') {
                throw new Error('Handler must be a function');
            }
            middleware.push(handler)
        }
    }

    func.close = function (socketID) {
        return delete connections[socketID];
    }

    func.connect = function (connection) {
        let handleConnection = handlers && handlers.connection;
        const socket = connection.socket, socketId = connection.socketId;

        if (!handleConnection || !socket || !socketId) {
            return;
        }
        handleConnection(connection);
        connections[socketId] = connection;
    }

    server.on('upgrade', upgradeRequest(socketServer));

    return {
        use,
        on,
        emit: (eventName, data) => emit(event, data, connections),
        to,
    }
}


const generateAccessKey = function (sockey, UID) {
    return crypto.createHash('sha1')
        .update(sockey + UID)
        .digest('base64');
}

const generateSocketID = function () {
    return crypto.randomBytes(16).toString("hex");
}

const upgradeRequest = function (server) {
    return async function (req, socket, head) {
        let isPass = await Promise.all(server.middleware.map((fn) => fn()));
        if (!isPass) {
            return;
        }
        const headers = req.headers;
        if (!headers) {
            return;
        }

        if (!headers['sec-websocket-key'] || headers['upgrade'].toLowerCase() !== "websocket") {
            return;
        }

        const digest = generateAccessKey(headers['sec-websocket-key'], AppConfig.UID);

        const protocol = req.headers['sec-websocket-protocol'];
        const protocols = !protocol ? [] : protocol.split(',').map(s => s.trim());

        const responseHeaders = [
            'HTTP/1.1 101 Web Socket Protocol Handshake',
            'Upgrade: websocket',
            'Connection: keep-alive, Upgrade',
            'Sec-WebSocket-Accept: ' + digest,
        ]

        if (protocols.includes('json')) {
            responseHeaders.push(`Sec-WebSocket-Protocol: json`);
        }

        socket.write(responseHeaders.concat('\r\n').join('\r\n'));

        const connection = Connection(socket, server);
        server.func.connect(connection)
    }

}

const processFrame = function (fin, opcode, payload) {

    if (opcode === 1) {
        let frameBuffer;
        payload = payload.toString()
        frameBuffer = frameBuffer ? frameBuffer + payload : payload
        return frameBuffer;
    }
    return false;
}

const extractFrame = function (buffer) {
    var fin, opcode, B, HB, mask, len, payload, start, i, hasMask;

    if (buffer.length < 2) {
        return
    }

    B = buffer[0];
    HB = B >> 4;
    if (HB % 8) {
        return false;
    }
    fin = HB === 8
    opcode = B % 16

    if (opcode !== 0 && opcode !== 1 && opcode !== 2 &&
        opcode !== 8 && opcode !== 9 && opcode !== 10) {
        return false
    }
    if (opcode >= 8 && !fin) {
        return false
    }

    B = buffer[1]
    hasMask = B >> 7

    len = B % 128
    start = hasMask ? 6 : 2

    if (buffer.length < start + len) {
        return
    }
    if (len === 126) {
        len = buffer.readUInt16BE(2)
        start += 2
    } else if (len === 127) {
        len = buffer.readUInt32BE(2) * Math.pow(2, 32) + buffer.readUInt32BE(6)
        start += 8
    }

    if (buffer.length < start + len) {
        return
    }

    payload = buffer.slice(start, start + len)
    if (hasMask) {
        mask = buffer.slice(start - 4, start)
        for (i = 0; i < payload.length; i++) {
            payload[i] ^= mask[i % 4]
        }
    }

    buffer = buffer.slice(start + len);
    return processFrame(fin, opcode, payload);
}

const generateMetaData = function (fin, opcode, masked, payload) {

    var len, meta, start, mask, i

    len = payload.length;
    meta = Buffer.alloc(2 + (len < 126 ? 0 : (len < 65536 ? 2 : 8)) + (masked ? 4 : 0))

    meta[0] = (fin ? 128 : 0) + opcode;
    meta[1] = masked ? 128 : 0;
    start = 2;
    if (len < 126) {
        meta[1] += len
    } else if (len < 65536) {
        meta[1] += 126
        meta.writeUInt16BE(len, 2)
        start += 2
    } else {
        meta[1] += 127
        meta.writeUInt32BE(Math.floor(len / Math.pow(2, 32)), 2)
        meta.writeUInt32BE(len % Math.pow(2, 32), 6)
        start += 8
    }

    if (masked) {
        mask = Buffer.alloc(4)
        for (i = 0; i < 4; i++) {
            meta[start + i] = mask[i] = Math.floor(Math.random() * 256)
        }
        for (i = 0; i < payload.length; i++) {
            payload[i] ^= mask[i % 4]
        }
        start += 4
    }

    return meta
}

const generateMessage = function (data) {
    try {
        let payload = Buffer.from(data)
        let meta = generateMetaData(true, 1, false, payload);
        return Buffer.concat([meta, payload], meta.length + payload.length);
    } catch  {
        return false;
    }
}

ChatServer.start = function (server) {
    try {
        return createSocketServer(server);
    } catch (error) {
        console.error(error)
    }
}

module.exports = ChatServer;
