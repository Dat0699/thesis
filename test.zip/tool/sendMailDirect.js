// Please using NodeMailer for stability, mailsender has deprecated package.
// https://scribbble.io/wardpoel/setting-up-nodemailer-with-postfix/
// npm install nodemailer

import Mailer from 'nodemailer'

let transporter = Mailer.createTransport({
	sendmail: true,
	newline: 'unix',
	path: '/usr/sbin/sendmail',
	secure: true,
	dkim: {
		domainName: 'test.com',
		keySelector: 'default', // The key you used in your DKIM TXT DNS Record
		privateKey: key, // Content of you private key
	}
})

transporter.sendMail({
	to: 'email@example.com',
	from: '"Name" <mail@test.com>', // Make sure you don't forget the < > brackets
	subject: 'Testing a mail with Nodemailer',
	text: 'Your message in text', // Optional, but recommended
	html: '<h1>Hi</h1><br /><p>Your message</p>', // Optional
})

// https://nodemailer.com/about/
TransportConfig : {
	service		: "gmail",
	host		: "smtp.gmail.com",
	port		: 465,
	secure		: false,
	pool		: false,
	auth		: {
		type	: "login",
		user	: "higam.vn@gmail.com",
		pass	: "123789?gFt",
	}
},
