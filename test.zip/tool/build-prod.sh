#!/bin/bash

export env=prod

rm -rf pms-api* > /dev/null
gstart pack . pms-api.pack -x 'premium.js' -x 'premium.glic' -x 'premimun-config.js'
