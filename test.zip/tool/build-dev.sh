#!/bin/bash

export env=dev
rm -rf pms-api* > /dev/null
gstart pack . pms-api.pack -x 'premium.js' -x 'premium.glic' -x 'premimun-config.js' -x 'spam.prod.js' -x 'app.prod.js' -x 'api.prod.js'
