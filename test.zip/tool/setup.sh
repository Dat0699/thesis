#!/bin/bash

server=192.168.1.27
port=22

appHome=/home/pms-prod/app

userUID=1001
userGroupUID=1001
userName=pms-prod
userGroup=pms-prod
userPath=/home/pms-prod
userShell=/bin/bash
userData=/data/app/pms-prod

gitUID=6789
gitGroupUID=998
gitName=git
gitGroup=git
gitPath=/home/pms-git
gitShell=/bin/bash
gitData=/data/app/pms-git

vmUID=6788
vmGroupUID=997
vmName=gvm
vmGroup=gvm
vmPath=/home/pms-vm
vmShell=/bin/bash
vmData=/data/app/pms-vm

echo "Install GStart Framework........."
ssh -p $port root@$server -C "apt install -y curl; curl https://gcore.gitgam.com/gstart/install.sh | bash -"


echo "Create Application User........."
ssh -p $port root@$server -C "useradd -u $userUID -s $userShell -m -d $userPath $userName;"
ssh -p $port root@$server -C "usermod -u $userUID $userName; groupmod -g $userGroupUID $userGroup;"
ssh -p $port root@$server -C "mkdir -p $userData; chown $userName:$userGroup $userData;"
ssh -p $port root@$server -C "chown $userName:$userGroup $userPath;"

echo "Create Application Path........."
ssh -p $port root@$server -C "mkdir -p $appHome; chown $userName:$userGroup $appHome;"


echo "Create Git User........."
ssh -p $port root@$server -C "useradd -u $gitUID -s $gitShell -m -d $gitPath $gitName;"
ssh -p $port root@$server -C "usermod -u $gitUID $gitName; groupmod -g $gitGroupUID $gitGroup;"
ssh -p $port root@$server -C "mkdir -p $gitData; chown $gitName:$gitGroup $gitData;"
ssh -p $port root@$server -C "chown $gitName:$gitGroup $gitPath;"

echo "Create VM User........."
ssh -p $port root@$server -C "useradd -u $vmUID -s $vmShell -m -d $vmPath $vmName;"
ssh -p $port root@$server -C "usermod -u $vmUID $vmName; groupmod -g $vmGroupUID $vmGroup;"
ssh -p $port root@$server -C "mkdir -p $vmData; chown $vmName:$vmGroup $vmData;"
ssh -p $port root@$server -C "chown $vmName:$vmGroup $vmPath;"


echo "Setup Completed!"
echo ""
