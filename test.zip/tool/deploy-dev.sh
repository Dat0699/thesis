#!/bin/bash

server=dev-pms.gitgam.com
port=2200

name=pms-api
path=/home/pms-dev/pms/pms-api/

user=pms-dev
group=pms-dev

ssh -p $port root@$server -C "mkdir -p $path"
scp -P $port $name.pack root@$server:$path
ssh -p $port root@$server -C "chown -R $user:$group $path"
ssh -p $port root@$server -C "gstart up rp -p $path -u $user -g $group -n $name -e 'ENV=dev' $name.pack"
ssh -p $port root@$server -C "systemctl restart $name"
