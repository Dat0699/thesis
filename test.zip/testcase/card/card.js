const CardTC = {};

// Naming for this Test Case.
// CardTC.name = "CardTC";

// List imported function/object from GStart to import.
CardTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'CardTC.func' to use.
CardTC.start = async function(A, F) {

}

module.exports = CardTC;