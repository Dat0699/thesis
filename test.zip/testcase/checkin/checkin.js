const CheckinTC = {};

// Naming for this Test Case.
// CheckinTC.name = "CheckinTC";

// List imported function/object from GStart to import.
CheckinTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'CheckinTC.func' to use.
CheckinTC.start = async function(A, F) {

}

module.exports = CheckinTC;