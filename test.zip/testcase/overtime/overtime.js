const OvertimeTC = {};

// Naming for this Test Case.
// OvertimeTC.name = "OvertimeTC";

// List imported function/object from GStart to import.
OvertimeTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'OvertimeTC.func' to use.
OvertimeTC.start = async function(A, F) {

}

module.exports = OvertimeTC;