const CompanydomainTC = {};

// Naming for this Test Case.
// CompanydomainTC.name = "CompanydomainTC";

// List imported function/object from GStart to import.
CompanydomainTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'CompanydomainTC.func' to use.
CompanydomainTC.start = async function(A, F) {

}

module.exports = CompanydomainTC;