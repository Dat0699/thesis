var fsFile = require("fs");

var TrimObject = {};

var dgram = require('dgram');

TrimObject.func = [
	"trimObject",
	"unifyObject",
	"CP",
];

// Default Send Data Length is 9216.


TrimObject.start = function(A, F) {
	console.log("trim starte -----");

	var obj1 = {
		key1: "ok",
		key2: null,
		key3: undefined,
		key4: {
			key1: "ok",
			key2: null,
			key3: undefined,
			key4: [1,2, null, "", undefined, 5, "ok", true, false, {}, []],
		},
		abc: {
			a: {
				b: {}
			}
		},
		empty: [[[[],[]]]],
		key5: {},
		key6: [],
		keyA1: ["", "", null],
		keyA2: [null],
		keyA3: [null, null],
		aa: true,
		bb: false,

		key7: {
			k1: "",
		},
		key8: "",
	};

	var obj2 = [
		1,2, null, "", undefined, 5, "ok", true, false, {}, [],
		{a: {}, b:{}, c:{}, d:[]},
		{a: [], b:[[],[],{}]},
		{s: {}, k: {a: {}, b: {}}, l:[[], [], [[], [], {}]] },
		"",
		[1,2,9,"OK",3,4,12,4,5, "OK", true, 10, false, 10, 15, true, 1, "as", "false", false, false, "true", "true"],
		[{a: 1}, {a: 1}, {a:1, b:2}, [1,2,3,3,4,2,1]]
	];

	var obj3 = "obj3";
	var obj4 = null;
	var obj5 = undefined;
	var obj6 = false;
	var obj7 = true;


	var r1 = F.trimObject(obj1);
	console.log("r1: ", r1, "\n\n");

	var r2 = F.trimObject(obj2);
	console.log("r2: ", r2, "\n\n");

	var r3 = F.trimObject(obj3);
	console.log("r3: ", r3, "\n\n");

	var r4 = F.trimObject(obj4);
	console.log("r4: ", r4, "\n\n");

	var r5 = F.trimObject(obj5);
	console.log("r5: ", r5, "\n\n");

	var r6 = F.trimObject(obj6);
	console.log("r6: ", r6, "\n\n");

	var r7 = F.trimObject(obj7);
	console.log("r7: ", r7, "\n\n");


	var obj8 = [
		1,2, null, "", undefined, 5, "ok", true, false, {}, [],
		{a: {}, b:{}, c:{}, d:[]},
		{a: [], b:[[],[],{}]},
		{s: {}, k: {a: {}, b: {}}, l:[[], [], [[], [], {}]] },
		"",
		[1,2,9,"OK",3,4,12,4,5, "OK", true, 10, false, 10, 15, true, 1, "as", "false", false, false, "true", "true"],
		[{a: 1}, {a: 1}, {a:1, b:2}, [1,2,3,3,4,2,1]]
	];
	var r8 = F.unifyObject(obj8, true);
	console.log("Unify: ", obj8, "\n\n", r8, "\n\n");


	return true;
}

module.exports = TrimObject;
