const TestcasecommentTC = {};

// Naming for this Test Case.
// TestcasecommentTC.name = "TestcasecommentTC";

// List imported function/object from GStart to import.
TestcasecommentTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'TestcasecommentTC.func' to use.
TestcasecommentTC.start = async function(A, F) {

}

module.exports = TestcasecommentTC;