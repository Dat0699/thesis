const MeetingTC = {};

// Naming for this Test Case.
// MeetingTC.name = "MeetingTC";

// List imported function/object from GStart to import.
MeetingTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'MeetingTC.func' to use.
MeetingTC.start = async function(A, F) {

}

module.exports = MeetingTC;