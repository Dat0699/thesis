var fsFile = require("fs");

var TestRangeDownload = {};

var dgram = require('dgram');

TestRangeDownload.func = [
	"downloadRangeData",
];

// Default Send Data Length is 9216.
var PORT = 8083;
var HOST = '127.0.0.1';

var url = "https://audio-akp-quic-spotify-com.akamaized.net/audio/d4f22623409160b046e3f1793bb2593fdfc14fb7?__token__=exp=1585288175~hmac=0769e7af2444a8b564edaa80f4f6815d8b18bed967703eb35477c5e803d34e5d";

var sendData = async function(A, F) {

	//console.log("\n\n\n[PubSub] Start send UDP ------ : ", count);
	var data = await F.downloadRangeData("GET", url, "", {}, function(success, data, res, hasFinished) {
		//console.log("Callback: ", res, data);
		console.log(`[Test Range] Receive data range ${res.headers["content-range"]}.`);
	});

	console.log("Finished Data: ---------\n", data);
	fsFile.writeFileSync(`./file-${(new Date()).getTime()}.mp3`, data);
}


TestRangeDownload.start = async function(A, F) {
	await sendData(A, F);
	return true;
}

module.exports = TestRangeDownload;
