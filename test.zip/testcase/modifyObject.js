var ModifyObject = {};

var dgram = require('dgram');


// Default Send Data Length is 9216.
var PORT = 8080;
var HOST = '127.0.0.1';
var PROTOCOL = "http:";

var route = "test/task"; //"markdown/project/5e58e36f1ac9369e22c0ca3c/user";
var token = "base7388vylazgc49qZ02z8ly0z88nw5vftaz5z4nbf7o59ej1p0gaf31879kch9ndi2qa34r5tev5a76772A80901Z790d66228m5n1yVjQ6S9Upsk17d1OfsgzpQj9eya943";


ModifyObject.func = [
    "Mongo",
    "ID",
	"sendDataSync",
	"Root",
];

// Declare a Route object
var route1 = {
	route	: "test",
    ctrl	: false,
    model	: false,

    POST	: [
		[["/task"], [
		    //"A.findMany:task:(@task1),(@task2):(@task3):@task4:@task5,@task6",
			"A.findMany:task:([\"@task1\", \"@task2\"]), ({\"A\": \"@task5\", \"B\" : \"@task6\"}):([\"4\", \"OK\"]), ({\"OK Larter\": \"@OK.baby\"})",
		    //`A.modifyObject > abc::
			//respData = Key1.sub2.ss1,`,
			//`A.modifyObject(abc):: respData = xyz`,
			//
			// `A.modifyObject(*) > anc::
			// zzzz <- +P.body.B.D.F:
			// zzzz <- /#12.0:
			// aabb <- +P.body.A:
			// aabb <- *P.body.A:
			// aabb <- +P.body.A`,
			//
			`A.modifyObject::
			B.Z = B.C.X,
			B.C = *B.Z,
			B.C = /B.Z,
			K = *A,
			K = *B.C,
			`,

			`A.mixObject(*) > P.A.B.B[1]D.abc::
			(["@P.body.A", 1, {"a": "@P.body.A"}, {"C": "@(P.body.A)" }, "@(P.body.B)"])`,

			`A.modifyObject(P.A.B)::`

			//`A.modifyObject(P.body.name) > respData1::`,
			//`A.modifyObject(*)::`
		]],
	],
    config	: {
        checkMIFs	: [],
    }
};

// Declare a Model object
var model1 = {

};

// Declare a Controller object
var controller1 = {

};

ModifyObject.ExportRoot = {
	Route: {
		TestRoute: route1,
	},
	Model : {
		TestModel: model1,
	},
	Controller : {
		TestController: controller1,
	},
}


var callModify = async function(A, F) {
	//console.log("Root: ", F.Root);
	var rs = await F.sendDataSync(
		"POST",
		`${PROTOCOL}//${HOST}:${PORT}/${route}?qqq=1&kkkk=2`,
		{
			modifiedAt: "2020-03-04T07:13:06.881Z ---- ",
			name : "ABC Tes 123",
			A: [1,2,3, "ABC", "XYZ"],
			B: {
				C : [ {X: 4}, 5, 6, 7, 8, {X: "X1"}, {X: "X2"}, {X: "X3"}],
				D : { E : 1, F: 2}

			},
			E: {X: 1, Y: 2, C: "123 CC"},
			F: {X: 1, Y: 2, C: "123 CC"}
		},
		{
			"user-token" : token,
		}
	);

	console.log("\n============\nServer Return:\n");
	console.log(JSON.stringify(JSON.parse(rs), null, 4));
	console.log("\n\n");

	return rs;
}

ModifyObject.start = async function(A, F) {
	return await callModify(A, F);
}

module.exports = ModifyObject;
