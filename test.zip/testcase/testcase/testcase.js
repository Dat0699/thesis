const TestcaseTC = {};

// Naming for this Test Case.
// TestcaseTC.name = "TestcaseTC";

// List imported function/object from GStart to import.
TestcaseTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'TestcaseTC.func' to use.
TestcaseTC.start = async function(A, F) {

}

module.exports = TestcaseTC;