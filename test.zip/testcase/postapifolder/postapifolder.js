const PostapifolderTC = {};

// Naming for this Test Case.
// PostapifolderTC.name = "PostapifolderTC";

// List imported function/object from GStart to import.
PostapifolderTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'PostapifolderTC.func' to use.
PostapifolderTC.start = async function(A, F) {

}

module.exports = PostapifolderTC;