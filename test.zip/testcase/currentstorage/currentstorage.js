const CurrentstorageTC = {};

// Naming for this Test Case.
// CurrentstorageTC.name = "CurrentstorageTC";

// List imported function/object from GStart to import.
CurrentstorageTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'CurrentstorageTC.func' to use.
CurrentstorageTC.start = async function(A, F) {

}

module.exports = CurrentstorageTC;