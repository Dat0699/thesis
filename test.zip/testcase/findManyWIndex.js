
var findManyWIndex = {};

findManyWIndex.func = [
    "Mongo",
    "ID"
];

const prepareDataForTest = async function (Param, fnc, db) {
    const { ops } = await db.collection("room").insertOne({ name: "Room " + ("z" + (parseInt(Math.random() * (36 ** 2))).toString(36)).substr(1, 2)});
    const roomId = ops[0]._id;
    Param.route.roomId = roomId;

    const createMessage = async _ => {
        for (let index = 0; index < 10; index++) {
            const data = {
                messageData: {
                    messageData: "Hello" + ("z" + (parseInt(Math.random() * (36 ** 2))).toString(36)).substr(1, 2),
                }
            };
            await fnc(Param, data, "room", "roomId", "_id", "roomId", "message", "messages", "messageData");
        }
    }
    await createMessage();
}

findManyWIndex.start = async function (A, F) {
    const db = F.Mongo.client.db("test");
    const Param = {
        user: {
            "_id": A.isIdString("5e54abbbd0f3cc20758f0650"),
            "email": "emthanchet@gmail.com",
            "shortName": "Gia Ly Nguyen",
            "userId": A.isIdString("5e54a2d9c983a01e57b45af6"),
            "userCode": "e586e0c9acd0ef0c",
            "displayName": "Gia Ly Nguyen",
        },
        route: {},
        query: {},
        onResponse: function (success, message) {
            if (!success) {
                console.error(message || "Something error");
                return false;
            }
            console.log("success");
            return true;
        },
        mongo: {
            db,
        }
    }
    await prepareDataForTest(Param, A.insertOneWIndex, db);
    const result = await A.findManyWIndex(Param, {}, "roomId", "roomId", "message", "messages")
    if (!result) return false;
    if (result.length !== 10) return false;
    return true;
};

module.exports = findManyWIndex;
