var TreeCache = {};


TreeCache.func = [
    "JO",
    "setTreeCacheValue",
	"getTreeCacheValue",
	"Root",
];


var callTreeCache = async function(A, F) {
	var obj = {
		a: 1,
		b: 2,
	};

	var key = "1/2/3";

	F.setTreeCacheValue({}, "document", key, obj);

	var rs = await F.getTreeCacheValue({}, "document", key);

	console.log("Result: ", obj, rs);
	return rs === obj;
}

TreeCache.start = async function(A, F) {
	return await callTreeCache(A, F);
}

module.exports = TreeCache;
