const CommentTC = {};

// Naming for this Test Case.
// CommentTC.name = "CommentTC";

// List imported function/object from GStart to import.
CommentTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'CommentTC.func' to use.
CommentTC.start = async function(A, F) {

}

module.exports = CommentTC;