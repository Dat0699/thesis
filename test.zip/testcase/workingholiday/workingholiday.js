const WorkingholidayTC = {};

// Naming for this Test Case.
// WorkingholidayTC.name = "WorkingholidayTC";

// List imported function/object from GStart to import.
WorkingholidayTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'WorkingholidayTC.func' to use.
WorkingholidayTC.start = async function(A, F) {

}

module.exports = WorkingholidayTC;