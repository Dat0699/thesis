var MergeDefinedObject = {};

MergeDefinedObject.func = [
    "Mongo",
    "ID",
	"sendDataSync",
	"Root",
	"mixFreeObject",
	"mixDefinedObject",
	"verifyObjectStructure",
	"verifyArrayStructure",
	"JO",
	"CP"
];



var callMerge = async function(A, F) {
	//console.log("Root: ", F.Root);

	var obj0 = {
		permit: {
			wiki: {
				view    : false,
			    create  : false,
			    edit    : false,
			    delete  : false,
			    approve : false,
				diff2	: false,
				arr		: [ 1,2,3, 123, "123"],
				arr3	: [ 1,2,3],
				arr2 	: "123"
			},
			wiki4: [4,5,6],
			wiki2: {a: 4},
			wiki8: "After",
			wiki6: 456
		},
		array: [
			1,2,3, 123, "123"
		],
		array3: [
			1,2,3
		],
		string: "string before",
		string3: "string before",
		number: 0,
		number3: 0,
	};

	var obj1 = {
		permit: {
			wiki: {
				view    : true,
			    create  : true,
			    edit    : true,
			    delete  : true,
			    approve : true,
				diff1	: true,
				arr		: [ 4,5,6],
				arr2	: [ 4,5,6],
			},

			wiki2: [4,5,6],
			wiki4: {a: 4},
			wiki6: "After",
			wiki8: 456

		},
		array: [
			4,5,6,  "123", 123
		],
		array2: [
			4,5,6, "123", 123
		],
		array4: {
			"o2" : 123
		},
		string: "string After",
		string2: "string After",
		string2: 111,
		number: 1,
		number2: 1,
		number4: "string After",
	};


	var arr0 = [obj0];
	var arr1 = [obj0, obj1];

	var c1 = F.CP(obj0);
	var c2 = F.CP(obj0);
	var c3 = F.CP(obj0);


	var c4 = F.CP(arr0);
	var c5 = F.CP(arr1);

	//console.log(c1, c2);

	F.mixFreeObject(c1, obj1);
	F.mixDefinedObject(c2, obj1);
	c3 = F.verifyObjectStructure({}, c3, obj1);


	var a1 = F.verifyArrayStructure({}, c4, arr1, false);
	var a2 = F.verifyArrayStructure({}, c4, arr1, true);

	console.log("mixFreeObject", F.JO(c1));
	console.log("mixDefinedObject: ", F.JO(c2));
	console.log("verifyObjectStructure: ", F.JO(c3));

	console.log("verifyArrayStructure chkSubArray  NO: ", F.JO(a1));
	console.log("verifyArrayStructure chkSubArray YES: ", F.JO(a2));

	return  c1 && (F.JO(c1) != F.JO(obj1)) &&
			c2 && (F.JO(c2) != F.JO(obj1)) &&
			c3 && (F.JO(c3) != F.JO(obj1)) &&

			a1 && (F.JO(a1) != F.JO(arr1)) &&
			a2 && (F.JO(a2) != F.JO(arr1));

}

MergeDefinedObject.start = async function(A, F) {
	return await callMerge(A, F);
}

module.exports = MergeDefinedObject;
