const HistoryCardTC = {};

// Naming for this Test Case.
// HistoryCardTC.name = "HistoryCardTC";

// List imported function/object from GStart to import.
HistoryCardTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'HistoryCardTC.func' to use.
HistoryCardTC.start = async function(A, F) {

}

module.exports = HistoryCardTC;