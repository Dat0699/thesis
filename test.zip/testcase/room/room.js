const RoomTC = {};

// Naming for this Test Case.
// RoomTC.name = "RoomTC";

// List imported function/object from GStart to import.
RoomTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'RoomTC.func' to use.
RoomTC.start = async function(A, F) {

}

module.exports = RoomTC;