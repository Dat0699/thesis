var Password = {};

Password.start = function(Common) {
	for(var i=0; i< 1000; i++) {
		var pass = `122SASD${Math.random().toString(36)}s342#$#@`;

		var a = Common.createPassword(pass);
		//console.log(a);
		 var c = Common.comparePassword(pass, a);
		 if(!c) {
			 console.log("[Failed] Test Wrong, ", i);
			 return false;
		 }
	}

	console.log("[OK] Test OK!");
	return true;
}

module.exports = Password;
