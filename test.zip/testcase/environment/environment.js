const EnvironmentTC = {};

// Naming for this Test Case.
// EnvironmentTC.name = "EnvironmentTC";

// List imported function/object from GStart to import.
EnvironmentTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'EnvironmentTC.func' to use.
EnvironmentTC.start = async function(A, F) {

}

module.exports = EnvironmentTC;