const parseBodyData = function (defRoute, reqData, headers) {
    //---------------- Way 1 -----------------

    var obj = {};

    var k = "boundary=";
    var boundary = Buffer.from("--" + TR(type.substr(type.indexOf(k) + k.length)));

    var slLine = Buffer.from("\r\n\r\n");
    var slLen = slLine.length;

    var name = Buffer.from(" name=\"");
    var nameLen = name.length;

    var fname = Buffer.from("filename=\"");
    var fLen = fname.length;

    var mine = Buffer.from("Content-Type: ");
    var mLen = mine.length;

    var ss = Buffer.from("\"");


    var index = boundary.length;
    var blen = index;

    var rlen = reqData.length;

    while(index < rlen) {
        var nextIndex = reqData.indexOf(boundary, index);
        if(nextIndex < 0) break;

        var buf = reqData.subarray(index, nextIndex - 2);

        // Get value
        var dIndex = buf.indexOf(slLine) + slLen;
        var value = buf.subarray(dIndex);
        buf = buf.subarray(0, dIndex);

        // Get key
        var kIndex = buf.indexOf(name) + nameLen;
        var kIndex2 = buf.indexOf(ss, kIndex);
        var key = buf.subarray(kIndex, kIndex2);

        // Get File Name
        var fileName = false;
        var fIndex = buf.indexOf(fname) + fLen;
        if(fIndex >= fLen) {
            fileName = buf.subarray(fIndex, buf.indexOf(ss, fIndex));

            var mIndex = buf.indexOf(mine) + mLen;
            var mimeType = buf.subarray(mIndex, buf.indexOf("\r\n", mIndex));
            mimeType = (mimeType.toString().split(";")[0]).trim();

            value = {
                path	: fileName,
                content	: value,
                type	: mimeType,
            };

        } else {
            value = value.toString();
        }

        //console.log(`Key: [${key.toString()}]\nFileName: [${fileName}]\nMime: [${mimeType}]\nValue: [${value.toString()}]\n\n`);

        obj[key.toString()] = value;

        index = nextIndex + blen;
    }

    //console.log("Object:\n", obj);
    //var content = Buffer.from(obj.abcd.content);
    //console.log(content, "Length", content.length);
    //fs.writeFileSync("abc.jpg", content);

    return obj;



    //---------------- Way 2 -----------------
    //var k = "boundary=";
    //var b = "--" + TR(type.substr(type.indexOf(k) + k.length));
    // var bc = (reqData.toString("binary") || "").split(b);
    //
    // var obj = {};
    // for (var i = 1; i < bc.length - 1; i++) {
    // 	var bi = bc[i].split("\r\n");
    //
    // 	var sname = bi[1];
    // 	var s = sname.substr(sname.indexOf("name=\"") + 6);
    //
    // 	var valObj = bi[bi.length-2];
    // 	var isFile = s.indexOf("filename=\"");
    // 	if(isFile >= 0) {
    // 		var fileName = s.substr(isFile + 10);
    // 		fileName = fileName.substr(0, fileName.length-1);
    // 		var contentType = (bi[2].split("Content-Type:")[1]).trim();
    // 		valObj = {
    // 			__filePath		: fileName,
    // 			__content		: Buffer.from(valObj, "binary"),
    // 			__contentType	: contentType,
    // 		}
    // 	}
    // 	sname = s.substr(0, s.indexOf("\""));
    // 	obj[sname] = valObj;
    // }

    //console.log(headers);
    //console.log("Object:\n", obj);
    //var content = Buffer.from(obj.abcd.__content, "binary");
    //console.log(content, "Length", content.length);
    //fs.writeFileSync("abc.jpg", content, "binary");

    //return obj;
}

module.export = parseBodyData;
