const TestflowTC = {};

// Naming for this Test Case.
// TestflowTC.name = "TestflowTC";

// List imported function/object from GStart to import.
TestflowTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'TestflowTC.func' to use.
TestflowTC.start = async function(A, F) {

}

module.exports = TestflowTC;