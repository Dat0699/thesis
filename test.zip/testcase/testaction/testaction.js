const TestactionTC = {};

// Naming for this Test Case.
// TestactionTC.name = "TestactionTC";

// List imported function/object from GStart to import.
TestactionTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'TestactionTC.func' to use.
TestactionTC.start = async function(A, F) {

}

module.exports = TestactionTC;