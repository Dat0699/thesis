var PubSub = {};

var dgram = require('dgram');

PubSub.func = [
	"sendUDPMessage",
	"sleep",
	"RDup"
];

// Default Send Data Length is 9216.
var PORT = 8083;
var HOST = '127.0.0.1';

var dataBack = 0;
var sendData = function(A, F, data) {
	return new Promise(async (cb) => {

		//console.log("\n\n\n[PubSub] Start send UDP ------ : ", count);
		await F.sendUDPMessage(data, HOST, PORT, "udp4", function(rdata) {
			console.log(`\nData backed {[!]} -------- ${++dataBack} --------: `, "rdata.token", "\n\n");
			//data.data = rdata;
			cb(rdata);
		});

		//console.log('[PubSub] UDP message sent to ' + HOST +':'+ PORT);
		//cb(true);
	});
}

var data = {
	event		: "device-joined", // "UDP Event Type name",
	pubsub		: "chat", // "PubSub Type, or Group of Event",
	sender		: { // Sender is a server.
		ip		: "127.0.0.1",
		port 	: PORT,
		udp		: "udp4",
	},
	time		: new Date(), // "Collection Time",
	status		: 1, // "Status code",
	token		: { // Used for Create, refresh token/automatically,
		key		: "",
		expired	: "",
		user	: { // User is the Web/Mobile User
			ip	: "127.0.0.1",
			port: PORT,
			udp	: "udp4",
			id	: "userId_id",
		},
	},
	toUsers		: [], // List token devices to forward message
	data		: {"ABC": "value 1", Key2 : "value 2"}, // "Data",
	//handle	: "handler0123456789", // "Handle id of send to recieve back data, it is a callback pointer function name",
	//reply		: true, // If server return to client
	company 	: "company123",
	user		: "userId_id",
};


var events = ["device-joined", "device-value", "device-refresh", "user-join-room", "device-expired", "device-disconnected", "device-message", "device-blacklist", "device-redlist" ];
var datas = [];
var results = [];
var refs = [0, 0];

var count = 0;
var maxCount = 20;//events.length || 1;

PubSub.start = async function(A, F) {
	var odate = new Date();
	for(var i = count; i < maxCount; i++) {
		data.event = events[parseInt(i%events.length)];
		//var key = datas[i] || results[refs[i]||i] || data.data;
		//data.token = {
		//	key: key,
		//	time : false,
		//}

		if(data.token) {
			data.token.key = results[i-1];
			data.time = new Date();
			//console.log(data.event);
		}

		var rs = await sendData(A, F, data);

		console.log(rs);

		if(rs && rs.token) {
			results[i] = (rs.token || {}).key;
			data.toUsers.push(data.token.user.id);
			data.toUsers = F.RDup(data.toUsers);
		}

		//data.data.time = false;
		//data.data = false;
		//await F.sleep(1000);
	}

	console.log(results);
	var edate = new Date();

	console.log("Test time: ", edate - odate);

	return true;
}

module.exports = PubSub;
