const ReportlabelTC = {};

// Naming for this Test Case.
// ReportlabelTC.name = "ReportlabelTC";

// List imported function/object from GStart to import.
ReportlabelTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'ReportlabelTC.func' to use.
ReportlabelTC.start = async function(A, F) {

}

module.exports = ReportlabelTC;