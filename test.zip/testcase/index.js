
// Load all file in this folder except index.js

var IndexTestCase = {};

require("fs").readdirSync(__dirname).forEach(function(file) {
    if(file.endsWith(".js") && !file.endsWith("index.js")) {
        let name = file[0].toUpperCase() + file.substr(1, file.length-4);
        IndexTestCase[name] = require("./" + file);
    }
});


module.exports = IndexTestCase;
