const LeavingTC = {};

// Naming for this Test Case.
// LeavingTC.name = "LeavingTC";

// List imported function/object from GStart to import.
LeavingTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'LeavingTC.func' to use.
LeavingTC.start = async function(A, F) {

}

module.exports = LeavingTC;