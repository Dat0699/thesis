
var findByIdWIndex = {};

findByIdWIndex.func = [
    "Mongo",
    "ID"
];

const prepareDataForTest = async function (Param, fnc, db) {
    const { ops } = await db.collection("room").insertOne({ name: "Room " + ("z" + (parseInt(Math.random() * (36 ** 2))).toString(36)).substr(1, 2)});
    const roomId = ops[0]._id;
    Param.route.roomId = roomId;
    const data = {
        messageData: {
            messageData: "Hello" + ("z" + (parseInt(Math.random() * (36 ** 2))).toString(36)).substr(1, 2),
        }
    };
    const messageData = await fnc(Param, data, "room", "roomId", "_id", "roomId", "message", "messages", "messageData", true);
    return messageData;
}

findByIdWIndex.start = async function (A, F) {
    const db = F.Mongo.client.db("test");
    const Param = {
        user: {
            "_id": A.isIdString("5e54abbbd0f3cc20758f0650"),
            "email": "emthanchet@gmail.com",
            "shortName": "Gia Ly Nguyen",
            "userId": A.isIdString("5e54a2d9c983a01e57b45af6"),
            "userCode": "e586e0c9acd0ef0c",
            "displayName": "Gia Ly Nguyen",
        },
        route: {},
        query: {},
        onResponse: function (success, message) {
            if (!success) {
                console.error(message || "Something error");
                return false;
            }
            console.log("success");
            return true;
        },
        mongo: {
            db,
        }
    }
    const r1 = await prepareDataForTest(Param, A.insertOneWIndex, db);
    const messageId = Param.route.messageId = r1._id;
    const r2 = await A.findByIdWIndex(Param, {}, "roomId", "roomId", "message", "messages", "messageId");
    if (!r2) return false;
    if (r2._id.toString() != messageId.toString()) return false;
    return true;
};

module.exports = findByIdWIndex;
