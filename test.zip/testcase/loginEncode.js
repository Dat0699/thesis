
var LoginEncode = {};

LoginEncode.func = [
	// Import from Core
	"mergeToken",
	"adjustToken",
	"revertToken",
	"parseToken",
	"port = APIConfig.ServerPort",
	"url = APIConfig.ServerUrl1 || http://abc.com",
	"APIConfig -> C",
	"M1 = APIConfig.ServerUrl1 || 122",
	"M2 = APIConfig.ServerUrl1 || \"122\"",

	"APIConfig.ServerUrl1 || \"122\" -> M3",
	"APIConfig.ServerUrl1 || 122 -> M4",

];

LoginEncode.start = function(A, F) {
	console.log(A);
	console.log("\n");
	console.log(F);

    var uniqueStr = "jk5lqh3v90724kuj0zq4kzpgouEzyZ5df0fedae1b38661fd9a90293w1k1432771019v3dvdd9klgtoy3z0ypkz0Zz0wki";
    var companyId = "5df0fedae1b38661fd9a9029";

    var timeCount = 1000;
    var nm = 0;

    for(var i=0; i<timeCount; i++) {

    	var mergedToken = F.mergeToken(companyId, uniqueStr);
    	var adjustedToken = F.adjustToken(mergedToken);
    	var revertedToken = F.revertToken(adjustedToken);

    	var parsedToken = F.parseToken(revertedToken);

    	var companyIdP = parsedToken[0];
    	var uniqueStrP = parsedToken[1];


    	if(mergedToken != revertedToken || (companyId != companyIdP) || uniqueStr != uniqueStrP) {
    		nm++;
    		//console.log(i + " Not match\n", mergedToken, "\n", revertedToken, "\n");
    	}
    }

    console.log("Not matched " + nm);

	return nm <= 0;
}

module.exports = LoginEncode;
