const PostapiTC = {};

// Naming for this Test Case.
// PostapiTC.name = "PostapiTC";

// List imported function/object from GStart to import.
PostapiTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'PostapiTC.func' to use.
PostapiTC.start = async function(A, F) {

}

module.exports = PostapiTC;