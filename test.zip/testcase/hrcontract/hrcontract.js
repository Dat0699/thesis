const OverviewTC = {};

// Naming for this Test Case.
// OverviewTC.name = "OverviewTC";

// List imported function/object from GStart to import.
OverviewTC.func = [
	"Mongo",
    "ID"
];

// Function start is required function called to start this TestCase.
// A: list Common function 'A' to use.
// F: Imported fucntion 'OverviewTC.func' to use.
OverviewTC.start = async function(A, F) {

}

module.exports = OverviewTC;