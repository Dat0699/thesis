var UDP = {};

var dgram = require('dgram');
var message = Buffer.from(`
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good! My UDP Server is Good!
	My UDP Server is Good! sh123456789909767sdhassafsadsadsdsads
	`);


// Default Send Data Length is 9216.
var PORT = 8083;
var HOST = '127.0.0.1';

var count = 0;
var sendData = function() {
	return new Promise(cb => {

		console.log("Start send UDP ------ ", message.length, ": ", count++);

		var client = dgram.createSocket({
			type: 'udp4',
			sendBufferSize: Math.min(65535, 65507), // 65507 = 65535 - 8UDPHeader - 20IPHeader //SO_RCVBUF,
		});

		// UDP data lenth = 65,507 bytes, within (65,535 − 8 bytes UDP header − 20 bytes IP header)
		//client.setSendBufferSize(655-20-800);
		//console.log("Buffer size: ", client.getSendBufferSize());


		client.send(message, 0, message.length, PORT, HOST, function(err, bytes) {
			if (err) {
				cb(false);
				throw err;
			}

			client.close();
			console.log('[CACHE] Cache message sent to ' + HOST +':'+ PORT);
			cb(true);
		});
	});
}


UDP.start = async function() {
	var count = 0;
	return new Promise(cb => {
		var itv = setInterval(async() => {
			await sendData();
			if(count++ >= 6000) {
				clearInterval(itv);
				cb(true);
			}

		}, 10);
	});

	return true;
}

module.exports = UDP;
