#!/bin/bash

userName="pms-dev"
groupName="pms-dev"
defaultPassword="123456?z"

if [ "$EUID" -ne 0 ]; then
        echo "Please run as root"
        exit
fi

if id "$userName" >/dev/null 2>&1; then
        echo "user exists"
        exit
fi

groupadd -f $groupName
useradd -g $groupName -m $userName
yes $defaultPassword | passwd $userName



