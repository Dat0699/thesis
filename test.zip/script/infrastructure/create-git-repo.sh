#!/bin/bash

branch="master"

while getopts n: flag

do
        case "${flag}" in
                n) project_name=${OPTARG}
                        ;;
                b) branch=${OPTARG}
                        ;;
                *) echo "Invalid option: -$flag" ;;
        esac
done

mkdir -p ${HOME}/sources
mkdir -p ${HOME}/apps

project_source="${HOME}/sources/${project_name}.git"
project_release="${HOME}/apps/${project_name}"

if [ -d "$project_source" ]; then 
    echo "Project Git Source has existed ..."
    exit
fi

if [ -d "$project_release" ]; then 
    echo "Project App has existed ..."
    exit
fi

mkdir $project_source
cd $project_source
git init --bare

export project_source project_release project_name branch

tee -a $project_source/hooks/post-receive > /dev/null <<EOT
NAME="$project_name"
TARGET="$project_release"
GIT_DIR="$project_source"
BRANCH="$branch"

while read oldrev newrev ref
do
        # only checking out the master (or whatever branch you would like to deploy)
        if [ "\$ref" = "refs/heads/\$BRANCH" ];
        then
                echo "Ref \$ref received. Deploying ${BRANCH} branch to production..."

                mkdir -p "\$TARGET"
                cd "\$TARGET"

                git --work-tree="\$TARGET" --git-dir="\$GIT_DIR" checkout -f "\$BRANCH"

                export NVM_DIR="\$HOME/.nvm"
                [ -s "\$NVM_DIR/nvm.sh" ] && \. "\$NVM_DIR/nvm.sh"

                npm i
                pm2 stop --silent "\$NAME"
                pm2 start gstart --name "\$NAME"

        else
            echo "Ref \$ref received. Doing nothing: only the \${BRANCH} branch may be deployed on this server."
        fi
done
EOT

chmod +x $project_source/hooks/post-receive
