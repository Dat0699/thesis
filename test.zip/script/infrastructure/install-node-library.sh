#!/bin/bash

node_isExist=$(which node)

if [ -x "$node_isExist" ]; then
    echo "Nodejs not installed ..."
    exit
fi

npm install -g pm2