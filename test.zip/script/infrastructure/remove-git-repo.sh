#!/bin/bash

while getopts n: flag

do
        case "${flag}" in
                n) project_name=${OPTARG}
                        ;;
                b) branch=${OPTARG}
                        ;;
                *) echo "Invalid option: -$flag" ;;
        esac
done

doneproject_source="~/sources/${project_name}.git"
project_release="~/apps/${project_name}"

rm -rf $doneproject_source 2> /dev/null
rm -rf $project_release 2> /dev/null
