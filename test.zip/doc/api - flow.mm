graph TD
U>Client User] --> RR[Root Route]
RR --> SS((Statistical))
SS --> AA{Authentication?}
AA -- YES --> IP{{IP Access?}}
IP -- YES --> CE{Company Enable?}
CE -- YES --> FE{{Feature Enable?}}
FE -- YES --> MF{{Member In Feature?}}
MF -- YES --> RP{{Role Permission in that Feature?}}
RP --> FI[\Filter Input Client Sent Data/]
FI --> EX((Execution))
EX --> FO[\Filter Output Server Data sent to Client/]
FO --> RE>Return Client]

AA -- NO --> RF>Return Failed]
IP -- NO --> RF
CE -- NO --> RF
FE -- NO --> RF
MF -- NO --> RF
RP -- NO --> RF
